package net.minecraft.server.v1_6_R3;

public class ChunkMap
{
    public byte[] compressedData;
    public int chunkExistFlag;
    public int chunkHasAddSectionFlag;
}
