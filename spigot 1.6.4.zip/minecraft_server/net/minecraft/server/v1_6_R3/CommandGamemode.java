package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandGamemode extends CommandAbstract
{
    public String getCommandName()
    {
        return "gamemode";
    }

    public int a()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.gamemode.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length > 0)
        {
            EnumGamemode var3 = this.f(var1, var2[0]);
            EntityPlayer var4 = var2.length >= 2 ? d(var1, var2[1]) : b(var1);
            var4.setGameType(var3);
            var4.fallDistance = 0.0F;
            ChatMessage var5 = ChatMessage.e("gameMode." + var3.b());

            if (var4 != var1)
            {
                a(var1, 1, "commands.gamemode.success.other", new Object[] {var4.getLocalizedName(), var5});
            }
            else
            {
                a(var1, 1, "commands.gamemode.success.self", new Object[] {var5});
            }
        }
        else
        {
            throw new ExceptionUsage("commands.gamemode.usage", new Object[0]);
        }
    }

    protected EnumGamemode f(ICommandListener var1, String var2)
    {
        return !var2.equalsIgnoreCase(EnumGamemode.SURVIVAL.b()) && !var2.equalsIgnoreCase("s") ? (!var2.equalsIgnoreCase(EnumGamemode.CREATIVE.b()) && !var2.equalsIgnoreCase("c") ? (!var2.equalsIgnoreCase(EnumGamemode.ADVENTURE.b()) && !var2.equalsIgnoreCase("a") ? WorldSettings.a(a(var1, var2, 0, EnumGamemode.values().length - 2)) : EnumGamemode.ADVENTURE) : EnumGamemode.CREATIVE) : EnumGamemode.SURVIVAL;
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, new String[] {"survival", "creative", "adventure"}): (var2.length == 2 ? a(var2, this.d()) : null);
    }

    protected String[] d()
    {
        return MinecraftServer.getServer().getPlayers();
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return var2 == 1;
    }
}
