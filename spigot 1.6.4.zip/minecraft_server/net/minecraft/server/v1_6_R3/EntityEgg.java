package net.minecraft.server.v1_6_R3;

import org.bukkit.Location;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Egg;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerEggThrowEvent;

public class EntityEgg extends EntityProjectile
{
    public EntityEgg(World par1World)
    {
        super(par1World);
    }

    public EntityEgg(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityEgg(World par1World, double par2, double par4, double par6)
    {
        super(par1World, par2, par4, par6);
    }

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition par1MovingObjectPosition)
    {
        if (par1MovingObjectPosition.entity != null)
        {
            par1MovingObjectPosition.entity.attackEntityFrom(DamageSource.projectile(this, this.getShooter()), 0.0F);
        }

        boolean var2 = !this.world.isStatic && this.random.nextInt(8) == 0;
        int var3 = this.random.nextInt(32) == 0 ? 4 : 1;

        if (!var2)
        {
            var3 = 0;
        }

        EntityType var4 = EntityType.CHICKEN;
        EntityLiving var5 = this.getShooter();

        if (var5 instanceof EntityPlayer)
        {
            Player var6 = var5 == null ? null : (Player)var5.getBukkitEntity();
            PlayerEggThrowEvent var7 = new PlayerEggThrowEvent(var6, (Egg)this.getBukkitEntity(), var2, (byte)var3, var4);
            this.world.getServer().getPluginManager().callEvent(var7);
            var2 = var7.isHatching();
            var3 = var7.getNumHatches();
            var4 = var7.getHatchingType();
        }

        int var8;

        if (var2)
        {
            for (var8 = 0; var8 < var3; ++var8)
            {
                org.bukkit.entity.Entity var9 = this.world.getWorld().spawn(new Location(this.world.getWorld(), this.locX, this.locY, this.locZ, this.yaw, 0.0F), var4.getEntityClass(), CreatureSpawnEvent.SpawnReason.EGG);

                if (var9 instanceof Ageable)
                {
                    ((Ageable)var9).setBaby();
                }
            }
        }

        for (var8 = 0; var8 < 8; ++var8)
        {
            this.world.addParticle("snowballpoof", this.locX, this.locY, this.locZ, 0.0D, 0.0D, 0.0D);
        }

        if (!this.world.isStatic)
        {
            this.die();
        }
    }
}
