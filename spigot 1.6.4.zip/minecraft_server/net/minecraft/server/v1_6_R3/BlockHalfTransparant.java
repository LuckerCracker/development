package net.minecraft.server.v1_6_R3;

public class BlockHalfTransparant extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    private boolean displayOnCreativeTab;

    /** The unlocalized name of this block. */
    private String unlocalizedName;

    protected BlockHalfTransparant(int var1, String var2, Material var3, boolean var4)
    {
        super(var1, var3);
        this.displayOnCreativeTab = var4;
        this.unlocalizedName = var2;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }
}
