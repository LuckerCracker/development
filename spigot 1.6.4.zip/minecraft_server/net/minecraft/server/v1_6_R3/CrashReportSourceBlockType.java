package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportSourceBlockType implements Callable
{
    final int a;

    final World b;

    CrashReportSourceBlockType(World var1, int var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        try
        {
            return String.format("ID #%d (%s // %s)", new Object[] {Integer.valueOf(this.a), Block.byId[this.a].getUnlocalizedName(), Block.byId[this.a].getClass().getCanonicalName()});
        }
        catch (Throwable var2)
        {
            return "ID #" + this.a;
        }
    }

    public Object call()
    {
        return this.a();
    }
}
