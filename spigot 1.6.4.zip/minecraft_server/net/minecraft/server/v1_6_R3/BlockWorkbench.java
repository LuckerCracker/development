package net.minecraft.server.v1_6_R3;

public class BlockWorkbench extends Block
{
    protected BlockWorkbench(int par1)
    {
        super(par1, Material.WOOD);
        this.a(CreativeModeTab.c);
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            var5.startCrafting(var2, var3, var4);
            return true;
        }
    }
}
