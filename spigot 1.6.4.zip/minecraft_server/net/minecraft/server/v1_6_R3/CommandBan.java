package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandBan extends CommandAbstract
{
    public String getCommandName()
    {
        return "ban";
    }

    public int a()
    {
        return 3;
    }

    public String c(ICommandListener var1)
    {
        return "commands.ban.usage";
    }

    public boolean a(ICommandListener var1)
    {
        return MinecraftServer.getServer().getPlayerList().getNameBans().isEnabled() && super.a(var1);
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length >= 1 && var2[0].length() > 0)
        {
            EntityPlayer var3 = MinecraftServer.getServer().getPlayerList().getPlayer(var2[0]);
            BanEntry var4 = new BanEntry(var2[0]);
            var4.setSource(var1.getName());

            if (var2.length >= 2)
            {
                var4.setReason(a(var1, var2, 1));
            }

            MinecraftServer.getServer().getPlayerList().getNameBans().add(var4);

            if (var3 != null)
            {
                var3.playerConnection.disconnect("You are banned from this server.");
            }

            a(var1, "commands.ban.success", new Object[] {var2[0]});
        }
        else
        {
            throw new ExceptionUsage("commands.ban.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length >= 1 ? a(var2, MinecraftServer.getServer().getPlayers()) : null;
    }
}
