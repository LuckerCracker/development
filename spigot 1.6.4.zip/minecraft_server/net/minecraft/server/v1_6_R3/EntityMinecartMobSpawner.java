package net.minecraft.server.v1_6_R3;

public class EntityMinecartMobSpawner extends EntityMinecartAbstract
{
    /** Mob spawner logic for this spawner minecart. */
    private final MobSpawnerAbstract mobSpawnerLogic = new MobSpawnerMinecart(this);

    public EntityMinecartMobSpawner(World par1World)
    {
        super(par1World);
    }

    public EntityMinecartMobSpawner(World par1World, double par2, double par4, double par6)
    {
        super(par1World, par2, par4, par6);
    }

    public int getType()
    {
        return 4;
    }

    public Block getDefaultDisplayTile()
    {
        return Block.MOB_SPAWNER;
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);
        this.mobSpawnerLogic.a(par1NBTTagCompound);
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        this.mobSpawnerLogic.b(par1NBTTagCompound);
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();
        this.mobSpawnerLogic.g();
    }
}
