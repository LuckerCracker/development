package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityTargetEvent;

public class EntityExperienceOrb extends Entity {
	public int a;
	public int nextEntityID;

	/**
	 * The distance that has to be exceeded in order to triger a new step sound
	 * and an onEntityWalking event on a block
	 */
	public int nextStepDistance;
	private int fire = 5;
	public int value;
	private EntityHuman targetPlayer;
	private int targetTime;

	public EntityExperienceOrb(World world, double d0, double d1, double d2, int i) {
		super(world);
		this.setSize(0.5F, 0.5F);
		this.height = this.length / 2.0F;
		this.setPosition(d0, d1, d2);
		this.yaw = (float) (Math.random() * 360.0D);
		this.motX = (double) ((float) (Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
		this.motY = (double) ((float) (Math.random() * 0.2D) * 2.0F);
		this.motZ = (double) ((float) (Math.random() * 0.20000000298023224D - 0.10000000149011612D) * 2.0F);
		this.value = i;
	}

	/**
	 * returns if this entity triggers Block.onEntityWalking on the blocks they
	 * walk on. used for spiders and wolves to prevent them from trampling crops
	 */
	protected boolean canTriggerWalking() {
		return false;
	}

	public EntityExperienceOrb(World world) {
		super(world);
		this.setSize(0.25F, 0.25F);
		this.height = this.length / 2.0F;
	}

	protected void entityInit() {
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		super.onUpdate();

		if (this.nextStepDistance > 0) {
			--this.nextStepDistance;
		}

		this.lastX = this.locX;
		this.lastY = this.locY;
		this.lastZ = this.locZ;
		this.motY -= 0.029999999329447746D;

		if (this.world.getMaterial(MathHelper.floor(this.locX), MathHelper.floor(this.locY),
				MathHelper.floor(this.locZ)) == Material.LAVA) {
			this.motY = 0.20000000298023224D;
			this.motX = (double) ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F);
			this.motZ = (double) ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F);
			this.makeSound("random.fizz", 0.4F, 2.0F + this.random.nextFloat() * 0.4F);
		}

		this.pushOutOfBlocks(this.locX, (this.boundingBox.minY + this.boundingBox.maxY) / 2.0D, this.locZ);
		double d0 = 8.0D;

		if (this.targetTime < this.a - 20 + this.id % 100) {
			if (this.targetPlayer == null || this.targetPlayer.getDistanceSqToEntity(this) > d0 * d0) {
				this.targetPlayer = this.world.findNearbyPlayer(this, d0);
			}

			this.targetTime = this.a;
		}

		if (this.targetPlayer != null) {
			EntityTargetEvent f = CraftEventFactory.callEntityTargetEvent(this, this.targetPlayer,
					EntityTargetEvent.TargetReason.CLOSEST_PLAYER);
			Entity i = f.getTarget() == null ? null : ((CraftEntity) f.getTarget()).getHandle();

			if (!f.isCancelled() && i != null) {
				double d1 = (i.locX - this.locX) / d0;
				double d2 = (i.locY + (double) i.getHeadHeight() - this.locY) / d0;
				double d3 = (i.locZ - this.locZ) / d0;
				double d4 = Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3);
				double d5 = 1.0D - d4;

				if (d5 > 0.0D) {
					d5 *= d5;
					this.motX += d1 / d4 * d5 * 0.1D;
					this.motY += d2 / d4 * d5 * 0.1D;
					this.motZ += d3 / d4 * d5 * 0.1D;
				}
			}
		}

		this.move(this.motX, this.motY, this.motZ);
		float var15 = 0.98F;

		if (this.onGround) {
			var15 = 0.58800006F;
			int var16 = this.world.getTypeId(MathHelper.floor(this.locX), MathHelper.floor(this.boundingBox.minY) - 1,
					MathHelper.floor(this.locZ));

			if (var16 > 0) {
				var15 = Block.byId[var16].frictionFactor * 0.98F;
			}
		}

		this.motX *= (double) var15;
		this.motY *= 0.9800000190734863D;
		this.motZ *= (double) var15;

		if (this.onGround) {
			this.motY *= -0.8999999761581421D;
		}

		++this.a;
		++this.nextEntityID;

		if (this.nextEntityID >= 6000) {
			this.die();
		}
	}

	/**
	 * Returns if this entity is in water and will end up adding the waters
	 * velocity to the entity
	 */
	public boolean handleWaterMovement() {
		return this.world.handleMaterialAcceleration(this.boundingBox, Material.WATER, this);
	}

	protected void burn(int i) {
		this.attackEntityFrom(DamageSource.FIRE, (float) i);
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else {
			this.setBeenAttacked();
			this.fire = (int) ((float) this.fire - f);

			if (this.fire <= 0) {
				this.die();
			}

			return false;
		}
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		nbttagcompound.setShort("Health", (short) ((byte) this.fire));
		nbttagcompound.setShort("Age", (short) this.nextEntityID);
		nbttagcompound.setShort("Value", (short) this.value);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		this.fire = nbttagcompound.getShort("Health") & 255;
		this.nextEntityID = nbttagcompound.getShort("Age");
		this.value = nbttagcompound.getShort("Value");
	}

	public void b_(EntityHuman entityhuman) {
		if (!this.world.isStatic && this.nextStepDistance == 0 && entityhuman.isLeashed == 0) {
			entityhuman.isLeashed = 2;
			this.makeSound("random.orb", 0.1F,
					0.5F * ((this.random.nextFloat() - this.random.nextFloat()) * 0.7F + 1.8F));
			entityhuman.receive(this, 1);
			entityhuman.giveExp(CraftEventFactory.callPlayerExpChangeEvent(entityhuman, this.value).getAmount());
			this.die();
		}
	}

	public int c() {
		return this.value;
	}

	public static int getOrbValue(int i) {
		return i > 162670129 ? i - 100000
				: (i > 81335063 ? 81335063
						: (i > 40667527 ? 40667527
								: (i > 20333759 ? 20333759
										: (i > 10166857 ? 10166857
												: (i > 5083423 ? 5083423
														: (i > 2541701 ? 2541701
																: (i > 1270849 ? 1270849
																		: (i > 635413 ? 635413
																				: (i > 317701 ? 317701
																						: (i > 158849 ? 158849
																								: (i > 79423 ? 79423
																										: (i > 39709
																												? 39709
																												: (i > 19853
																														? 19853
																														: (i > 9923
																																? 9923
																																: (i > 4957
																																		? 4957
																																		: (i >= 2477
																																				? 2477
																																				: (i >= 1237
																																						? 1237
																																						: (i >= 617
																																								? 617
																																								: (i >= 307
																																										? 307
																																										: (i >= 149
																																												? 149
																																												: (i >= 73
																																														? 73
																																														: (i >= 37
																																																? 37
																																																: (i >= 17
																																																		? 17
																																																		: (i >= 7
																																																				? 7
																																																				: (i >= 3
																																																						? 3
																																																						: 1)))))))))))))))))))))))));
	}

	/**
	 * If returns false, the item will not inflict any damage against entities.
	 */
	public boolean canAttackWithItem() {
		return false;
	}
}
