package net.minecraft.server.v1_6_R3;

import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public abstract class EntityFireball extends Entity
{
    private int xTile = -1;
    private int yTile = -1;
    private int zTile = -1;
    private int inTile;
    private boolean inGround;
    public EntityLiving shooter;
    private int ticksAlive;
    private int ticksInAir;
    public double dirX;
    public double dirY;
    public double dirZ;
    public float bukkitYield = 1.0F;
    public boolean isIncendiary = true;

    public EntityFireball(World par1World)
    {
        super(par1World);
        this.setSize(1.0F, 1.0F);
    }

    protected void entityInit() {}

    public EntityFireball(World par1World, double par2, double par4, double par6, double par8, double par10, double par12)
    {
        super(par1World);
        this.setSize(1.0F, 1.0F);
        this.setPositionRotation(par2, par4, par6, this.yaw, this.pitch);
        this.setPosition(par2, par4, par6);
        double var14 = (double)MathHelper.sqrt(par8 * par8 + par10 * par10 + par12 * par12);
        this.dirX = par8 / var14 * 0.1D;
        this.dirY = par10 / var14 * 0.1D;
        this.dirZ = par12 / var14 * 0.1D;
    }

    public EntityFireball(World world, EntityLiving entityliving, double d0, double d1, double d2)
    {
        super(world);
        this.shooter = entityliving;
        this.setSize(1.0F, 1.0F);
        this.setPositionRotation(entityliving.locX, entityliving.locY, entityliving.locZ, entityliving.yaw, entityliving.pitch);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.height = 0.0F;
        this.motX = this.motY = this.motZ = 0.0D;
        this.setDirection(d0, d1, d2);
    }

    public void setDirection(double d0, double d1, double d2)
    {
        d0 += this.random.nextGaussian() * 0.4D;
        d1 += this.random.nextGaussian() * 0.4D;
        d2 += this.random.nextGaussian() * 0.4D;
        double d3 = (double)MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
        this.dirX = d0 / d3 * 0.1D;
        this.dirY = d1 / d3 * 0.1D;
        this.dirZ = d2 / d3 * 0.1D;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        if (!this.world.isStatic && (this.shooter != null && this.shooter.dead || !this.world.isLoaded((int)this.locX, (int)this.locY, (int)this.locZ)))
        {
            this.die();
        }
        else
        {
            super.onUpdate();
            this.setOnFire(1);

            if (this.inGround)
            {
                int var1 = this.world.getTypeId(this.xTile, this.yTile, this.zTile);

                if (var1 == this.inTile)
                {
                    ++this.ticksAlive;

                    if (this.ticksAlive == 600)
                    {
                        this.die();
                    }

                    return;
                }

                this.inGround = false;
                this.motX *= (double)(this.random.nextFloat() * 0.2F);
                this.motY *= (double)(this.random.nextFloat() * 0.2F);
                this.motZ *= (double)(this.random.nextFloat() * 0.2F);
                this.ticksAlive = 0;
                this.ticksInAir = 0;
            }
            else
            {
                ++this.ticksInAir;
            }

            Vec3D var15 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
            Vec3D var2 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
            MovingObjectPosition var3 = this.world.a(var15, var2);
            var15 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
            var2 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);

            if (var3 != null)
            {
                var2 = this.world.getVec3DPool().create(var3.pos.c, var3.pos.d, var3.pos.e);
            }

            Entity var4 = null;
            List var5 = this.world.getEntities(this, this.boundingBox.addCoord(this.motX, this.motY, this.motZ).grow(1.0D, 1.0D, 1.0D));
            double var6 = 0.0D;

            for (int var8 = 0; var8 < var5.size(); ++var8)
            {
                Entity var9 = (Entity)var5.get(var8);

                if (var9.canBeCollidedWith() && (!var9.isEntityEqual(this.shooter) || this.ticksInAir >= 25))
                {
                    float var10 = 0.3F;
                    AxisAlignedBB var11 = var9.boundingBox.grow((double)var10, (double)var10, (double)var10);
                    MovingObjectPosition var12 = var11.a(var15, var2);

                    if (var12 != null)
                    {
                        double var13 = var15.distanceSquared(var12.pos);

                        if (var13 < var6 || var6 == 0.0D)
                        {
                            var4 = var9;
                            var6 = var13;
                        }
                    }
                }
            }

            if (var4 != null)
            {
                var3 = new MovingObjectPosition(var4);
            }

            if (var3 != null)
            {
                this.onImpact(var3);

                if (this.dead)
                {
                    CraftEventFactory.callProjectileHitEvent(this);
                }
            }

            this.locX += this.motX;
            this.locY += this.motY;
            this.locZ += this.motZ;
            float var16 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
            this.yaw = (float)(Math.atan2(this.motZ, this.motX) * 180.0D / Math.PI) + 90.0F;

            for (this.pitch = (float)(Math.atan2((double)var16, this.motY) * 180.0D / Math.PI) - 90.0F; this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
            {
                ;
            }

            while (this.pitch - this.lastPitch >= 180.0F)
            {
                this.lastPitch += 360.0F;
            }

            while (this.yaw - this.lastYaw < -180.0F)
            {
                this.lastYaw -= 360.0F;
            }

            while (this.yaw - this.lastYaw >= 180.0F)
            {
                this.lastYaw += 360.0F;
            }

            this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
            this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
            float var17 = this.getMotionFactor();

            if (this.isInWater())
            {
                for (int var18 = 0; var18 < 4; ++var18)
                {
                    float var19 = 0.25F;
                    this.world.addParticle("bubble", this.locX - this.motX * (double)var19, this.locY - this.motY * (double)var19, this.locZ - this.motZ * (double)var19, this.motX, this.motY, this.motZ);
                }

                var17 = 0.8F;
            }

            this.motX += this.dirX;
            this.motY += this.dirY;
            this.motZ += this.dirZ;
            this.motX *= (double)var17;
            this.motY *= (double)var17;
            this.motZ *= (double)var17;
            this.world.addParticle("smoke", this.locX, this.locY + 0.5D, this.locZ, 0.0D, 0.0D, 0.0D);
            this.setPosition(this.locX, this.locY, this.locZ);
        }
    }

    /**
     * Return the motion factor for this projectile. The factor is multiplied by the original motion.
     */
    protected float getMotionFactor()
    {
        return 0.95F;
    }

    /**
     * Called when this EntityFireball hits a block or entity.
     */
    protected abstract void onImpact(MovingObjectPosition var1);

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        par1NBTTagCompound.setShort("xTile", (short)this.xTile);
        par1NBTTagCompound.setShort("yTile", (short)this.yTile);
        par1NBTTagCompound.setShort("zTile", (short)this.zTile);
        par1NBTTagCompound.setByte("inTile", (byte)this.inTile);
        par1NBTTagCompound.setByte("inGround", (byte)(this.inGround ? 1 : 0));
        par1NBTTagCompound.set("power", this.newDoubleNBTList(new double[] {this.dirX, this.dirY, this.dirZ}));
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        this.xTile = par1NBTTagCompound.getShort("xTile");
        this.yTile = par1NBTTagCompound.getShort("yTile");
        this.zTile = par1NBTTagCompound.getShort("zTile");
        this.inTile = par1NBTTagCompound.getByte("inTile") & 255;
        this.inGround = par1NBTTagCompound.getByte("inGround") == 1;

        if (par1NBTTagCompound.hasKey("power"))
        {
            NBTTagList var2 = par1NBTTagCompound.getList("power");
            this.dirX = ((NBTTagDouble)var2.get(0)).data;
            this.dirY = ((NBTTagDouble)var2.get(1)).data;
            this.dirZ = ((NBTTagDouble)var2.get(2)).data;
        }
        else
        {
            this.die();
        }
    }

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
        return true;
    }

    public float getCollisionBorderSize()
    {
        return 1.0F;
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else
        {
            this.setBeenAttacked();

            if (damagesource.getEntity() != null)
            {
                Vec3D vec3d = damagesource.getEntity().getLookVec();

                if (vec3d != null)
                {
                    this.motX = vec3d.c;
                    this.motY = vec3d.d;
                    this.motZ = vec3d.e;
                    this.dirX = this.motX * 0.1D;
                    this.dirY = this.motY * 0.1D;
                    this.dirZ = this.motZ * 0.1D;
                }

                if (damagesource.getEntity() instanceof EntityLiving)
                {
                    this.shooter = (EntityLiving)damagesource.getEntity();
                }

                return true;
            }
            else
            {
                return false;
            }
        }
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float par1)
    {
        return 1.0F;
    }
}
