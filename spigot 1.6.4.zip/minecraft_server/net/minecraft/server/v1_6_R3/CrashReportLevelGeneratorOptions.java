package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportLevelGeneratorOptions implements Callable
{
    final WorldData a;

    CrashReportLevelGeneratorOptions(WorldData var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return WorldData.c(this.a);
    }

    public Object call()
    {
        return this.a();
    }
}
