package net.minecraft.server.v1_6_R3;

public class BlockBeacon extends BlockContainer
{
    public BlockBeacon(int par1)
    {
        super(par1, Material.SHATTERABLE);
        this.setHardness(3.0F);
        this.a(CreativeModeTab.f);
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityBeacon();
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            TileEntityBeacon var10 = (TileEntityBeacon)var1.getTileEntity(var2, var3, var4);

            if (var10 != null)
            {
                var5.openBeacon(var10);
            }

            return true;
        }
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 34;
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        super.postPlace(var1, var2, var3, var4, var5, var6);

        if (var6.hasName())
        {
            ((TileEntityBeacon)var1.getTileEntity(var2, var3, var4)).func_94047_a(var6.getName());
        }
    }
}
