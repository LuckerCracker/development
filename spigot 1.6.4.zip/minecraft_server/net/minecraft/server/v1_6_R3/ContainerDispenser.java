package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public class ContainerDispenser extends Container {
	public TileEntityDispenser items;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public ContainerDispenser(IInventory par1IInventory, TileEntityDispenser par2TileEntityDispenser) {
		this.items = par2TileEntityDispenser;
		this.player = (PlayerInventory) par1IInventory;
		int var3;
		int var4;

		for (var3 = 0; var3 < 3; ++var3) {
			for (var4 = 0; var4 < 3; ++var4) {
				this.addSlotToContainer(
						new Slot(par2TileEntityDispenser, var4 + var3 * 3, 62 + var4 * 18, 17 + var3 * 18));
			}
		}

		for (var3 = 0; var3 < 3; ++var3) {
			for (var4 = 0; var4 < 9; ++var4) {
				this.addSlotToContainer(new Slot(par1IInventory, var4 + var3 * 9 + 9, 8 + var4 * 18, 84 + var3 * 18));
			}
		}

		for (var3 = 0; var3 < 9; ++var3) {
			this.addSlotToContainer(new Slot(par1IInventory, var3, 8 + var3 * 18, 142));
		}
	}

	public boolean a(EntityHuman entityhuman) {
		return !this.checkReachable ? true : this.items.a(entityhuman);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i < 9) {
				if (!this.mergeItemStack(itemstack1, 9, 45, true)) {
					return null;
				}
			} else if (!this.mergeItemStack(itemstack1, 0, 9, false)) {
				return null;
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			CraftInventory inventory = new CraftInventory(this.items);
			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(), inventory, this);
			return this.bukkitEntity;
		}
	}
}
