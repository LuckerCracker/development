package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockHugeMushroom extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    private static final String[] displayOnCreativeTab = new String[] {"skin_brown", "skin_red"};

    /** The unlocalized name of this block. */
    private final int unlocalizedName;

    public BlockHugeMushroom(int var1, Material var2, int var3)
    {
        super(var1, var2);
        this.unlocalizedName = var3;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random var1)
    {
        int var2 = var1.nextInt(10) - 7;

        if (var2 < 0)
        {
            var2 = 0;
        }

        return var2;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Block.BROWN_MUSHROOM.id + this.unlocalizedName;
    }
}
