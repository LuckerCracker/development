package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.util.Vector;

final class DispenseBehaviorEmptyBucket extends DispenseBehaviorItem
{
    private final DispenseBehaviorItem b = new DispenseBehaviorItem();

    public ItemStack b(ISourceBlock isourceblock, ItemStack itemstack)
    {
        EnumFacing enumfacing = BlockDispenser.getFacing(isourceblock.h());
        World world = isourceblock.k();
        int i = isourceblock.getBlockX() + enumfacing.getFrontOffsetX();
        int j = isourceblock.getBlockY() + enumfacing.getFrontOffsetY();
        int k = isourceblock.getBlockZ() + enumfacing.getFrontOffsetZ();
        Material material = world.getMaterial(i, j, k);
        int l = world.getData(i, j, k);
        Item item;

        if (Material.WATER.equals(material) && l == 0)
        {
            item = Item.WATER_BUCKET;
        }
        else
        {
            if (!Material.LAVA.equals(material) || l != 0)
            {
                return super.b(isourceblock, itemstack);
            }

            item = Item.LAVA_BUCKET;
        }

        org.bukkit.block.Block block = world.getWorld().getBlockAt(isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ());
        CraftItemStack craftItem = CraftItemStack.asCraftMirror(itemstack);
        BlockDispenseEvent event = new BlockDispenseEvent(block, craftItem.clone(), new Vector(i, j, k));

        if (!BlockDispenser.eventFired)
        {
            world.getServer().getPluginManager().callEvent(event);
        }

        if (event.isCancelled())
        {
            return itemstack;
        }
        else
        {
            if (!event.getItem().equals(craftItem))
            {
                ItemStack eventStack = CraftItemStack.asNMSCopy(event.getItem());
                IDispenseBehavior idispensebehavior = (IDispenseBehavior)BlockDispenser.dispenseBehaviorRegistry.getObject(eventStack.getItem());

                if (idispensebehavior != IDispenseBehavior.a && idispensebehavior != this)
                {
                    idispensebehavior.a(isourceblock, eventStack);
                    return itemstack;
                }
            }

            world.setAir(i, j, k);

            if (--itemstack.count == 0)
            {
                itemstack.id = item.id;
                itemstack.count = 1;
            }
            else if (((TileEntityDispenser)isourceblock.getTileEntity()).addItem(new ItemStack(item)) < 0)
            {
                this.b.a(isourceblock, new ItemStack(item));
            }

            return itemstack;
        }
    }
}
