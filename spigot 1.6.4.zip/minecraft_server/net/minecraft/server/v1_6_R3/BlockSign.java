package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.event.block.BlockRedstoneEvent;

public class BlockSign extends BlockContainer
{
    private Class signEntityClass;

    /** Whether this is a freestanding sign or a wall-mounted sign */
    private boolean isFreestanding;

    protected BlockSign(int par1, Class par2Class, boolean par3)
    {
        super(par1, Material.WOOD);
        this.isFreestanding = par3;
        this.signEntityClass = par2Class;
        float var4 = 0.25F;
        float var5 = 1.0F;
        this.setBlockBounds(0.5F - var4, 0.0F, 0.5F - var4, 0.5F + var4, var5, 0.5F + var4);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return null;
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        if (!this.isFreestanding)
        {
            int l = iblockaccess.getData(i, j, k);
            float f = 0.28125F;
            float f1 = 0.78125F;
            float f2 = 0.0F;
            float f3 = 1.0F;
            float f4 = 0.125F;
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);

            if (l == 2)
            {
                this.setBlockBounds(f2, f, 1.0F - f4, f3, f1, 1.0F);
            }

            if (l == 3)
            {
                this.setBlockBounds(f2, f, 0.0F, f3, f1, f4);
            }

            if (l == 4)
            {
                this.setBlockBounds(1.0F - f4, f, f2, 1.0F, f1, f3);
            }

            if (l == 5)
            {
                this.setBlockBounds(0.0F, f, f2, f4, f1, f3);
            }
        }
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return -1;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public boolean getBlocksMovement(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return true;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        try
        {
            return (TileEntity)this.signEntityClass.newInstance();
        }
        catch (Exception var3)
        {
            throw new RuntimeException(var3);
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Item.SIGN.id;
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        boolean flag = false;

        if (this.isFreestanding)
        {
            if (!world.getMaterial(i, j - 1, k).isBuildable())
            {
                flag = true;
            }
        }
        else
        {
            int block = world.getData(i, j, k);
            flag = true;

            if (block == 2 && world.getMaterial(i, j, k + 1).isBuildable())
            {
                flag = false;
            }

            if (block == 3 && world.getMaterial(i, j, k - 1).isBuildable())
            {
                flag = false;
            }

            if (block == 4 && world.getMaterial(i + 1, j, k).isBuildable())
            {
                flag = false;
            }

            if (block == 5 && world.getMaterial(i - 1, j, k).isBuildable())
            {
                flag = false;
            }
        }

        if (flag)
        {
            this.dropBlockAsItem(world, i, j, k, world.getData(i, j, k), 0);
            world.setAir(i, j, k);
        }

        super.doPhysics(world, i, j, k, l);

        if (Block.byId[l] != null && Block.byId[l].isPowerSource())
        {
            org.bukkit.block.Block block1 = world.getWorld().getBlockAt(i, j, k);
            int power = block1.getBlockPower();
            BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block1, power, power);
            world.getServer().getPluginManager().callEvent(eventRedstone);
        }
    }
}
