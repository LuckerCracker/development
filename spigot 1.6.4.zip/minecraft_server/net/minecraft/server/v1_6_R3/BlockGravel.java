package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockGravel extends BlockSand
{
    public BlockGravel(int par1)
    {
        super(par1);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        if (var3 > 3)
        {
            var3 = 3;
        }

        return var2.nextInt(10 - var3 * 3) == 0 ? Item.FLINT.id : this.id;
    }
}
