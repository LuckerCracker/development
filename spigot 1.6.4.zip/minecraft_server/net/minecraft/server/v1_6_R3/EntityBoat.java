package net.minecraft.server.v1_6_R3;

import java.util.List;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_6_R3.CraftServer;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.vehicle.VehicleCreateEvent;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.event.vehicle.VehicleDestroyEvent;
import org.bukkit.event.vehicle.VehicleEntityCollisionEvent;
import org.bukkit.event.vehicle.VehicleMoveEvent;
import org.bukkit.event.vehicle.VehicleUpdateEvent;

public class EntityBoat extends Entity
{
    private boolean field_70279_a;
    private double speedMultiplier;
    private int boatPosRotationIncrements;
    private double boatX;
    private double boatY;
    private double boatZ;
    private double boatYaw;
    private double boatPitch;
    public double maxSpeed;
    public double occupiedDeceleration;
    public double unoccupiedDeceleration;
    public boolean landBoats;

    public void collide(Entity entity)
    {
        CraftEntity hitEntity = entity == null ? null : entity.getBukkitEntity();
        VehicleEntityCollisionEvent event = new VehicleEntityCollisionEvent((Vehicle)this.getBukkitEntity(), hitEntity);
        this.world.getServer().getPluginManager().callEvent(event);

        if (!event.isCancelled())
        {
            super.collide(entity);
        }
    }

    public EntityBoat(World par1World)
    {
        super(par1World);
        this.maxSpeed = 0.4D;
        this.occupiedDeceleration = 0.2D;
        this.unoccupiedDeceleration = -1.0D;
        this.landBoats = false;
        this.field_70279_a = true;
        this.speedMultiplier = 0.07D;
        this.preventEntitySpawning = true;
        this.setSize(1.5F, 0.6F);
        this.height = this.length / 2.0F;
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    protected void entityInit()
    {
        this.datawatcher.addObject(17, new Integer(0));
        this.datawatcher.addObject(18, new Integer(1));
        this.datawatcher.addObject(19, new Float(0.0F));
    }

    /**
     * Returns a boundingBox used to collide the entity with other entities and blocks. This enables the entity to be
     * pushable on contact, like boats or minecarts.
     */
    public AxisAlignedBB getCollisionBox(Entity par1Entity)
    {
        return par1Entity.boundingBox;
    }

    /**
     * returns the bounding box for this entity
     */
    public AxisAlignedBB getBoundingBox()
    {
        return this.boundingBox;
    }

    /**
     * Returns true if this entity should push and be pushed by other entities when colliding.
     */
    public boolean canBePushed()
    {
        return true;
    }

    public EntityBoat(World par1World, double par2, double par4, double par6)
    {
        this(par1World);
        this.setPosition(par2, par4 + (double)this.height, par6);
        this.motX = 0.0D;
        this.motY = 0.0D;
        this.motZ = 0.0D;
        this.lastX = par2;
        this.lastY = par4;
        this.lastZ = par6;
        this.world.getServer().getPluginManager().callEvent(new VehicleCreateEvent((Vehicle)this.getBukkitEntity()));
    }

    /**
     * Returns the Y offset from the entity's position for any entity riding this one.
     */
    public double getMountedYOffset()
    {
        return (double)this.length * 0.0D - 0.30000001192092896D;
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else if (!this.world.isStatic && !this.dead)
        {
            Vehicle vehicle = (Vehicle)this.getBukkitEntity();
            CraftEntity attacker = damagesource.getEntity() == null ? null : damagesource.getEntity().getBukkitEntity();
            VehicleDamageEvent event = new VehicleDamageEvent(vehicle, attacker, (double)f);
            this.world.getServer().getPluginManager().callEvent(event);

            if (event.isCancelled())
            {
                return true;
            }
            else
            {
                this.setForwardDirection(-this.getForwardDirection());
                this.setTimeSinceHit(10);
                this.setDamage(this.getDamage() + f * 10.0F);
                this.setBeenAttacked();
                boolean flag = damagesource.getEntity() instanceof EntityHuman && ((EntityHuman)damagesource.getEntity()).abilities.canInstantlyBuild;

                if (flag || this.getDamage() > 40.0F)
                {
                    VehicleDestroyEvent destroyEvent = new VehicleDestroyEvent(vehicle, attacker);
                    this.world.getServer().getPluginManager().callEvent(destroyEvent);

                    if (destroyEvent.isCancelled())
                    {
                        this.setDamage(40.0F);
                        return true;
                    }

                    if (this.passenger != null)
                    {
                        this.passenger.mount(this);
                    }

                    if (!flag)
                    {
                        this.dropItemWithOffset(Item.BOAT.id, 1, 0.0F);
                    }

                    this.die();
                }

                return true;
            }
        }
        else
        {
            return true;
        }
    }

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
        return !this.dead;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        double var1 = this.locX;
        double var3 = this.locY;
        double var5 = this.locZ;
        float var7 = this.yaw;
        float var8 = this.pitch;
        super.onUpdate();

        if (this.getTimeSinceHit() > 0)
        {
            this.setTimeSinceHit(this.getTimeSinceHit() - 1);
        }

        if (this.getDamage() > 0.0F)
        {
            this.setDamage(this.getDamage() - 1.0F);
        }

        this.lastX = this.locX;
        this.lastY = this.locY;
        this.lastZ = this.locZ;
        byte var9 = 5;
        double var10 = 0.0D;

        for (int var12 = 0; var12 < var9; ++var12)
        {
            double var13 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(var12 + 0) / (double)var9 - 0.125D;
            double var15 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(var12 + 1) / (double)var9 - 0.125D;
            AxisAlignedBB var17 = AxisAlignedBB.getAABBPool().getAABB(this.boundingBox.minX, var13, this.boundingBox.minZ, this.boundingBox.maxX, var15, this.boundingBox.maxZ);

            if (this.world.isAABBInMaterial(var17, Material.WATER))
            {
                var10 += 1.0D / (double)var9;
            }
        }

        double var18 = Math.sqrt(this.motX * this.motX + this.motZ * this.motZ);
        double var20;
        double var22;

        if (var18 > 0.26249999999999996D)
        {
            var20 = Math.cos((double)this.yaw * Math.PI / 180.0D);
            var22 = Math.sin((double)this.yaw * Math.PI / 180.0D);

            for (int var24 = 0; (double)var24 < 1.0D + var18 * 60.0D; ++var24)
            {
                double var25 = (double)(this.random.nextFloat() * 2.0F - 1.0F);
                double var27 = (double)(this.random.nextInt(2) * 2 - 1) * 0.7D;
                double var29;
                double var31;

                if (this.random.nextBoolean())
                {
                    var29 = this.locX - var20 * var25 * 0.8D + var22 * var27;
                    var31 = this.locZ - var22 * var25 * 0.8D - var20 * var27;
                    this.world.addParticle("splash", var29, this.locY - 0.125D, var31, this.motX, this.motY, this.motZ);
                }
                else
                {
                    var29 = this.locX + var20 + var22 * var25 * 0.7D;
                    var31 = this.locZ + var22 - var20 * var25 * 0.7D;
                    this.world.addParticle("splash", var29, this.locY - 0.125D, var31, this.motX, this.motY, this.motZ);
                }
            }
        }

        double var33;
        double var35;

        if (this.world.isStatic && this.field_70279_a)
        {
            if (this.boatPosRotationIncrements > 0)
            {
                var20 = this.locX + (this.boatX - this.locX) / (double)this.boatPosRotationIncrements;
                var22 = this.locY + (this.boatY - this.locY) / (double)this.boatPosRotationIncrements;
                var33 = this.locZ + (this.boatZ - this.locZ) / (double)this.boatPosRotationIncrements;
                var35 = MathHelper.wrapAngleTo180_double(this.boatYaw - (double)this.yaw);
                this.yaw = (float)((double)this.yaw + var35 / (double)this.boatPosRotationIncrements);
                this.pitch = (float)((double)this.pitch + (this.boatPitch - (double)this.pitch) / (double)this.boatPosRotationIncrements);
                --this.boatPosRotationIncrements;
                this.setPosition(var20, var22, var33);
                this.setRotation(this.yaw, this.pitch);
            }
            else
            {
                var20 = this.locX + this.motX;
                var22 = this.locY + this.motY;
                var33 = this.locZ + this.motZ;
                this.setPosition(var20, var22, var33);

                if (this.onGround)
                {
                    this.motX *= 0.5D;
                    this.motY *= 0.5D;
                    this.motZ *= 0.5D;
                }

                this.motX *= 0.9900000095367432D;
                this.motY *= 0.949999988079071D;
                this.motZ *= 0.9900000095367432D;
            }
        }
        else
        {
            if (var10 < 1.0D)
            {
                var20 = var10 * 2.0D - 1.0D;
                this.motY += 0.03999999910593033D * var20;
            }
            else
            {
                if (this.motY < 0.0D)
                {
                    this.motY /= 2.0D;
                }

                this.motY += 0.007000000216066837D;
            }

            if (this.passenger != null && this.passenger instanceof EntityLiving)
            {
                var20 = (double)((EntityLiving)this.passenger).moveForward;

                if (var20 > 0.0D)
                {
                    var22 = -Math.sin((double)(this.passenger.yaw * (float)Math.PI / 180.0F));
                    var33 = Math.cos((double)(this.passenger.yaw * (float)Math.PI / 180.0F));
                    this.motX += var22 * this.speedMultiplier * 0.05000000074505806D;
                    this.motZ += var33 * this.speedMultiplier * 0.05000000074505806D;
                }
            }
            else if (this.unoccupiedDeceleration >= 0.0D)
            {
                this.motX *= this.unoccupiedDeceleration;
                this.motZ *= this.unoccupiedDeceleration;

                if (this.motX <= 1.0E-5D)
                {
                    this.motX = 0.0D;
                }

                if (this.motZ <= 1.0E-5D)
                {
                    this.motZ = 0.0D;
                }
            }

            var20 = Math.sqrt(this.motX * this.motX + this.motZ * this.motZ);

            if (var20 > 0.35D)
            {
                var22 = 0.35D / var20;
                this.motX *= var22;
                this.motZ *= var22;
                var20 = 0.35D;
            }

            if (var20 > var18 && this.speedMultiplier < 0.35D)
            {
                this.speedMultiplier += (0.35D - this.speedMultiplier) / 35.0D;

                if (this.speedMultiplier > 0.35D)
                {
                    this.speedMultiplier = 0.35D;
                }
            }
            else
            {
                this.speedMultiplier -= (this.speedMultiplier - 0.07D) / 35.0D;

                if (this.speedMultiplier < 0.07D)
                {
                    this.speedMultiplier = 0.07D;
                }
            }

            if (this.onGround && !this.landBoats)
            {
                this.motX *= 0.5D;
                this.motY *= 0.5D;
                this.motZ *= 0.5D;
            }

            this.move(this.motX, this.motY, this.motZ);

            if (this.positionChanged && var18 > 0.2D)
            {
                if (!this.world.isStatic && !this.dead)
                {
                    Vehicle var37 = (Vehicle)this.getBukkitEntity();
                    VehicleDestroyEvent var38 = new VehicleDestroyEvent(var37, (org.bukkit.entity.Entity)null);
                    this.world.getServer().getPluginManager().callEvent(var38);

                    if (!var38.isCancelled())
                    {
                        this.die();
                        int var39;

                        for (var39 = 0; var39 < 3; ++var39)
                        {
                            this.dropItemWithOffset(Block.WOOD.id, 1, 0.0F);
                        }

                        for (var39 = 0; var39 < 2; ++var39)
                        {
                            this.dropItemWithOffset(Item.STICK.id, 1, 0.0F);
                        }
                    }
                }
            }
            else
            {
                this.motX *= 0.9900000095367432D;
                this.motY *= 0.949999988079071D;
                this.motZ *= 0.9900000095367432D;
            }

            this.pitch = 0.0F;
            var22 = (double)this.yaw;
            var33 = this.lastX - this.locX;
            var35 = this.lastZ - this.locZ;

            if (var33 * var33 + var35 * var35 > 0.001D)
            {
                var22 = (double)((float)(Math.atan2(var35, var33) * 180.0D / Math.PI));
            }

            double var40 = MathHelper.wrapAngleTo180_double(var22 - (double)this.yaw);

            if (var40 > 20.0D)
            {
                var40 = 20.0D;
            }

            if (var40 < -20.0D)
            {
                var40 = -20.0D;
            }

            this.yaw = (float)((double)this.yaw + var40);
            this.setRotation(this.yaw, this.pitch);
            CraftServer var53 = this.world.getServer();
            CraftWorld var42 = this.world.getWorld();
            Location var43 = new Location(var42, var1, var3, var5, var7, var8);
            Location var44 = new Location(var42, this.locX, this.locY, this.locZ, this.yaw, this.pitch);
            Vehicle var45 = (Vehicle)this.getBukkitEntity();
            var53.getPluginManager().callEvent(new VehicleUpdateEvent(var45));

            if (!var43.equals(var44))
            {
                VehicleMoveEvent var46 = new VehicleMoveEvent(var45, var43, var44);
                var53.getPluginManager().callEvent(var46);
            }

            if (!this.world.isStatic)
            {
                List var54 = this.world.getEntities(this, this.boundingBox.grow(0.20000000298023224D, 0.0D, 0.20000000298023224D));
                int var47;

                if (var54 != null && !var54.isEmpty())
                {
                    for (var47 = 0; var47 < var54.size(); ++var47)
                    {
                        Entity var48 = (Entity)var54.get(var47);

                        if (var48 != this.passenger && var48.canBePushed() && var48 instanceof EntityBoat)
                        {
                            var48.collide(this);
                        }
                    }
                }

                for (var47 = 0; var47 < 4; ++var47)
                {
                    int var55 = MathHelper.floor(this.locX + ((double)(var47 % 2) - 0.5D) * 0.8D);
                    int var49 = MathHelper.floor(this.locZ + ((double)(var47 / 2) - 0.5D) * 0.8D);

                    for (int var50 = 0; var50 < 2; ++var50)
                    {
                        int var51 = MathHelper.floor(this.locY) + var50;
                        int var52 = this.world.getTypeId(var55, var51, var49);

                        if (var52 == Block.SNOW.id)
                        {
                            if (!CraftEventFactory.callEntityChangeBlockEvent(this, var55, var51, var49, 0, 0).isCancelled())
                            {
                                this.world.setAir(var55, var51, var49);
                            }
                        }
                        else if (var52 == Block.WATER_LILY.id && !CraftEventFactory.callEntityChangeBlockEvent(this, var55, var51, var49, 0, 0).isCancelled())
                        {
                            this.world.setAir(var55, var51, var49, true);
                        }
                    }
                }

                if (this.passenger != null && this.passenger.dead)
                {
                    this.passenger.vehicle = null;
                    this.passenger = null;
                }
            }
        }
    }

    public void updateRiderPosition()
    {
        if (this.passenger != null)
        {
            double var1 = Math.cos((double)this.yaw * Math.PI / 180.0D) * 0.4D;
            double var3 = Math.sin((double)this.yaw * Math.PI / 180.0D) * 0.4D;
            this.passenger.setPosition(this.locX + var1, this.locY + this.getMountedYOffset() + this.passenger.getYOffset(), this.locZ + var3);
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {}

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {}

    public boolean c(EntityHuman entityhuman)
    {
        if (this.passenger != null && this.passenger instanceof EntityHuman && this.passenger != entityhuman)
        {
            return true;
        }
        else
        {
            if (!this.world.isStatic)
            {
                entityhuman.mount(this);
            }

            return true;
        }
    }

    public void setDamage(float f)
    {
        this.datawatcher.watch(19, Float.valueOf(f));
    }

    public float getDamage()
    {
        return this.datawatcher.getFloat(19);
    }

    /**
     * Sets the time to count down from since the last time entity was hit.
     */
    public void setTimeSinceHit(int par1)
    {
        this.datawatcher.watch(17, Integer.valueOf(par1));
    }

    /**
     * Gets the time since the last hit.
     */
    public int getTimeSinceHit()
    {
        return this.datawatcher.getInt(17);
    }

    /**
     * Sets the forward direction of the entity.
     */
    public void setForwardDirection(int par1)
    {
        this.datawatcher.watch(18, Integer.valueOf(par1));
    }

    /**
     * Gets the forward direction of the entity.
     */
    public int getForwardDirection()
    {
        return this.datawatcher.getInt(18);
    }
}
