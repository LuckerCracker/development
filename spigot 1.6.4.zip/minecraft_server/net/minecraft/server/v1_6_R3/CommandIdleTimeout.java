package net.minecraft.server.v1_6_R3;

public class CommandIdleTimeout extends CommandAbstract
{
    public String getCommandName()
    {
        return "setidletimeout";
    }

    public int a()
    {
        return 3;
    }

    public String c(ICommandListener var1)
    {
        return "commands.setidletimeout.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length == 1)
        {
            int var3 = a(var1, var2[0], 0);
            MinecraftServer.getServer().e(var3);
            a(var1, "commands.setidletimeout.success", new Object[] {Integer.valueOf(var3)});
        }
        else
        {
            throw new ExceptionUsage("commands.setidletimeout.usage", new Object[0]);
        }
    }
}
