package net.minecraft.server.v1_6_R3;

public class EnchantmentWeaponDamage extends Enchantment
{
    private static final String[] C = new String[] {"all", "undead", "arthropods"};
    private static final int[] D = new int[] {1, 5, 5};
    private static final int[] E = new int[] {11, 8, 8};
    private static final int[] F = new int[] {20, 20, 20};
    public final int weight;

    public EnchantmentWeaponDamage(int var1, int var2, int var3)
    {
        super(var1, var2, EnchantmentSlotType.WEAPON);
        this.weight = var3;
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int var1)
    {
        return D[this.weight] + (var1 - 1) * E[this.weight];
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int var1)
    {
        return this.getMinEnchantability(var1) + F[this.weight];
    }

    public int getMaxLevel()
    {
        return 5;
    }

    public float a(int var1, EntityLiving var2)
    {
        return this.weight == 0 ? (float)var1 * 1.25F : (this.weight == 1 && var2.getMonsterType() == EnumMonsterType.UNDEAD ? (float)var1 * 2.5F : (this.weight == 2 && var2.getMonsterType() == EnumMonsterType.ARTHROPOD ? (float)var1 * 2.5F : 0.0F));
    }

    /**
     * Return the name of key in translation table of this enchantment.
     */
    public String getName()
    {
        return "enchantment.damage." + C[this.weight];
    }

    /**
     * Determines if the enchantment passed can be applyied together with this enchantment.
     */
    public boolean canApplyTogether(Enchantment var1)
    {
        return !(var1 instanceof EnchantmentWeaponDamage);
    }

    public boolean canEnchant(ItemStack var1)
    {
        return var1.getItem() instanceof ItemAxe ? true : super.canEnchant(var1);
    }
}
