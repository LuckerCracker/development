package net.minecraft.server.v1_6_R3;

public abstract class EntityAmbient extends EntityInsentient implements IAnimal
{
    public EntityAmbient(World var1)
    {
        super(var1);
    }

    public boolean allowLeashing()
    {
        return false;
    }

    protected boolean a(EntityHuman var1)
    {
        return false;
    }
}
