package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandEnchant extends CommandAbstract
{
    public String getCommandName()
    {
        return "enchant";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.enchant.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length < 2)
        {
            throw new ExceptionUsage("commands.enchant.usage", new Object[0]);
        }
        else
        {
            EntityPlayer var3 = d(var1, var2[0]);
            int var4 = a(var1, var2[1], 0, Enchantment.byId.length - 1);
            int var5 = 1;
            ItemStack var6 = var3.getCurrentEquippedItem();

            if (var6 == null)
            {
                throw new CommandException("commands.enchant.noItem", new Object[0]);
            }
            else
            {
                Enchantment var7 = Enchantment.byId[var4];

                if (var7 == null)
                {
                    throw new ExceptionInvalidNumber("commands.enchant.notFound", new Object[] {Integer.valueOf(var4)});
                }
                else if (!var7.canEnchant(var6))
                {
                    throw new CommandException("commands.enchant.cantEnchant", new Object[0]);
                }
                else
                {
                    if (var2.length >= 3)
                    {
                        var5 = a(var1, var2[2], var7.getStartLevel(), var7.getMaxLevel());
                    }

                    if (var6.hasTag())
                    {
                        NBTTagList var8 = var6.getEnchantments();

                        if (var8 != null)
                        {
                            for (int var9 = 0; var9 < var8.size(); ++var9)
                            {
                                short var10 = ((NBTTagCompound)var8.get(var9)).getShort("id");

                                if (Enchantment.byId[var10] != null)
                                {
                                    Enchantment var11 = Enchantment.byId[var10];

                                    if (!var11.canApplyTogether(var7))
                                    {
                                        throw new CommandException("commands.enchant.cantCombine", new Object[] {var7.getTranslatedName(var5), var11.getTranslatedName(((NBTTagCompound)var8.get(var9)).getShort("lvl"))});
                                    }
                                }
                            }
                        }
                    }

                    var6.addEnchantment(var7, var5);
                    a(var1, "commands.enchant.success", new Object[0]);
                }
            }
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, this.getListOfPlayers()) : null;
    }

    protected String[] getListOfPlayers()
    {
        return MinecraftServer.getServer().getPlayers();
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] par1ArrayOfStr, int par2)
    {
        return par2 == 0;
    }
}
