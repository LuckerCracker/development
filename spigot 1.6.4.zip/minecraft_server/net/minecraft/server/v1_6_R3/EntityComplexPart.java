package net.minecraft.server.v1_6_R3;

public class EntityComplexPart extends Entity
{
    public final IComplex owner;
    public final String nextEntityID;

    public EntityComplexPart(IComplex var1, String var2, float var3, float var4)
    {
        super(var1.b());
        this.setSize(var3, var4);
        this.owner = var1;
        this.nextEntityID = var2;
    }

    protected void entityInit() {}

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound var1) {}

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound var1) {}

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
        return true;
    }

    public boolean attackEntityFrom(DamageSource var1, float var2)
    {
        return this.isInvulnerable() ? false : this.owner.a(this, var1, var2);
    }

    /**
     * Returns true if Entity argument is equal to this Entity
     */
    public boolean isEntityEqual(Entity var1)
    {
        return this == var1 || this.owner == var1;
    }
}
