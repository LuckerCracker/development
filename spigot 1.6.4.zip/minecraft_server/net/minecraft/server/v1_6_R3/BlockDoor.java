package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.event.block.BlockRedstoneEvent;

public class BlockDoor extends Block
{
    protected BlockDoor(int par1, Material par2Material)
    {
        super(par1, par2Material);
        float var3 = 0.5F;
        float var4 = 1.0F;
        this.setBlockBounds(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, var4, 0.5F + var3);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    public boolean getBlocksMovement(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        int var5 = this.getFullMetadata(par1IBlockAccess, par2, par3, par4);
        return (var5 & 4) != 0;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 7;
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        this.updateShape(par1World, par2, par3, par4);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        this.setDoorRotation(this.getFullMetadata(iblockaccess, i, j, k));
    }

    /**
     * Returns 0, 1, 2 or 3 depending on where the hinge is.
     */
    public int getDoorOrientation(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return this.getFullMetadata(par1IBlockAccess, par2, par3, par4) & 3;
    }

    public boolean isDoorOpen(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return (this.getFullMetadata(par1IBlockAccess, par2, par3, par4) & 4) != 0;
    }

    private void setDoorRotation(int par1)
    {
        float var2 = 0.1875F;
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F);
        int var3 = par1 & 3;
        boolean var4 = (par1 & 4) != 0;
        boolean var5 = (par1 & 16) != 0;

        if (var3 == 0)
        {
            if (var4)
            {
                if (!var5)
                {
                    this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var2);
                }
                else
                {
                    this.setBlockBounds(0.0F, 0.0F, 1.0F - var2, 1.0F, 1.0F, 1.0F);
                }
            }
            else
            {
                this.setBlockBounds(0.0F, 0.0F, 0.0F, var2, 1.0F, 1.0F);
            }
        }
        else if (var3 == 1)
        {
            if (var4)
            {
                if (!var5)
                {
                    this.setBlockBounds(1.0F - var2, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
                }
                else
                {
                    this.setBlockBounds(0.0F, 0.0F, 0.0F, var2, 1.0F, 1.0F);
                }
            }
            else
            {
                this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var2);
            }
        }
        else if (var3 == 2)
        {
            if (var4)
            {
                if (!var5)
                {
                    this.setBlockBounds(0.0F, 0.0F, 1.0F - var2, 1.0F, 1.0F, 1.0F);
                }
                else
                {
                    this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var2);
                }
            }
            else
            {
                this.setBlockBounds(1.0F - var2, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            }
        }
        else if (var3 == 3)
        {
            if (var4)
            {
                if (!var5)
                {
                    this.setBlockBounds(0.0F, 0.0F, 0.0F, var2, 1.0F, 1.0F);
                }
                else
                {
                    this.setBlockBounds(1.0F - var2, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
                }
            }
            else
            {
                this.setBlockBounds(0.0F, 0.0F, 1.0F - var2, 1.0F, 1.0F, 1.0F);
            }
        }
    }

    public void attack(World world, int i, int j, int k, EntityHuman entityhuman) {}

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        if (this.material == Material.ORE)
        {
            return true;
        }
        else
        {
            int i1 = this.getFullMetadata(world, i, j, k);
            int j1 = i1 & 7;
            j1 ^= 4;

            if ((i1 & 8) == 0)
            {
                world.setData(i, j, k, j1, 2);
                world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
            }
            else
            {
                world.setData(i, j - 1, k, j1, 2);
                world.markBlockRangeForRenderUpdate(i, j - 1, k, i, j, k);
            }

            world.a(entityhuman, 1003, i, j, k, 0);
            return true;
        }
    }

    public void setDoor(World world, int i, int j, int k, boolean flag)
    {
        int l = this.getFullMetadata(world, i, j, k);
        boolean flag1 = (l & 4) != 0;

        if (flag1 != flag)
        {
            int i1 = l & 7;
            i1 ^= 4;

            if ((l & 8) == 0)
            {
                world.setData(i, j, k, i1, 2);
                world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
            }
            else
            {
                world.setData(i, j - 1, k, i1, 2);
                world.markBlockRangeForRenderUpdate(i, j - 1, k, i, j, k);
            }

            world.a((EntityHuman)null, 1003, i, j, k, 0);
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        int i1 = world.getData(i, j, k);

        if ((i1 & 8) == 0)
        {
            boolean flag = false;

            if (world.getTypeId(i, j + 1, k) != this.id)
            {
                world.setAir(i, j, k);
                flag = true;
            }

            if (!world.doesBlockHaveSolidTopSurface(i, j - 1, k))
            {
                world.setAir(i, j, k);
                flag = true;

                if (world.getTypeId(i, j + 1, k) == this.id)
                {
                    world.setAir(i, j + 1, k);
                }
            }

            if (flag)
            {
                if (!world.isStatic)
                {
                    this.dropBlockAsItem(world, i, j, k, i1, 0);
                }
            }
            else if (l > 0 && Block.byId[l].isPowerSource())
            {
                CraftWorld bworld = world.getWorld();
                org.bukkit.block.Block block = bworld.getBlockAt(i, j, k);
                org.bukkit.block.Block blockTop = bworld.getBlockAt(i, j + 1, k);
                int power = block.getBlockPower();
                int powerTop = blockTop.getBlockPower();

                if (powerTop > power)
                {
                    power = powerTop;
                }

                int oldPower = (world.getData(i, j, k) & 4) > 0 ? 15 : 0;

                if (oldPower == 0 ^ power == 0)
                {
                    BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, oldPower, power);
                    world.getServer().getPluginManager().callEvent(eventRedstone);
                    this.setDoor(world, i, j, k, eventRedstone.getNewCurrent() > 0);
                }
            }
        }
        else if (world.getTypeId(i, j - 1, k) != this.id)
        {
            world.setAir(i, j, k);
        }
        else if (l > 0 && l != this.id)
        {
            this.doPhysics(world, i, j - 1, k, l);
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return (i & 8) != 0 ? 0 : (this.material == Material.ORE ? Item.IRON_DOOR.id : Item.WOOD_DOOR.id);
    }

    public MovingObjectPosition a(World world, int i, int j, int k, Vec3D vec3d, Vec3D vec3d1)
    {
        this.updateShape(world, i, j, k);
        return super.a(world, i, j, k, vec3d, vec3d1);
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return j >= 255 ? false : world.doesBlockHaveSolidTopSurface(i, j - 1, k) && super.canPlace(world, i, j, k) && super.canPlace(world, i, j + 1, k);
    }

    /**
     * Returns the mobility information of the block, 0 = free, 1 = can't push but can move over, 2 = total immobility
     * and stop pistons
     */
    public int getMobilityFlag()
    {
        return 1;
    }

    /**
     * Returns the full metadata value created by combining the metadata of both blocks the door takes up.
     */
    public int getFullMetadata(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        int var5 = par1IBlockAccess.getData(par2, par3, par4);
        boolean var6 = (var5 & 8) != 0;
        int var7;
        int var8;

        if (var6)
        {
            var7 = par1IBlockAccess.getData(par2, par3 - 1, par4);
            var8 = var5;
        }
        else
        {
            var7 = var5;
            var8 = par1IBlockAccess.getData(par2, par3 + 1, par4);
        }

        boolean var9 = (var8 & 1) != 0;
        return var7 & 7 | (var6 ? 8 : 0) | (var9 ? 16 : 0);
    }

    public void a(World world, int i, int j, int k, int l, EntityHuman entityhuman)
    {
        if (entityhuman.abilities.canInstantlyBuild && (l & 8) != 0 && world.getTypeId(i, j - 1, k) == this.id)
        {
            world.setAir(i, j - 1, k);
        }
    }
}
