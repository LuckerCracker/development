package net.minecraft.server.v1_6_R3;

public class BiomeOcean extends BiomeBase
{
    public BiomeOcean(int var1)
    {
        super(var1);
        this.spawnableCreatureList.clear();
    }
}
