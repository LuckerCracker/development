package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockLongGrass extends BlockFlower
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    private static final String[] displayOnCreativeTab = new String[] {"deadbush", "tallgrass", "fern"};

    protected BlockLongGrass(int var1)
    {
        super(var1, Material.REPLACEABLE_PLANT);
        float var2 = 0.4F;
        this.setBlockBounds(0.5F - var2, 0.0F, 0.5F - var2, 0.5F + var2, 0.8F, 0.5F + var2);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return var2.nextInt(8) == 0 ? Item.SEEDS.id : -1;
    }

    public int getDropCount(int var1, Random var2)
    {
        return 1 + var2.nextInt(var1 * 2 + 1);
    }

    public void a(World var1, EntityHuman var2, int var3, int var4, int var5, int var6)
    {
        if (!var1.isStatic && var2.getCurrentEquippedItem() != null && var2.getCurrentEquippedItem().id == Item.SHEARS.id)
        {
            var2.addStat(StatisticList.C[this.id], 1);
            this.dropBlockAsItem_do(var1, var3, var4, var5, new ItemStack(Block.LONG_GRASS, 1, var6));
        }
        else
        {
            super.a(var1, var2, var3, var4, var5, var6);
        }
    }

    public int getDropData(World var1, int var2, int var3, int var4)
    {
        return var1.getData(var2, var3, var4);
    }
}
