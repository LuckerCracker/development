package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.entity.Explosive;
import org.bukkit.event.entity.ExplosionPrimeEvent;

public class EntityLargeFireball extends EntityFireball
{
    public int yield = 1;

    public EntityLargeFireball(World par1World)
    {
        super(par1World);
    }

    public EntityLargeFireball(World world, EntityLiving entityliving, double d0, double d1, double d2)
    {
        super(world, entityliving, d0, d1, d2);
    }

    /**
     * Called when this EntityFireball hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition par1MovingObjectPosition)
    {
        if (!this.world.isStatic)
        {
            if (par1MovingObjectPosition.entity != null)
            {
                par1MovingObjectPosition.entity.attackEntityFrom(DamageSource.fireball(this, this.shooter), 6.0F);
            }

            ExplosionPrimeEvent var2 = new ExplosionPrimeEvent((Explosive)CraftEntity.getEntity(this.world.getServer(), this));
            this.world.getServer().getPluginManager().callEvent(var2);

            if (!var2.isCancelled())
            {
                this.world.createExplosion(this, this.locX, this.locY, this.locZ, var2.getRadius(), var2.getFire(), this.world.getGameRules().getBoolean("mobGriefing"));
            }

            this.die();
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setInt("ExplosionPower", this.yield);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);

        if (par1NBTTagCompound.hasKey("ExplosionPower"))
        {
            this.bukkitYield = (float)(this.yield = par1NBTTagCompound.getInt("ExplosionPower"));
        }
    }
}
