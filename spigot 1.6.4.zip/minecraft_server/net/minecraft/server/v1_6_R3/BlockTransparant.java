package net.minecraft.server.v1_6_R3;

public class BlockTransparant extends Block
{
    protected boolean d;

    protected BlockTransparant(int var1, Material var2, boolean var3)
    {
        super(var1, var2);
        this.d = var3;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }
}
