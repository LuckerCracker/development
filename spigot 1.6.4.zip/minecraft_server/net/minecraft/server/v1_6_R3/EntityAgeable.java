package net.minecraft.server.v1_6_R3;

import org.bukkit.event.entity.CreatureSpawnEvent;

public abstract class EntityAgeable extends EntityCreature {
	private float field_98056_d = -1.0F;
	private float field_98057_e;
	public boolean ageLocked = false;

	public void inactiveTick() {
		super.inactiveTick();

		if (!this.world.isStatic && !this.ageLocked) {
			int i = this.getAge();

			if (i < 0) {
				++i;
				this.setAge(i);
			} else if (i > 0) {
				--i;
				this.setAge(i);
			}
		} else {
			this.setScaleForAge(this.isBaby());
		}
	}

	public EntityAgeable(World par1World) {
		super(par1World);
	}

	public abstract EntityAgeable createChild(EntityAgeable var1);

	public boolean a(EntityHuman entityhuman) {
		ItemStack itemstack = entityhuman.inventory.getItemInHand();

		if (itemstack != null && itemstack.id == Item.MONSTER_EGG.id) {
			if (!this.world.isStatic) {
				Class oclass = EntityTypes.a(itemstack.getData());

				if (oclass != null && oclass.isAssignableFrom(this.getClass())) {
					EntityAgeable entityageable = this.createChild(this);

					if (entityageable != null) {
						entityageable.setAge(-24000);
						entityageable.setPositionRotation(this.locX, this.locY, this.locZ, 0.0F, 0.0F);
						this.world.addEntity(entityageable, CreatureSpawnEvent.SpawnReason.SPAWNER_EGG);

						if (itemstack.hasName()) {
							entityageable.setCustomName(itemstack.getName());
						}

						if (!entityhuman.abilities.canInstantlyBuild) {
							--itemstack.count;

							if (itemstack.count == 0) {
								entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack) null);
							}
						}
					}
				}
			}

			return true;
		} else {
			return false;
		}
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(12, new Integer(0));
	}

	public int getAge() {
		return this.datawatcher.getInt(12);
	}

	/**
	 * "Adds the value of the parameter times 20 to the age of this entity. If
	 * the entity is an adult (if the entity's age is greater than 0), it will
	 * have no effect."
	 */
	public void addGrowth(int par1) {
		int var2 = this.getAge();
		var2 += par1 * 20;

		if (var2 > 0) {
			var2 = 0;
		}

		this.setAge(var2);
	}

	public void setAge(int i) {
		this.datawatcher.watch(12, Integer.valueOf(i));
		this.setScaleForAge(this.isBaby());
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setInt("Age", this.getAge());
		par1NBTTagCompound.setBoolean("AgeLocked", this.ageLocked);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.setAge(par1NBTTagCompound.getInt("Age"));
		this.ageLocked = par1NBTTagCompound.getBoolean("AgeLocked");
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		super.onLivingUpdate();

		if (!this.world.isStatic && !this.ageLocked) {
			int var1 = this.getAge();

			if (var1 < 0) {
				++var1;
				this.setAge(var1);
			} else if (var1 > 0) {
				--var1;
				this.setAge(var1);
			}
		} else {
			this.setScaleForAge(this.isBaby());
		}
	}

	public boolean isBaby() {
		return this.getAge() < 0;
	}

	/**
	 * "Sets the scale for an ageable entity according to the boolean parameter,
	 * which says if it's a child."
	 */
	public void setScaleForAge(boolean par1) {
		this.setScale(par1 ? 0.5F : 1.0F);
	}

	/**
	 * Sets the width and height of the entity. Args: width, height
	 */
	protected final void setSize(float par1, float par2) {
		boolean var3 = this.field_98056_d > 0.0F;
		this.field_98056_d = par1;
		this.field_98057_e = par2;

		if (!var3) {
			this.setScale(1.0F);
		}
	}

	protected final void setScale(float par1) {
		super.setSize(this.field_98056_d * par1, this.field_98057_e * par1);
	}
}
