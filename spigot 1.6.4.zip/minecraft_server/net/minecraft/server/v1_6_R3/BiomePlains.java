package net.minecraft.server.v1_6_R3;

public class BiomePlains extends BiomeBase
{
    protected BiomePlains(int var1)
    {
        super(var1);
        this.spawnableCreatureList.add(new BiomeMeta(EntityHorse.class, 5, 2, 6));
        this.theBiomeDecorator.treesPerChunk = -999;
        this.theBiomeDecorator.flowersPerChunk = 4;
        this.theBiomeDecorator.grassPerChunk = 10;
    }
}
