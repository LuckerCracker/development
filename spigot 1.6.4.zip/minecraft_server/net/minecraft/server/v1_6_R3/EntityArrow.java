package net.minecraft.server.v1_6_R3;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftItem;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

public class EntityArrow extends Entity implements IProjectile
{
    private int xTile = -1;
    private int yTile = -1;
    private int zTile = -1;
    private int inTile;
    private int inData;
    public boolean inGround = false;
    public int fromPlayer;
    public int shake;
    public Entity shooter;
    private int ticksInGround;
    private int ticksInAir;
    private double damage = 2.0D;

    /** The amount of knockback an arrow applies when it hits a mob. */
    private int knockbackStrength;

    public EntityArrow(World par1World)
    {
        super(par1World);
        this.renderDistanceWeight = 10.0D;
        this.setSize(0.5F, 0.5F);
    }

    public EntityArrow(World par1World, double par2, double par4, double par6)
    {
        super(par1World);
        this.renderDistanceWeight = 10.0D;
        this.setSize(0.5F, 0.5F);
        this.setPosition(par2, par4, par6);
        this.height = 0.0F;
    }

    public EntityArrow(World world, EntityLiving entityliving, EntityLiving entityliving1, float f, float f1)
    {
        super(world);
        this.renderDistanceWeight = 10.0D;
        this.shooter = entityliving;

        if (entityliving instanceof EntityHuman)
        {
            this.fromPlayer = 1;
        }

        this.locY = entityliving.locY + (double)entityliving.getHeadHeight() - 0.10000000149011612D;
        double d0 = entityliving1.locX - entityliving.locX;
        double d1 = entityliving1.boundingBox.minY + (double)(entityliving1.length / 3.0F) - this.locY;
        double d2 = entityliving1.locZ - entityliving.locZ;
        double d3 = (double)MathHelper.sqrt(d0 * d0 + d2 * d2);

        if (d3 >= 1.0E-7D)
        {
            float f2 = (float)(Math.atan2(d2, d0) * 180.0D / Math.PI) - 90.0F;
            float f3 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
            double d4 = d0 / d3;
            double d5 = d2 / d3;
            this.setPositionRotation(entityliving.locX + d4, this.locY, entityliving.locZ + d5, f2, f3);
            this.height = 0.0F;
            float f4 = (float)d3 * 0.2F;
            this.shoot(d0, d1 + (double)f4, d2, f, f1);
        }
    }

    public EntityArrow(World world, EntityLiving entityliving, float f)
    {
        super(world);
        this.renderDistanceWeight = 10.0D;
        this.shooter = entityliving;

        if (entityliving instanceof EntityHuman)
        {
            this.fromPlayer = 1;
        }

        this.setSize(0.5F, 0.5F);
        this.setPositionRotation(entityliving.locX, entityliving.locY + (double)entityliving.getHeadHeight(), entityliving.locZ, entityliving.yaw, entityliving.pitch);
        this.locX -= (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.locY -= 0.10000000149011612D;
        this.locZ -= (double)(MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.height = 0.0F;
        this.motX = (double)(-MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI));
        this.motZ = (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI));
        this.motY = (double)(-MathHelper.sin(this.pitch / 180.0F * (float)Math.PI));
        this.shoot(this.motX, this.motY, this.motZ, f * 1.5F, 1.0F);
    }

    protected void entityInit()
    {
        this.datawatcher.addObject(16, Byte.valueOf((byte)0));
    }

    public void shoot(double d0, double d1, double d2, float f, float f1)
    {
        float f2 = MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= (double)f2;
        d1 /= (double)f2;
        d2 /= (double)f2;
        d0 += this.random.nextGaussian() * (double)(this.random.nextBoolean() ? -1 : 1) * 0.007499999832361937D * (double)f1;
        d1 += this.random.nextGaussian() * (double)(this.random.nextBoolean() ? -1 : 1) * 0.007499999832361937D * (double)f1;
        d2 += this.random.nextGaussian() * (double)(this.random.nextBoolean() ? -1 : 1) * 0.007499999832361937D * (double)f1;
        d0 *= (double)f;
        d1 *= (double)f;
        d2 *= (double)f;
        this.motX = d0;
        this.motY = d1;
        this.motZ = d2;
        float f3 = MathHelper.sqrt(d0 * d0 + d2 * d2);
        this.lastYaw = this.yaw = (float)(Math.atan2(d0, d2) * 180.0D / Math.PI);
        this.lastPitch = this.pitch = (float)(Math.atan2(d1, (double)f3) * 180.0D / Math.PI);
        this.ticksInGround = 0;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (this.lastPitch == 0.0F && this.lastYaw == 0.0F)
        {
            float var1 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
            this.lastYaw = this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);
            this.lastPitch = this.pitch = (float)(Math.atan2(this.motY, (double)var1) * 180.0D / Math.PI);
        }

        int var18 = this.world.getTypeId(this.xTile, this.yTile, this.zTile);

        if (var18 > 0)
        {
            Block.byId[var18].updateShape(this.world, this.xTile, this.yTile, this.zTile);
            AxisAlignedBB var2 = Block.byId[var18].getCollisionBoundingBoxFromPool(this.world, this.xTile, this.yTile, this.zTile);

            if (var2 != null && var2.a(this.world.getVec3DPool().create(this.locX, this.locY, this.locZ)))
            {
                this.inGround = true;
            }
        }

        if (this.shake > 0)
        {
            --this.shake;
        }

        if (this.inGround)
        {
            int var19 = this.world.getTypeId(this.xTile, this.yTile, this.zTile);
            int var3 = this.world.getData(this.xTile, this.yTile, this.zTile);

            if (var19 == this.inTile && var3 == this.inData)
            {
                ++this.ticksInGround;

                if (this.ticksInGround == this.world.spigotConfig.arrowDespawnRate)
                {
                    this.die();
                }
            }
            else
            {
                this.inGround = false;
                this.motX *= (double)(this.random.nextFloat() * 0.2F);
                this.motY *= (double)(this.random.nextFloat() * 0.2F);
                this.motZ *= (double)(this.random.nextFloat() * 0.2F);
                this.ticksInGround = 0;
                this.ticksInAir = 0;
            }
        }
        else
        {
            ++this.ticksInAir;
            Vec3D var20 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
            Vec3D var21 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
            MovingObjectPosition var4 = this.world.rayTrace(var20, var21, false, true);
            var20 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
            var21 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);

            if (var4 != null)
            {
                var21 = this.world.getVec3DPool().create(var4.pos.c, var4.pos.d, var4.pos.e);
            }

            Entity var5 = null;
            List var6 = this.world.getEntities(this, this.boundingBox.addCoord(this.motX, this.motY, this.motZ).grow(1.0D, 1.0D, 1.0D));
            double var7 = 0.0D;
            int var9;
            float var11;

            for (var9 = 0; var9 < var6.size(); ++var9)
            {
                Entity var10 = (Entity)var6.get(var9);

                if (var10.canBeCollidedWith() && (var10 != this.shooter || this.ticksInAir >= 5))
                {
                    var11 = 0.3F;
                    AxisAlignedBB var12 = var10.boundingBox.grow((double)var11, (double)var11, (double)var11);
                    MovingObjectPosition var13 = var12.a(var20, var21);

                    if (var13 != null)
                    {
                        double var14 = var20.distanceSquared(var13.pos);

                        if (var14 < var7 || var7 == 0.0D)
                        {
                            var5 = var10;
                            var7 = var14;
                        }
                    }
                }
            }

            if (var5 != null)
            {
                var4 = new MovingObjectPosition(var5);
            }

            if (var4 != null && var4.entity != null && var4.entity instanceof EntityHuman)
            {
                EntityHuman var22 = (EntityHuman)var4.entity;

                if (var22.abilities.isInvulnerable || this.shooter instanceof EntityHuman && !((EntityHuman)this.shooter).canAttackPlayer(var22))
                {
                    var4 = null;
                }
            }

            float var23;
            float var24;

            if (var4 != null)
            {
                CraftEventFactory.callProjectileHitEvent(this);

                if (var4.entity != null)
                {
                    var23 = MathHelper.sqrt(this.motX * this.motX + this.motY * this.motY + this.motZ * this.motZ);
                    int var25 = MathHelper.ceiling_double_int((double)var23 * this.damage);

                    if (this.getIsCritical())
                    {
                        var25 += this.random.nextInt(var25 / 2 + 2);
                    }

                    DamageSource var16 = null;

                    if (this.shooter == null)
                    {
                        var16 = DamageSource.arrow(this, this);
                    }
                    else
                    {
                        var16 = DamageSource.arrow(this, this.shooter);
                    }

                    if (var4.entity.attackEntityFrom(var16, (float)var25))
                    {
                        if (this.isBurning() && !(var4.entity instanceof EntityEnderman) && (!(var4.entity instanceof EntityPlayer) || !(this.shooter instanceof EntityPlayer) || this.world.pvpMode))
                        {
                            EntityCombustByEntityEvent var17 = new EntityCombustByEntityEvent(this.getBukkitEntity(), var5.getBukkitEntity(), 5);
                            Bukkit.getPluginManager().callEvent(var17);

                            if (!var17.isCancelled())
                            {
                                var4.entity.setOnFire(var17.getDuration());
                            }
                        }

                        if (var4.entity instanceof EntityLiving)
                        {
                            EntityLiving var27 = (EntityLiving)var4.entity;

                            if (!this.world.isStatic)
                            {
                                var27.setArrowCountInEntity(var27.getArrowCountInEntity() + 1);
                            }

                            if (this.knockbackStrength > 0)
                            {
                                var24 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);

                                if (var24 > 0.0F)
                                {
                                    var4.entity.addVelocity(this.motX * (double)this.knockbackStrength * 0.6000000238418579D / (double)var24, 0.1D, this.motZ * (double)this.knockbackStrength * 0.6000000238418579D / (double)var24);
                                }
                            }

                            if (this.shooter != null)
                            {
                                EnchantmentThorns.a(this.shooter, var27, this.random);
                            }

                            if (this.shooter != null && var4.entity != this.shooter && var4.entity instanceof EntityHuman && this.shooter instanceof EntityPlayer)
                            {
                                ((EntityPlayer)this.shooter).playerConnection.sendPacket(new Packet70Bed(6, 0));
                            }
                        }

                        this.makeSound("random.bowhit", 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));

                        if (!(var4.entity instanceof EntityEnderman))
                        {
                            this.die();
                        }
                    }
                    else
                    {
                        this.motX *= -0.10000000149011612D;
                        this.motY *= -0.10000000149011612D;
                        this.motZ *= -0.10000000149011612D;
                        this.yaw += 180.0F;
                        this.lastYaw += 180.0F;
                        this.ticksInAir = 0;
                    }
                }
                else
                {
                    this.xTile = var4.blockX;
                    this.yTile = var4.blockY;
                    this.zTile = var4.blockZ;
                    this.inTile = this.world.getTypeId(this.xTile, this.yTile, this.zTile);
                    this.inData = this.world.getData(this.xTile, this.yTile, this.zTile);
                    this.motX = (double)((float)(var4.pos.c - this.locX));
                    this.motY = (double)((float)(var4.pos.d - this.locY));
                    this.motZ = (double)((float)(var4.pos.e - this.locZ));
                    var23 = MathHelper.sqrt(this.motX * this.motX + this.motY * this.motY + this.motZ * this.motZ);
                    this.locX -= this.motX / (double)var23 * 0.05000000074505806D;
                    this.locY -= this.motY / (double)var23 * 0.05000000074505806D;
                    this.locZ -= this.motZ / (double)var23 * 0.05000000074505806D;
                    this.makeSound("random.bowhit", 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
                    this.inGround = true;
                    this.shake = 7;
                    this.setIsCritical(false);

                    if (this.inTile != 0)
                    {
                        Block.byId[this.inTile].onEntityCollidedWithBlock(this.world, this.xTile, this.yTile, this.zTile, this);
                    }
                }
            }

            if (this.getIsCritical())
            {
                for (var9 = 0; var9 < 4; ++var9)
                {
                    this.world.addParticle("crit", this.locX + this.motX * (double)var9 / 4.0D, this.locY + this.motY * (double)var9 / 4.0D, this.locZ + this.motZ * (double)var9 / 4.0D, -this.motX, -this.motY + 0.2D, -this.motZ);
                }
            }

            this.locX += this.motX;
            this.locY += this.motY;
            this.locZ += this.motZ;
            var23 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
            this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);

            for (this.pitch = (float)(Math.atan2(this.motY, (double)var23) * 180.0D / Math.PI); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
            {
                ;
            }

            while (this.pitch - this.lastPitch >= 180.0F)
            {
                this.lastPitch += 360.0F;
            }

            while (this.yaw - this.lastYaw < -180.0F)
            {
                this.lastYaw -= 360.0F;
            }

            while (this.yaw - this.lastYaw >= 180.0F)
            {
                this.lastYaw += 360.0F;
            }

            this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
            this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
            float var26 = 0.99F;
            var11 = 0.05F;

            if (this.isInWater())
            {
                for (int var28 = 0; var28 < 4; ++var28)
                {
                    var24 = 0.25F;
                    this.world.addParticle("bubble", this.locX - this.motX * (double)var24, this.locY - this.motY * (double)var24, this.locZ - this.motZ * (double)var24, this.motX, this.motY, this.motZ);
                }

                var26 = 0.8F;
            }

            this.motX *= (double)var26;
            this.motY *= (double)var26;
            this.motZ *= (double)var26;
            this.motY -= (double)var11;
            this.setPosition(this.locX, this.locY, this.locZ);
            this.doBlockCollisions();
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        par1NBTTagCompound.setShort("xTile", (short)this.xTile);
        par1NBTTagCompound.setShort("yTile", (short)this.yTile);
        par1NBTTagCompound.setShort("zTile", (short)this.zTile);
        par1NBTTagCompound.setByte("inTile", (byte)this.inTile);
        par1NBTTagCompound.setByte("inData", (byte)this.inData);
        par1NBTTagCompound.setByte("shake", (byte)this.shake);
        par1NBTTagCompound.setByte("inGround", (byte)(this.inGround ? 1 : 0));
        par1NBTTagCompound.setByte("pickup", (byte)this.fromPlayer);
        par1NBTTagCompound.setDouble("damage", this.damage);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        this.xTile = par1NBTTagCompound.getShort("xTile");
        this.yTile = par1NBTTagCompound.getShort("yTile");
        this.zTile = par1NBTTagCompound.getShort("zTile");
        this.inTile = par1NBTTagCompound.getByte("inTile") & 255;
        this.inData = par1NBTTagCompound.getByte("inData") & 255;
        this.shake = par1NBTTagCompound.getByte("shake") & 255;
        this.inGround = par1NBTTagCompound.getByte("inGround") == 1;

        if (par1NBTTagCompound.hasKey("damage"))
        {
            this.damage = par1NBTTagCompound.getDouble("damage");
        }

        if (par1NBTTagCompound.hasKey("pickup"))
        {
            this.fromPlayer = par1NBTTagCompound.getByte("pickup");
        }
        else if (par1NBTTagCompound.hasKey("player"))
        {
            this.fromPlayer = par1NBTTagCompound.getBoolean("player") ? 1 : 0;
        }
    }

    public void b_(EntityHuman entityhuman)
    {
        if (!this.world.isStatic && this.inGround && this.shake <= 0)
        {
            ItemStack itemstack = new ItemStack(Item.ARROW);

            if (this.fromPlayer == 1 && entityhuman.inventory.canHold(itemstack) > 0)
            {
                EntityItem flag = new EntityItem(this.world, this.locX, this.locY, this.locZ, itemstack);
                PlayerPickupItemEvent event = new PlayerPickupItemEvent((Player)entityhuman.getBukkitEntity(), new CraftItem(this.world.getServer(), this, flag), 0);
                this.world.getServer().getPluginManager().callEvent(event);

                if (event.isCancelled())
                {
                    return;
                }
            }

            boolean flag1 = this.fromPlayer == 1 || this.fromPlayer == 2 && entityhuman.abilities.canInstantlyBuild;

            if (this.fromPlayer == 1 && !entityhuman.inventory.pickup(new ItemStack(Item.ARROW, 1)))
            {
                flag1 = false;
            }

            if (flag1)
            {
                this.makeSound("random.pop", 0.2F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
                entityhuman.receive(this, 1);
                this.die();
            }
        }
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    public void setDamage(double par1)
    {
        this.damage = par1;
    }

    public double getDamage()
    {
        return this.damage;
    }

    /**
     * Sets the amount of knockback the arrow applies when it hits a mob.
     */
    public void setKnockbackStrength(int par1)
    {
        this.knockbackStrength = par1;
    }

    /**
     * If returns false, the item will not inflict any damage against entities.
     */
    public boolean canAttackWithItem()
    {
        return false;
    }

    /**
     * Whether the arrow has a stream of critical hit particles flying behind it.
     */
    public void setIsCritical(boolean par1)
    {
        byte var2 = this.datawatcher.getByte(16);

        if (par1)
        {
            this.datawatcher.watch(16, Byte.valueOf((byte)(var2 | 1)));
        }
        else
        {
            this.datawatcher.watch(16, Byte.valueOf((byte)(var2 & -2)));
        }
    }

    /**
     * Whether the arrow has a stream of critical hit particles flying behind it.
     */
    public boolean getIsCritical()
    {
        byte var1 = this.datawatcher.getByte(16);
        return (var1 & 1) != 0;
    }

    public boolean isInGround()
    {
        return this.inGround;
    }
}
