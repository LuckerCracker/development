package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftHumanEntity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryHolder;

public class ContainerEnchantTableInventory extends InventorySubcontainer
{
    private final ContainerEnchantTable enchantTable;
    public List<HumanEntity> transaction = new ArrayList();
    public Player player;
    private int maxStack = 64;

    public ItemStack[] getContents()
    {
        return this.items;
    }

    public void onOpen(CraftHumanEntity who)
    {
        this.transaction.add(who);
    }

    public void onClose(CraftHumanEntity who)
    {
        this.transaction.remove(who);
    }

    public List<HumanEntity> getViewers()
    {
        return this.transaction;
    }

    public InventoryHolder getOwner()
    {
        return this.player;
    }

    public void setMaxStackSize(int size)
    {
        this.maxStack = size;
    }

    ContainerEnchantTableInventory(ContainerEnchantTable containerenchanttable, String s, boolean flag, int i)
    {
        super(s, flag, i);
        this.enchantTable = containerenchanttable;
        this.setMaxStackSize(1);
    }

    public int getMaxStackSize()
    {
        return this.maxStack;
    }

    public void update()
    {
        super.update();
        this.enchantTable.onCraftMatrixChanged(this);
    }

    /**
     * Returns true if automation is allowed to insert the given stack (ignoring stack size) into the given slot.
     */
    public boolean isItemValidForSlot(int i, ItemStack itemstack)
    {
        return true;
    }
}
