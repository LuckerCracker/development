package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryBeacon;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public class ContainerBeacon extends Container {
	private TileEntityBeacon theBeacon;

	/**
	 * This beacon's slot where you put in Emerald, Diamond, Gold or Iron Ingot.
	 */
	private final SlotBeacon beaconSlot;
	private int field_82865_g;
	private int field_82867_h;
	private int field_82868_i;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public ContainerBeacon(PlayerInventory playerinventory, TileEntityBeacon tileentitybeacon) {
		this.player = playerinventory;
		this.theBeacon = tileentitybeacon;
		this.addSlotToContainer(this.beaconSlot = new SlotBeacon(this, tileentitybeacon, 0, 136, 110));
		byte b0 = 36;
		short short1 = 137;
		int i;

		for (i = 0; i < 3; ++i) {
			for (int j = 0; j < 9; ++j) {
				this.addSlotToContainer(new Slot(playerinventory, j + i * 9 + 9, b0 + j * 18, short1 + i * 18));
			}
		}

		for (i = 0; i < 9; ++i) {
			this.addSlotToContainer(new Slot(playerinventory, i, b0 + i * 18, 58 + short1));
		}

		this.field_82865_g = tileentitybeacon.getLevels();
		this.field_82867_h = tileentitybeacon.getPrimaryEffect();
		this.field_82868_i = tileentitybeacon.getSecondaryEffect();
	}

	public void addSlotListener(ICrafting icrafting) {
		super.addSlotListener(icrafting);
		icrafting.setContainerData(this, 0, this.field_82865_g);
		icrafting.setContainerData(this, 1, this.field_82867_h);
		icrafting.setContainerData(this, 2, this.field_82868_i);
	}

	/**
	 * Returns the Tile Entity behind this beacon inventory / container
	 */
	public TileEntityBeacon getBeacon() {
		return this.theBeacon;
	}

	public boolean a(EntityHuman entityhuman) {
		return !this.checkReachable ? true : this.theBeacon.a(entityhuman);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i == 0) {
				if (!this.mergeItemStack(itemstack1, 1, 37, true)) {
					return null;
				}

				slot.onSlotChange(itemstack1, itemstack);
			} else if (!this.beaconSlot.getHasStack() && this.beaconSlot.isAllowed(itemstack1)
					&& itemstack1.count == 1) {
				if (!this.mergeItemStack(itemstack1, 0, 1, false)) {
					return null;
				}
			} else if (i >= 1 && i < 28) {
				if (!this.mergeItemStack(itemstack1, 28, 37, false)) {
					return null;
				}
			} else if (i >= 28 && i < 37) {
				if (!this.mergeItemStack(itemstack1, 1, 28, false)) {
					return null;
				}
			} else if (!this.mergeItemStack(itemstack1, 1, 37, false)) {
				return null;
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			CraftInventoryBeacon inventory = new CraftInventoryBeacon(this.theBeacon);
			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(), inventory, this);
			return this.bukkitEntity;
		}
	}
}
