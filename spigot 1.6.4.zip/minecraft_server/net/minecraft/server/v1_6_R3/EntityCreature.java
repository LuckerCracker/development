package net.minecraft.server.v1_6_R3;

import java.util.UUID;
import org.bukkit.craftbukkit.v1_6_R3.TrigMath;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityTargetEvent.TargetReason;
import org.bukkit.event.entity.EntityUnleashEvent;
import org.bukkit.event.entity.EntityUnleashEvent.UnleashReason;

public abstract class EntityCreature extends EntityInsentient {
	public static final UUID field_110179_h = UUID.fromString("E199AD21-BA8A-4C53-8D13-6182D5C69D3A");
	public static final AttributeModifier field_110181_i = (new AttributeModifier(field_110179_h, "Fleeing speed bonus",
			2.0D, 2)).setSaved(false);
	public PathEntity pathEntity;
	public Entity target;

	/**
	 * returns true if a creature has attacked recently only used for creepers
	 * and skeletons
	 */
	protected boolean hasAttacked;

	/** Used to make a creature speed up and wander away when hit. */
	protected int fleeingTick;
	private ChunkCoordinates homePosition = new ChunkCoordinates(0, 0, 0);

	/** If -1 there is no maximum distance */
	private float maximumHomeDistance = -1.0F;
	private PathfinderGoal field_110178_bs = new PathfinderGoalMoveTowardsRestriction(this, 1.0D);
	private boolean field_110180_bt;

	public EntityCreature(World par1World) {
		super(par1World);
	}

	/**
	 * Disables a mob's ability to move on its own while true.
	 */
	protected boolean isMovementCeased() {
		return false;
	}

	protected void updateEntityActionState() {
		this.world.methodProfiler.a("ai");

		if (this.fleeingTick > 0 && --this.fleeingTick == 0) {
			AttributeInstance var1 = this.getAttributeInstance(GenericAttributes.d);
			var1.removeModifier(field_110181_i);
		}

		this.hasAttacked = this.isMovementCeased();
		float var21 = 16.0F;

		if (this.target == null) {
			Entity var2 = this.findTarget();

			if (var2 != null) {
				EntityTargetEvent var3 = new EntityTargetEvent(this.getBukkitEntity(), var2.getBukkitEntity(),
						EntityTargetEvent.TargetReason.CLOSEST_PLAYER);
				this.world.getServer().getPluginManager().callEvent(var3);

				if (!var3.isCancelled()) {
					if (var3.getTarget() == null) {
						this.target = null;
					} else {
						this.target = ((CraftEntity) var3.getTarget()).getHandle();
					}
				}
			}

			if (this.target != null) {
				this.pathEntity = this.world.findPath(this, this.target, var21, true, false, false, true);
			}
		} else if (this.target.isAlive()) {
			float var22 = this.target.getDistanceToEntity(this);

			if (this.canEntityBeSeen(this.target)) {
				this.attackEntity(this.target, var22);
			}
		} else {
			EntityTargetEvent var23 = new EntityTargetEvent(this.getBukkitEntity(), (org.bukkit.entity.Entity) null,
					EntityTargetEvent.TargetReason.TARGET_DIED);
			this.world.getServer().getPluginManager().callEvent(var23);

			if (!var23.isCancelled()) {
				if (var23.getTarget() == null) {
					this.target = null;
				} else {
					this.target = ((CraftEntity) var23.getTarget()).getHandle();
				}
			}
		}

		this.world.methodProfiler.b();

		if (!this.hasAttacked && this.target != null && (this.pathEntity == null || this.random.nextInt(20) == 0)) {
			this.pathEntity = this.world.findPath(this, this.target, var21, true, false, false, true);
		} else if (!this.hasAttacked && (this.pathEntity == null && this.random.nextInt(180) == 0
				|| this.random.nextInt(120) == 0 || this.fleeingTick > 0) && this.entityAge < 100) {
			this.updateWanderPath();
		}

		int var24 = MathHelper.floor(this.boundingBox.minY + 0.5D);
		boolean var25 = this.isInWater();
		boolean var4 = this.handleLavaMovement();
		this.pitch = 0.0F;

		if (this.pathEntity != null && this.random.nextInt(100) != 0) {
			this.world.methodProfiler.a("followpath");
			Vec3D var5 = this.pathEntity.a(this);
			double var6 = (double) (this.width * 2.0F);

			while (var5 != null && var5.d(this.locX, var5.d, this.locZ) < var6 * var6) {
				this.pathEntity.incrementPathIndex();

				if (this.pathEntity.isFinished()) {
					var5 = null;
					this.pathEntity = null;
				} else {
					var5 = this.pathEntity.a(this);
				}
			}

			this.isJumping = false;

			if (var5 != null) {
				double var8 = var5.c - this.locX;
				double var10 = var5.e - this.locZ;
				double var12 = var5.d - (double) var24;
				float var14 = (float) (TrigMath.atan2(var10, var8) * 180.0D / Math.PI) - 90.0F;
				float var15 = MathHelper.wrapAngleTo180_float(var14 - this.yaw);
				this.moveForward = (float) this.getAttributeInstance(GenericAttributes.d).getValue();

				if (var15 > 30.0F) {
					var15 = 30.0F;
				}

				if (var15 < -30.0F) {
					var15 = -30.0F;
				}

				this.yaw += var15;

				if (this.hasAttacked && this.target != null) {
					double var16 = this.target.locX - this.locX;
					double var18 = this.target.locZ - this.locZ;
					float var20 = this.yaw;
					this.yaw = (float) (Math.atan2(var18, var16) * 180.0D / Math.PI) - 90.0F;
					var15 = (var20 - this.yaw + 90.0F) * (float) Math.PI / 180.0F;
					this.moveStrafing = -MathHelper.sin(var15) * this.moveForward * 1.0F;
					this.moveForward = MathHelper.cos(var15) * this.moveForward * 1.0F;
				}

				if (var12 > 0.0D) {
					this.isJumping = true;
				}
			}

			if (this.target != null) {
				this.faceEntity(this.target, 30.0F, 30.0F);
			}

			if (this.positionChanged && !this.hasPath()) {
				this.isJumping = true;
			}

			if (this.random.nextFloat() < 0.8F && (var25 || var4)) {
				this.isJumping = true;
			}

			this.world.methodProfiler.b();
		} else {
			super.updateEntityActionState();
			this.pathEntity = null;
		}
	}

	/**
	 * Time remaining during which the Animal is sped up and flees.
	 */
	protected void updateWanderPath() {
		this.world.methodProfiler.a("stroll");
		boolean var1 = false;
		int var2 = -1;
		int var3 = -1;
		int var4 = -1;
		float var5 = -99999.0F;

		for (int var6 = 0; var6 < 10; ++var6) {
			int var7 = MathHelper.floor(this.locX + (double) this.random.nextInt(13) - 6.0D);
			int var8 = MathHelper.floor(this.locY + (double) this.random.nextInt(7) - 3.0D);
			int var9 = MathHelper.floor(this.locZ + (double) this.random.nextInt(13) - 6.0D);
			float var10 = this.getBlockPathWeight(var7, var8, var9);

			if (var10 > var5) {
				var5 = var10;
				var2 = var7;
				var3 = var8;
				var4 = var9;
				var1 = true;
			}
		}

		if (var1) {
			this.pathEntity = this.world.getEntityPathToXYZ(this, var2, var3, var4, 10.0F, true, false, false, true);
		}

		this.world.methodProfiler.b();
	}

	/**
	 * Basic mob attack. Default to touch of death in EntityCreature. Overridden
	 * by each mob to define their attack.
	 */
	protected void attackEntity(Entity par1Entity, float par2) {
	}

	/**
	 * Takes a coordinate in and returns a weight to determine how likely this
	 * creature will try to path to the block. Args: x, y, z
	 */
	public float getBlockPathWeight(int par1, int par2, int par3) {
		return 0.0F;
	}

	protected Entity findTarget() {
		return null;
	}

	public boolean canSpawn() {
		int i = MathHelper.floor(this.locX);
		int j = MathHelper.floor(this.boundingBox.minY);
		int k = MathHelper.floor(this.locZ);
		return super.canSpawn() && this.getBlockPathWeight(i, j, k) >= 0.0F;
	}

	/**
	 * if the entity got a PathEntity it returns true, else false
	 */
	public boolean hasPath() {
		return this.pathEntity != null;
	}

	public void setPathEntity(PathEntity pathentity) {
		this.pathEntity = pathentity;
	}

	/**
	 * returns the target Entity
	 */
	public Entity getEntityToAttack() {
		return this.target;
	}

	public void setTarget(Entity entity) {
		this.target = entity;
	}

	public boolean func_110173_bK() {
		return this.func_110176_b(MathHelper.floor(this.locX), MathHelper.floor(this.locY),
				MathHelper.floor(this.locZ));
	}

	public boolean func_110176_b(int par1, int par2, int par3) {
		return this.maximumHomeDistance == -1.0F ? true
				: this.homePosition.getDistanceSquared(par1, par2, par3) < this.maximumHomeDistance
						* this.maximumHomeDistance;
	}

	public void setHomeArea(int par1, int par2, int par3, int par4) {
		this.homePosition.set(par1, par2, par3);
		this.maximumHomeDistance = (float) par4;
	}

	/**
	 * Returns the chunk coordinate object of the home position.
	 */
	public ChunkCoordinates getHomePosition() {
		return this.homePosition;
	}

	public float func_110174_bM() {
		return this.maximumHomeDistance;
	}

	public void detachHome() {
		this.maximumHomeDistance = -1.0F;
	}

	/**
	 * Returns whether a home area is defined for this entity.
	 */
	public boolean hasHome() {
		return this.maximumHomeDistance != -1.0F;
	}

	protected void func_110159_bB() {
		super.func_110159_bB();

		if (this.getLeashed() && this.getLeashHolder() != null && this.getLeashHolder().world == this.world) {
			Entity var1 = this.getLeashHolder();
			this.setHomeArea((int) var1.locX, (int) var1.locY, (int) var1.locZ, 5);
			float var2 = this.getDistanceToEntity(var1);

			if (this instanceof EntityTameableAnimal && ((EntityTameableAnimal) this).isSitting()) {
				if (var2 > 10.0F) {
					this.world.getServer().getPluginManager().callEvent(
							new EntityUnleashEvent(this.getBukkitEntity(), EntityUnleashEvent.UnleashReason.DISTANCE));
					this.unleash(true, true);
				}

				return;
			}

			if (!this.field_110180_bt) {
				this.goalSelector.a(2, this.field_110178_bs);
				this.getNavigation().a(false);
				this.field_110180_bt = true;
			}

			this.func_142017_o(var2);

			if (var2 > 4.0F) {
				this.getNavigation().a(var1, 1.0D);
			}

			if (var2 > 6.0F) {
				double var3 = (var1.locX - this.locX) / (double) var2;
				double var5 = (var1.locY - this.locY) / (double) var2;
				double var7 = (var1.locZ - this.locZ) / (double) var2;
				this.motX += var3 * Math.abs(var3) * 0.4D;
				this.motY += var5 * Math.abs(var5) * 0.4D;
				this.motZ += var7 * Math.abs(var7) * 0.4D;
			}

			if (var2 > 10.0F) {
				this.world.getServer().getPluginManager().callEvent(
						new EntityUnleashEvent(this.getBukkitEntity(), EntityUnleashEvent.UnleashReason.DISTANCE));
				this.unleash(true, true);
			}
		} else if (!this.getLeashed() && this.field_110180_bt) {
			this.field_110180_bt = false;
			this.goalSelector.a(this.field_110178_bs);
			this.getNavigation().a(true);
			this.detachHome();
		}
	}

	protected void func_142017_o(float par1) {
	}
}
