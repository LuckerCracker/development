package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import org.bukkit.event.block.BlockRedstoneEvent;

public class BlockRedstoneWire extends Block
{
    /**
     * When false, power transmission methods do not look at other redstone wires. Used internally during
     * updateCurrentStrength.
     */
    private boolean wiresProvidePower = true;
    private Set blocksNeedingUpdate = new HashSet();

    public BlockRedstoneWire(int par1)
    {
        super(par1, Material.ORIENTABLE);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.0625F, 1.0F);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return null;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 5;
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return world.doesBlockHaveSolidTopSurface(i, j - 1, k) || world.getTypeId(i, j - 1, k) == Block.GLOWSTONE.id;
    }

    /**
     * Sets the strength of the wire current (0-15) for this block based on neighboring blocks and propagates to
     * neighboring redstone wires
     */
    private void updateAndPropagateCurrentStrength(World par1World, int par2, int par3, int par4)
    {
        this.calculateCurrentChanges(par1World, par2, par3, par4, par2, par3, par4);
        ArrayList var5 = new ArrayList(this.blocksNeedingUpdate);
        this.blocksNeedingUpdate.clear();

        for (int var6 = 0; var6 < var5.size(); ++var6)
        {
            ChunkPosition var7 = (ChunkPosition)var5.get(var6);
            par1World.applyPhysics(var7.x, var7.y, var7.z, this.id);
        }
    }

    private void calculateCurrentChanges(World par1World, int par2, int par3, int par4, int par5, int par6, int par7)
    {
        int var8 = par1World.getData(par2, par3, par4);
        byte var9 = 0;
        int var10 = this.getPower(par1World, par5, par6, par7, var9);
        this.wiresProvidePower = false;
        int var11 = par1World.getHighestNeighborSignal(par2, par3, par4);
        this.wiresProvidePower = true;

        if (var11 > 0 && var11 > var10 - 1)
        {
            var10 = var11;
        }

        int var12 = 0;

        for (int var13 = 0; var13 < 4; ++var13)
        {
            int var14 = par2;
            int var15 = par4;

            if (var13 == 0)
            {
                var14 = par2 - 1;
            }

            if (var13 == 1)
            {
                ++var14;
            }

            if (var13 == 2)
            {
                var15 = par4 - 1;
            }

            if (var13 == 3)
            {
                ++var15;
            }

            if (var14 != par5 || var15 != par7)
            {
                var12 = this.getPower(par1World, var14, par3, var15, var12);
            }

            if (par1World.isBlockNormalCube(var14, par3, var15) && !par1World.isBlockNormalCube(par2, par3 + 1, par4))
            {
                if ((var14 != par5 || var15 != par7) && par3 >= par6)
                {
                    var12 = this.getPower(par1World, var14, par3 + 1, var15, var12);
                }
            }
            else if (!par1World.isBlockNormalCube(var14, par3, var15) && (var14 != par5 || var15 != par7) && par3 <= par6)
            {
                var12 = this.getPower(par1World, var14, par3 - 1, var15, var12);
            }
        }

        if (var12 > var10)
        {
            var10 = var12 - 1;
        }
        else if (var10 > 0)
        {
            --var10;
        }
        else
        {
            var10 = 0;
        }

        if (var11 > var10 - 1)
        {
            var10 = var11;
        }

        if (var8 != var10)
        {
            BlockRedstoneEvent var16 = new BlockRedstoneEvent(par1World.getWorld().getBlockAt(par2, par3, par4), var8, var10);
            par1World.getServer().getPluginManager().callEvent(var16);
            var10 = var16.getNewCurrent();
        }

        if (var8 != var10)
        {
            par1World.setData(par2, par3, par4, var10, 2);
            this.blocksNeedingUpdate.add(new ChunkPosition(par2, par3, par4));
            this.blocksNeedingUpdate.add(new ChunkPosition(par2 - 1, par3, par4));
            this.blocksNeedingUpdate.add(new ChunkPosition(par2 + 1, par3, par4));
            this.blocksNeedingUpdate.add(new ChunkPosition(par2, par3 - 1, par4));
            this.blocksNeedingUpdate.add(new ChunkPosition(par2, par3 + 1, par4));
            this.blocksNeedingUpdate.add(new ChunkPosition(par2, par3, par4 - 1));
            this.blocksNeedingUpdate.add(new ChunkPosition(par2, par3, par4 + 1));
        }
    }

    /**
     * Calls World.notifyBlocksOfNeighborChange() for all neighboring blocks, but only if the given block is a redstone
     * wire.
     */
    private void notifyWireNeighborsOfNeighborChange(World par1World, int par2, int par3, int par4)
    {
        if (par1World.getTypeId(par2, par3, par4) == this.id)
        {
            par1World.applyPhysics(par2, par3, par4, this.id);
            par1World.applyPhysics(par2 - 1, par3, par4, this.id);
            par1World.applyPhysics(par2 + 1, par3, par4, this.id);
            par1World.applyPhysics(par2, par3, par4 - 1, this.id);
            par1World.applyPhysics(par2, par3, par4 + 1, this.id);
            par1World.applyPhysics(par2, par3 - 1, par4, this.id);
            par1World.applyPhysics(par2, par3 + 1, par4, this.id);
        }
    }

    public void onPlace(World world, int i, int j, int k)
    {
        super.onPlace(world, i, j, k);

        if (!world.isStatic)
        {
            this.updateAndPropagateCurrentStrength(world, i, j, k);
            world.applyPhysics(i, j + 1, k, this.id);
            world.applyPhysics(i, j - 1, k, this.id);
            this.notifyWireNeighborsOfNeighborChange(world, i - 1, j, k);
            this.notifyWireNeighborsOfNeighborChange(world, i + 1, j, k);
            this.notifyWireNeighborsOfNeighborChange(world, i, j, k - 1);
            this.notifyWireNeighborsOfNeighborChange(world, i, j, k + 1);

            if (world.isBlockNormalCube(i - 1, j, k))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i - 1, j + 1, k);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i - 1, j - 1, k);
            }

            if (world.isBlockNormalCube(i + 1, j, k))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i + 1, j + 1, k);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i + 1, j - 1, k);
            }

            if (world.isBlockNormalCube(i, j, k - 1))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k - 1);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k - 1);
            }

            if (world.isBlockNormalCube(i, j, k + 1))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k + 1);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k + 1);
            }
        }
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        super.remove(world, i, j, k, l, i1);

        if (!world.isStatic)
        {
            world.applyPhysics(i, j + 1, k, this.id);
            world.applyPhysics(i, j - 1, k, this.id);
            world.applyPhysics(i + 1, j, k, this.id);
            world.applyPhysics(i - 1, j, k, this.id);
            world.applyPhysics(i, j, k + 1, this.id);
            world.applyPhysics(i, j, k - 1, this.id);
            this.updateAndPropagateCurrentStrength(world, i, j, k);
            this.notifyWireNeighborsOfNeighborChange(world, i - 1, j, k);
            this.notifyWireNeighborsOfNeighborChange(world, i + 1, j, k);
            this.notifyWireNeighborsOfNeighborChange(world, i, j, k - 1);
            this.notifyWireNeighborsOfNeighborChange(world, i, j, k + 1);

            if (world.isBlockNormalCube(i - 1, j, k))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i - 1, j + 1, k);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i - 1, j - 1, k);
            }

            if (world.isBlockNormalCube(i + 1, j, k))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i + 1, j + 1, k);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i + 1, j - 1, k);
            }

            if (world.isBlockNormalCube(i, j, k - 1))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k - 1);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k - 1);
            }

            if (world.isBlockNormalCube(i, j, k + 1))
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j + 1, k + 1);
            }
            else
            {
                this.notifyWireNeighborsOfNeighborChange(world, i, j - 1, k + 1);
            }
        }
    }

    public int getPower(World world, int i, int j, int k, int l)
    {
        if (world.getTypeId(i, j, k) != this.id)
        {
            return l;
        }
        else
        {
            int i1 = world.getData(i, j, k);
            return i1 > l ? i1 : l;
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (!world.isStatic)
        {
            boolean flag = this.canPlace(world, i, j, k);

            if (flag)
            {
                this.updateAndPropagateCurrentStrength(world, i, j, k);
            }
            else
            {
                this.dropBlockAsItem(world, i, j, k, 0, 0);
                world.setAir(i, j, k);
            }

            super.doPhysics(world, i, j, k, l);
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Item.REDSTONE.id;
    }

    /**
     * Returns true if the block is emitting direct/strong redstone power on the specified side. Args: World, X, Y, Z,
     * side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingStrongPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        return !this.wiresProvidePower ? 0 : this.isProvidingWeakPower(par1IBlockAccess, par2, par3, par4, par5);
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        if (!this.wiresProvidePower)
        {
            return 0;
        }
        else
        {
            int var6 = par1IBlockAccess.getData(par2, par3, par4);

            if (var6 == 0)
            {
                return 0;
            }
            else if (par5 == 1)
            {
                return var6;
            }
            else
            {
                boolean var7 = isPoweredOrRepeater(par1IBlockAccess, par2 - 1, par3, par4, 1) || !par1IBlockAccess.isBlockNormalCube(par2 - 1, par3, par4) && isPoweredOrRepeater(par1IBlockAccess, par2 - 1, par3 - 1, par4, -1);
                boolean var8 = isPoweredOrRepeater(par1IBlockAccess, par2 + 1, par3, par4, 3) || !par1IBlockAccess.isBlockNormalCube(par2 + 1, par3, par4) && isPoweredOrRepeater(par1IBlockAccess, par2 + 1, par3 - 1, par4, -1);
                boolean var9 = isPoweredOrRepeater(par1IBlockAccess, par2, par3, par4 - 1, 2) || !par1IBlockAccess.isBlockNormalCube(par2, par3, par4 - 1) && isPoweredOrRepeater(par1IBlockAccess, par2, par3 - 1, par4 - 1, -1);
                boolean var10 = isPoweredOrRepeater(par1IBlockAccess, par2, par3, par4 + 1, 0) || !par1IBlockAccess.isBlockNormalCube(par2, par3, par4 + 1) && isPoweredOrRepeater(par1IBlockAccess, par2, par3 - 1, par4 + 1, -1);

                if (!par1IBlockAccess.isBlockNormalCube(par2, par3 + 1, par4))
                {
                    if (par1IBlockAccess.isBlockNormalCube(par2 - 1, par3, par4) && isPoweredOrRepeater(par1IBlockAccess, par2 - 1, par3 + 1, par4, -1))
                    {
                        var7 = true;
                    }

                    if (par1IBlockAccess.isBlockNormalCube(par2 + 1, par3, par4) && isPoweredOrRepeater(par1IBlockAccess, par2 + 1, par3 + 1, par4, -1))
                    {
                        var8 = true;
                    }

                    if (par1IBlockAccess.isBlockNormalCube(par2, par3, par4 - 1) && isPoweredOrRepeater(par1IBlockAccess, par2, par3 + 1, par4 - 1, -1))
                    {
                        var9 = true;
                    }

                    if (par1IBlockAccess.isBlockNormalCube(par2, par3, par4 + 1) && isPoweredOrRepeater(par1IBlockAccess, par2, par3 + 1, par4 + 1, -1))
                    {
                        var10 = true;
                    }
                }

                return !var9 && !var8 && !var7 && !var10 && par5 >= 2 && par5 <= 5 ? var6 : (par5 == 2 && var9 && !var7 && !var8 ? var6 : (par5 == 3 && var10 && !var7 && !var8 ? var6 : (par5 == 4 && var7 && !var9 && !var10 ? var6 : (par5 == 5 && var8 && !var9 && !var10 ? var6 : 0))));
            }
        }
    }

    public boolean isPowerSource()
    {
        return this.wiresProvidePower;
    }

    /**
     * Returns true if redstone wire can connect to the specified block. Params: World, X, Y, Z, side (not a normal
     * notch-side, this can be 0, 1, 2, 3 or -1)
     */
    public static boolean isPowerProviderOrWire(IBlockAccess par0IBlockAccess, int par1, int par2, int par3, int par4)
    {
        int var5 = par0IBlockAccess.getTypeId(par1, par2, par3);

        if (var5 == Block.REDSTONE_WIRE.id)
        {
            return true;
        }
        else if (var5 == 0)
        {
            return false;
        }
        else if (!Block.DIODE_OFF.g(var5))
        {
            return Block.byId[var5].isPowerSource() && par4 != -1;
        }
        else
        {
            int var6 = par0IBlockAccess.getData(par1, par2, par3);
            return par4 == (var6 & 3) || par4 == Direction.rotateOpposite[var6 & 3];
        }
    }

    /**
     * Returns true if the block coordinate passed can provide power, or is a redstone wire, or if its a repeater that
     * is powered.
     */
    public static boolean isPoweredOrRepeater(IBlockAccess par0IBlockAccess, int par1, int par2, int par3, int par4)
    {
        if (isPowerProviderOrWire(par0IBlockAccess, par1, par2, par3, par4))
        {
            return true;
        }
        else
        {
            int var5 = par0IBlockAccess.getTypeId(par1, par2, par3);

            if (var5 == Block.DIODE_ON.id)
            {
                int var6 = par0IBlockAccess.getData(par1, par2, par3);
                return par4 == (var6 & 3);
            }
            else
            {
                return false;
            }
        }
    }
}
