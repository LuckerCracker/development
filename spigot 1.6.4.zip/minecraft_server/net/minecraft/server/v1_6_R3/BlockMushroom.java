package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Random;
import org.bukkit.BlockChangeDelegate;
import org.bukkit.Location;
import org.bukkit.TreeType;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.world.StructureGrowEvent;

public class BlockMushroom extends BlockFlower
{
    protected BlockMushroom(int par1)
    {
        super(par1);
        float var2 = 0.2F;
        this.setBlockBounds(0.5F - var2, 0.0F, 0.5F - var2, 0.5F + var2, var2 * 2.0F, 0.5F + var2);
        this.setTickRandomly(true);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (par5Random.nextInt(Math.max(1, (int)par1World.growthOdds / par1World.spigotConfig.mushroomModifier * 25)) == 0)
        {
            byte var9 = 4;
            int var10 = 5;
            int var11;
            int var12;
            int var13;

            for (var11 = par2 - var9; var11 <= par2 + var9; ++var11)
            {
                for (var12 = par4 - var9; var12 <= par4 + var9; ++var12)
                {
                    for (var13 = par3 - 1; var13 <= par3 + 1; ++var13)
                    {
                        if (par1World.getTypeId(var11, var13, var12) == this.id)
                        {
                            --var10;

                            if (var10 <= 0)
                            {
                                return;
                            }
                        }
                    }
                }
            }

            var11 = par2 + par5Random.nextInt(3) - 1;
            var12 = par3 + par5Random.nextInt(2) - par5Random.nextInt(2);
            var13 = par4 + par5Random.nextInt(3) - 1;

            for (int var14 = 0; var14 < 4; ++var14)
            {
                if (par1World.isEmpty(var11, var12, var13) && this.canBlockStay(par1World, var11, var12, var13))
                {
                    par2 = var11;
                    par3 = var12;
                    par4 = var13;
                }

                var11 = par2 + par5Random.nextInt(3) - 1;
                var12 = par3 + par5Random.nextInt(2) - par5Random.nextInt(2);
                var13 = par4 + par5Random.nextInt(3) - 1;
            }

            if (par1World.isEmpty(var11, var12, var13) && this.canBlockStay(par1World, var11, var12, var13))
            {
                CraftWorld var17 = par1World.getWorld();
                BlockState var15 = var17.getBlockAt(var11, var12, var13).getState();
                var15.setTypeId(this.id);
                BlockSpreadEvent var16 = new BlockSpreadEvent(var15.getBlock(), var17.getBlockAt(par2, par3, par4), var15);
                par1World.getServer().getPluginManager().callEvent(var16);

                if (!var16.isCancelled())
                {
                    var15.update(true);
                }
            }
        }
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return super.canPlace(world, i, j, k) && this.canBlockStay(world, i, j, k);
    }

    /**
     * Gets passed in the blockID of the block below and supposed to return true if its allowed to grow on the type of
     * blockID passed in. Args: blockID
     */
    protected boolean canThisPlantGrowOnThisBlockID(int par1)
    {
        return Block.opaqueCubeLookup[par1];
    }

    /**
     * Can this block stay at this position.  Similar to canPlaceBlockAt except gets checked often with plants.
     */
    public boolean canBlockStay(World par1World, int par2, int par3, int par4)
    {
        if (par3 >= 0 && par3 < 256)
        {
            int var5 = par1World.getTypeId(par2, par3 - 1, par4);
            return var5 == Block.MYCEL.id || par1World.getFullBlockLightValue(par2, par3, par4) < 13 && this.canThisPlantGrowOnThisBlockID(var5);
        }
        else
        {
            return false;
        }
    }

    public boolean grow(World world, int i, int j, int k, Random random, boolean bonemeal, Player player, ItemStack itemstack)
    {
        int l = world.getData(i, j, k);
        world.setAir(i, j, k);
        boolean grown = false;
        StructureGrowEvent event = null;
        Location location = new Location(world.getWorld(), (double)i, (double)j, (double)k);
        WorldGenHugeMushroom worldgenhugemushroom = null;

        if (this.id == Block.BROWN_MUSHROOM.id)
        {
            event = new StructureGrowEvent(location, TreeType.BROWN_MUSHROOM, bonemeal, player, new ArrayList());
            worldgenhugemushroom = new WorldGenHugeMushroom(0);
        }
        else if (this.id == Block.RED_MUSHROOM.id)
        {
            event = new StructureGrowEvent(location, TreeType.RED_MUSHROOM, bonemeal, player, new ArrayList());
            worldgenhugemushroom = new WorldGenHugeMushroom(1);
        }

        if (worldgenhugemushroom != null && event != null)
        {
            grown = worldgenhugemushroom.grow((BlockChangeDelegate)world, random, i, j, k, event, itemstack, world.getWorld());

            if (event.isFromBonemeal() && itemstack != null)
            {
                --itemstack.count;
            }
        }

        if (grown && !event.isCancelled())
        {
            return true;
        }
        else
        {
            world.setTypeIdAndData(i, j, k, this.id, l, 3);
            return false;
        }
    }
}
