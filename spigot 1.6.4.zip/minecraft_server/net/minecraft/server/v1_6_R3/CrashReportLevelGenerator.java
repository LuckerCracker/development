package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportLevelGenerator implements Callable
{
    final WorldData a;

    CrashReportLevelGenerator(WorldData var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return String.format("ID %02d - %s, ver %d. Features enabled: %b", new Object[] {Integer.valueOf(WorldData.a(this.a).getWorldTypeID()), WorldData.a(this.a).name(), Integer.valueOf(WorldData.a(this.a).getVersion()), Boolean.valueOf(WorldData.b(this.a))});
    }

    public Object call()
    {
        return this.a();
    }
}
