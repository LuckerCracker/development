package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockSnow extends Block
{
    protected BlockSnow(int par1)
    {
        super(par1, Material.SNOW_LAYER);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
        this.setTickRandomly(true);
        this.a(CreativeModeTab.c);
        this.setBlockBoundsForSnowDepth(0);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4) & 7;
        float var6 = 0.125F;
        return AxisAlignedBB.getAABBPool().getAABB((double)par2 + this.minX, (double)par3 + this.minY, (double)par4 + this.minZ, (double)par2 + this.maxX, (double)((float)par3 + (float)var5 * var6), (double)par4 + this.maxZ);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        this.setBlockBoundsForSnowDepth(0);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        this.setBlockBoundsForSnowDepth(iblockaccess.getData(i, j, k));
    }

    /**
     * calls setBlockBounds based on the depth of the snow. Int is any values 0x0-0x7, usually this blocks metadata.
     */
    protected void setBlockBoundsForSnowDepth(int par1)
    {
        int var2 = par1 & 7;
        float var3 = (float)(2 * (1 + var2)) / 16.0F;
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, var3, 1.0F);
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j - 1, k);
        return l == 0 ? false : (l == this.id && (world.getData(i, j - 1, k) & 7) == 7 ? true : (l != Block.LEAVES.id && !Block.byId[l].isOpaqueCube() ? false : world.getMaterial(i, j - 1, k).isSolid()));
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        this.canSnowStay(world, i, j, k);
    }

    /**
     * Checks if this snow block can stay at this location.
     */
    private boolean canSnowStay(World par1World, int par2, int par3, int par4)
    {
        if (!this.canPlace(par1World, par2, par3, par4))
        {
            this.dropBlockAsItem(par1World, par2, par3, par4, par1World.getData(par2, par3, par4), 0);
            par1World.setAir(par2, par3, par4);
            return false;
        }
        else
        {
            return true;
        }
    }

    public void a(World world, EntityHuman entityhuman, int i, int j, int k, int l)
    {
        int i1 = Item.SNOW_BALL.id;
        int j1 = l & 7;
        this.dropBlockAsItem_do(world, i, j, k, new ItemStack(i1, j1 + 1, 0));
        world.setAir(i, j, k);
        entityhuman.addStat(StatisticList.C[this.id], 1);
    }

    public int getDropType(int i, Random random, int j)
    {
        return Item.SNOW_BALL.id;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 0;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (par1World.getSavedLightValue(EnumSkyBlock.BLOCK, par2, par3, par4) > 11)
        {
            if (CraftEventFactory.callBlockFadeEvent(par1World.getWorld().getBlockAt(par2, par3, par4), 0).isCancelled())
            {
                return;
            }

            this.dropBlockAsItem(par1World, par2, par3, par4, par1World.getData(par2, par3, par4), 0);
            par1World.setAir(par2, par3, par4);
        }
    }
}
