package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;

public class EntityWither extends EntityMonster implements IRangedEntity {
	private float[] field_82220_d = new float[2];
	private float[] field_82221_e = new float[2];
	private float[] field_82217_f = new float[2];
	private float[] field_82218_g = new float[2];
	private int[] field_82223_h = new int[2];
	private int[] field_82224_i = new int[2];
	private int field_82222_j;

	/** Selector used to determine the entities a wither boss should attack. */
	private static final IEntitySelector attackEntitySelector = new EntitySelectorNotUndead();

	public EntityWither(World par1World) {
		super(par1World);
		this.setHealth(this.getMaxHealth());
		this.setSize(0.9F, 4.0F);
		this.fireProof = true;
		this.getNavigation().e(true);
		this.goalSelector.a(0, new PathfinderGoalFloat(this));
		this.goalSelector.a(2, new PathfinderGoalArrowAttack(this, 1.0D, 40, 20.0F));
		this.goalSelector.a(5, new PathfinderGoalRandomStroll(this, 1.0D));
		this.goalSelector.a(6, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
		this.goalSelector.a(7, new PathfinderGoalRandomLookaround(this));
		this.targetSelector.a(1, new PathfinderGoalHurtByTarget(this, false));
		this.targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, EntityInsentient.class, 0, false,
				false, attackEntitySelector));
		this.experienceValue = 50;
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(17, new Integer(0));
		this.datawatcher.addObject(18, new Integer(0));
		this.datawatcher.addObject(19, new Integer(0));
		this.datawatcher.addObject(20, new Integer(0));
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setInt("Invul", this.func_82212_n());
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.func_82215_s(par1NBTTagCompound.getInt("Invul"));
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return "mob.wither.idle";
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.wither.hurt";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.wither.death";
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		this.motY *= 0.6000000238418579D;
		double var4;
		double var6;
		double var8;

		if (!this.world.isStatic && this.getWatchedTargetId(0) > 0) {
			Entity var1 = this.world.getEntity(this.getWatchedTargetId(0));

			if (var1 != null) {
				if (this.locY < var1.locY || !this.isArmored() && this.locY < var1.locY + 5.0D) {
					if (this.motY < 0.0D) {
						this.motY = 0.0D;
					}

					this.motY += (0.5D - this.motY) * 0.6000000238418579D;
				}

				double var2 = var1.locX - this.locX;
				var4 = var1.locZ - this.locZ;
				var6 = var2 * var2 + var4 * var4;

				if (var6 > 9.0D) {
					var8 = (double) MathHelper.sqrt(var6);
					this.motX += (var2 / var8 * 0.5D - this.motX) * 0.6000000238418579D;
					this.motZ += (var4 / var8 * 0.5D - this.motZ) * 0.6000000238418579D;
				}
			}
		}

		if (this.motX * this.motX + this.motZ * this.motZ > 0.05000000074505806D) {
			this.yaw = (float) Math.atan2(this.motZ, this.motX) * (180F / (float) Math.PI) - 90.0F;
		}

		super.onLivingUpdate();
		int var22;

		for (var22 = 0; var22 < 2; ++var22) {
			this.field_82218_g[var22] = this.field_82221_e[var22];
			this.field_82217_f[var22] = this.field_82220_d[var22];
		}

		int var10;
		double var12;
		double var14;
		double var16;

		for (var22 = 0; var22 < 2; ++var22) {
			var10 = this.getWatchedTargetId(var22 + 1);
			Entity var11 = null;

			if (var10 > 0) {
				var11 = this.world.getEntity(var10);
			}

			if (var11 != null) {
				var4 = this.func_82214_u(var22 + 1);
				var6 = this.func_82208_v(var22 + 1);
				var8 = this.func_82213_w(var22 + 1);
				var12 = var11.locX - var4;
				var14 = var11.locY + (double) var11.getHeadHeight() - var6;
				var16 = var11.locZ - var8;
				double var18 = (double) MathHelper.sqrt(var12 * var12 + var16 * var16);
				float var20 = (float) (Math.atan2(var16, var12) * 180.0D / Math.PI) - 90.0F;
				float var21 = (float) (-(Math.atan2(var14, var18) * 180.0D / Math.PI));
				this.field_82220_d[var22] = this.func_82204_b(this.field_82220_d[var22], var21, 40.0F);
				this.field_82221_e[var22] = this.func_82204_b(this.field_82221_e[var22], var20, 10.0F);
			} else {
				this.field_82221_e[var22] = this.func_82204_b(this.field_82221_e[var22], this.renderYawOffset, 10.0F);
			}
		}

		boolean var23 = this.isArmored();

		for (var10 = 0; var10 < 3; ++var10) {
			var12 = this.func_82214_u(var10);
			var14 = this.func_82208_v(var10);
			var16 = this.func_82213_w(var10);
			this.world.addParticle("smoke", var12 + this.random.nextGaussian() * 0.30000001192092896D,
					var14 + this.random.nextGaussian() * 0.30000001192092896D,
					var16 + this.random.nextGaussian() * 0.30000001192092896D, 0.0D, 0.0D, 0.0D);

			if (var23 && this.world.random.nextInt(4) == 0) {
				this.world.addParticle("mobSpell", var12 + this.random.nextGaussian() * 0.30000001192092896D,
						var14 + this.random.nextGaussian() * 0.30000001192092896D,
						var16 + this.random.nextGaussian() * 0.30000001192092896D, 0.699999988079071D,
						0.699999988079071D, 0.5D);
			}
		}

		if (this.func_82212_n() > 0) {
			for (var10 = 0; var10 < 3; ++var10) {
				this.world.addParticle("mobSpell", this.locX + this.random.nextGaussian() * 1.0D,
						this.locY + (double) (this.random.nextFloat() * 3.3F),
						this.locZ + this.random.nextGaussian() * 1.0D, 0.699999988079071D, 0.699999988079071D,
						0.8999999761581421D);
			}
		}
	}

	protected void updateAITasks() {
		int var1;

		if (this.func_82212_n() > 0) {
			var1 = this.func_82212_n() - 1;

			if (var1 <= 0) {
				ExplosionPrimeEvent var2 = new ExplosionPrimeEvent(this.getBukkitEntity(), 7.0F, false);
				this.world.getServer().getPluginManager().callEvent(var2);

				if (!var2.isCancelled()) {
					this.world.createExplosion(this, this.locX, this.locY + (double) this.getHeadHeight(), this.locZ,
							var2.getRadius(), var2.getFire(), this.world.getGameRules().getBoolean("mobGriefing"));
				}

				this.world.createExplosion(this, this.locX, this.locY + (double) this.getHeadHeight(), this.locZ, 7.0F,
						false, this.world.getGameRules().getBoolean("mobGriefing"));
				this.world.func_82739_e(1013, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
			}

			this.func_82215_s(var1);

			if (this.ticksLived % 10 == 0) {
				this.heal(10.0F, EntityRegainHealthEvent.RegainReason.WITHER_SPAWN);
			}
		} else {
			super.updateAITasks();
			int var3;
			int var18;

			for (var1 = 1; var1 < 3; ++var1) {
				if (this.ticksLived >= this.field_82223_h[var1 - 1]) {
					this.field_82223_h[var1 - 1] = this.ticksLived + 10 + this.random.nextInt(10);
					int var4;

					if (this.world.difficulty >= 2) {
						var3 = var1 - 1;
						var4 = this.field_82224_i[var1 - 1];
						this.field_82224_i[var3] = this.field_82224_i[var1 - 1] + 1;

						if (var4 > 15) {
							float var5 = 10.0F;
							float var6 = 5.0F;
							double var7 = MathHelper.getRandomDoubleInRange(this.random, this.locX - (double) var5,
									this.locX + (double) var5);
							double var9 = MathHelper.getRandomDoubleInRange(this.random, this.locY - (double) var6,
									this.locY + (double) var6);
							double var11 = MathHelper.getRandomDoubleInRange(this.random, this.locZ - (double) var5,
									this.locZ + (double) var5);
							this.func_82209_a(var1 + 1, var7, var9, var11, true);
							this.field_82224_i[var1 - 1] = 0;
						}
					}

					var18 = this.getWatchedTargetId(var1);

					if (var18 > 0) {
						Entity var19 = this.world.getEntity(var18);

						if (var19 != null && var19.isAlive() && this.getDistanceSqToEntity(var19) <= 900.0D
								&& this.canEntityBeSeen(var19)) {
							this.a(var1 + 1, (EntityLiving) var19);
							this.field_82223_h[var1 - 1] = this.ticksLived + 40 + this.random.nextInt(20);
							this.field_82224_i[var1 - 1] = 0;
						} else {
							this.func_82211_c(var1, 0);
						}
					} else {
						List var20 = this.world.selectEntitiesWithinAABB(EntityLiving.class,
								this.boundingBox.grow(20.0D, 8.0D, 20.0D), attackEntitySelector);

						for (var4 = 0; var4 < 10 && !var20.isEmpty(); ++var4) {
							EntityLiving var22 = (EntityLiving) var20.get(this.random.nextInt(var20.size()));

							if (var22 != this && var22.isAlive() && this.canEntityBeSeen(var22)) {
								if (var22 instanceof EntityHuman) {
									if (!((EntityHuman) var22).abilities.isInvulnerable) {
										this.func_82211_c(var1, var22.id);
									}
								} else {
									this.func_82211_c(var1, var22.id);
								}

								break;
							}

							var20.remove(var22);
						}
					}
				}
			}

			if (this.getGoalTarget() != null) {
				this.func_82211_c(0, this.getGoalTarget().id);
			} else {
				this.func_82211_c(0, 0);
			}

			if (this.field_82222_j > 0) {
				--this.field_82222_j;

				if (this.field_82222_j == 0 && this.world.getGameRules().getBoolean("mobGriefing")) {
					var1 = MathHelper.floor(this.locY);
					var18 = MathHelper.floor(this.locX);
					var3 = MathHelper.floor(this.locZ);
					boolean var21 = false;

					for (int var23 = -1; var23 <= 1; ++var23) {
						for (int var24 = -1; var24 <= 1; ++var24) {
							for (int var13 = 0; var13 <= 3; ++var13) {
								int var14 = var18 + var23;
								int var15 = var1 + var13;
								int var16 = var3 + var24;
								int var17 = this.world.getTypeId(var14, var15, var16);

								if (var17 > 0 && var17 != Block.BEDROCK.id && var17 != Block.ENDER_PORTAL.id
										&& var17 != Block.ENDER_PORTAL_FRAME.id
										&& !CraftEventFactory
												.callEntityChangeBlockEvent(this, var14, var15, var16, 0, 0)
												.isCancelled()) {
									var21 = this.world.setAir(var14, var15, var16, true) || var21;
								}
							}
						}
					}

					if (var21) {
						this.world.a((EntityHuman) null, 1012, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
					}
				}
			}

			if (this.ticksLived % 20 == 0) {
				this.heal(1.0F);
			}
		}
	}

	public void func_82206_m() {
		this.func_82215_s(220);
		this.setHealth(this.getMaxHealth() / 3.0F);
	}

	/**
	 * Sets the Entity inside a web block.
	 */
	public void setInWeb() {
	}

	/**
	 * Returns the current armor value as determined by a call to
	 * InventoryPlayer.getTotalArmorValue
	 */
	public int getTotalArmorValue() {
		return 4;
	}

	private double func_82214_u(int par1) {
		if (par1 <= 0) {
			return this.locX;
		} else {
			float var2 = (this.renderYawOffset + (float) (180 * (par1 - 1))) / 180.0F * (float) Math.PI;
			float var3 = MathHelper.cos(var2);
			return this.locX + (double) var3 * 1.3D;
		}
	}

	private double func_82208_v(int par1) {
		return par1 <= 0 ? this.locY + 3.0D : this.locY + 2.2D;
	}

	private double func_82213_w(int par1) {
		if (par1 <= 0) {
			return this.locZ;
		} else {
			float var2 = (this.renderYawOffset + (float) (180 * (par1 - 1))) / 180.0F * (float) Math.PI;
			float var3 = MathHelper.sin(var2);
			return this.locZ + (double) var3 * 1.3D;
		}
	}

	private float func_82204_b(float par1, float par2, float par3) {
		float var4 = MathHelper.wrapAngleTo180_float(par2 - par1);

		if (var4 > par3) {
			var4 = par3;
		}

		if (var4 < -par3) {
			var4 = -par3;
		}

		return par1 + var4;
	}

	private void a(int i, EntityLiving entityliving) {
		this.func_82209_a(i, entityliving.locX, entityliving.locY + (double) entityliving.getHeadHeight() * 0.5D,
				entityliving.locZ, i == 0 && this.random.nextFloat() < 0.001F);
	}

	private void func_82209_a(int par1, double par2, double par4, double par6, boolean par8) {
		this.world.a((EntityHuman) null, 1014, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
		double var9 = this.func_82214_u(par1);
		double var11 = this.func_82208_v(par1);
		double var13 = this.func_82213_w(par1);
		double var15 = par2 - var9;
		double var17 = par4 - var11;
		double var19 = par6 - var13;
		EntityWitherSkull var21 = new EntityWitherSkull(this.world, this, var15, var17, var19);

		if (par8) {
			var21.setInvulnerable(true);
		}

		var21.locY = var11;
		var21.locX = var9;
		var21.locZ = var13;
		this.world.addEntity(var21);
	}

	public void a(EntityLiving entityliving, float f) {
		this.a(0, entityliving);
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else if (damagesource == DamageSource.DROWN) {
			return false;
		} else if (this.func_82212_n() > 0) {
			return false;
		} else {
			Entity entity;

			if (this.isArmored()) {
				entity = damagesource.getSourceOfDamage();

				if (entity instanceof EntityArrow) {
					return false;
				}
			}

			entity = damagesource.getEntity();

			if (entity != null && !(entity instanceof EntityHuman) && entity instanceof EntityLiving
					&& ((EntityLiving) entity).getMonsterType() == this.getMonsterType()) {
				return false;
			} else {
				if (this.field_82222_j <= 0) {
					this.field_82222_j = 20;
				}

				for (int i = 0; i < this.field_82224_i.length; ++i) {
					this.field_82224_i[i] += 3;
				}

				return super.attackEntityFrom(damagesource, f);
			}
		}
	}

	protected void dropDeathLoot(boolean flag, int i) {
		ArrayList loot = new ArrayList();
		loot.add(new org.bukkit.inventory.ItemStack(Item.NETHER_STAR.id, 1));
		CraftEventFactory.callEntityDeathEvent(this, loot);
	}

	/**
	 * Makes the entity despawn if requirements are reached
	 */
	protected void despawnEntity() {
		this.entityAge = 0;
	}

	/**
	 * Returns true if other Entities should be prevented from moving through
	 * this Entity.
	 */
	public boolean canBeCollidedWith() {
		return !this.dead;
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float par1) {
	}

	public void addEffect(MobEffect mobeffect) {
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	protected boolean isAIEnabled() {
		return true;
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.a).setValue(300.0D);
		this.getAttributeInstance(GenericAttributes.d).setValue(0.6000000238418579D);
		this.getAttributeInstance(GenericAttributes.b).setValue(40.0D);
	}

	public int func_82212_n() {
		return this.datawatcher.getInt(20);
	}

	public void func_82215_s(int par1) {
		this.datawatcher.watch(20, Integer.valueOf(par1));
	}

	/**
	 * Returns the target entity ID if present, or -1 if not @param par1 The
	 * target offset, should be from 0-2
	 */
	public int getWatchedTargetId(int par1) {
		return this.datawatcher.getInt(17 + par1);
	}

	public void func_82211_c(int par1, int par2) {
		this.datawatcher.watch(17 + par1, Integer.valueOf(par2));
	}

	/**
	 * Returns whether the wither is armored with its boss armor or not by
	 * checking whether its health is below half of its maximum.
	 */
	public boolean isArmored() {
		return this.getHealth() <= this.getMaxHealth() / 2.0F;
	}

	public EnumMonsterType getMonsterType() {
		return EnumMonsterType.UNDEAD;
	}

	public void mount(Entity entity) {
		this.vehicle = null;
	}
}
