package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public abstract class BlockStepAbstract extends Block {
	/**
	 * used as foreach item, if item.tab = current tab, display it on the screen
	 */
	protected final boolean displayOnCreativeTab;

	public BlockStepAbstract(int var1, boolean var2, Material var3) {
		super(var1, var3);
		this.displayOnCreativeTab = var2;

		if (var2) {
			opaqueCubeLookup[var1] = true;
		} else {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
		}

		this.setLightOpacity(255);
	}

	public void updateShape(IBlockAccess var1, int var2, int var3, int var4) {
		if (this.displayOnCreativeTab) {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		} else {
			boolean var5 = (var1.getData(var2, var3, var4) & 8) != 0;

			if (var5) {
				this.setBlockBounds(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
			} else {
				this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
			}
		}
	}

	/**
	 * Sets the block's bounds for rendering it as an item
	 */
	public void setBlockBoundsForItemRender() {
		if (this.displayOnCreativeTab) {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		} else {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
		}
	}

	/**
	 * Adds all intersecting collision boxes to a list. (Be sure to only add
	 * boxes to the list if they intersect the mask.) Parameters: World, X, Y,
	 * Z, mask, list, colliding entity
	 */
	public void addCollisionBoxesToList(World var1, int var2, int var3, int var4, AxisAlignedBB var5, List var6,
			Entity var7) {
		this.updateShape(var1, var2, var3, var4);
		super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube? This determines whether
	 * or not to render the shared face of two adjacent blocks and also whether
	 * the player can attach torches, redstone wire, etc to this block.
	 */
	public boolean isOpaqueCube() {
		return this.displayOnCreativeTab;
	}

	public int getPlacedData(World var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8,
			int var9) {
		return this.displayOnCreativeTab ? var9 : (var5 != 0 && (var5 == 1 || (double) var7 <= 0.5D) ? var9 : var9 | 8);
	}

	/**
	 * Returns the quantity of items to drop on block destruction.
	 */
	public int quantityDropped(Random var1) {
		return this.displayOnCreativeTab ? 2 : 1;
	}

	public int getDropData(int var1) {
		return var1 & 7;
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False
	 * (examples: signs, buttons, stairs, etc)
	 */
	public boolean renderAsNormalBlock() {
		return this.displayOnCreativeTab;
	}

	public abstract String getFullSlabName(int var1);

	public int getDropData(World var1, int var2, int var3, int var4) {
		return super.getDropData(var1, var2, var3, var4) & 7;
	}
}
