package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;

public class AABBPool
{
    /**
     * Maximum number of times the pool can be "cleaned" before the list is shrunk
     */
    private final int maxNumCleans;

    /**
     * Number of Pool entries to remove when cleanPool is called maxNumCleans times.
     */
    private final int numEntriesToRemove;
    private final List pool = new ArrayList();

    /** Next index to use when adding a Pool Entry. */
    private int nextPoolIndex;
    private int largestSize;
    private int resizeTime;

    public AABBPool(int par1, int par2)
    {
        this.maxNumCleans = par1;
        this.numEntriesToRemove = par2;
    }

    /**
     * Creates a new AABB, or reuses one that's no longer in use. Parameters: minX, minY, minZ, maxX, maxY, maxZ. AABBs
     * returned from this function should only be used for one frame or tick, as after that they will be reused.
     */
    public AxisAlignedBB getAABB(double par1, double par3, double par5, double par7, double par9, double par11)
    {
        if (this.resizeTime == 0)
        {
            return new AxisAlignedBB(par1, par3, par5, par7, par9, par11);
        }
        else
        {
            AxisAlignedBB var13;

            if (this.nextPoolIndex >= this.pool.size())
            {
                var13 = new AxisAlignedBB(par1, par3, par5, par7, par9, par11);
                this.pool.add(var13);
            }
            else
            {
                var13 = (AxisAlignedBB)this.pool.get(this.nextPoolIndex);
                var13.setBounds(par1, par3, par5, par7, par9, par11);
            }

            ++this.nextPoolIndex;
            return var13;
        }
    }

    /**
     * Marks the pool as "empty", starting over when adding new entries. If this is called maxNumCleans times, the list
     * size is reduced
     */
    public void cleanPool()
    {
        if (this.nextPoolIndex > this.largestSize)
        {
            this.largestSize = this.nextPoolIndex;
        }

        if ((this.resizeTime++ & 255) == 0)
        {
            int var1 = this.pool.size() - (this.pool.size() >> 3);

            if (var1 > this.largestSize)
            {
                for (int var2 = this.pool.size() - 1; var2 > var1; --var2)
                {
                    this.pool.remove(var2);
                }
            }

            this.largestSize = 0;
        }

        this.nextPoolIndex = 0;
    }

    public int getlistAABBsize()
    {
        return this.pool.size();
    }

    public int getnextPoolIndex()
    {
        return this.nextPoolIndex;
    }
}
