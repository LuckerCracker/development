package net.minecraft.server.v1_6_R3;

import java.util.Arrays;
import java.util.List;

public class CommandTell extends CommandAbstract
{
    public List getCommandAliases()
    {
        return Arrays.asList(new String[] {"w", "msg"});
    }

    public String getCommandName()
    {
        return "tell";
    }

    public int a()
    {
        return 0;
    }

    public String c(ICommandListener var1)
    {
        return "commands.message.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length < 2)
        {
            throw new ExceptionUsage("commands.message.usage", new Object[0]);
        }
        else
        {
            EntityPlayer var3 = d(var1, var2[0]);

            if (var3 == null)
            {
                throw new ExceptionPlayerNotFound();
            }
            else if (var3 == var1)
            {
                throw new ExceptionPlayerNotFound("commands.message.sameTarget", new Object[0]);
            }
            else
            {
                String var4 = a(var1, var2, 1, !(var1 instanceof EntityHuman));
                var3.sendMessage(ChatMessage.b("commands.message.display.incoming", new Object[] {var1.getName(), var4}).a(EnumChatFormat.GRAY).b(Boolean.valueOf(true)));
                var1.sendMessage(ChatMessage.b("commands.message.display.outgoing", new Object[] {var3.getName(), var4}).a(EnumChatFormat.GRAY).b(Boolean.valueOf(true)));
            }
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return a(var2, MinecraftServer.getServer().getPlayers());
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return var2 == 0;
    }
}
