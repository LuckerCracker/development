package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportLevelSeed implements Callable
{
    final WorldData a;

    CrashReportLevelSeed(WorldData var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return String.valueOf(this.a.getSeed());
    }

    public Object call()
    {
        return this.a();
    }
}
