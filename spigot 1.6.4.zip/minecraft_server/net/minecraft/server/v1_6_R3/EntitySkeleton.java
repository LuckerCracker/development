package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Calendar;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.entity.EntityCombustEvent;

public class EntitySkeleton extends EntityMonster implements IRangedEntity
{
    private PathfinderGoalArrowAttack aiArrowAttack = new PathfinderGoalArrowAttack(this, 1.0D, 20, 60, 15.0F);
    private PathfinderGoalMeleeAttack aiAttackOnCollide = new PathfinderGoalMeleeAttack(this, EntityHuman.class, 1.2D, false);

    public EntitySkeleton(World par1World)
    {
        super(par1World);
        this.goalSelector.a(1, new PathfinderGoalFloat(this));
        this.goalSelector.a(2, new PathfinderGoalRestrictSun(this));
        this.goalSelector.a(3, new PathfinderGoalFleeSun(this, 1.0D));
        this.goalSelector.a(5, new PathfinderGoalRandomStroll(this, 1.0D));
        this.goalSelector.a(6, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
        this.goalSelector.a(6, new PathfinderGoalRandomLookaround(this));
        this.targetSelector.a(1, new PathfinderGoalHurtByTarget(this, false));
        this.targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, EntityHuman.class, 0, true));

        if (par1World != null && !par1World.isStatic)
        {
            this.setCombatTask();
        }
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.d).setValue(0.25D);
    }

    protected void entityInit()
    {
        super.entityInit();
        this.datawatcher.addObject(13, new Byte((byte)0));
    }

    /**
     * Returns true if the newer Entity AI code should be run
     */
    public boolean isAIEnabled()
    {
        return true;
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return "mob.skeleton.say";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.skeleton.hurt";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.skeleton.death";
    }

    /**
     * Plays step sound at given x, y, z for the entity
     */
    protected void playStepSound(int par1, int par2, int par3, int par4)
    {
        this.makeSound("mob.skeleton.step", 0.15F, 1.0F);
    }

    public boolean attackEntityAsMob(Entity par1Entity)
    {
        if (super.attackEntityAsMob(par1Entity))
        {
            if (this.getSkeletonType() == 1 && par1Entity instanceof EntityLiving)
            {
                ((EntityLiving)par1Entity).addEffect(new MobEffect(MobEffectList.WITHER.id, 200));
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public EnumMonsterType getMonsterType()
    {
        return EnumMonsterType.UNDEAD;
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
        if (this.world.isDaytime() && !this.world.isStatic)
        {
            float var1 = this.getBrightness(1.0F);

            if (var1 > 0.5F && this.random.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F && this.world.canBlockSeeTheSky(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ)))
            {
                boolean var2 = true;
                ItemStack var3 = this.getEquipment(4);

                if (var3 != null)
                {
                    if (var3.isItemStackDamageable())
                    {
                        var3.setData(var3.getItemDamageForDisplay() + this.random.nextInt(2));

                        if (var3.getItemDamageForDisplay() >= var3.getMaxDamage())
                        {
                            this.renderBrokenItemStack(var3);
                            this.setEquipment(4, (ItemStack)null);
                        }
                    }

                    var2 = false;
                }

                if (var2)
                {
                    EntityCombustEvent var4 = new EntityCombustEvent(this.getBukkitEntity(), 8);
                    this.world.getServer().getPluginManager().callEvent(var4);

                    if (!var4.isCancelled())
                    {
                        this.setOnFire(var4.getDuration());
                    }
                }
            }
        }

        if (this.world.isStatic && this.getSkeletonType() == 1)
        {
            this.setSize(0.72F, 2.34F);
        }

        super.onLivingUpdate();
    }

    /**
     * Handles updating while being ridden by an entity
     */
    public void updateRidden()
    {
        super.updateRidden();

        if (this.vehicle instanceof EntityCreature)
        {
            EntityCreature var1 = (EntityCreature)this.vehicle;
            this.renderYawOffset = var1.renderYawOffset;
        }
    }

    public void die(DamageSource damagesource)
    {
        super.die(damagesource);

        if (damagesource.getSourceOfDamage() instanceof EntityArrow && damagesource.getEntity() instanceof EntityHuman)
        {
            EntityHuman entityhuman = (EntityHuman)damagesource.getEntity();
            double d0 = entityhuman.locX - this.locX;
            double d1 = entityhuman.locZ - this.locZ;

            if (d0 * d0 + d1 * d1 >= 2500.0D)
            {
                entityhuman.triggerAchievement((Statistic)AchievementList.snipeSkeleton);
            }
        }
    }

    protected int getLootId()
    {
        return Item.ARROW.id;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        ArrayList loot = new ArrayList();
        int count;

        if (this.getSkeletonType() == 1)
        {
            count = this.random.nextInt(3 + i) - 1;

            if (count > 0)
            {
                loot.add(new org.bukkit.inventory.ItemStack(org.bukkit.Material.COAL, count));
            }
        }
        else
        {
            count = this.random.nextInt(3 + i);

            if (count > 0)
            {
                loot.add(new org.bukkit.inventory.ItemStack(org.bukkit.Material.ARROW, count));
            }
        }

        count = this.random.nextInt(3 + i);

        if (count > 0)
        {
            loot.add(new org.bukkit.inventory.ItemStack(org.bukkit.Material.BONE, count));
        }

        if (this.lastDamageByPlayerTime > 0)
        {
            int k = this.random.nextInt(200) - i;

            if (k < 5)
            {
                ItemStack itemstack = this.l(k <= 0 ? 1 : 0);

                if (itemstack != null)
                {
                    loot.add(CraftItemStack.asCraftMirror(itemstack));
                }
            }
        }

        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    protected ItemStack l(int i)
    {
        return this.getSkeletonType() == 1 ? new ItemStack(Item.SKULL.id, 1, 1) : null;
    }

    /**
     * Makes entity wear random armor based on difficulty
     */
    protected void addRandomArmor()
    {
        super.addRandomArmor();
        this.setEquipment(0, new ItemStack(Item.BOW));
    }

    public GroupDataEntity a(GroupDataEntity groupdataentity)
    {
        groupdataentity = super.a(groupdataentity);

        if (this.world.worldProvider instanceof WorldProviderHell && this.getRNG().nextInt(5) > 0)
        {
            this.goalSelector.a(4, this.aiAttackOnCollide);
            this.setSkeletonType(1);
            this.setEquipment(0, new ItemStack(Item.STONE_SWORD));
            this.getAttributeInstance(GenericAttributes.e).setValue(4.0D);
        }
        else
        {
            this.goalSelector.a(4, this.aiArrowAttack);
            this.addRandomArmor();
            this.enchantEquipment();
        }

        this.setCanPickUpLoot(this.random.nextFloat() < 0.55F * this.world.getLocationTensionFactor(this.locX, this.locY, this.locZ));

        if (this.getEquipment(4) == null)
        {
            Calendar calendar = this.world.getCurrentDate();

            if (calendar.get(2) + 1 == 10 && calendar.get(5) == 31 && this.random.nextFloat() < 0.25F)
            {
                this.setEquipment(4, new ItemStack(this.random.nextFloat() < 0.1F ? Block.JACK_O_LANTERN : Block.PUMPKIN));
                this.dropChances[4] = 0.0F;
            }
        }

        return groupdataentity;
    }

    /**
     * sets this entity's combat AI.
     */
    public void setCombatTask()
    {
        this.goalSelector.a((PathfinderGoal)this.aiAttackOnCollide);
        this.goalSelector.a((PathfinderGoal)this.aiArrowAttack);
        ItemStack var1 = this.getHeldItem();

        if (var1 != null && var1.id == Item.BOW.id)
        {
            this.goalSelector.a(4, this.aiArrowAttack);
        }
        else
        {
            this.goalSelector.a(4, this.aiAttackOnCollide);
        }
    }

    public void a(EntityLiving entityliving, float f)
    {
        EntityArrow entityarrow = new EntityArrow(this.world, this, entityliving, 1.6F, (float)(14 - this.world.difficulty * 4));
        int i = EnchantmentManager.getEnchantmentLevel(Enchantment.ARROW_DAMAGE.id, this.getHeldItem());
        int j = EnchantmentManager.getEnchantmentLevel(Enchantment.ARROW_KNOCKBACK.id, this.getHeldItem());
        entityarrow.setDamage((double)(f * 2.0F) + this.random.nextGaussian() * 0.25D + (double)((float)this.world.difficulty * 0.11F));

        if (i > 0)
        {
            entityarrow.setDamage(entityarrow.getDamage() + (double)i * 0.5D + 0.5D);
        }

        if (j > 0)
        {
            entityarrow.setKnockbackStrength(j);
        }

        if (EnchantmentManager.getEnchantmentLevel(Enchantment.ARROW_FIRE.id, this.getHeldItem()) > 0 || this.getSkeletonType() == 1)
        {
            entityarrow.setOnFire(100);
        }

        this.makeSound("random.bow", 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
        this.world.addEntity(entityarrow);
    }

    public int getSkeletonType()
    {
        return this.datawatcher.getByte(13);
    }

    public void setSkeletonType(int i)
    {
        this.datawatcher.watch(13, Byte.valueOf((byte)i));
        this.fireProof = i == 1;

        if (i == 1)
        {
            this.setSize(0.72F, 2.34F);
        }
        else
        {
            this.setSize(0.6F, 1.8F);
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);

        if (par1NBTTagCompound.hasKey("SkeletonType"))
        {
            byte var2 = par1NBTTagCompound.getByte("SkeletonType");
            this.setSkeletonType(var2);
        }

        this.setCombatTask();
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setByte("SkeletonType", (byte)this.getSkeletonType());
    }

    public void setEquipment(int i, ItemStack itemstack)
    {
        super.setEquipment(i, itemstack);

        if (!this.world.isStatic && i == 0)
        {
            this.setCombatTask();
        }
    }

    /**
     * Returns the Y Offset of this entity.
     */
    public double getYOffset()
    {
        return super.getYOffset() - 0.5D;
    }
}
