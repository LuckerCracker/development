package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.Cancellable;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityInteractEvent;

public class BlockSoil extends Block
{
    protected BlockSoil(int i)
    {
        super(i, Material.EARTH);
        this.setTickRandomly(true);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.9375F, 1.0F);
        this.setLightOpacity(255);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        return AxisAlignedBB.getAABBPool().getAABB((double)(i + 0), (double)(j + 0), (double)(k + 0), (double)(i + 1), (double)(j + 1), (double)(k + 1));
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        if (!this.m(world, i, j, k) && !world.isRainingAt(i, j + 1, k))
        {
            int l = world.getData(i, j, k);

            if (l > 0)
            {
                world.setData(i, j, k, l - 1, 2);
            }
            else if (!this.k(world, i, j, k))
            {
                org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);

                if (CraftEventFactory.callBlockFadeEvent(block, Block.DIRT.id).isCancelled())
                {
                    return;
                }

                world.setTypeIdUpdate(i, j, k, Block.DIRT.id);
            }
        }
        else
        {
            world.setData(i, j, k, 7, 2);
        }
    }

    /**
     * Block's chance to react to an entity falling on it.
     */
    public void onFallenUpon(World world, int i, int j, int k, Entity entity, float f)
    {
        if (!world.isStatic && world.random.nextFloat() < f - 0.5F)
        {
            if (!(entity instanceof EntityHuman) && !world.getGameRules().getBoolean("mobGriefing"))
            {
                return;
            }

            Object cancellable;

            if (entity instanceof EntityHuman)
            {
                cancellable = CraftEventFactory.callPlayerInteractEvent((EntityHuman)entity, Action.PHYSICAL, i, j, k, -1, (ItemStack)null);
            }
            else
            {
                cancellable = new EntityInteractEvent(entity.getBukkitEntity(), world.getWorld().getBlockAt(i, j, k));
                world.getServer().getPluginManager().callEvent((EntityInteractEvent)cancellable);
            }

            if (((Cancellable)cancellable).isCancelled())
            {
                return;
            }

            world.setTypeIdUpdate(i, j, k, Block.DIRT.id);
        }
    }

    private boolean k(World world, int i, int j, int k)
    {
        byte b0 = 0;

        for (int l = i - b0; l <= i + b0; ++l)
        {
            for (int i1 = k - b0; i1 <= k + b0; ++i1)
            {
                int j1 = world.getTypeId(l, j + 1, i1);

                if (j1 == Block.CROPS.id || j1 == Block.MELON_STEM.id || j1 == Block.PUMPKIN_STEM.id || j1 == Block.POTATOES.id || j1 == Block.CARROTS.id)
                {
                    return true;
                }
            }
        }

        return false;
    }

    private boolean m(World world, int i, int j, int k)
    {
        for (int l = i - 4; l <= i + 4; ++l)
        {
            for (int i1 = j; i1 <= j + 1; ++i1)
            {
                for (int j1 = k - 4; j1 <= k + 4; ++j1)
                {
                    if (world.getMaterial(l, i1, j1) == Material.WATER)
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        super.doPhysics(world, i, j, k, l);
        Material material = world.getMaterial(i, j + 1, k);

        if (material.isBuildable())
        {
            world.setTypeIdUpdate(i, j, k, Block.DIRT.id);
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Block.DIRT.getDropType(0, random, j);
    }
}
