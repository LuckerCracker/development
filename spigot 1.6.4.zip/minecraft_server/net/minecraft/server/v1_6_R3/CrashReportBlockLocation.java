package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

final class CrashReportBlockLocation implements Callable
{
    final int a;

    final int b;

    final int c;

    CrashReportBlockLocation(int var1, int var2, int var3)
    {
        this.a = var1;
        this.b = var2;
        this.c = var3;
    }

    public String a()
    {
        return CrashReportSystemDetails.a(this.a, this.b, this.c);
    }

    public Object call()
    {
        return this.a();
    }
}
