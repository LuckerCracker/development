package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockDaylightDetector extends BlockContainer
{
    private IIcon[] iconArray = new IIcon[2];

    public BlockDaylightDetector(int par1)
    {
        super(par1, Material.WOOD);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.375F, 1.0F);
        this.a(CreativeModeTab.d);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.375F, 1.0F);
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        return par1IBlockAccess.getData(par2, par3, par4);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random) {}

    public void doPhysics(World world, int i, int j, int k, int l) {}

    public void onPlace(World world, int i, int j, int k) {}

    public void updateLightLevel(World par1World, int par2, int par3, int par4)
    {
        if (!par1World.worldProvider.hasNoSky)
        {
            int var5 = par1World.getData(par2, par3, par4);
            int var6 = par1World.getSavedLightValue(EnumSkyBlock.SKY, par2, par3, par4) - par1World.skylightSubtracted;
            float var7 = par1World.getCelestialAngleRadians(1.0F);

            if (var7 < (float)Math.PI)
            {
                var7 += (0.0F - var7) * 0.2F;
            }
            else
            {
                var7 += (((float)Math.PI * 2F) - var7) * 0.2F;
            }

            var6 = Math.round((float)var6 * MathHelper.cos(var7));

            if (var6 < 0)
            {
                var6 = 0;
            }

            if (var6 > 15)
            {
                var6 = 15;
            }

            if (var5 != var6)
            {
                var6 = CraftEventFactory.callRedstoneChange(par1World, par2, par3, par4, var5, var6).getNewCurrent();
                par1World.setData(par2, par3, par4, var6, 3);
            }
        }
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    public boolean isPowerSource()
    {
        return true;
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityLightDetector();
    }
}
