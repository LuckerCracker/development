package net.minecraft.server.v1_6_R3;

import java.util.Comparator;

public class DistanceComparator implements Comparator
{
    private final Entity a;

    public DistanceComparator(Entity var1)
    {
        this.a = var1;
    }

    public int a(Entity var1, Entity var2)
    {
        double var3 = this.a.getDistanceSqToEntity(var1);
        double var5 = this.a.getDistanceSqToEntity(var2);
        return var3 < var5 ? -1 : (var3 > var5 ? 1 : 0);
    }

    public int compare(Object var1, Object var2)
    {
        return this.a((Entity)var1, (Entity)var2);
    }
}
