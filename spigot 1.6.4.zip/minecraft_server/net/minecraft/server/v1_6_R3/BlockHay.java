package net.minecraft.server.v1_6_R3;

public class BlockHay extends BlockRotatable
{
    public BlockHay(int par1)
    {
        super(par1, Material.GRASS);
        this.a(CreativeModeTab.b);
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 31;
    }
}
