package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockWoodStep extends BlockStepAbstract {
	/** The unlocalized name of this block. */
	public static final String[] unlocalizedName = new String[] { "oak", "spruce", "birch", "jungle" };

	public BlockWoodStep(int var1, boolean var2) {
		super(var1, var2, Material.WOOD);
		this.a(CreativeModeTab.b);
	}

	public int getDropType(int var1, Random var2, int var3) {
		return Block.WOOD_STEP.id;
	}

	/**
	 * Returns an item stack containing a single instance of the current block
	 * type. 'i' is the block's subtype/damage and is ignored for blocks which
	 * do not support subtypes. Blocks which cannot be harvested should return
	 * null.
	 */
	protected ItemStack createStackedBlock(int var1) {
		return new ItemStack(Block.WOOD_STEP.id, 2, var1 & 7);
	}

	public String getFullSlabName(int var1) {
		if (var1 < 0 || var1 >= unlocalizedName.length) {
			var1 = 0;
		}

		return super.getUnlocalizedName() + "." + unlocalizedName[var1];
	}
}
