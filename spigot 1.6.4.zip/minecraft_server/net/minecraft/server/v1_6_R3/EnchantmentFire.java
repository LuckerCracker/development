package net.minecraft.server.v1_6_R3;

public class EnchantmentFire extends Enchantment
{
    protected EnchantmentFire(int var1, int var2)
    {
        super(var1, var2, EnchantmentSlotType.WEAPON);
        this.setName("fire");
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int var1)
    {
        return 10 + 20 * (var1 - 1);
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int var1)
    {
        return super.getMinEnchantability(var1) + 50;
    }

    public int getMaxLevel()
    {
        return 2;
    }
}
