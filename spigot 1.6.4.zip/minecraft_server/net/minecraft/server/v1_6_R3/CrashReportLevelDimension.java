package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportLevelDimension implements Callable
{
    final WorldData a;

    CrashReportLevelDimension(WorldData var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return String.valueOf(WorldData.i(this.a));
    }

    public Object call()
    {
        return this.a();
    }
}
