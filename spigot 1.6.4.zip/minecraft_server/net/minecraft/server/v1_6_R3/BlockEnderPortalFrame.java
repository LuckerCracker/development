package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class BlockEnderPortalFrame extends Block
{
    public BlockEnderPortalFrame(int var1)
    {
        super(var1, Material.STONE);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 26;
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.8125F, 1.0F);
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World var1, int var2, int var3, int var4, AxisAlignedBB var5, List var6, Entity var7)
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.8125F, 1.0F);
        super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
        int var8 = var1.getData(var2, var3, var4);

        if (d(var8))
        {
            this.setBlockBounds(0.3125F, 0.8125F, 0.3125F, 0.6875F, 1.0F, 0.6875F);
            super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
        }

        this.setBlockBoundsForItemRender();
    }

    public static boolean d(int var0)
    {
        return (var0 & 4) != 0;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return 0;
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        int var7 = ((MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3) + 2) % 4;
        var1.setData(var2, var3, var4, var7, 2);
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World var1, int var2, int var3, int var4, int var5)
    {
        int var6 = var1.getData(var2, var3, var4);
        return d(var6) ? 15 : 0;
    }
}
