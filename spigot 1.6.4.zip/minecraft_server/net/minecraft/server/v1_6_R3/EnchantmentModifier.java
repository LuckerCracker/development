package net.minecraft.server.v1_6_R3;

interface EnchantmentModifier
{
    void calculateModifier(Enchantment var1, int var2);
}
