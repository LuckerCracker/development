package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.v1_6_R3.CraftServer;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.event.block.BlockFromToEvent;

public class BlockFlowing extends BlockFluids
{
    /**
     * Number of horizontally adjacent liquid source blocks. Diagonal doesn't count. Only source blocks of the same
     * liquid as the block using the field are counted.
     */
    int numAdjacentSources;

    /**
     * Indicates whether the flow direction is optimal. Each array index corresponds to one of the four cardinal
     * directions.
     */
    boolean[] isOptimalFlowDirection = new boolean[4];

    /**
     * The estimated cost to flow in a given direction from the current point. Each array index corresponds to one of
     * the four cardinal directions.
     */
    int[] flowCost = new int[4];

    protected BlockFlowing(int par1, Material par2Material)
    {
        super(par1, par2Material);
    }

    /**
     * Updates the flow for the BlockFlowing object.
     */
    private void updateFlow(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4);
        par1World.setTypeIdAndData(par2, par3, par4, this.id + 1, var5, 2);
    }

    public boolean getBlocksMovement(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return this.material != Material.LAVA;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        CraftWorld var6 = par1World.getWorld();
        CraftServer var7 = par1World.getServer();
        org.bukkit.block.Block var8 = var6 == null ? null : var6.getBlockAt(par2, par3, par4);
        int var9 = this.l_(par1World, par2, par3, par4);
        byte var10 = 1;

        if (this.material == Material.LAVA && !par1World.worldProvider.isHellWorld)
        {
            var10 = 2;
        }

        boolean var11 = true;
        int var12 = this.tickRate(par1World);
        int var15;
        int var16;

        if (var9 > 0)
        {
            byte var13 = -100;
            this.numAdjacentSources = 0;
            int var14 = this.getSmallestFlowDecay(par1World, par2 - 1, par3, par4, var13);
            var14 = this.getSmallestFlowDecay(par1World, par2 + 1, par3, par4, var14);
            var14 = this.getSmallestFlowDecay(par1World, par2, par3, par4 - 1, var14);
            var14 = this.getSmallestFlowDecay(par1World, par2, par3, par4 + 1, var14);
            var15 = var14 + var10;

            if (var15 >= 8 || var14 < 0)
            {
                var15 = -1;
            }

            if (this.l_(par1World, par2, par3 + 1, par4) >= 0)
            {
                var16 = this.l_(par1World, par2, par3 + 1, par4);

                if (var16 >= 8)
                {
                    var15 = var16;
                }
                else
                {
                    var15 = var16 + 8;
                }
            }

            if (this.numAdjacentSources >= 2 && this.material == Material.WATER)
            {
                if (par1World.getMaterial(par2, par3 - 1, par4).isBuildable())
                {
                    var15 = 0;
                }
                else if (par1World.getMaterial(par2, par3 - 1, par4) == this.material && par1World.getData(par2, par3 - 1, par4) == 0)
                {
                    var15 = 0;
                }
            }

            if (this.material == Material.LAVA && var9 < 8 && var15 < 8 && var15 > var9 && par5Random.nextInt(4) != 0)
            {
                var12 *= 4;
            }

            if (var15 == var9)
            {
                if (var11)
                {
                    this.updateFlow(par1World, par2, par3, par4);
                }
            }
            else
            {
                var9 = var15;

                if (var15 < 0)
                {
                    par1World.setAir(par2, par3, par4);
                }
                else
                {
                    par1World.setData(par2, par3, par4, var15, 2);
                    par1World.scheduleBlockUpdate(par2, par3, par4, this.id, var12);
                    par1World.applyPhysics(par2, par3, par4, this.id);
                }
            }
        }
        else
        {
            this.updateFlow(par1World, par2, par3, par4);
        }

        if (this.liquidCanDisplaceBlock(par1World, par2, par3 - 1, par4))
        {
            BlockFromToEvent var22 = new BlockFromToEvent(var8, BlockFace.DOWN);

            if (var7 != null)
            {
                var7.getPluginManager().callEvent(var22);
            }

            if (!var22.isCancelled())
            {
                if (this.material == Material.LAVA && par1World.getMaterial(par2, par3 - 1, par4) == Material.WATER)
                {
                    par1World.setTypeIdUpdate(par2, par3 - 1, par4, Block.STONE.id);
                    this.fizz(par1World, par2, par3 - 1, par4);
                    return;
                }

                if (var9 >= 8)
                {
                    this.flow(par1World, par2, par3 - 1, par4, var9);
                }
                else
                {
                    this.flow(par1World, par2, par3 - 1, par4, var9 + 8);
                }
            }
        }
        else if (var9 >= 0 && (var9 == 0 || this.blockBlocksFlow(par1World, par2, par3 - 1, par4)))
        {
            boolean[] var23 = this.getOptimalFlowDirections(par1World, par2, par3, par4);
            var15 = var9 + var10;

            if (var9 >= 8)
            {
                var15 = 1;
            }

            if (var15 >= 8)
            {
                return;
            }

            BlockFace[] var24 = new BlockFace[] {BlockFace.WEST, BlockFace.EAST, BlockFace.NORTH, BlockFace.SOUTH};
            var16 = 0;
            BlockFace[] var17 = var24;
            int var18 = var24.length;

            for (int var19 = 0; var19 < var18; ++var19)
            {
                BlockFace var20 = var17[var19];

                if (var23[var16])
                {
                    BlockFromToEvent var21 = new BlockFromToEvent(var8, var20);

                    if (var7 != null)
                    {
                        var7.getPluginManager().callEvent(var21);
                    }

                    if (!var21.isCancelled())
                    {
                        this.flow(par1World, par2 + var20.getModX(), par3, par4 + var20.getModZ(), var15);
                    }
                }

                ++var16;
            }
        }
    }

    private void flow(World world, int i, int j, int k, int l)
    {
        if (this.liquidCanDisplaceBlock(world, i, j, k))
        {
            int i1 = world.getTypeId(i, j, k);

            if (i1 > 0)
            {
                if (this.material == Material.LAVA)
                {
                    this.fizz(world, i, j, k);
                }
                else
                {
                    Block.byId[i1].dropBlockAsItem(world, i, j, k, world.getData(i, j, k), 0);
                }
            }

            world.setTypeIdAndData(i, j, k, this.id, l, 3);
        }
    }

    /**
     * calculateFlowCost(World world, int x, int y, int z, int accumulatedCost, int previousDirectionOfFlow) - Used to
     * determine the path of least resistance, this method returns the lowest possible flow cost for the direction of
     * flow indicated. Each necessary horizontal flow adds to the flow cost.
     */
    private int calculateFlowCost(World par1World, int par2, int par3, int par4, int par5, int par6)
    {
        int var7 = 1000;

        for (int var8 = 0; var8 < 4; ++var8)
        {
            if ((var8 != 0 || par6 != 1) && (var8 != 1 || par6 != 0) && (var8 != 2 || par6 != 3) && (var8 != 3 || par6 != 2))
            {
                int var9 = par2;
                int var10 = par4;

                if (var8 == 0)
                {
                    var9 = par2 - 1;
                }

                if (var8 == 1)
                {
                    ++var9;
                }

                if (var8 == 2)
                {
                    var10 = par4 - 1;
                }

                if (var8 == 3)
                {
                    ++var10;
                }

                if (!this.blockBlocksFlow(par1World, var9, par3, var10) && (par1World.getMaterial(var9, par3, var10) != this.material || par1World.getData(var9, par3, var10) != 0))
                {
                    if (!this.blockBlocksFlow(par1World, var9, par3 - 1, var10))
                    {
                        return par5;
                    }

                    if (par5 < 4)
                    {
                        int var11 = this.calculateFlowCost(par1World, var9, par3, var10, par5 + 1, var8);

                        if (var11 < var7)
                        {
                            var7 = var11;
                        }
                    }
                }
            }
        }

        return var7;
    }

    /**
     * Returns a boolean array indicating which flow directions are optimal based on each direction's calculated flow
     * cost. Each array index corresponds to one of the four cardinal directions. A value of true indicates the
     * direction is optimal.
     */
    private boolean[] getOptimalFlowDirections(World par1World, int par2, int par3, int par4)
    {
        int var5;
        int var6;

        for (var5 = 0; var5 < 4; ++var5)
        {
            this.flowCost[var5] = 1000;
            var6 = par2;
            int var7 = par4;

            if (var5 == 0)
            {
                var6 = par2 - 1;
            }

            if (var5 == 1)
            {
                ++var6;
            }

            if (var5 == 2)
            {
                var7 = par4 - 1;
            }

            if (var5 == 3)
            {
                ++var7;
            }

            if (!this.blockBlocksFlow(par1World, var6, par3, var7) && (par1World.getMaterial(var6, par3, var7) != this.material || par1World.getData(var6, par3, var7) != 0))
            {
                if (this.blockBlocksFlow(par1World, var6, par3 - 1, var7))
                {
                    this.flowCost[var5] = this.calculateFlowCost(par1World, var6, par3, var7, 1, var5);
                }
                else
                {
                    this.flowCost[var5] = 0;
                }
            }
        }

        var5 = this.flowCost[0];

        for (var6 = 1; var6 < 4; ++var6)
        {
            if (this.flowCost[var6] < var5)
            {
                var5 = this.flowCost[var6];
            }
        }

        for (var6 = 0; var6 < 4; ++var6)
        {
            this.isOptimalFlowDirection[var6] = this.flowCost[var6] == var5;
        }

        return this.isOptimalFlowDirection;
    }

    /**
     * Returns true if block at coords blocks fluids
     */
    private boolean blockBlocksFlow(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getTypeId(par2, par3, par4);

        if (var5 != Block.WOODEN_DOOR.id && var5 != Block.IRON_DOOR_BLOCK.id && var5 != Block.SIGN_POST.id && var5 != Block.LADDER.id && var5 != Block.SUGAR_CANE_BLOCK.id)
        {
            if (var5 == 0)
            {
                return false;
            }
            else
            {
                Material var6 = Block.byId[var5].material;
                return var6 == Material.PORTAL ? true : var6.isSolid();
            }
        }
        else
        {
            return true;
        }
    }

    /**
     * getSmallestFlowDecay(World world, intx, int y, int z, int currentSmallestFlowDecay) - Looks up the flow decay at
     * the coordinates given and returns the smaller of this value or the provided currentSmallestFlowDecay. If one
     * value is valid and the other isn't, the valid value will be returned. Valid values are >= 0. Flow decay is the
     * amount that a liquid has dissipated. 0 indicates a source block.
     */
    protected int getSmallestFlowDecay(World par1World, int par2, int par3, int par4, int par5)
    {
        int var6 = this.l_(par1World, par2, par3, par4);

        if (var6 < 0)
        {
            return par5;
        }
        else
        {
            if (var6 == 0)
            {
                ++this.numAdjacentSources;
            }

            if (var6 >= 8)
            {
                var6 = 0;
            }

            return par5 >= 0 && var6 >= par5 ? par5 : var6;
        }
    }

    /**
     * Returns true if the block at the coordinates can be displaced by the liquid.
     */
    private boolean liquidCanDisplaceBlock(World par1World, int par2, int par3, int par4)
    {
        Material var5 = par1World.getMaterial(par2, par3, par4);
        return var5 == this.material ? false : (var5 == Material.LAVA ? false : !this.blockBlocksFlow(par1World, par2, par3, par4));
    }

    public void onPlace(World world, int i, int j, int k)
    {
        super.onPlace(world, i, j, k);

        if (world.getTypeId(i, j, k) == this.id)
        {
            world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
        }
    }

    public boolean func_82506_l()
    {
        return true;
    }
}
