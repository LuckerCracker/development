package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CallableConnection implements Callable
{
    final PlayerConnection a;

    final ServerConnection b;

    CallableConnection(ServerConnection var1, PlayerConnection var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        return this.a.toString();
    }

    public Object call()
    {
        return this.a();
    }
}
