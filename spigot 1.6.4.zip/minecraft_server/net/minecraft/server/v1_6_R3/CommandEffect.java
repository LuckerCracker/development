package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandEffect extends CommandAbstract
{
    public String getCommandName()
    {
        return "effect";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.effect.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length < 2)
        {
            throw new ExceptionUsage("commands.effect.usage", new Object[0]);
        }
        else
        {
            EntityPlayer var3 = d(var1, var2[0]);

            if (var2[1].equals("clear"))
            {
                if (var3.getEffects().isEmpty())
                {
                    throw new CommandException("commands.effect.failure.notActive.all", new Object[] {var3.getLocalizedName()});
                }

                var3.clearActivePotions();
                a(var1, "commands.effect.success.removed.all", new Object[] {var3.getLocalizedName()});
            }
            else
            {
                int var4 = a(var1, var2[1], 1);
                int var5 = 600;
                int var6 = 30;
                int var7 = 0;

                if (var4 < 0 || var4 >= MobEffectList.byId.length || MobEffectList.byId[var4] == null)
                {
                    throw new ExceptionInvalidNumber("commands.effect.notFound", new Object[] {Integer.valueOf(var4)});
                }

                if (var2.length >= 3)
                {
                    var6 = a(var1, var2[2], 0, 1000000);

                    if (MobEffectList.byId[var4].isInstant())
                    {
                        var5 = var6;
                    }
                    else
                    {
                        var5 = var6 * 20;
                    }
                }
                else if (MobEffectList.byId[var4].isInstant())
                {
                    var5 = 1;
                }

                if (var2.length >= 4)
                {
                    var7 = a(var1, var2[3], 0, 255);
                }

                if (var6 == 0)
                {
                    if (!var3.hasEffect(var4))
                    {
                        throw new CommandException("commands.effect.failure.notActive", new Object[] {ChatMessage.e(MobEffectList.byId[var4].a()), var3.getLocalizedName()});
                    }

                    var3.removePotionEffect(var4);
                    a(var1, "commands.effect.success.removed", new Object[] {ChatMessage.e(MobEffectList.byId[var4].a()), var3.getLocalizedName()});
                }
                else
                {
                    MobEffect var8 = new MobEffect(var4, var5, var7);
                    var3.addEffect(var8);
                    a(var1, "commands.effect.success", new Object[] {ChatMessage.e(var8.f()), Integer.valueOf(var4), Integer.valueOf(var7), var3.getLocalizedName(), Integer.valueOf(var6)});
                }
            }
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, this.getAllUsernames()) : null;
    }

    protected String[] getAllUsernames()
    {
        return MinecraftServer.getServer().getPlayers();
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] par1ArrayOfStr, int par2)
    {
        return par2 == 0;
    }
}
