package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandTime extends CommandAbstract
{
    public String getCommandName()
    {
        return "time";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.time.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length > 1)
        {
            int var3;

            if (var2[0].equals("set"))
            {
                if (var2[1].equals("day"))
                {
                    var3 = 0;
                }
                else if (var2[1].equals("night"))
                {
                    var3 = 12500;
                }
                else
                {
                    var3 = a(var1, var2[1], 0);
                }

                this.a(var1, var3);
                a(var1, "commands.time.set", new Object[] {Integer.valueOf(var3)});
                return;
            }

            if (var2[0].equals("add"))
            {
                var3 = a(var1, var2[1], 0);
                this.b(var1, var3);
                a(var1, "commands.time.added", new Object[] {Integer.valueOf(var3)});
                return;
            }
        }

        throw new ExceptionUsage("commands.time.usage", new Object[0]);
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, new String[] {"set", "add"}): (var2.length == 2 && var2[0].equals("set") ? a(var2, new String[] {"day", "night"}): null);
    }

    protected void a(ICommandListener var1, int var2)
    {
        for (int var3 = 0; var3 < MinecraftServer.getServer().worldServer.length; ++var3)
        {
            MinecraftServer.getServer().worldServer[var3].setDayTime((long)var2);
        }
    }

    protected void b(ICommandListener var1, int var2)
    {
        for (int var3 = 0; var3 < MinecraftServer.getServer().worldServer.length; ++var3)
        {
            WorldServer var4 = MinecraftServer.getServer().worldServer[var3];
            var4.setDayTime(var4.getDayTime() + (long)var2);
        }
    }
}
