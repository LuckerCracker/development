package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockBookshelf extends Block
{
    public BlockBookshelf(int par1)
    {
        super(par1, Material.WOOD);
        this.a(CreativeModeTab.b);
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 3;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Item.BOOK.id;
    }
}
