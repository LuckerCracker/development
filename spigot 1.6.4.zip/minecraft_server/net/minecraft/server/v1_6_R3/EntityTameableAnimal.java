package net.minecraft.server.v1_6_R3;

public abstract class EntityTameableAnimal extends EntityAnimal implements EntityOwnable {
	protected PathfinderGoalSit inLove = new PathfinderGoalSit(this);

	public EntityTameableAnimal(World var1) {
		super(var1);
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(16, Byte.valueOf((byte) 0));
		this.datawatcher.addObject(17, "");
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound var1) {
		super.writeEntityToNBT(var1);

		if (this.getOwnerName() == null) {
			var1.setString("Owner", "");
		} else {
			var1.setString("Owner", this.getOwnerName());
		}

		var1.setBoolean("Sitting", this.isSitting());
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound var1) {
		super.readEntityFromNBT(var1);
		String var2 = var1.getString("Owner");

		if (var2.length() > 0) {
			this.setOwnerName(var2);
			this.setTamed(true);
		}

		this.inLove.setSitting(var1.getBoolean("Sitting"));
		this.setSitting(var1.getBoolean("Sitting"));
	}

	protected void i(boolean var1) {
		String var2 = "heart";

		if (!var1) {
			var2 = "smoke";
		}

		for (int var3 = 0; var3 < 7; ++var3) {
			double var4 = this.random.nextGaussian() * 0.02D;
			double var6 = this.random.nextGaussian() * 0.02D;
			double var8 = this.random.nextGaussian() * 0.02D;
			this.world.addParticle(var2,
					this.locX + (double) (this.random.nextFloat() * this.width * 2.0F) - (double) this.width,
					this.locY + 0.5D + (double) (this.random.nextFloat() * this.length),
					this.locZ + (double) (this.random.nextFloat() * this.width * 2.0F) - (double) this.width, var4,
					var6, var8);
		}
	}

	public boolean isTamed() {
		return (this.datawatcher.getByte(16) & 4) != 0;
	}

	public void setTamed(boolean var1) {
		byte var2 = this.datawatcher.getByte(16);

		if (var1) {
			this.datawatcher.watch(16, Byte.valueOf((byte) (var2 | 4)));
		} else {
			this.datawatcher.watch(16, Byte.valueOf((byte) (var2 & -5)));
		}
	}

	public boolean isSitting() {
		return (this.datawatcher.getByte(16) & 1) != 0;
	}

	public void setSitting(boolean var1) {
		byte var2 = this.datawatcher.getByte(16);

		if (var1) {
			this.datawatcher.watch(16, Byte.valueOf((byte) (var2 | 1)));
		} else {
			this.datawatcher.watch(16, Byte.valueOf((byte) (var2 & -2)));
		}
	}

	public String getOwnerName() {
		return this.datawatcher.getString(17);
	}

	public void setOwnerName(String var1) {
		this.datawatcher.watch(17, var1);
	}

	public EntityLiving getOwner() {
		return this.world.a(this.getOwnerName());
	}

	public PathfinderGoalSit getGoalSit() {
		return this.inLove;
	}

	public boolean a(EntityLiving var1, EntityLiving var2) {
		return true;
	}

	public ScoreboardTeamBase getScoreboardTeam() {
		if (this.isTamed()) {
			EntityLiving var1 = this.getOwner();

			if (var1 != null) {
				return var1.getScoreboardTeam();
			}
		}

		return super.getScoreboardTeam();
	}

	public boolean isOnSameTeam(EntityLiving var1) {
		if (this.isTamed()) {
			EntityLiving var2 = this.getOwner();

			if (var1 == var2) {
				return true;
			}

			if (var2 != null) {
				return var2.isOnSameTeam(var1);
			}
		}

		return super.isOnSameTeam(var1);
	}
}
