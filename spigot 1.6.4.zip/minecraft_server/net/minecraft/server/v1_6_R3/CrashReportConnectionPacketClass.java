package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportConnectionPacketClass implements Callable
{
    final Packet a;

    final PlayerConnection b;

    CrashReportConnectionPacketClass(PlayerConnection var1, Packet var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        return this.a.getClass().getCanonicalName();
    }

    public Object call()
    {
        return this.a();
    }
}
