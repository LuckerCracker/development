package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class EntityPig extends EntityAnimal {
	/** AI task for player control. */
	private final PathfinderGoalPassengerCarrotStick aiControlledByPlayer;

	public EntityPig(World par1World) {
		super(par1World);
		this.setSize(0.9F, 0.9F);
		this.getNavigation().a(true);
		this.goalSelector.a(0, new PathfinderGoalFloat(this));
		this.goalSelector.a(1, new PathfinderGoalPanic(this, 1.25D));
		this.goalSelector.a(2, this.aiControlledByPlayer = new PathfinderGoalPassengerCarrotStick(this, 0.3F));
		this.goalSelector.a(3, new PathfinderGoalBreed(this, 1.0D));
		this.goalSelector.a(4, new PathfinderGoalTempt(this, 1.2D, Item.CARROT_STICK.id, false));
		this.goalSelector.a(4, new PathfinderGoalTempt(this, 1.2D, Item.CARROT.id, false));
		this.goalSelector.a(5, new PathfinderGoalFollowParent(this, 1.1D));
		this.goalSelector.a(6, new PathfinderGoalRandomStroll(this, 1.0D));
		this.goalSelector.a(7, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 6.0F));
		this.goalSelector.a(8, new PathfinderGoalRandomLookaround(this));
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	public boolean isAIEnabled() {
		return true;
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.a).setValue(10.0D);
		this.getAttributeInstance(GenericAttributes.d).setValue(0.25D);
	}

	protected void updateAITasks() {
		super.updateAITasks();
	}

	/**
	 * returns true if all the conditions for steering the entity are met. For
	 * pigs, this is true if it is being ridden by a player and the player is
	 * holding a carrot-on-a-stick
	 */
	public boolean canBeSteered() {
		ItemStack var1 = ((EntityHuman) this.passenger).getHeldItem();
		return var1 != null && var1.id == Item.CARROT_STICK.id;
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(16, Byte.valueOf((byte) 0));
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setBoolean("Saddle", this.hasSaddle());
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.setSaddle(par1NBTTagCompound.getBoolean("Saddle"));
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return "mob.pig.say";
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.pig.say";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.pig.death";
	}

	/**
	 * Plays step sound at given x, y, z for the entity
	 */
	protected void playStepSound(int par1, int par2, int par3, int par4) {
		this.makeSound("mob.pig.step", 0.15F, 1.0F);
	}

	public boolean a(EntityHuman entityhuman) {
		if (super.a(entityhuman)) {
			return true;
		} else if (this.hasSaddle() && !this.world.isStatic
				&& (this.passenger == null || this.passenger == entityhuman)) {
			entityhuman.mount(this);
			return true;
		} else {
			return false;
		}
	}

	protected int getLootId() {
		return this.isBurning() ? Item.GRILLED_PORK.id : Item.PORK.id;
	}

	protected void dropDeathLoot(boolean flag, int i) {
		ArrayList loot = new ArrayList();
		int j = this.random.nextInt(3) + 1 + this.random.nextInt(1 + i);

		if (j > 0) {
			if (this.isBurning()) {
				loot.add(new org.bukkit.inventory.ItemStack(Item.GRILLED_PORK.id, j));
			} else {
				loot.add(new org.bukkit.inventory.ItemStack(Item.PORK.id, j));
			}
		}

		if (this.hasSaddle()) {
			loot.add(new org.bukkit.inventory.ItemStack(Item.SADDLE.id, 1));
		}

		CraftEventFactory.callEntityDeathEvent(this, loot);
	}

	public boolean hasSaddle() {
		return (this.datawatcher.getByte(16) & 1) != 0;
	}

	public void setSaddle(boolean flag) {
		if (flag) {
			this.datawatcher.watch(16, Byte.valueOf((byte) 1));
		} else {
			this.datawatcher.watch(16, Byte.valueOf((byte) 0));
		}
	}

	public void a(EntityLightning entitylightning) {
		if (!this.world.isStatic) {
			EntityPigZombie entitypigzombie = new EntityPigZombie(this.world);

			if (CraftEventFactory.callPigZapEvent(this, entitylightning, entitypigzombie).isCancelled()) {
				return;
			}

			entitypigzombie.setPositionRotation(this.locX, this.locY, this.locZ, this.yaw, this.pitch);
			this.world.addEntity(entitypigzombie, CreatureSpawnEvent.SpawnReason.LIGHTNING);
			this.die();
		}
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float par1) {
		super.fall(par1);

		if (par1 > 5.0F && this.passenger instanceof EntityHuman) {
			((EntityHuman) this.passenger).triggerAchievement((Statistic) AchievementList.flyPig);
		}
	}

	/**
	 * This function is used when two same-species animals in 'love mode' breed
	 * to generate the new baby animal.
	 */
	public EntityPig spawnBabyAnimal(EntityAgeable par1EntityAgeable) {
		return new EntityPig(this.world);
	}

	/**
	 * Checks if the parameter is an item which this animal can be fed to breed
	 * it (wheat, carrots or seeds depending on the animal type)
	 */
	public boolean isBreedingItem(ItemStack par1ItemStack) {
		return par1ItemStack != null && par1ItemStack.id == Item.CARROT.id;
	}

	public PathfinderGoalPassengerCarrotStick bU() {
		return this.aiControlledByPlayer;
	}

	public EntityAgeable createChild(EntityAgeable entityageable) {
		return this.spawnBabyAnimal(entityageable);
	}
}
