package net.minecraft.server.v1_6_R3;

import java.util.Random;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class BlockCactus extends Block {
	protected BlockCactus(int par1) {
		super(par1, Material.CACTUS);
		this.setTickRandomly(true);
		this.a(CreativeModeTab.c);
	}

	/**
	 * Ticks the block if it's been scheduled
	 */
	public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random) {
		if (par1World.isEmpty(par2, par3 + 1, par4)) {
			int var6;

			for (var6 = 1; par1World.getTypeId(par2, par3 - var6, par4) == this.id; ++var6) {
				;
			}

			if (var6 < 3) {
				int var7 = par1World.getData(par2, par3, par4);

				if (var7 >= (byte) ((int) range(3.0F,
						par1World.growthOdds / (float) par1World.spigotConfig.cactusModifier * 15.0F + 0.5F, 15.0F))) {
					CraftEventFactory.handleBlockGrowEvent(par1World, par2, par3 + 1, par4, this.id, 0);
					par1World.setData(par2, par3, par4, 0, 4);
					this.doPhysics(par1World, par2, par3 + 1, par4, this.id);
				} else {
					par1World.setData(par2, par3, par4, var7 + 1, 4);
				}
			}
		}
	}

	/**
	 * Returns a bounding box from the pool of bounding boxes (this means this
	 * box can change after the pool has been cleared to be reused)
	 */
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
		float var5 = 0.0625F;
		return AxisAlignedBB.getAABBPool().getAABB((double) ((float) par2 + var5), (double) par3,
				(double) ((float) par4 + var5), (double) ((float) (par2 + 1) - var5),
				(double) ((float) (par3 + 1) - var5), (double) ((float) (par4 + 1) - var5));
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False
	 * (examples: signs, buttons, stairs, etc)
	 */
	public boolean renderAsNormalBlock() {
		return false;
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube? This determines whether
	 * or not to render the shared face of two adjacent blocks and also whether
	 * the player can attach torches, redstone wire, etc to this block.
	 */
	public boolean isOpaqueCube() {
		return false;
	}

	/**
	 * The type of render function that is called for this block
	 */
	public int getRenderType() {
		return 13;
	}

	public boolean canPlace(World world, int i, int j, int k) {
		return !super.canPlace(world, i, j, k) ? false : this.canBlockStay(world, i, j, k);
	}

	public void doPhysics(World world, int i, int j, int k, int l) {
		if (!this.canBlockStay(world, i, j, k)) {
			world.setAir(i, j, k, true);
		}
	}

	/**
	 * Can this block stay at this position. Similar to canPlaceBlockAt except
	 * gets checked often with plants.
	 */
	public boolean canBlockStay(World par1World, int par2, int par3, int par4) {
		if (par1World.getMaterial(par2 - 1, par3, par4).isBuildable()) {
			return false;
		} else if (par1World.getMaterial(par2 + 1, par3, par4).isBuildable()) {
			return false;
		} else if (par1World.getMaterial(par2, par3, par4 - 1).isBuildable()) {
			return false;
		} else if (par1World.getMaterial(par2, par3, par4 + 1).isBuildable()) {
			return false;
		} else {
			int var5 = par1World.getTypeId(par2, par3 - 1, par4);
			return var5 == Block.CACTUS.id || var5 == Block.SAND.id;
		}
	}

	/**
	 * Triggered whenever an entity collides with this block (enters into the
	 * block). Args: world, x, y, z, entity
	 */
	public void onEntityCollidedWithBlock(World par1World, int par2, int par3, int par4, Entity par5Entity) {
		if (par5Entity instanceof EntityLiving) {
			org.bukkit.block.Block var6 = par1World.getWorld().getBlockAt(par2, par3, par4);
			CraftEntity var7 = par5Entity == null ? null : par5Entity.getBukkitEntity();
			EntityDamageByBlockEvent var8 = new EntityDamageByBlockEvent(var6, var7,
					EntityDamageEvent.DamageCause.CONTACT, 1.0D);
			par1World.getServer().getPluginManager().callEvent(var8);

			if (!var8.isCancelled()) {
				var7.setLastDamageCause(var8);
				par5Entity.attackEntityFrom(DamageSource.CACTUS, (float) var8.getDamage());
			}
		} else {
			par5Entity.attackEntityFrom(DamageSource.CACTUS, 1.0F);
		}
	}
}
