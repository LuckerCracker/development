package net.minecraft.server.v1_6_R3;

public abstract class EntityWeather extends Entity
{
    public EntityWeather(World var1)
    {
        super(var1);
    }
}
