package net.minecraft.server.v1_6_R3;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.WeatherType;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerTeleportEvent;

import com.google.common.collect.ImmutableList;

public class EntityPlayer extends EntityHuman implements ICrafting {
	private String locale = "en_US";
	public PlayerConnection playerConnection;
	public MinecraftServer server;
	public PlayerInteractManager playerInteractManager;

	/**
	 * Whether this player's spawn point is forced, preventing execution of bed
	 * checks.
	 */
	public double spawnForced;

	/** Holds the coordinate of the player when enter a minecraft to ride. */
	public double startMinecartRidingCoordinate;
	public final List chunkCoordIntPairQueue = new LinkedList();
	public final List removeQueue = new LinkedList();
	private float bO = Float.MIN_VALUE;
	private float bP = -1.0E8F;
	private int bQ = -99999999;
	private boolean bR = true;
	public int lastSentExp = -99999999;
	public int invulnerableTicks = 60;
	private int bU;
	private int bV;
	private boolean bW = true;
	private long bX = 0L;
	private int containerCounter;
	public boolean field_82249_h;
	public int ping;
	public boolean viewingCredits;
	public String displayName;
	public String listName;
	public Location compassTarget;
	public int newExp = 0;
	public int newLevel = 0;
	public int newTotalExp = 0;
	public boolean keepLevel = false;
	public double maxHealthCache;
	public int lastPing = -1;
	public boolean collidesWithEntities = true;
	public long timeOffset = 0L;
	public boolean relativeTime = true;
	public WeatherType weather = null;

	/**
	 * Returns true if other Entities should be prevented from moving through
	 * this Entity.
	 */
	public boolean canBeCollidedWith() {
		return this.collidesWithEntities && super.canBeCollidedWith();
	}

	/**
	 * Returns true if this entity should push and be pushed by other entities
	 * when colliding.
	 */
	public boolean canBePushed() {
		return this.collidesWithEntities && super.canBePushed();
	}

	public EntityPlayer(MinecraftServer minecraftserver, World world, String s,
			PlayerInteractManager playerinteractmanager) {
		super(world, s);
		playerinteractmanager.player = this;
		this.playerInteractManager = playerinteractmanager;
		this.bU = minecraftserver.getPlayerList().o();
		ChunkCoordinates chunkcoordinates = world.getSpawn();
		int i = chunkcoordinates.x;
		int j = chunkcoordinates.z;
		int k = chunkcoordinates.y;

		if (!world.worldProvider.hasNoSky && world.getWorldData().getGameType() != EnumGamemode.ADVENTURE) {
			int l = Math.max(5, minecraftserver.getSpawnProtection() - 6);
			i += this.random.nextInt(l * 2) - l;
			j += this.random.nextInt(l * 2) - l;
			k = world.getTopSolidOrLiquidBlock(i, j);
		}

		this.server = minecraftserver;
		this.stepHeight = 0.0F;
		this.height = 0.0F;
		this.setPositionRotation((double) i + 0.5D, (double) k, (double) j + 0.5D, 0.0F, 0.0F);

		while (!world.getCubes(this, this.boundingBox).isEmpty()) {
			this.setPosition(this.locX, this.locY + 1.0D, this.locZ);
		}

		this.displayName = this.name;
		this.listName = this.name;
		this.maxHealthCache = (double) this.getMaxHealth();
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);

		if (par1NBTTagCompound.hasKey("playerGameType")) {
			if (MinecraftServer.getServer().getForceGamemode()) {
				this.playerInteractManager.setGameMode(MinecraftServer.getServer().getGamemode());
			} else {
				this.playerInteractManager.setGameMode(EnumGamemode.a(par1NBTTagCompound.getInt("playerGameType")));
			}
		}

		this.getBukkitEntity().readExtraData(par1NBTTagCompound);
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setInt("playerGameType", this.playerInteractManager.getGameMode().a());
		this.getBukkitEntity().setExtraData(par1NBTTagCompound);
	}

	public void spawnIn(World world) {
		super.spawnIn((World) world);

		if (world == null) {
			this.dead = false;
			ChunkCoordinates position = null;

			if (this.spawnWorld != null && !this.spawnWorld.equals("")) {
				CraftWorld cworld = (CraftWorld) Bukkit.getServer().getWorld(this.spawnWorld);

				if (cworld != null && this.getBed() != null) {
					world = cworld.getHandle();
					position = EntityHuman.getBed(cworld.getHandle(), this.getBed(), false);
				}
			}

			if (world == null || position == null) {
				world = ((CraftWorld) Bukkit.getServer().getWorlds().get(0)).getHandle();
				position = ((World) world).getSpawn();
			}

			this.world = (World) world;
			this.setPosition((double) position.x + 0.5D, (double) position.y, (double) position.z + 0.5D);
		}

		this.dimension = ((WorldServer) this.world).dimension;
		this.playerInteractManager.a((WorldServer) world);
	}

	public void levelDown(int i) {
		super.levelDown(i);
		this.lastSentExp = -1;
	}

	public void syncInventory() {
		this.activeContainer.addSlotListener(this);
	}

	/**
	 * sets the players height back to normal after doing things like sleeping
	 * and dieing
	 */
	protected void resetHeight() {
		this.height = 0.0F;
	}

	public float getHeadHeight() {
		return 1.62F;
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		this.playerInteractManager.a();
		--this.invulnerableTicks;
		this.activeContainer.detectAndSendChanges();

		if (!this.world.isStatic && !this.activeContainer.a(this)) {
			this.closeInventory();
			this.activeContainer = this.defaultContainer;
		}

		if (this.noDamageTicks > 0) {
			--this.noDamageTicks;
		}

		while (!this.removeQueue.isEmpty()) {
			int var1 = Math.min(this.removeQueue.size(), 127);
			int[] var2 = new int[var1];
			Iterator var3 = this.removeQueue.iterator();
			int var4 = 0;

			while (var3.hasNext() && var4 < var1) {
				var2[var4++] = ((Integer) var3.next()).intValue();
				var3.remove();
			}

			this.playerConnection.sendPacket(new Packet29DestroyEntity(var2));
		}

		if (!this.chunkCoordIntPairQueue.isEmpty()) {
			ArrayList var6 = new ArrayList();
			Iterator var7 = this.chunkCoordIntPairQueue.iterator();
			ArrayList var8 = new ArrayList();
			Chunk var5;

			while (var7.hasNext() && var6.size() < 5) {
				ChunkCoordIntPair var9 = (ChunkCoordIntPair) var7.next();
				var7.remove();

				if (var9 != null && this.world.isLoaded(var9.x << 4, 0, var9.z << 4)) {
					var5 = this.world.getChunkAt(var9.x, var9.z);
					var6.add(var5);
					var8.addAll(var5.tileEntities.values());
				}
			}

			if (!var6.isEmpty()) {
				this.playerConnection.sendPacket(new Packet56MapChunkBulk(var6));
				Iterator var10 = var8.iterator();

				while (var10.hasNext()) {
					TileEntity var11 = (TileEntity) var10.next();
					this.b(var11);
				}

				var10 = var6.iterator();

				while (var10.hasNext()) {
					var5 = (Chunk) var10.next();
					this.p().getTracker().a(this, var5);
				}
			}
		}

		if (this.bX > 0L && this.server.ar() > 0
				&& MinecraftServer.aq() - this.bX > (long) (this.server.ar() * 1000 * 60)) {
			this.playerConnection.disconnect("You have been idle for too long!");
		}
	}

	public void h() {
		try {
			super.onUpdate();

			for (int throwable = 0; throwable < this.inventory.getSize(); ++throwable) {
				ItemStack var5 = this.inventory.getItem(throwable);

				if (var5 != null && Item.byId[var5.id].isMap() && this.playerConnection.lowPriorityCount() <= 5) {
					Packet var6 = ((ItemWorldMapBase) Item.byId[var5.id]).c(var5, this.world, this);

					if (var6 != null) {
						this.playerConnection.sendPacket(var6);
					}
				}
			}

			if (this.getHealth() != this.bP || this.bQ != this.foodData.a() || this.foodData.e() == 0.0F != this.bR) {
				this.playerConnection.sendPacket(new Packet8UpdateHealth(this.getBukkitEntity().getScaledHealth(),
						this.foodData.a(), this.foodData.e()));
				this.bP = this.getHealth();
				this.bQ = this.foodData.a();
				this.bR = this.foodData.e() == 0.0F;
			}

			if (this.getHealth() + this.getAbsorptionAmount() != this.bO) {
				this.bO = this.getHealth() + this.getAbsorptionAmount();
				this.world.getServer().getScoreboardManager().updateAllScoresForList(IScoreboardCriteria.f,
						this.getLocalizedName(), ImmutableList.of(this));
			}

			if (this.maxHealthCache != (double) this.getMaxHealth()) {
				this.getBukkitEntity().updateScaledHealth();
			}

			if (this.expTotal != this.lastSentExp) {
				this.lastSentExp = this.expTotal;
				this.playerConnection.sendPacket(new Packet43SetExperience(this.exp, this.expTotal, this.expLevel));
			}

			if (this.oldLevel == -1) {
				this.oldLevel = this.expLevel;
			}

			if (this.oldLevel != this.expLevel) {
				CraftEventFactory.callPlayerLevelChangeEvent(this.world.getServer().getPlayer(this), this.oldLevel,
						this.expLevel);
				this.oldLevel = this.expLevel;
			}
		} catch (Throwable var4) {
			CrashReport crashreport = CrashReport.makeCrashReport(var4, "Ticking player");
			CrashReportSystemDetails crashreportsystemdetails = crashreport.a("Player being ticked");
			this.a(crashreportsystemdetails);
			throw new ReportedException(crashreport);
		}
	}

	public void die(DamageSource damagesource) {
		if (!this.dead) {
			ArrayList loot = new ArrayList();
			boolean keepInventory = this.world.getGameRules().getBoolean("keepInventory");

			if (!keepInventory) {
				int chatmessage;

				for (chatmessage = 0; chatmessage < this.inventory.items.length; ++chatmessage) {
					if (this.inventory.items[chatmessage] != null) {
						loot.add(CraftItemStack.asCraftMirror(this.inventory.items[chatmessage]));
					}
				}

				for (chatmessage = 0; chatmessage < this.inventory.armor.length; ++chatmessage) {
					if (this.inventory.armor[chatmessage] != null) {
						loot.add(CraftItemStack.asCraftMirror(this.inventory.armor[chatmessage]));
					}
				}
			}

			ChatMessage var11 = this.func_110142_aN().b();
			String deathmessage = var11.toString();
			PlayerDeathEvent event = CraftEventFactory.callPlayerDeathEvent(this, loot, deathmessage);
			String deathMessage = event.getDeathMessage();

			if (deathMessage != null && deathMessage.length() > 0) {
				if (deathMessage.equals(var11.toString())) {
					this.server.getPlayerList().sendMessage(var11);
				} else {
					this.server.getPlayerList().sendMessage(ChatMessage.d(event.getDeathMessage()));
				}
			}

			if (!keepInventory) {
				int collection;

				for (collection = 0; collection < this.inventory.items.length; ++collection) {
					this.inventory.items[collection] = null;
				}

				for (collection = 0; collection < this.inventory.armor.length; ++collection) {
					this.inventory.armor[collection] = null;
				}
			}

			this.closeInventory();
			Collection var12 = this.world.getServer().getScoreboardManager().getScoreboardScores(IScoreboardCriteria.c,
					this.getLocalizedName(), new ArrayList());
			Iterator iterator = var12.iterator();

			while (iterator.hasNext()) {
				ScoreboardScore entityliving = (ScoreboardScore) iterator.next();
				entityliving.incrementScore();
			}

			EntityLiving var13 = this.func_94060_bK();

			if (var13 != null) {
				var13.addToPlayerScore(this, this.scoreValue);
			}

			this.addStat(StatisticList.y, 1);
		}
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else {
			boolean flag = this.server.isDedicatedServer() && this.world.pvpMode
					&& "fall".equals(damagesource.translationIndex);

			if (!flag && this.invulnerableTicks > 0 && damagesource != DamageSource.OUT_OF_WORLD) {
				return false;
			} else {
				if (damagesource instanceof EntityDamageSource) {
					Entity entity = damagesource.getEntity();

					if (entity instanceof EntityHuman && !this.canAttackPlayer((EntityHuman) entity)) {
						return false;
					}

					if (entity instanceof EntityArrow) {
						EntityArrow entityarrow = (EntityArrow) entity;

						if (entityarrow.shooter instanceof EntityHuman
								&& !this.canAttackPlayer((EntityHuman) entityarrow.shooter)) {
							return false;
						}
					}
				}

				return super.attackEntityFrom(damagesource, f);
			}
		}
	}

	public boolean canAttackPlayer(EntityHuman entityhuman) {
		return !this.world.pvpMode ? false : super.canAttackPlayer(entityhuman);
	}

	/**
	 * Teleports the entity to another dimension. Params: Dimension number to
	 * teleport to
	 */
	public void travelToDimension(int i) {
		if (this.dimension == 1 && i == 1) {
			this.triggerAchievement((Statistic) AchievementList.theEnd2);
			this.world.kill(this);
			this.viewingCredits = true;
			this.playerConnection.sendPacket(new Packet70Bed(4, 0));
		} else {
			if (this.dimension == 0 && i == 1) {
				this.triggerAchievement((Statistic) AchievementList.theEnd);
			} else {
				this.triggerAchievement((Statistic) AchievementList.portal);
			}

			PlayerTeleportEvent.TeleportCause cause = this.dimension != 1 && i != 1
					? PlayerTeleportEvent.TeleportCause.NETHER_PORTAL : PlayerTeleportEvent.TeleportCause.END_PORTAL;
			this.server.getPlayerList().changeDimension(this, i, cause);
			this.lastSentExp = -1;
			this.bP = -1.0F;
			this.bQ = -1;
		}
	}

	private void b(TileEntity tileentity) {
		if (tileentity != null) {
			Packet packet = tileentity.getUpdatePacket();

			if (packet != null) {
				this.playerConnection.sendPacket(packet);
			}
		}
	}

	public void receive(Entity entity, int i) {
		super.receive(entity, i);
		this.activeContainer.detectAndSendChanges();
	}

	public EnumBedResult sleepInBedAt(int i, int j, int k) {
		EnumBedResult enumbedresult = super.sleepInBedAt(i, j, k);

		if (enumbedresult == EnumBedResult.OK) {
			Packet17EntityLocationAction packet17entitylocationaction = new Packet17EntityLocationAction(this, 0, i, j,
					k);
			this.p().getTracker().sendPacketToTrackedPlayers(this, packet17entitylocationaction);
			this.playerConnection.a(this.locX, this.locY, this.locZ, this.yaw, this.pitch);
			this.playerConnection.sendPacket(packet17entitylocationaction);
		}

		return enumbedresult;
	}

	/**
	 * Wake up the player if they're sleeping.
	 */
	public void wakeUpPlayer(boolean par1, boolean par2, boolean par3) {
		if (!this.fauxSleeping || this.sleeping) {
			if (this.isSleeping()) {
				this.p().getTracker().sendPacketToEntity(this, new Packet18ArmAnimation(this, 3));
			}

			super.wakeUpPlayer(par1, par2, par3);

			if (this.playerConnection != null) {
				this.playerConnection.a(this.locX, this.locY, this.locZ, this.yaw, this.pitch);
			}
		}
	}

	public void mount(Entity entity) {
		this.setPassengerOf(entity);
	}

	public void setPassengerOf(Entity entity) {
		Entity currentVehicle = this.vehicle;
		super.setPassengerOf(entity);

		if (currentVehicle != this.vehicle) {
			this.playerConnection.sendPacket(new Packet39AttachEntity(0, this, this.vehicle));
			this.playerConnection.a(this.locX, this.locY, this.locZ, this.yaw, this.pitch);
		}
	}

	/**
	 * Takes in the distance the entity has fallen this tick and whether its on
	 * the ground to update the fall distance and deal fall damage if landing on
	 * the ground. Args: distanceFallenThisTick, onGround
	 */
	protected void updateFallState(double d0, boolean flag) {
	}

	public void b(double d0, boolean flag) {
		super.updateFallState(d0, flag);
	}

	/**
	 * Displays the GUI for editing a sign. Args: tileEntitySign
	 */
	public void displayGUIEditSign(TileEntity par1TileEntity) {
		if (par1TileEntity instanceof TileEntitySign) {
			((TileEntitySign) par1TileEntity).a(this);
			this.playerConnection
					.sendPacket(new Packet133OpenTileEntity(0, par1TileEntity.x, par1TileEntity.y, par1TileEntity.z));
		}
	}

	public int nextContainerCounter() {
		this.containerCounter = this.containerCounter % 100 + 1;
		return this.containerCounter;
	}

	public void startCrafting(int i, int j, int k) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerWorkbench(this.inventory, this.world, i, j, k));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 1, "Crafting", 9, true));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void startEnchanting(int i, int j, int k, String s) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerEnchantTable(this.inventory, this.world, i, j, k));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection
					.sendPacket(new Packet100OpenWindow(this.containerCounter, 4, s == null ? "" : s, 9, s != null));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openAnvil(int i, int j, int k) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerAnvil(this.inventory, this.world, i, j, k, this));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 8, "Repairing", 9, true));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openContainer(IInventory iinventory) {
		if (this.activeContainer != this.defaultContainer) {
			this.closeInventory();
		}

		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerChest(this.inventory, iinventory));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 0, iinventory.getName(),
					iinventory.getSize(), iinventory.isInvNameLocalized()));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openHopper(TileEntityHopper tileentityhopper) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerHopper(this.inventory, tileentityhopper));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 9,
					tileentityhopper.getName(), tileentityhopper.getSize(), tileentityhopper.isInvNameLocalized()));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openMinecartHopper(EntityMinecartHopper entityminecarthopper) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerHopper(this.inventory, entityminecarthopper));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection
					.sendPacket(new Packet100OpenWindow(this.containerCounter, 9, entityminecarthopper.getName(),
							entityminecarthopper.getSize(), entityminecarthopper.isInvNameLocalized()));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openFurnace(TileEntityFurnace tileentityfurnace) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerFurnace(this.inventory, tileentityfurnace));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 2,
					tileentityfurnace.getName(), tileentityfurnace.getSize(), tileentityfurnace.isInvNameLocalized()));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openDispenser(TileEntityDispenser tileentitydispenser) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerDispenser(this.inventory, tileentitydispenser));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter,
					tileentitydispenser instanceof TileEntityDropper ? 10 : 3, tileentitydispenser.getName(),
					tileentitydispenser.getSize(), tileentitydispenser.isInvNameLocalized()));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openBrewingStand(TileEntityBrewingStand tileentitybrewingstand) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerBrewingStand(this.inventory, tileentitybrewingstand));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection
					.sendPacket(new Packet100OpenWindow(this.containerCounter, 5, tileentitybrewingstand.getName(),
							tileentitybrewingstand.getSize(), tileentitybrewingstand.isInvNameLocalized()));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openBeacon(TileEntityBeacon tileentitybeacon) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerBeacon(this.inventory, tileentitybeacon));

		if (container != null) {
			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 7,
					tileentitybeacon.getName(), tileentitybeacon.getSize(), tileentitybeacon.isInvNameLocalized()));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	public void openTrade(IMerchant imerchant, String s) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerMerchant(this.inventory, imerchant, this.world));

		if (container != null) {
			this.nextContainerCounter();
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
			InventoryMerchant inventorymerchant = ((ContainerMerchant) this.activeContainer).getMerchantInventory();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 6, s == null ? "" : s,
					inventorymerchant.getSize(), s != null));
			MerchantRecipeList merchantrecipelist = imerchant.getOffers(this);

			if (merchantrecipelist != null) {
				try {
					ByteArrayOutputStream ioexception = new ByteArrayOutputStream();
					DataOutputStream dataoutputstream = new DataOutputStream(ioexception);
					dataoutputstream.writeInt(this.containerCounter);
					merchantrecipelist.writeRecipiesToStream(dataoutputstream);
					this.playerConnection
							.sendPacket(new Packet250CustomPayload("MC|TrList", ioexception.toByteArray()));
				} catch (IOException var8) {
					var8.printStackTrace();
				}
			}
		}
	}

	public void openHorseInventory(EntityHorse entityhorse, IInventory iinventory) {
		Container container = CraftEventFactory.callInventoryOpenEvent(this,
				new ContainerHorse(this.inventory, iinventory, entityhorse));

		if (container != null) {
			if (this.activeContainer != this.defaultContainer) {
				this.closeInventory();
			}

			this.nextContainerCounter();
			this.playerConnection.sendPacket(new Packet100OpenWindow(this.containerCounter, 11, iinventory.getName(),
					iinventory.getSize(), iinventory.isInvNameLocalized(), entityhorse.id));
			this.activeContainer = container;
			this.activeContainer.windowId = this.containerCounter;
			this.activeContainer.addSlotListener(this);
		}
	}

	/**
	 * Sends the contents of an inventory slot to the client-side Container.
	 * This doesn't have to match the actual contents of that slot. Args:
	 * Container, slot number, slot contents
	 */
	public void sendSlotContents(Container container, int i, ItemStack itemstack) {
		if (!(container.getSlot(i) instanceof SlotResult) && !this.field_82249_h) {
			this.playerConnection.sendPacket(new Packet103SetSlot(container.windowId, i, itemstack));
		}
	}

	public void updateInventory(Container container) {
		this.updateCraftingInventory(container, container.getInventory());
	}

	/**
	 * update the crafting window inventory with the items in the list
	 */
	public void updateCraftingInventory(Container container, List list) {
		this.playerConnection.sendPacket(new Packet104WindowItems(container.windowId, list));
		this.playerConnection.sendPacket(new Packet103SetSlot(-1, -1, this.inventory.getCarried()));

		if (EnumSet.of(InventoryType.CRAFTING, InventoryType.WORKBENCH).contains(container.getBukkitView().getType())) {
			this.playerConnection
					.sendPacket(new Packet103SetSlot(container.windowId, 0, container.getSlot(0).getItem()));
		}
	}

	public void setContainerData(Container container, int i, int j) {
		this.playerConnection.sendPacket(new Packet105CraftProgressBar(container.windowId, i, j));
	}

	public void closeInventory() {
		CraftEventFactory.handleInventoryCloseEvent(this);
		this.playerConnection.sendPacket(new Packet101CloseWindow(this.activeContainer.windowId));
		this.k();
	}

	public void broadcastCarriedItem() {
		if (!this.field_82249_h) {
			this.playerConnection.sendPacket(new Packet103SetSlot(-1, -1, this.inventory.getCarried()));
		}
	}

	public void k() {
		this.activeContainer.b(this);
		this.activeContainer = this.defaultContainer;
	}

	public void a(float f, float f1, boolean flag, boolean flag1) {
		if (this.vehicle != null) {
			if (f >= -1.0F && f <= 1.0F) {
				this.moveStrafing = f;
			}

			if (f1 >= -1.0F && f1 <= 1.0F) {
				this.moveForward = f1;
			}

			this.isJumping = flag;
			this.setSneaking(flag1);
		}
	}

	public void addStat(Statistic statistic, int i) {
		if (statistic != null && !statistic.f) {
			this.playerConnection.sendPacket(new Packet200Statistic(statistic.e, i));
		}
	}

	public void l() {
		if (this.passenger != null) {
			this.passenger.mount(this);
		}

		if (this.sleeping) {
			this.wakeUpPlayer(true, false, false);
		}
	}

	public void triggerHealthUpdate() {
		this.bP = -1.0E8F;
		this.lastSentExp = -1;
	}

	/**
	 * Add a chat message to the player
	 */
	public void addChatMessage(String par1Str) {
		this.playerConnection.sendPacket(new Packet3Chat(ChatMessage.e(par1Str)));
	}

	/**
	 * Used for when item use count runs out, ie: eating completed
	 */
	protected void onItemUseFinish() {
		this.playerConnection.sendPacket(new Packet38EntityStatus(this.id, (byte) 9));
		super.eatGrassBonus();
	}

	/**
	 * sets the itemInUse when the use item button is clicked. Args: itemstack,
	 * int maxItemUseDuration
	 */
	public void setItemInUse(ItemStack par1ItemStack, int par2) {
		super.setItemInUse(par1ItemStack, par2);

		if (par1ItemStack != null && par1ItemStack.getItem() != null
				&& par1ItemStack.getItem().c_(par1ItemStack) == EnumAnimation.EAT) {
			this.p().getTracker().sendPacketToEntity(this, new Packet18ArmAnimation(this, 5));
		}
	}

	public void copyTo(EntityHuman entityhuman, boolean flag) {
		super.copyTo(entityhuman, flag);
		this.lastSentExp = -1;
		this.bP = -1.0F;
		this.bQ = -1;
		this.removeQueue.addAll(((EntityPlayer) entityhuman).removeQueue);
	}

	protected void onNewPotionEffect(MobEffect mobeffect) {
		super.onNewPotionEffect(mobeffect);
		this.playerConnection.sendPacket(new Packet41MobEffect(this.id, mobeffect));
	}

	protected void onChangedPotionEffect(MobEffect mobeffect, boolean flag) {
		super.onChangedPotionEffect(mobeffect, flag);
		this.playerConnection.sendPacket(new Packet41MobEffect(this.id, mobeffect));
	}

	protected void onFinishedPotionEffect(MobEffect mobeffect) {
		super.onFinishedPotionEffect(mobeffect);
		this.playerConnection.sendPacket(new Packet42RemoveMobEffect(this.id, mobeffect));
	}

	public void enderTeleportTo(double d0, double d1, double d2) {
		this.playerConnection.a(d0, d1, d2, this.yaw, this.pitch);
	}

	/**
	 * Called when the player performs a critical hit on the Entity. Args:
	 * entity that was hit critically
	 */
	public void onCriticalHit(Entity par1Entity) {
		this.p().getTracker().sendPacketToEntity(this, new Packet18ArmAnimation(par1Entity, 6));
	}

	public void onEnchantmentCritical(Entity par1Entity) {
		this.p().getTracker().sendPacketToEntity(this, new Packet18ArmAnimation(par1Entity, 7));
	}

	public void updateAbilities() {
		if (this.playerConnection != null) {
			this.playerConnection.sendPacket(new Packet202Abilities(this.abilities));
		}
	}

	public WorldServer p() {
		return (WorldServer) this.world;
	}

	public void setGameType(EnumGamemode enumgamemode) {
		this.playerInteractManager.setGameMode(enumgamemode);
		this.playerConnection.sendPacket(new Packet70Bed(3, enumgamemode.a()));
	}

	public void sendMessage(ChatMessage chatmessage) {
		this.playerConnection.sendPacket(new Packet3Chat(chatmessage));
	}

	public boolean a(int i, String s) {
		return "seed".equals(s) && !this.server.isDedicatedServer() ? true
				: (!"tell".equals(s) && !"help".equals(s) && !"me".equals(s)
						? (this.server.getPlayerList().isOp(this.name) ? this.server.func_110455_j() >= i : false)
						: true);
	}

	public String q() {
		String s = this.playerConnection.networkManager.getSocketAddress().toString();
		s = s.substring(s.indexOf("/") + 1);
		s = s.substring(0, s.indexOf(":"));
		return s;
	}

	public void a(Packet204LocaleAndViewDistance packet204localeandviewdistance) {
		this.locale = packet204localeandviewdistance.d();
		int i = 256 >> packet204localeandviewdistance.f();

		if (i > 3 && i < 15) {
			this.bU = i;
		}

		this.bV = packet204localeandviewdistance.g();
		this.bW = packet204localeandviewdistance.h();

		if (this.server.K() && this.server.J().equals(this.name)) {
			this.server.c(packet204localeandviewdistance.i());
		}

		this.setHideCape(1, !packet204localeandviewdistance.j());
	}

	public int getChatFlags() {
		return this.bV;
	}

	public void a(String s, int i) {
		String s1 = s + "\u0000" + i;
		this.playerConnection.sendPacket(new Packet250CustomPayload("MC|TPack", s1.getBytes()));
	}

	public ChunkCoordinates b() {
		return new ChunkCoordinates(MathHelper.floor(this.locX), MathHelper.floor(this.locY + 0.5D),
				MathHelper.floor(this.locZ));
	}

	/**
	 * Makes the entity despawn if requirements are reached
	 */
	public void despawnEntity() {
		this.bX = MinecraftServer.aq();
	}

	public long getPlayerTime() {
		return this.relativeTime ? this.world.getDayTime() + this.timeOffset
				: this.world.getDayTime() - this.world.getDayTime() % 24000L + this.timeOffset;
	}

	public WeatherType getPlayerWeather() {
		return this.weather;
	}

	public void setPlayerWeather(WeatherType type, boolean plugin) {
		if (plugin || this.weather == null) {
			if (plugin) {
				this.weather = type;
			}

			this.playerConnection.sendPacket(new Packet70Bed(type == WeatherType.DOWNFALL ? 1 : 2, 0));
		}
	}

	public void resetPlayerWeather() {
		this.weather = null;
		this.setPlayerWeather(this.world.getWorldData().hasStorm() ? WeatherType.DOWNFALL : WeatherType.CLEAR, false);
	}

	public String toString() {
		return super.toString() + "(" + this.name + " at " + this.locX + "," + this.locY + "," + this.locZ + ")";
	}

	public void reset() {
		float exp = 0.0F;
		boolean keepInventory = this.world.getGameRules().getBoolean("keepInventory");

		if (this.keepLevel || keepInventory) {
			exp = this.exp;
			this.newTotalExp = this.expTotal;
			this.newLevel = this.expLevel;
		}

		this.setHealth(this.getMaxHealth());
		this.fireTicks = 0;
		this.fallDistance = 0.0F;
		this.foodData = new FoodMetaData();
		this.expLevel = this.newLevel;
		this.expTotal = this.newTotalExp;
		this.exp = 0.0F;
		this.deathTicks = 0;
		this.clearActivePotions();
		this.updateEffects = true;
		this.activeContainer = this.defaultContainer;
		this.killer = null;
		this.lastDamager = null;
		this.combatTracker = new CombatTracker(this);
		this.lastSentExp = -1;

		if (!this.keepLevel && !keepInventory) {
			this.giveExp(this.newExp);
		} else {
			this.exp = exp;
		}

		this.keepLevel = false;
	}

	public CraftPlayer getBukkitEntity() {
		return (CraftPlayer) super.getBukkitEntity();
	}
}
