package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportChunkPosHash implements Callable
{
    final int a;

    final int b;

    final StructureGenerator c;

    CrashReportChunkPosHash(StructureGenerator var1, int var2, int var3)
    {
        this.c = var1;
        this.a = var2;
        this.b = var3;
    }

    public String a()
    {
        return String.valueOf(ChunkCoordIntPair.chunkXZ2Int(this.a, this.b));
    }

    public Object call()
    {
        return this.a();
    }
}
