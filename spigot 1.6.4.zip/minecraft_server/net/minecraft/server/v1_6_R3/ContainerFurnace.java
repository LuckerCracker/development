package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryFurnace;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public class ContainerFurnace extends Container {
	private TileEntityFurnace furnace;
	private int lastCookTime;
	private int lastBurnTime;
	private int lastItemBurnTime;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			CraftInventoryFurnace inventory = new CraftInventoryFurnace(this.furnace);
			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(), inventory, this);
			return this.bukkitEntity;
		}
	}

	public ContainerFurnace(PlayerInventory playerinventory, TileEntityFurnace tileentityfurnace) {
		this.furnace = tileentityfurnace;
		this.addSlotToContainer(new Slot(tileentityfurnace, 0, 56, 17));
		this.addSlotToContainer(new Slot(tileentityfurnace, 1, 56, 53));
		this.addSlotToContainer(new SlotFurnaceResult(playerinventory.player, tileentityfurnace, 2, 116, 35));
		this.player = playerinventory;
		int i;

		for (i = 0; i < 3; ++i) {
			for (int j = 0; j < 9; ++j) {
				this.addSlotToContainer(new Slot(playerinventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
			}
		}

		for (i = 0; i < 9; ++i) {
			this.addSlotToContainer(new Slot(playerinventory, i, 8 + i * 18, 142));
		}
	}

	public void addSlotListener(ICrafting icrafting) {
		super.addSlotListener(icrafting);
		icrafting.setContainerData(this, 0, this.furnace.cookTime);
		icrafting.setContainerData(this, 1, this.furnace.burnTime);
		icrafting.setContainerData(this, 2, this.furnace.ticksForCurrentFuel);
	}

	/**
	 * Looks for changes made in the container, sends them to every listener.
	 */
	public void detectAndSendChanges() {
		super.detectAndSendChanges();

		for (int var1 = 0; var1 < this.listeners.size(); ++var1) {
			ICrafting var2 = (ICrafting) this.listeners.get(var1);

			if (this.lastCookTime != this.furnace.cookTime) {
				var2.setContainerData(this, 0, this.furnace.cookTime);
			}

			if (this.lastBurnTime != this.furnace.burnTime) {
				var2.setContainerData(this, 1, this.furnace.burnTime);
			}

			if (this.lastItemBurnTime != this.furnace.ticksForCurrentFuel) {
				var2.setContainerData(this, 2, this.furnace.ticksForCurrentFuel);
			}
		}

		this.lastCookTime = this.furnace.cookTime;
		this.lastBurnTime = this.furnace.burnTime;
		this.lastItemBurnTime = this.furnace.ticksForCurrentFuel;
	}

	public boolean a(EntityHuman entityhuman) {
		return !this.checkReachable ? true : this.furnace.a(entityhuman);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i == 2) {
				if (!this.mergeItemStack(itemstack1, 3, 39, true)) {
					return null;
				}

				slot.onSlotChange(itemstack1, itemstack);
			} else if (i != 1 && i != 0) {
				if (RecipesFurnace.getInstance().getResult(itemstack1.getItem().id) != null) {
					if (!this.mergeItemStack(itemstack1, 0, 1, false)) {
						return null;
					}
				} else if (TileEntityFurnace.isFuel(itemstack1)) {
					if (!this.mergeItemStack(itemstack1, 1, 2, false)) {
						return null;
					}
				} else if (i >= 3 && i < 30) {
					if (!this.mergeItemStack(itemstack1, 30, 39, false)) {
						return null;
					}
				} else if (i >= 30 && i < 39 && !this.mergeItemStack(itemstack1, 3, 30, false)) {
					return null;
				}
			} else if (!this.mergeItemStack(itemstack1, 3, 39, false)) {
				return null;
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}
}
