package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportCorruptNBTTag2 implements Callable
{
    final int a;

    final NBTTagCompound b;

    CrashReportCorruptNBTTag2(NBTTagCompound var1, int var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        return NBTBase.NBTTypes[this.a];
    }

    public Object call()
    {
        return this.a();
    }
}
