package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.Random;

public class BlockChest extends BlockContainer
{
    private final Random random = new Random();

    /** 1 for trapped chests, 0 for normal chests. */
    public final int chestType;

    protected BlockChest(int par1, int par2)
    {
        super(par1, Material.WOOD);
        this.chestType = par2;
        this.a(CreativeModeTab.c);
        this.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 22;
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        if (var1.getTypeId(var2, var3, var4 - 1) == this.id)
        {
            this.setBlockBounds(0.0625F, 0.0F, 0.0F, 0.9375F, 0.875F, 0.9375F);
        }
        else if (var1.getTypeId(var2, var3, var4 + 1) == this.id)
        {
            this.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 1.0F);
        }
        else if (var1.getTypeId(var2 - 1, var3, var4) == this.id)
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
        }
        else if (var1.getTypeId(var2 + 1, var3, var4) == this.id)
        {
            this.setBlockBounds(0.0625F, 0.0F, 0.0625F, 1.0F, 0.875F, 0.9375F);
        }
        else
        {
            this.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
        }
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        super.onPlace(var1, var2, var3, var4);
        this.unifyAdjacentChests(var1, var2, var3, var4);
        int var5 = var1.getTypeId(var2, var3, var4 - 1);
        int var6 = var1.getTypeId(var2, var3, var4 + 1);
        int var7 = var1.getTypeId(var2 - 1, var3, var4);
        int var8 = var1.getTypeId(var2 + 1, var3, var4);

        if (var5 == this.id)
        {
            this.unifyAdjacentChests(var1, var2, var3, var4 - 1);
        }

        if (var6 == this.id)
        {
            this.unifyAdjacentChests(var1, var2, var3, var4 + 1);
        }

        if (var7 == this.id)
        {
            this.unifyAdjacentChests(var1, var2 - 1, var3, var4);
        }

        if (var8 == this.id)
        {
            this.unifyAdjacentChests(var1, var2 + 1, var3, var4);
        }
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        int var7 = var1.getTypeId(var2, var3, var4 - 1);
        int var8 = var1.getTypeId(var2, var3, var4 + 1);
        int var9 = var1.getTypeId(var2 - 1, var3, var4);
        int var10 = var1.getTypeId(var2 + 1, var3, var4);
        byte var11 = 0;
        int var12 = MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3;

        if (var12 == 0)
        {
            var11 = 2;
        }

        if (var12 == 1)
        {
            var11 = 5;
        }

        if (var12 == 2)
        {
            var11 = 3;
        }

        if (var12 == 3)
        {
            var11 = 4;
        }

        if (var7 != this.id && var8 != this.id && var9 != this.id && var10 != this.id)
        {
            var1.setData(var2, var3, var4, var11, 3);
        }
        else
        {
            if ((var7 == this.id || var8 == this.id) && (var11 == 4 || var11 == 5))
            {
                if (var7 == this.id)
                {
                    var1.setData(var2, var3, var4 - 1, var11, 3);
                }
                else
                {
                    var1.setData(var2, var3, var4 + 1, var11, 3);
                }

                var1.setData(var2, var3, var4, var11, 3);
            }

            if ((var9 == this.id || var10 == this.id) && (var11 == 2 || var11 == 3))
            {
                if (var9 == this.id)
                {
                    var1.setData(var2 - 1, var3, var4, var11, 3);
                }
                else
                {
                    var1.setData(var2 + 1, var3, var4, var11, 3);
                }

                var1.setData(var2, var3, var4, var11, 3);
            }
        }

        if (var6.hasName())
        {
            ((TileEntityChest)var1.getTileEntity(var2, var3, var4)).setChestGuiName(var6.getName());
        }
    }

    /**
     * Turns the adjacent chests to a double chest.
     */
    public void unifyAdjacentChests(World par1World, int par2, int par3, int par4)
    {
        if (!par1World.isStatic)
        {
            int var5 = par1World.getTypeId(par2, par3, par4 - 1);
            int var6 = par1World.getTypeId(par2, par3, par4 + 1);
            int var7 = par1World.getTypeId(par2 - 1, par3, par4);
            int var8 = par1World.getTypeId(par2 + 1, par3, par4);
            boolean var9 = true;
            int var10;
            int var11;
            boolean var12;
            byte var13;
            int var14;

            if (var5 != this.id && var6 != this.id)
            {
                if (var7 != this.id && var8 != this.id)
                {
                    var13 = 3;

                    if (Block.opaqueCubeLookup[var5] && !Block.opaqueCubeLookup[var6])
                    {
                        var13 = 3;
                    }

                    if (Block.opaqueCubeLookup[var6] && !Block.opaqueCubeLookup[var5])
                    {
                        var13 = 2;
                    }

                    if (Block.opaqueCubeLookup[var7] && !Block.opaqueCubeLookup[var8])
                    {
                        var13 = 5;
                    }

                    if (Block.opaqueCubeLookup[var8] && !Block.opaqueCubeLookup[var7])
                    {
                        var13 = 4;
                    }
                }
                else
                {
                    var10 = par1World.getTypeId(var7 == this.id ? par2 - 1 : par2 + 1, par3, par4 - 1);
                    var11 = par1World.getTypeId(var7 == this.id ? par2 - 1 : par2 + 1, par3, par4 + 1);
                    var13 = 3;
                    var12 = true;

                    if (var7 == this.id)
                    {
                        var14 = par1World.getData(par2 - 1, par3, par4);
                    }
                    else
                    {
                        var14 = par1World.getData(par2 + 1, par3, par4);
                    }

                    if (var14 == 2)
                    {
                        var13 = 2;
                    }

                    if ((Block.opaqueCubeLookup[var5] || Block.opaqueCubeLookup[var10]) && !Block.opaqueCubeLookup[var6] && !Block.opaqueCubeLookup[var11])
                    {
                        var13 = 3;
                    }

                    if ((Block.opaqueCubeLookup[var6] || Block.opaqueCubeLookup[var11]) && !Block.opaqueCubeLookup[var5] && !Block.opaqueCubeLookup[var10])
                    {
                        var13 = 2;
                    }
                }
            }
            else
            {
                var10 = par1World.getTypeId(par2 - 1, par3, var5 == this.id ? par4 - 1 : par4 + 1);
                var11 = par1World.getTypeId(par2 + 1, par3, var5 == this.id ? par4 - 1 : par4 + 1);
                var13 = 5;
                var12 = true;

                if (var5 == this.id)
                {
                    var14 = par1World.getData(par2, par3, par4 - 1);
                }
                else
                {
                    var14 = par1World.getData(par2, par3, par4 + 1);
                }

                if (var14 == 4)
                {
                    var13 = 4;
                }

                if ((Block.opaqueCubeLookup[var7] || Block.opaqueCubeLookup[var10]) && !Block.opaqueCubeLookup[var8] && !Block.opaqueCubeLookup[var11])
                {
                    var13 = 5;
                }

                if ((Block.opaqueCubeLookup[var8] || Block.opaqueCubeLookup[var11]) && !Block.opaqueCubeLookup[var7] && !Block.opaqueCubeLookup[var10])
                {
                    var13 = 4;
                }
            }

            par1World.setData(par2, par3, par4, var13, 3);
        }
    }

    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        int var5 = 0;

        if (var1.getTypeId(var2 - 1, var3, var4) == this.id)
        {
            ++var5;
        }

        if (var1.getTypeId(var2 + 1, var3, var4) == this.id)
        {
            ++var5;
        }

        if (var1.getTypeId(var2, var3, var4 - 1) == this.id)
        {
            ++var5;
        }

        if (var1.getTypeId(var2, var3, var4 + 1) == this.id)
        {
            ++var5;
        }

        return var5 > 1 ? false : (this.isThereANeighborChest(var1, var2 - 1, var3, var4) ? false : (this.isThereANeighborChest(var1, var2 + 1, var3, var4) ? false : (this.isThereANeighborChest(var1, var2, var3, var4 - 1) ? false : !this.isThereANeighborChest(var1, var2, var3, var4 + 1))));
    }

    /**
     * Checks the neighbor blocks to see if there is a chest there. Args: world, x, y, z
     */
    private boolean isThereANeighborChest(World par1World, int par2, int par3, int par4)
    {
        return par1World.getTypeId(par2, par3, par4) != this.id ? false : (par1World.getTypeId(par2 - 1, par3, par4) == this.id ? true : (par1World.getTypeId(par2 + 1, par3, par4) == this.id ? true : (par1World.getTypeId(par2, par3, par4 - 1) == this.id ? true : par1World.getTypeId(par2, par3, par4 + 1) == this.id)));
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        super.doPhysics(var1, var2, var3, var4, var5);
        TileEntityChest var6 = (TileEntityChest)var1.getTileEntity(var2, var3, var4);

        if (var6 != null)
        {
            var6.updateContainingBlockInfo();
        }
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        TileEntityChest var7 = (TileEntityChest)var1.getTileEntity(var2, var3, var4);

        if (var7 != null)
        {
            for (int var8 = 0; var8 < var7.getSize(); ++var8)
            {
                ItemStack var9 = var7.getItem(var8);

                if (var9 != null)
                {
                    float var10 = this.random.nextFloat() * 0.8F + 0.1F;
                    float var11 = this.random.nextFloat() * 0.8F + 0.1F;
                    EntityItem var14;

                    for (float var12 = this.random.nextFloat() * 0.8F + 0.1F; var9.count > 0; var1.addEntity(var14))
                    {
                        int var13 = this.random.nextInt(21) + 10;

                        if (var13 > var9.count)
                        {
                            var13 = var9.count;
                        }

                        var9.count -= var13;
                        var14 = new EntityItem(var1, (double)((float)var2 + var10), (double)((float)var3 + var11), (double)((float)var4 + var12), new ItemStack(var9.id, var13, var9.getData()));
                        float var15 = 0.05F;
                        var14.motX = (double)((float)this.random.nextGaussian() * var15);
                        var14.motY = (double)((float)this.random.nextGaussian() * var15 + 0.2F);
                        var14.motZ = (double)((float)this.random.nextGaussian() * var15);

                        if (var9.hasTag())
                        {
                            var14.getItemStack().setTag((NBTTagCompound)var9.getTag().clone());
                        }
                    }
                }
            }

            var1.func_96440_m(var2, var3, var4, var5);
        }

        super.remove(var1, var2, var3, var4, var5, var6);
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            IInventory var10 = this.getInventory(var1, var2, var3, var4);

            if (var10 != null)
            {
                var5.openContainer(var10);
            }

            return true;
        }
    }

    /**
     * Gets the inventory of the chest at the specified coords, accounting for blocks or ocelots on top of the chest,
     * and double chests.
     */
    public IInventory getInventory(World par1World, int par2, int par3, int par4)
    {
        Object var5 = (TileEntityChest)par1World.getTileEntity(par2, par3, par4);

        if (var5 == null)
        {
            return null;
        }
        else if (par1World.isBlockNormalCube(par2, par3 + 1, par4))
        {
            return null;
        }
        else if (isOcelotBlockingChest(par1World, par2, par3, par4))
        {
            return null;
        }
        else if (par1World.getTypeId(par2 - 1, par3, par4) == this.id && (par1World.isBlockNormalCube(par2 - 1, par3 + 1, par4) || isOcelotBlockingChest(par1World, par2 - 1, par3, par4)))
        {
            return null;
        }
        else if (par1World.getTypeId(par2 + 1, par3, par4) == this.id && (par1World.isBlockNormalCube(par2 + 1, par3 + 1, par4) || isOcelotBlockingChest(par1World, par2 + 1, par3, par4)))
        {
            return null;
        }
        else if (par1World.getTypeId(par2, par3, par4 - 1) == this.id && (par1World.isBlockNormalCube(par2, par3 + 1, par4 - 1) || isOcelotBlockingChest(par1World, par2, par3, par4 - 1)))
        {
            return null;
        }
        else if (par1World.getTypeId(par2, par3, par4 + 1) == this.id && (par1World.isBlockNormalCube(par2, par3 + 1, par4 + 1) || isOcelotBlockingChest(par1World, par2, par3, par4 + 1)))
        {
            return null;
        }
        else
        {
            if (par1World.getTypeId(par2 - 1, par3, par4) == this.id)
            {
                var5 = new InventoryLargeChest("container.chestDouble", (TileEntityChest)par1World.getTileEntity(par2 - 1, par3, par4), (IInventory)var5);
            }

            if (par1World.getTypeId(par2 + 1, par3, par4) == this.id)
            {
                var5 = new InventoryLargeChest("container.chestDouble", (IInventory)var5, (TileEntityChest)par1World.getTileEntity(par2 + 1, par3, par4));
            }

            if (par1World.getTypeId(par2, par3, par4 - 1) == this.id)
            {
                var5 = new InventoryLargeChest("container.chestDouble", (TileEntityChest)par1World.getTileEntity(par2, par3, par4 - 1), (IInventory)var5);
            }

            if (par1World.getTypeId(par2, par3, par4 + 1) == this.id)
            {
                var5 = new InventoryLargeChest("container.chestDouble", (IInventory)var5, (TileEntityChest)par1World.getTileEntity(par2, par3, par4 + 1));
            }

            return (IInventory)var5;
        }
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        TileEntityChest var2 = new TileEntityChest();
        return var2;
    }

    public boolean isPowerSource()
    {
        return this.chestType == 1;
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        if (!this.isPowerSource())
        {
            return 0;
        }
        else
        {
            int var6 = ((TileEntityChest)par1IBlockAccess.getTileEntity(par2, par3, par4)).numUsingPlayers;
            return MathHelper.clamp_int(var6, 0, 15);
        }
    }

    /**
     * Returns true if the block is emitting direct/strong redstone power on the specified side. Args: World, X, Y, Z,
     * side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingStrongPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        return par5 == 1 ? this.isProvidingWeakPower(par1IBlockAccess, par2, par3, par4, par5) : 0;
    }

    /**
     * Looks for a sitting ocelot within certain bounds. Such an ocelot is considered to be blocking access to the
     * chest.
     */
    private static boolean isOcelotBlockingChest(World par0World, int par1, int par2, int par3)
    {
        Iterator var4 = par0World.getEntitiesWithinAABB(EntityOcelot.class, AxisAlignedBB.getAABBPool().getAABB((double)par1, (double)(par2 + 1), (double)par3, (double)(par1 + 1), (double)(par2 + 2), (double)(par3 + 1))).iterator();
        EntityOcelot var6;

        do
        {
            if (!var4.hasNext())
            {
                return false;
            }

            EntityOcelot var5 = (EntityOcelot)var4.next();
            var6 = (EntityOcelot)var5;
        }
        while (!var6.isSitting());

        return true;
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        return Container.calcRedstoneFromInventory(this.getInventory(par1World, par2, par3, par4));
    }
}
