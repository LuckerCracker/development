package net.minecraft.server.v1_6_R3;

public class BlockPotatoes extends BlockCrops
{
    public BlockPotatoes(int var1)
    {
        super(var1);
    }

    /**
     * Generate a seed ItemStack for this crop.
     */
    protected int getSeedItem()
    {
        return Item.POTATO.id;
    }

    /**
     * Generate a crop produce ItemStack for this crop.
     */
    protected int getCropItem()
    {
        return Item.POTATO.id;
    }

    public void dropNaturally(World var1, int var2, int var3, int var4, int var5, float var6, int var7)
    {
        super.dropNaturally(var1, var2, var3, var4, var5, var6, var7);

        if (!var1.isStatic)
        {
            if (var5 >= 7 && var1.random.nextInt(50) == 0)
            {
                this.dropBlockAsItem_do(var1, var2, var3, var4, new ItemStack(Item.POTATO_POISON));
            }
        }
    }
}
