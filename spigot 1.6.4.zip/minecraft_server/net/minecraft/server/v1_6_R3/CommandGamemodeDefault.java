package net.minecraft.server.v1_6_R3;

import java.util.Iterator;

public class CommandGamemodeDefault extends CommandGamemode
{
    public String getCommandName()
    {
        return "defaultgamemode";
    }

    public String c(ICommandListener var1)
    {
        return "commands.defaultgamemode.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length > 0)
        {
            EnumGamemode var3 = this.f(var1, var2[0]);
            this.a(var3);
            a(var1, "commands.defaultgamemode.success", new Object[] {ChatMessage.e("gameMode." + var3.b())});
        }
        else
        {
            throw new ExceptionUsage("commands.defaultgamemode.usage", new Object[0]);
        }
    }

    protected void a(EnumGamemode var1)
    {
        MinecraftServer var2 = MinecraftServer.getServer();
        var2.a(var1);
        EntityPlayer var4;

        if (var2.getForceGamemode())
        {
            for (Iterator var3 = MinecraftServer.getServer().getPlayerList().players.iterator(); var3.hasNext(); var4.fallDistance = 0.0F)
            {
                var4 = (EntityPlayer)var3.next();
                var4.setGameType(var1);
            }
        }
    }
}
