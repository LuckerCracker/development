package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportCorruptNBTTag implements Callable
{
    final String a;

    final NBTTagCompound b;

    CrashReportCorruptNBTTag(NBTTagCompound var1, String var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        return NBTBase.NBTTypes[((NBTBase)NBTTagCompound.getTagMap(this.b).get(this.a)).getTypeId()];
    }

    public Object call()
    {
        return this.a();
    }
}
