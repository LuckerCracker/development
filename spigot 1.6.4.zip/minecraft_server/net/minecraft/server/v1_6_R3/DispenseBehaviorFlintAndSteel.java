package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.util.Vector;

final class DispenseBehaviorFlintAndSteel extends DispenseBehaviorItem
{
    private boolean b = true;

    protected ItemStack b(ISourceBlock isourceblock, ItemStack itemstack)
    {
        EnumFacing enumfacing = BlockDispenser.getFacing(isourceblock.h());
        World world = isourceblock.k();
        int i = isourceblock.getBlockX() + enumfacing.getFrontOffsetX();
        int j = isourceblock.getBlockY() + enumfacing.getFrontOffsetY();
        int k = isourceblock.getBlockZ() + enumfacing.getFrontOffsetZ();
        org.bukkit.block.Block block = world.getWorld().getBlockAt(isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ());
        CraftItemStack craftItem = CraftItemStack.asCraftMirror(itemstack);
        BlockDispenseEvent event = new BlockDispenseEvent(block, craftItem.clone(), new Vector(0, 0, 0));

        if (!BlockDispenser.eventFired)
        {
            world.getServer().getPluginManager().callEvent(event);
        }

        if (event.isCancelled())
        {
            return itemstack;
        }
        else
        {
            if (!event.getItem().equals(craftItem))
            {
                ItemStack eventStack = CraftItemStack.asNMSCopy(event.getItem());
                IDispenseBehavior idispensebehavior = (IDispenseBehavior)BlockDispenser.dispenseBehaviorRegistry.getObject(eventStack.getItem());

                if (idispensebehavior != IDispenseBehavior.a && idispensebehavior != this)
                {
                    idispensebehavior.a(isourceblock, eventStack);
                    return itemstack;
                }
            }

            if (world.isEmpty(i, j, k))
            {
                if (!CraftEventFactory.callBlockIgniteEvent(world, i, j, k, isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ()).isCancelled())
                {
                    world.setTypeIdUpdate(i, j, k, Block.FIRE.id);

                    if (itemstack.isDamaged(1, world.random))
                    {
                        itemstack.count = 0;
                    }
                }
            }
            else if (world.getTypeId(i, j, k) == Block.TNT.id)
            {
                Block.TNT.postBreak(world, i, j, k, 1);
                world.setAir(i, j, k);
            }
            else
            {
                this.b = false;
            }

            return itemstack;
        }
    }

    protected void a(ISourceBlock isourceblock)
    {
        if (this.b)
        {
            isourceblock.k().triggerEffect(1000, isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ(), 0);
        }
        else
        {
            isourceblock.k().triggerEffect(1001, isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ(), 0);
        }
    }
}
