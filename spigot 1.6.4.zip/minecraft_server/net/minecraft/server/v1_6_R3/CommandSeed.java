package net.minecraft.server.v1_6_R3;

public class CommandSeed extends CommandAbstract
{
    public boolean a(ICommandListener var1)
    {
        return MinecraftServer.getServer().K() || super.a(var1);
    }

    public String getCommandName()
    {
        return "seed";
    }

    public int a()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.seed.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        Object var3 = var1 instanceof EntityHuman ? ((EntityHuman)var1).world : MinecraftServer.getServer().getWorldServer(0);
        var1.sendMessage(ChatMessage.b("commands.seed.success", new Object[] {Long.valueOf(((World)var3).getSeed())}));
    }
}
