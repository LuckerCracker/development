package net.minecraft.server.v1_6_R3;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import org.bukkit.craftbukkit.libs.com.google.gson.Gson;
import org.bukkit.craftbukkit.libs.com.google.gson.GsonBuilder;

public class ChatMessage
{
    private static final Gson a = (new GsonBuilder()).registerTypeAdapter(ChatMessage.class, new ChatSerializer()).create();
    private EnumChatFormat b;
    private Boolean c;
    private Boolean d;
    private Boolean e;
    private Boolean f;
    private String g;
    private String h;
    private List i;

    public ChatMessage() {}

    public ChatMessage(ChatMessage var1)
    {
        this.b = var1.b;
        this.c = var1.c;
        this.d = var1.d;
        this.e = var1.e;
        this.f = var1.f;
        this.g = var1.g;
        this.h = var1.h;
        this.i = var1.i == null ? null : Lists.newArrayList(var1.i);
    }

    public ChatMessage a(EnumChatFormat var1)
    {
        if (var1 != null && !var1.c())
        {
            throw new IllegalArgumentException("Argument is not a valid color!");
        }
        else
        {
            this.b = var1;
            return this;
        }
    }

    public EnumChatFormat a()
    {
        return this.b;
    }

    public ChatMessage a(Boolean var1)
    {
        this.c = var1;
        return this;
    }

    public Boolean b()
    {
        return this.c;
    }

    public ChatMessage b(Boolean var1)
    {
        this.d = var1;
        return this;
    }

    public Boolean c()
    {
        return this.d;
    }

    public ChatMessage c(Boolean var1)
    {
        this.e = var1;
        return this;
    }

    public Boolean d()
    {
        return this.e;
    }

    public ChatMessage d(Boolean var1)
    {
        this.f = var1;
        return this;
    }

    public Boolean e()
    {
        return this.f;
    }

    protected String f()
    {
        return this.g;
    }

    protected String g()
    {
        return this.h;
    }

    protected List h()
    {
        return this.i;
    }

    public ChatMessage a(ChatMessage var1)
    {
        if (this.g == null && this.h == null)
        {
            if (this.i != null)
            {
                this.i.add(var1);
            }
            else
            {
                this.i = Lists.newArrayList(new ChatMessage[] {var1});
            }
        }
        else
        {
            this.i = Lists.newArrayList(new ChatMessage[] {new ChatMessage(this), var1});
            this.g = null;
            this.h = null;
        }

        return this;
    }

    public ChatMessage a(String var1)
    {
        if (this.g == null && this.h == null)
        {
            if (this.i != null)
            {
                this.i.add(d(var1));
            }
            else
            {
                this.g = var1;
            }
        }
        else
        {
            this.i = Lists.newArrayList(new ChatMessage[] {new ChatMessage(this), d(var1)});
            this.g = null;
            this.h = null;
        }

        return this;
    }

    public ChatMessage b(String var1)
    {
        if (this.g == null && this.h == null)
        {
            if (this.i != null)
            {
                this.i.add(e(var1));
            }
            else
            {
                this.h = var1;
            }
        }
        else
        {
            this.i = Lists.newArrayList(new ChatMessage[] {new ChatMessage(this), e(var1)});
            this.g = null;
            this.h = null;
        }

        return this;
    }

    public ChatMessage a(String var1, Object ... var2)
    {
        if (this.g == null && this.h == null)
        {
            if (this.i != null)
            {
                this.i.add(b(var1, var2));
            }
            else
            {
                this.h = var1;
                this.i = Lists.newArrayList();
                Object[] var3 = var2;
                int var4 = var2.length;

                for (int var5 = 0; var5 < var4; ++var5)
                {
                    Object var6 = var3[var5];

                    if (var6 instanceof ChatMessage)
                    {
                        this.i.add((ChatMessage)var6);
                    }
                    else
                    {
                        this.i.add(d(var6.toString()));
                    }
                }
            }
        }
        else
        {
            this.i = Lists.newArrayList(new ChatMessage[] {new ChatMessage(this), b(var1, var2)});
            this.g = null;
            this.h = null;
        }

        return this;
    }

    public String toString()
    {
        return this.a(false);
    }

    public String a(boolean var1)
    {
        return this.a(var1, (EnumChatFormat)null, false, false, false, false);
    }

    public String a(boolean var1, EnumChatFormat var2, boolean var3, boolean var4, boolean var5, boolean var6)
    {
        StringBuilder var7 = new StringBuilder();
        EnumChatFormat var8 = this.b == null ? var2 : this.b;
        boolean var9 = this.c == null ? var3 : this.c.booleanValue();
        boolean var10 = this.d == null ? var4 : this.d.booleanValue();
        boolean var11 = this.e == null ? var5 : this.e.booleanValue();
        boolean var12 = this.f == null ? var6 : this.f.booleanValue();

        if (this.h != null)
        {
            if (var1)
            {
                a(var7, var8, var9, var10, var11, var12);
            }

            if (this.i != null)
            {
                String[] var13 = new String[this.i.size()];

                for (int var14 = 0; var14 < this.i.size(); ++var14)
                {
                    var13[var14] = ((ChatMessage)this.i.get(var14)).a(var1, var8, var9, var10, var11, var12);
                }

                var7.append(LocaleI18n.get(this.h, var13));
            }
            else
            {
                var7.append(LocaleI18n.get(this.h));
            }
        }
        else if (this.g != null)
        {
            if (var1)
            {
                a(var7, var8, var9, var10, var11, var12);
            }

            var7.append(this.g);
        }
        else
        {
            ChatMessage var16;

            if (this.i != null)
            {
                for (Iterator var15 = this.i.iterator(); var15.hasNext(); var7.append(var16.a(var1, var8, var9, var10, var11, var12)))
                {
                    var16 = (ChatMessage)var15.next();

                    if (var1)
                    {
                        a(var7, var8, var9, var10, var11, var12);
                    }
                }
            }
        }

        return var7.toString();
    }

    private static void a(StringBuilder var0, EnumChatFormat var1, boolean var2, boolean var3, boolean var4, boolean var5)
    {
        if (var1 != null)
        {
            var0.append(var1);
        }
        else if (var2 || var3 || var4 || var5)
        {
            var0.append(EnumChatFormat.RESET);
        }

        if (var2)
        {
            var0.append(EnumChatFormat.BOLD);
        }

        if (var3)
        {
            var0.append(EnumChatFormat.ITALIC);
        }

        if (var4)
        {
            var0.append(EnumChatFormat.UNDERLINE);
        }

        if (var5)
        {
            var0.append(EnumChatFormat.RANDOM);
        }
    }

    public static ChatMessage d(String var0)
    {
        ChatMessage var1 = new ChatMessage();
        var1.a(var0);
        return var1;
    }

    public static ChatMessage e(String var0)
    {
        ChatMessage var1 = new ChatMessage();
        var1.b(var0);
        return var1;
    }

    public static ChatMessage b(String var0, Object ... var1)
    {
        ChatMessage var2 = new ChatMessage();
        var2.a(var0, var1);
        return var2;
    }

    public String i()
    {
        return a.toJson((Object)this);
    }
}
