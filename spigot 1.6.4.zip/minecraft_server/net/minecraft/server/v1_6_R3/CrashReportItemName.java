package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportItemName implements Callable
{
    final ItemStack a;

    final PlayerInventory b;

    CrashReportItemName(PlayerInventory var1, ItemStack var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        return this.a.getName();
    }

    public Object call()
    {
        return this.a();
    }
}
