package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockMonsterEggs extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    public static final String[] displayOnCreativeTab = new String[] {"stone", "cobble", "brick"};

    public BlockMonsterEggs(int var1)
    {
        super(var1, Material.CLAY);
        this.setHardness(0.0F);
        this.a(CreativeModeTab.c);
    }

    public void postBreak(World var1, int var2, int var3, int var4, int var5)
    {
        if (!var1.isStatic)
        {
            EntitySilverfish var6 = new EntitySilverfish(var1);
            var6.setPositionRotation((double)var2 + 0.5D, (double)var3, (double)var4 + 0.5D, 0.0F, 0.0F);
            var1.addEntity(var6);
            var6.spawnExplosionParticle();
        }

        super.postBreak(var1, var2, var3, var4, var5);
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random var1)
    {
        return 0;
    }

    public static boolean d(int var0)
    {
        return var0 == Block.STONE.id || var0 == Block.COBBLESTONE.id || var0 == Block.SMOOTH_BRICK.id;
    }

    public static int e(int var0)
    {
        return var0 == Block.COBBLESTONE.id ? 1 : (var0 == Block.SMOOTH_BRICK.id ? 2 : 0);
    }

    /**
     * Returns an item stack containing a single instance of the current block type. 'i' is the block's subtype/damage
     * and is ignored for blocks which do not support subtypes. Blocks which cannot be harvested should return null.
     */
    protected ItemStack createStackedBlock(int var1)
    {
        Block var2 = Block.STONE;

        if (var1 == 1)
        {
            var2 = Block.COBBLESTONE;
        }

        if (var1 == 2)
        {
            var2 = Block.SMOOTH_BRICK;
        }

        return new ItemStack(var2);
    }

    public int getDropData(World var1, int var2, int var3, int var4)
    {
        return var1.getData(var2, var3, var4);
    }
}
