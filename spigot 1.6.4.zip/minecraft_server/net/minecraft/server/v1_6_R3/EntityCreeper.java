package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.CreeperPowerEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;

public class EntityCreeper extends EntityMonster {
	/**
	 * Time when this creeper was last in an active state (Messed up code here,
	 * probably causes creeper animation to go weird)
	 */
	private int lastActiveTime;
	private int fuseTicks;
	private int maxFuseTicks = 30;
	private int explosionRadius = 3;
	private int record = -1;

	public EntityCreeper(World par1World) {
		super(par1World);
		this.goalSelector.a(1, new PathfinderGoalFloat(this));
		this.goalSelector.a(2, new PathfinderGoalSwell(this));
		this.goalSelector.a(3, new PathfinderGoalAvoidPlayer(this, EntityOcelot.class, 6.0F, 1.0D, 1.2D));
		this.goalSelector.a(4, new PathfinderGoalMeleeAttack(this, 1.0D, false));
		this.goalSelector.a(5, new PathfinderGoalRandomStroll(this, 0.8D));
		this.goalSelector.a(6, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
		this.goalSelector.a(6, new PathfinderGoalRandomLookaround(this));
		this.targetSelector.a(1, new PathfinderGoalNearestAttackableTarget(this, EntityHuman.class, 0, true));
		this.targetSelector.a(2, new PathfinderGoalHurtByTarget(this, false));
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.d).setValue(0.25D);
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	public boolean isAIEnabled() {
		return true;
	}

	/**
	 * The number of iterations PathFinder.getSafePoint will execute before
	 * giving up.
	 */
	public int getMaxSafePointTries() {
		return this.getGoalTarget() == null ? 3 : 3 + (int) (this.getHealth() - 1.0F);
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float par1) {
		super.fall(par1);
		this.fuseTicks = (int) ((float) this.fuseTicks + par1 * 1.5F);

		if (this.fuseTicks > this.maxFuseTicks - 5) {
			this.fuseTicks = this.maxFuseTicks - 5;
		}
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(16, Byte.valueOf((byte) -1));
		this.datawatcher.addObject(17, Byte.valueOf((byte) 0));
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);

		if (this.datawatcher.getByte(17) == 1) {
			par1NBTTagCompound.setBoolean("powered", true);
		}

		par1NBTTagCompound.setShort("Fuse", (short) this.maxFuseTicks);
		par1NBTTagCompound.setByte("ExplosionRadius", (byte) this.explosionRadius);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.datawatcher.watch(17, Byte.valueOf((byte) (par1NBTTagCompound.getBoolean("powered") ? 1 : 0)));

		if (par1NBTTagCompound.hasKey("Fuse")) {
			this.maxFuseTicks = par1NBTTagCompound.getShort("Fuse");
		}

		if (par1NBTTagCompound.hasKey("ExplosionRadius")) {
			this.explosionRadius = par1NBTTagCompound.getByte("ExplosionRadius");
		}
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		if (this.isAlive()) {
			this.lastActiveTime = this.fuseTicks;
			int var1 = this.getCreeperState();

			if (var1 > 0 && this.fuseTicks == 0) {
				this.makeSound("random.fuse", 1.0F, 0.5F);
			}

			this.fuseTicks += var1;

			if (this.fuseTicks < 0) {
				this.fuseTicks = 0;
			}

			if (this.fuseTicks >= this.maxFuseTicks) {
				this.fuseTicks = this.maxFuseTicks;

				if (!this.world.isStatic) {
					boolean var2 = this.world.getGameRules().getBoolean("mobGriefing");
					float var3 = this.isPowered() ? 6.0F : 3.0F;
					ExplosionPrimeEvent var4 = new ExplosionPrimeEvent(this.getBukkitEntity(), var3, false);
					this.world.getServer().getPluginManager().callEvent(var4);

					if (!var4.isCancelled()) {
						this.world.createExplosion(this, this.locX, this.locY, this.locZ, var4.getRadius(),
								var4.getFire(), var2);
						this.die();
					} else {
						this.fuseTicks = 0;
					}
				}
			}
		}

		super.onUpdate();
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.creeper.say";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.creeper.death";
	}

	public void die(DamageSource damagesource) {
		if (damagesource.getEntity() instanceof EntitySkeleton) {
			int i = Item.RECORD_1.id + this.random.nextInt(Item.RECORD_12.id - Item.RECORD_1.id + 1);
			this.record = i;
		}

		super.die(damagesource);
	}

	protected void dropDeathLoot(boolean flag, int i) {
		int j = this.getLootId();
		ArrayList loot = new ArrayList();

		if (j > 0) {
			int k = this.random.nextInt(3);

			if (i > 0) {
				k += this.random.nextInt(i + 1);
			}

			if (k > 0) {
				loot.add(new org.bukkit.inventory.ItemStack(j, k));
			}
		}

		if (this.record != -1) {
			loot.add(new org.bukkit.inventory.ItemStack(this.record, 1));
			this.record = -1;
		}

		CraftEventFactory.callEntityDeathEvent(this, loot);
	}

	public boolean attackEntityAsMob(Entity par1Entity) {
		return true;
	}

	public boolean isPowered() {
		return this.datawatcher.getByte(17) == 1;
	}

	protected int getLootId() {
		return Item.SULPHUR.id;
	}

	/**
	 * Returns the current state of creeper, -1 is idle, 1 is 'in fuse'
	 */
	public int getCreeperState() {
		return this.datawatcher.getByte(16);
	}

	/**
	 * Sets the state of creeper, -1 to idle and 1 to be 'in fuse'
	 */
	public void setCreeperState(int par1) {
		this.datawatcher.watch(16, Byte.valueOf((byte) par1));
	}

	public void a(EntityLightning entitylightning) {
		super.a(entitylightning);

		if (!CraftEventFactory.callCreeperPowerEvent(this, entitylightning, CreeperPowerEvent.PowerCause.LIGHTNING)
				.isCancelled()) {
			this.setPowered(true);
		}
	}

	public void setPowered(boolean powered) {
		if (!powered) {
			this.datawatcher.watch(17, Byte.valueOf((byte) 0));
		} else {
			this.datawatcher.watch(17, Byte.valueOf((byte) 1));
		}
	}
}
