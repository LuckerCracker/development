package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.entity.EntityUnleashEvent;

public abstract class EntityInsentient extends EntityLiving {
	/** Number of ticks since this EntityLiving last produced its sound */
	public int livingSoundTime;

	/** The experience points the Entity gives. */
	protected int experienceValue;
	private ControllerLook lookHelper;
	private ControllerMove moveController;
	private ControllerJump lookController;
	private EntityAIBodyControl bodyHelper;
	private Navigation navigation;
	protected final PathfinderGoalSelector goalSelector;
	protected final PathfinderGoalSelector targetSelector;
	private EntityLiving goalTarget;
	private EntitySenses senses;
	private ItemStack[] equipment = new ItemStack[5];
	public float[] dropChances = new float[5];
	public boolean canPickUpLoot;
	public boolean persistent = !this.isTypeNotPersistent();
	protected float defaultPitch;

	/** This entity's current target. */
	private Entity currentTarget;

	/** How long to keep a specific target entity */
	protected int numTicksToChaseTarget;
	private boolean isLeashed;
	private Entity leashedToEntity;
	private NBTTagCompound field_110170_bx;

	public EntityInsentient(World world) {
		super(world);
		this.goalSelector = new PathfinderGoalSelector(
				world != null && world.methodProfiler != null ? world.methodProfiler : null);
		this.targetSelector = new PathfinderGoalSelector(
				world != null && world.methodProfiler != null ? world.methodProfiler : null);
		this.lookHelper = new ControllerLook(this);
		this.moveController = new ControllerMove(this);
		this.lookController = new ControllerJump(this);
		this.bodyHelper = new EntityAIBodyControl(this);
		this.navigation = new Navigation(this, world);
		this.senses = new EntitySenses(this);

		for (int i = 0; i < this.dropChances.length; ++i) {
			this.dropChances[i] = 0.085F;
		}
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeMap().b(GenericAttributes.b).setValue(16.0D);
	}

	public ControllerLook getControllerLook() {
		return this.lookHelper;
	}

	public ControllerMove getControllerMove() {
		return this.moveController;
	}

	public ControllerJump getControllerJump() {
		return this.lookController;
	}

	public Navigation getNavigation() {
		return this.navigation;
	}

	public EntitySenses getEntitySenses() {
		return this.senses;
	}

	public EntityLiving getGoalTarget() {
		return this.goalTarget;
	}

	public void setGoalTarget(EntityLiving entityliving) {
		this.goalTarget = entityliving;
	}

	/**
	 * Returns true if this entity can attack entities of the specified class.
	 */
	public boolean canAttackClass(Class oclass) {
		return EntityCreeper.class != oclass && EntityGhast.class != oclass;
	}

	/**
	 * This function applies the benefits of growing back wool and faster
	 * growing up to the acting entity. (This function is used in the
	 * AIEatGrass)
	 */
	public void eatGrassBonus() {
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(11, Byte.valueOf((byte) 0));
		this.datawatcher.addObject(10, "");
	}

	/**
	 * Get number of ticks, at least during which the living entity will be
	 * silent.
	 */
	public int getTalkInterval() {
		return 80;
	}

	/**
	 * Plays living's sound at its position
	 */
	public void playLivingSound() {
		String s = this.getLivingSound();

		if (s != null) {
			this.makeSound(s, this.getSoundVolume(), this.getSoundPitch());
		}
	}

	/**
	 * Gets called every tick from main Entity class
	 */
	public void onEntityUpdate() {
		super.onEntityUpdate();
		this.world.methodProfiler.a("mobBaseTick");

		if (this.isAlive() && this.random.nextInt(1000) < this.livingSoundTime++) {
			this.livingSoundTime = -this.getTalkInterval();
			this.playLivingSound();
		}

		this.world.methodProfiler.b();
	}

	protected int getExpValue(EntityHuman entityhuman) {
		if (this.experienceValue > 0) {
			int i = this.experienceValue;
			ItemStack[] aitemstack = this.getEquipment();

			for (int j = 0; j < aitemstack.length; ++j) {
				if (aitemstack[j] != null && this.dropChances[j] <= 1.0F) {
					i += 1 + this.random.nextInt(3);
				}
			}

			return i;
		} else {
			return this.experienceValue;
		}
	}

	/**
	 * Spawns an explosion particle around the Entity's location
	 */
	public void spawnExplosionParticle() {
		for (int i = 0; i < 20; ++i) {
			double d0 = this.random.nextGaussian() * 0.02D;
			double d1 = this.random.nextGaussian() * 0.02D;
			double d2 = this.random.nextGaussian() * 0.02D;
			double d3 = 10.0D;
			this.world.addParticle("explode",
					this.locX + (double) (this.random.nextFloat() * this.width * 2.0F) - (double) this.width - d0 * d3,
					this.locY + (double) (this.random.nextFloat() * this.length) - d1 * d3,
					this.locZ + (double) (this.random.nextFloat() * this.width * 2.0F) - (double) this.width - d2 * d3,
					d0, d1, d2);
		}
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		super.onUpdate();

		if (!this.world.isStatic) {
			this.func_110159_bB();
		}
	}

	protected float func_110146_f(float f, float f1) {
		if (this.isAIEnabled()) {
			this.bodyHelper.a();
			return f1;
		} else {
			return super.func_110146_f(f, f1);
		}
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return null;
	}

	protected int getLootId() {
		return 0;
	}

	protected void dropDeathLoot(boolean flag, int i) {
		ArrayList loot = new ArrayList();
		int j = this.getLootId();
		int k;

		if (j > 0) {
			k = this.random.nextInt(3);

			if (i > 0) {
				k += this.random.nextInt(i + 1);
			}

			if (k > 0) {
				loot.add(new org.bukkit.inventory.ItemStack(j, k));
			}
		}

		if (this.lastDamageByPlayerTime > 0) {
			k = this.random.nextInt(200) - i;

			if (k < 5) {
				ItemStack itemstack = this.l(k <= 0 ? 1 : 0);

				if (itemstack != null) {
					loot.add(CraftItemStack.asCraftMirror(itemstack));
				}
			}
		}

		CraftEventFactory.callEntityDeathEvent(this, loot);
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.setBoolean("CanPickUpLoot", this.canPickUpLoot());
		nbttagcompound.setBoolean("PersistenceRequired", this.persistent);
		NBTTagList nbttaglist = new NBTTagList();
		NBTTagCompound nbttagcompound1;

		for (int nbttaglist1 = 0; nbttaglist1 < this.equipment.length; ++nbttaglist1) {
			nbttagcompound1 = new NBTTagCompound();

			if (this.equipment[nbttaglist1] != null) {
				this.equipment[nbttaglist1].save(nbttagcompound1);
			}

			nbttaglist.add(nbttagcompound1);
		}

		nbttagcompound.set("Equipment", nbttaglist);
		NBTTagList var6 = new NBTTagList();

		for (int entityhanging = 0; entityhanging < this.dropChances.length; ++entityhanging) {
			var6.add(new NBTTagFloat(entityhanging + "", this.dropChances[entityhanging]));
		}

		nbttagcompound.set("DropChances", var6);
		nbttagcompound.setString("CustomName", this.getCustomName());
		nbttagcompound.setBoolean("CustomNameVisible", this.getCustomNameVisible());
		nbttagcompound.setBoolean("Leashed", this.isLeashed);

		if (this.leashedToEntity != null) {
			nbttagcompound1 = new NBTTagCompound("Leash");

			if (this.leashedToEntity instanceof EntityLiving) {
				nbttagcompound1.setLong("UUIDMost", this.leashedToEntity.getUniqueID().getMostSignificantBits());
				nbttagcompound1.setLong("UUIDLeast", this.leashedToEntity.getUniqueID().getLeastSignificantBits());
			} else if (this.leashedToEntity instanceof EntityHanging) {
				EntityHanging var7 = (EntityHanging) this.leashedToEntity;
				nbttagcompound1.setInt("X", var7.motionX);
				nbttagcompound1.setInt("Y", var7.motionY);
				nbttagcompound1.setInt("Z", var7.motionZ);
			}

			nbttagcompound.set("Leash", nbttagcompound1);
		}
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		boolean data = nbttagcompound.getBoolean("CanPickUpLoot");

		if (isLevelAtLeast(nbttagcompound, 1) || data) {
			this.canPickUpLoot = data;
		}

		data = nbttagcompound.getBoolean("PersistenceRequired");

		if (isLevelAtLeast(nbttagcompound, 1) || data) {
			this.persistent = data;
		}

		if (nbttagcompound.hasKey("CustomName") && nbttagcompound.getString("CustomName").length() > 0) {
			this.setCustomName(nbttagcompound.getString("CustomName"));
		}

		this.setCustomNameVisible(nbttagcompound.getBoolean("CustomNameVisible"));
		NBTTagList nbttaglist;
		int i;

		if (nbttagcompound.hasKey("Equipment")) {
			nbttaglist = nbttagcompound.getList("Equipment");

			for (i = 0; i < this.equipment.length; ++i) {
				this.equipment[i] = ItemStack.createStack((NBTTagCompound) nbttaglist.get(i));
			}
		}

		if (nbttagcompound.hasKey("DropChances")) {
			nbttaglist = nbttagcompound.getList("DropChances");

			for (i = 0; i < nbttaglist.size(); ++i) {
				this.dropChances[i] = ((NBTTagFloat) nbttaglist.get(i)).data;
			}
		}

		this.isLeashed = nbttagcompound.getBoolean("Leashed");

		if (this.isLeashed && nbttagcompound.hasKey("Leash")) {
			this.field_110170_bx = nbttagcompound.getCompound("Leash");
		}
	}

	public void setMoveForward(float f) {
		this.moveForward = f;
	}

	/**
	 * set the movespeed used for the new AI system
	 */
	public void setAIMoveSpeed(float f) {
		super.setAIMoveSpeed(f);
		this.setMoveForward(f);
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		super.onLivingUpdate();
		this.world.methodProfiler.a("looting");

		if (!this.world.isStatic && this.canPickUpLoot() && !this.dead
				&& this.world.getGameRules().getBoolean("mobGriefing")) {
			List list = this.world.getEntitiesWithinAABB(EntityItem.class, this.boundingBox.grow(1.0D, 0.0D, 1.0D));
			Iterator iterator = list.iterator();

			while (iterator.hasNext()) {
				EntityItem entityitem = (EntityItem) iterator.next();

				if (!entityitem.dead && entityitem.getItemStack() != null) {
					ItemStack itemstack = entityitem.getItemStack();
					int i = getArmorPosition(itemstack);

					if (i > -1) {
						boolean flag = true;
						ItemStack itemstack1 = this.getEquipment(i);

						if (itemstack1 != null) {
							if (i == 0) {
								if (itemstack.getItem() instanceof ItemSword
										&& !(itemstack1.getItem() instanceof ItemSword)) {
									flag = true;
								} else if (itemstack.getItem() instanceof ItemSword
										&& itemstack1.getItem() instanceof ItemSword) {
									ItemSword itemarmor = (ItemSword) itemstack.getItem();
									ItemSword itemarmor1 = (ItemSword) itemstack1.getItem();

									if (itemarmor.func_82803_g() == itemarmor1.func_82803_g()) {
										flag = itemstack.getData() > itemstack1.getData()
												|| itemstack.hasTag() && !itemstack1.hasTag();
									} else {
										flag = itemarmor.func_82803_g() > itemarmor1.func_82803_g();
									}
								} else {
									flag = false;
								}
							} else if (itemstack.getItem() instanceof ItemArmor
									&& !(itemstack1.getItem() instanceof ItemArmor)) {
								flag = true;
							} else if (itemstack.getItem() instanceof ItemArmor
									&& itemstack1.getItem() instanceof ItemArmor) {
								ItemArmor itemarmor1 = (ItemArmor) itemstack.getItem();
								ItemArmor itemarmor11 = (ItemArmor) itemstack1.getItem();

								if (itemarmor1.damageReduceAmount == itemarmor11.damageReduceAmount) {
									flag = itemstack.getData() > itemstack1.getData()
											|| itemstack.hasTag() && !itemstack1.hasTag();
								} else {
									flag = itemarmor1.damageReduceAmount > itemarmor11.damageReduceAmount;
								}
							} else {
								flag = false;
							}
						}

						if (flag) {
							if (itemstack1 != null && this.random.nextFloat() - 0.1F < this.dropChances[i]) {
								this.entityDropItem(itemstack1, 0.0F);
							}

							this.setEquipment(i, itemstack);
							this.dropChances[i] = 2.0F;
							this.persistent = true;
							this.receive(entityitem, 1);
							entityitem.die();
						}
					}
				}
			}
		}

		this.world.methodProfiler.b();
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	protected boolean isAIEnabled() {
		return false;
	}

	protected boolean isTypeNotPersistent() {
		return true;
	}

	/**
	 * Makes the entity despawn if requirements are reached
	 */
	protected void despawnEntity() {
		if (this.persistent) {
			this.entityAge = 0;
		} else {
			EntityHuman entityhuman = this.world.findNearbyPlayer(this, -1.0D);

			if (entityhuman != null) {
				double d0 = entityhuman.locX - this.locX;
				double d1 = entityhuman.locY - this.locY;
				double d2 = entityhuman.locZ - this.locZ;
				double d3 = d0 * d0 + d1 * d1 + d2 * d2;

				if (d3 > 16384.0D) {
					this.die();
				}

				if (this.entityAge > 600 && this.random.nextInt(800) == 0 && d3 > 1024.0D) {
					this.die();
				} else if (d3 < 1024.0D) {
					this.entityAge = 0;
				}
			}
		}
	}

	protected void updateAITasks() {
		++this.entityAge;
		this.world.methodProfiler.a("checkDespawn");
		this.despawnEntity();
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("sensing");
		this.senses.clearSensingCache();
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("targetSelector");
		this.targetSelector.a();
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("goalSelector");
		this.goalSelector.a();
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("navigation");
		this.navigation.f();
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("mob tick");
		this.updateAITick();
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("controls");
		this.world.methodProfiler.a("move");
		this.moveController.c();
		this.world.methodProfiler.c("look");
		this.lookHelper.a();
		this.world.methodProfiler.c("jump");
		this.lookController.b();
		this.world.methodProfiler.b();
		this.world.methodProfiler.b();
	}

	protected void updateEntityActionState() {
		super.updateEntityActionState();
		this.moveStrafing = 0.0F;
		this.moveForward = 0.0F;
		this.despawnEntity();
		float f = 8.0F;

		if (this.random.nextFloat() < 0.02F) {
			EntityHuman flag = this.world.findNearbyPlayer(this, (double) f);

			if (flag != null) {
				this.currentTarget = flag;
				this.numTicksToChaseTarget = 10 + this.random.nextInt(20);
			} else {
				this.randomYawVelocity = (this.random.nextFloat() - 0.5F) * 20.0F;
			}
		}

		if (this.currentTarget != null) {
			this.faceEntity(this.currentTarget, 10.0F, (float) this.getVerticalFaceSpeed());

			if (this.numTicksToChaseTarget-- <= 0 || this.currentTarget.dead
					|| this.currentTarget.getDistanceSqToEntity(this) > (double) (f * f)) {
				this.currentTarget = null;
			}
		} else {
			if (this.random.nextFloat() < 0.05F) {
				this.randomYawVelocity = (this.random.nextFloat() - 0.5F) * 20.0F;
			}

			this.yaw += this.randomYawVelocity;
			this.pitch = this.defaultPitch;
		}

		boolean var4 = this.isInWater();
		boolean flag1 = this.handleLavaMovement();

		if (var4 || flag1) {
			this.isJumping = this.random.nextFloat() < 0.8F;
		}
	}

	/**
	 * The speed it takes to move the entityliving's rotationPitch through the
	 * faceEntity method. This is only currently use in wolves.
	 */
	public int getVerticalFaceSpeed() {
		return 40;
	}

	/**
	 * Changes pitch and yaw so that the entity calling the function is facing
	 * the entity provided as an argument.
	 */
	public void faceEntity(Entity entity, float f, float f1) {
		double d0 = entity.locX - this.locX;
		double d1 = entity.locZ - this.locZ;
		double d2;

		if (entity instanceof EntityLiving) {
			EntityLiving entityliving = (EntityLiving) entity;
			d2 = entityliving.locY + (double) entityliving.getHeadHeight()
					- (this.locY + (double) this.getHeadHeight());
		} else {
			d2 = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0D
					- (this.locY + (double) this.getHeadHeight());
		}

		double d3 = (double) MathHelper.sqrt(d0 * d0 + d1 * d1);
		float f2 = (float) (Math.atan2(d1, d0) * 180.0D / Math.PI) - 90.0F;
		float f3 = (float) (-(Math.atan2(d2, d3) * 180.0D / Math.PI));
		this.pitch = this.updateRotation(this.pitch, f3, f1);
		this.yaw = this.updateRotation(this.yaw, f2, f);
	}

	/**
	 * Arguments: current rotation, intended rotation, max increment.
	 */
	private float updateRotation(float f, float f1, float f2) {
		float f3 = MathHelper.wrapAngleTo180_float(f1 - f);

		if (f3 > f2) {
			f3 = f2;
		}

		if (f3 < -f2) {
			f3 = -f2;
		}

		return f + f3;
	}

	public boolean canSpawn() {
		return this.world.checkNoEntityCollision(this.boundingBox)
				&& this.world.getCubes(this, this.boundingBox).isEmpty()
				&& !this.world.containsLiquid(this.boundingBox);
	}

	/**
	 * Will return how many at most can spawn in a chunk at once.
	 */
	public int getMaxSpawnedInChunk() {
		return 4;
	}

	/**
	 * The number of iterations PathFinder.getSafePoint will execute before
	 * giving up.
	 */
	public int getMaxSafePointTries() {
		if (this.getGoalTarget() == null) {
			return 3;
		} else {
			int i = (int) (this.getHealth() - this.getMaxHealth() * 0.33F);
			i -= (3 - this.world.difficulty) * 4;

			if (i < 0) {
				i = 0;
			}

			return i + 3;
		}
	}

	/**
	 * Returns the item that this EntityLiving is holding, if any.
	 */
	public ItemStack getHeldItem() {
		return this.equipment[0];
	}

	public ItemStack getEquipment(int i) {
		return this.equipment[i];
	}

	public ItemStack func_130225_q(int i) {
		return this.equipment[i + 1];
	}

	public void setEquipment(int i, ItemStack itemstack) {
		this.equipment[i] = itemstack;
	}

	public ItemStack[] getEquipment() {
		return this.equipment;
	}

	protected void dropEquipment(boolean flag, int i) {
		for (int j = 0; j < this.getEquipment().length; ++j) {
			ItemStack itemstack = this.getEquipment(j);
			boolean flag1 = this.dropChances[j] > 1.0F;

			if (itemstack != null && (flag || flag1)
					&& this.random.nextFloat() - (float) i * 0.01F < this.dropChances[j]) {
				if (!flag1 && itemstack.isItemStackDamageable()) {
					int k = Math.max(itemstack.getMaxDamage() - 25, 1);
					int l = itemstack.getMaxDamage() - this.random.nextInt(this.random.nextInt(k) + 1);

					if (l > k) {
						l = k;
					}

					if (l < 1) {
						l = 1;
					}

					itemstack.setData(l);
				}

				this.entityDropItem(itemstack, 0.0F);
			}
		}
	}

	/**
	 * Makes entity wear random armor based on difficulty
	 */
	protected void addRandomArmor() {
		if (this.random.nextFloat() < 0.15F * this.world.getLocationTensionFactor(this.locX, this.locY, this.locZ)) {
			int i = this.random.nextInt(2);
			float f = this.world.difficulty == 3 ? 0.1F : 0.25F;

			if (this.random.nextFloat() < 0.095F) {
				++i;
			}

			if (this.random.nextFloat() < 0.095F) {
				++i;
			}

			if (this.random.nextFloat() < 0.095F) {
				++i;
			}

			for (int j = 3; j >= 0; --j) {
				ItemStack itemstack = this.func_130225_q(j);

				if (j < 3 && this.random.nextFloat() < f) {
					break;
				}

				if (itemstack == null) {
					Item item = getArmorItemForSlot(j + 1, i);

					if (item != null) {
						this.setEquipment(j + 1, new ItemStack(item));
					}
				}
			}
		}
	}

	public static int getArmorPosition(ItemStack itemstack) {
		if (itemstack.id != Block.PUMPKIN.id && itemstack.id != Item.SKULL.id) {
			if (itemstack.getItem() instanceof ItemArmor) {
				switch (((ItemArmor) itemstack.getItem()).armorType) {
				case 0:
					return 4;

				case 1:
					return 3;

				case 2:
					return 2;

				case 3:
					return 1;
				}
			}

			return 0;
		} else {
			return 4;
		}
	}

	/**
	 * Params: Armor slot, Item tier
	 */
	public static Item getArmorItemForSlot(int i, int j) {
		switch (i) {
		case 4:
			if (j == 0) {
				return Item.LEATHER_HELMET;
			} else if (j == 1) {
				return Item.GOLD_HELMET;
			} else if (j == 2) {
				return Item.CHAINMAIL_HELMET;
			} else if (j == 3) {
				return Item.IRON_HELMET;
			} else if (j == 4) {
				return Item.DIAMOND_HELMET;
			}

		case 3:
			if (j == 0) {
				return Item.LEATHER_CHESTPLATE;
			} else if (j == 1) {
				return Item.GOLD_CHESTPLATE;
			} else if (j == 2) {
				return Item.CHAINMAIL_CHESTPLATE;
			} else if (j == 3) {
				return Item.IRON_CHESTPLATE;
			} else if (j == 4) {
				return Item.DIAMOND_CHESTPLATE;
			}

		case 2:
			if (j == 0) {
				return Item.LEATHER_LEGGINGS;
			} else if (j == 1) {
				return Item.GOLD_LEGGINGS;
			} else if (j == 2) {
				return Item.CHAINMAIL_LEGGINGS;
			} else if (j == 3) {
				return Item.IRON_LEGGINGS;
			} else if (j == 4) {
				return Item.DIAMOND_LEGGINGS;
			}

		case 1:
			if (j == 0) {
				return Item.LEATHER_BOOTS;
			} else if (j == 1) {
				return Item.GOLD_BOOTS;
			} else if (j == 2) {
				return Item.CHAINMAIL_BOOTS;
			} else if (j == 3) {
				return Item.IRON_BOOTS;
			} else if (j == 4) {
				return Item.DIAMOND_BOOTS;
			}

		default:
			return null;
		}
	}

	/**
	 * Enchants the entity's armor and held item based on difficulty
	 */
	protected void enchantEquipment() {
		float f = this.world.getLocationTensionFactor(this.locX, this.locY, this.locZ);

		if (this.getHeldItem() != null && this.random.nextFloat() < 0.25F * f) {
			EnchantmentManager.a(this.random, this.getHeldItem(), (int) (5.0F + f * (float) this.random.nextInt(18)));
		}

		for (int i = 0; i < 4; ++i) {
			ItemStack itemstack = this.func_130225_q(i);

			if (itemstack != null && this.random.nextFloat() < 0.5F * f) {
				EnchantmentManager.a(this.random, itemstack, (int) (5.0F + f * (float) this.random.nextInt(18)));
			}
		}
	}

	public GroupDataEntity a(GroupDataEntity groupdataentity) {
		this.getAttributeInstance(GenericAttributes.b)
				.applyModifier(new AttributeModifier("Random spawn bonus", this.random.nextGaussian() * 0.05D, 1));
		return groupdataentity;
	}

	/**
	 * returns true if all the conditions for steering the entity are met. For
	 * pigs, this is true if it is being ridden by a player and the player is
	 * holding a carrot-on-a-stick
	 */
	public boolean canBeSteered() {
		return false;
	}

	public String getLocalizedName() {
		return this.hasCustomName() ? this.getCustomName() : super.getLocalizedName();
	}

	public void func_110163_bv() {
		this.persistent = true;
	}

	public void setCustomName(String s) {
		this.datawatcher.watch(10, s);
	}

	public String getCustomName() {
		return this.datawatcher.getString(10);
	}

	public boolean hasCustomName() {
		return this.datawatcher.getString(10).length() > 0;
	}

	public void setCustomNameVisible(boolean flag) {
		this.datawatcher.watch(11, Byte.valueOf((byte) (flag ? 1 : 0)));
	}

	public boolean getCustomNameVisible() {
		return this.datawatcher.getByte(11) == 1;
	}

	public void setEquipmentDropChance(int i, float f) {
		this.dropChances[i] = f;
	}

	public boolean canPickUpLoot() {
		return this.canPickUpLoot;
	}

	public void setCanPickUpLoot(boolean flag) {
		this.canPickUpLoot = flag;
	}

	public boolean isPersistent() {
		return this.persistent;
	}

	public final boolean c(EntityHuman entityhuman) {
		if (this.getLeashed() && this.getLeashHolder() == entityhuman) {
			if (CraftEventFactory.callPlayerUnleashEntityEvent(this, entityhuman).isCancelled()) {
				((EntityPlayer) entityhuman).playerConnection
						.sendPacket(new Packet39AttachEntity(1, this, this.getLeashHolder()));
				return false;
			} else {
				this.unleash(true, !entityhuman.abilities.canInstantlyBuild);
				return true;
			}
		} else {
			ItemStack itemstack = entityhuman.inventory.getItemInHand();

			if (itemstack != null && itemstack.id == Item.LEASH.id && this.allowLeashing()) {
				if (!(this instanceof EntityTameableAnimal) || !((EntityTameableAnimal) this).isTamed()) {
					if (CraftEventFactory.callPlayerLeashEntityEvent(this, entityhuman, entityhuman).isCancelled()) {
						((EntityPlayer) entityhuman).playerConnection
								.sendPacket(new Packet39AttachEntity(1, this, this.getLeashHolder()));
						return false;
					}

					this.setLeashHolder(entityhuman, true);
					--itemstack.count;
					return true;
				}

				if (entityhuman.getName().equalsIgnoreCase(((EntityTameableAnimal) this).getOwnerName())) {
					if (CraftEventFactory.callPlayerLeashEntityEvent(this, entityhuman, entityhuman).isCancelled()) {
						((EntityPlayer) entityhuman).playerConnection
								.sendPacket(new Packet39AttachEntity(1, this, this.getLeashHolder()));
						return false;
					}

					this.setLeashHolder(entityhuman, true);
					--itemstack.count;
					return true;
				}
			}

			return this.a(entityhuman) ? true : super.c(entityhuman);
		}
	}

	protected boolean a(EntityHuman entityhuman) {
		return false;
	}

	protected void func_110159_bB() {
		if (this.field_110170_bx != null) {
			this.recreateLeash();
		}

		if (this.isLeashed && (this.leashedToEntity == null || this.leashedToEntity.dead)) {
			this.world.getServer().getPluginManager().callEvent(
					new EntityUnleashEvent(this.getBukkitEntity(), EntityUnleashEvent.UnleashReason.HOLDER_GONE));
			this.unleash(true, true);
		}
	}

	public void unleash(boolean flag, boolean flag1) {
		if (this.isLeashed) {
			this.isLeashed = false;
			this.leashedToEntity = null;

			if (!this.world.isStatic && flag1) {
				this.dropItem(Item.LEASH.id, 1);
			}

			if (!this.world.isStatic && flag && this.world instanceof WorldServer) {
				((WorldServer) this.world).getTracker().sendPacketToTrackedPlayers(this,
						new Packet39AttachEntity(1, this, (Entity) null));
			}
		}
	}

	public boolean allowLeashing() {
		return !this.getLeashed() && !(this instanceof IMonster);
	}

	public boolean getLeashed() {
		return this.isLeashed;
	}

	public Entity getLeashHolder() {
		return this.leashedToEntity;
	}

	public void setLeashHolder(Entity entity, boolean flag) {
		this.isLeashed = true;
		this.leashedToEntity = entity;

		if (!this.world.isStatic && flag && this.world instanceof WorldServer) {
			((WorldServer) this.world).getTracker().sendPacketToTrackedPlayers(this,
					new Packet39AttachEntity(1, this, this.leashedToEntity));
		}
	}

	private void recreateLeash() {
		if (this.isLeashed && this.field_110170_bx != null) {
			if (this.field_110170_bx.hasKey("UUIDMost") && this.field_110170_bx.hasKey("UUIDLeast")) {
				UUID i1 = new UUID(this.field_110170_bx.getLong("UUIDMost"), this.field_110170_bx.getLong("UUIDLeast"));
				List j1 = this.world.getEntitiesWithinAABB(EntityLiving.class,
						this.boundingBox.grow(10.0D, 10.0D, 10.0D));
				Iterator k1 = j1.iterator();

				while (k1.hasNext()) {
					EntityLiving entityleash1 = (EntityLiving) k1.next();

					if (entityleash1.getUniqueID().equals(i1)) {
						this.leashedToEntity = entityleash1;
						break;
					}
				}
			} else if (this.field_110170_bx.hasKey("X") && this.field_110170_bx.hasKey("Y")
					&& this.field_110170_bx.hasKey("Z")) {
				int i = this.field_110170_bx.getInt("X");
				int j = this.field_110170_bx.getInt("Y");
				int k = this.field_110170_bx.getInt("Z");
				EntityLeash entityleash = EntityLeash.b(this.world, i, j, k);

				if (entityleash == null) {
					entityleash = EntityLeash.a(this.world, i, j, k);
				}

				this.leashedToEntity = entityleash;
			} else {
				this.world.getServer().getPluginManager().callEvent(
						new EntityUnleashEvent(this.getBukkitEntity(), EntityUnleashEvent.UnleashReason.UNKNOWN));
				this.unleash(false, true);
			}
		}

		this.field_110170_bx = null;
	}
}
