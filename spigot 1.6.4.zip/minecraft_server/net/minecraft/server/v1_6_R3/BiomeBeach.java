package net.minecraft.server.v1_6_R3;

public class BiomeBeach extends BiomeBase
{
    public BiomeBeach(int var1)
    {
        super(var1);
        this.spawnableCreatureList.clear();
        this.topBlock = (byte)Block.SAND.id;
        this.fillerBlock = (byte)Block.SAND.id;
        this.theBiomeDecorator.treesPerChunk = -999;
        this.theBiomeDecorator.deadBushPerChunk = 0;
        this.theBiomeDecorator.reedsPerChunk = 0;
        this.theBiomeDecorator.cactiPerChunk = 0;
    }
}
