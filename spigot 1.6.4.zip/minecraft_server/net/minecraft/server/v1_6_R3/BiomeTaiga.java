package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BiomeTaiga extends BiomeBase
{
    public BiomeTaiga(int var1)
    {
        super(var1);
        this.spawnableCreatureList.add(new BiomeMeta(EntityWolf.class, 8, 4, 4));
        this.theBiomeDecorator.treesPerChunk = 10;
        this.theBiomeDecorator.grassPerChunk = 1;
    }

    /**
     * Gets a WorldGen appropriate for this biome.
     */
    public WorldGenerator getRandomWorldGenForTrees(Random var1)
    {
        return (WorldGenerator)(var1.nextInt(3) == 0 ? new WorldGenTaiga1() : new WorldGenTaiga2(false));
    }
}
