package net.minecraft.server.v1_6_R3;

public class EntitySelectorEquipable implements IEntitySelector
{
    private final ItemStack c;

    public EntitySelectorEquipable(ItemStack var1)
    {
        this.c = var1;
    }

    /**
     * Return whether the specified entity is applicable to this filter.
     */
    public boolean isEntityApplicable(Entity var1)
    {
        if (!var1.isAlive())
        {
            return false;
        }
        else if (!(var1 instanceof EntityLiving))
        {
            return false;
        }
        else
        {
            EntityLiving var2 = (EntityLiving)var1;
            return var2.getEquipment(EntityInsentient.getArmorPosition(this.c)) != null ? false : (var2 instanceof EntityInsentient ? ((EntityInsentient)var2).canPickUpLoot() : var2 instanceof EntityHuman);
        }
    }
}
