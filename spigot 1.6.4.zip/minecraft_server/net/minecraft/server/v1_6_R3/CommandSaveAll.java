package net.minecraft.server.v1_6_R3;

public class CommandSaveAll extends CommandAbstract
{
    public String getCommandName()
    {
        return "save-all";
    }

    public int a()
    {
        return 4;
    }

    public String c(ICommandListener var1)
    {
        return "commands.save.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        MinecraftServer var3 = MinecraftServer.getServer();
        var1.sendMessage(ChatMessage.e("commands.save.start"));

        if (var3.getPlayerList() != null)
        {
            var3.getPlayerList().savePlayers();
        }

        try
        {
            int var4;
            WorldServer var5;
            boolean var6;

            for (var4 = 0; var4 < var3.worldServer.length; ++var4)
            {
                if (var3.worldServer[var4] != null)
                {
                    var5 = var3.worldServer[var4];
                    var6 = var5.savingDisabled;
                    var5.savingDisabled = false;
                    var5.save(true, (IProgressUpdate)null);
                    var5.savingDisabled = var6;
                }
            }

            if (var2.length > 0 && "flush".equals(var2[0]))
            {
                var1.sendMessage(ChatMessage.e("commands.save.flushStart"));

                for (var4 = 0; var4 < var3.worldServer.length; ++var4)
                {
                    if (var3.worldServer[var4] != null)
                    {
                        var5 = var3.worldServer[var4];
                        var6 = var5.savingDisabled;
                        var5.savingDisabled = false;
                        var5.flushSave();
                        var5.savingDisabled = var6;
                    }
                }

                var1.sendMessage(ChatMessage.e("commands.save.flushEnd"));
            }
        }
        catch (ExceptionWorldConflict var7)
        {
            a(var1, "commands.save.failed", new Object[] {var7.getMessage()});
            return;
        }

        a(var1, "commands.save.success", new Object[0]);
    }
}
