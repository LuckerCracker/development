package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockTorch extends Block
{
    protected BlockTorch(int par1)
    {
        super(par1, Material.ORIENTABLE);
        this.setTickRandomly(true);
        this.a(CreativeModeTab.c);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return null;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 2;
    }

    /**
     * Gets if we can place a torch on a block.
     */
    private boolean canPlaceTorchOn(World par1World, int par2, int par3, int par4)
    {
        if (par1World.doesBlockHaveSolidTopSurface(par2, par3, par4))
        {
            return true;
        }
        else
        {
            int var5 = par1World.getTypeId(par2, par3, par4);
            return var5 == Block.FENCE.id || var5 == Block.NETHER_FENCE.id || var5 == Block.GLASS.id || var5 == Block.COBBLE_WALL.id;
        }
    }

    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        return var1.isBlockNormalCubeDefault(var2 - 1, var3, var4, true) ? true : (var1.isBlockNormalCubeDefault(var2 + 1, var3, var4, true) ? true : (var1.isBlockNormalCubeDefault(var2, var3, var4 - 1, true) ? true : (var1.isBlockNormalCubeDefault(var2, var3, var4 + 1, true) ? true : this.canPlaceTorchOn(var1, var2, var3 - 1, var4))));
    }

    public int getPlacedData(World var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, int var9)
    {
        int var10 = var9;

        if (var5 == 1 && this.canPlaceTorchOn(var1, var2, var3 - 1, var4))
        {
            var10 = 5;
        }

        if (var5 == 2 && var1.isBlockNormalCubeDefault(var2, var3, var4 + 1, true))
        {
            var10 = 4;
        }

        if (var5 == 3 && var1.isBlockNormalCubeDefault(var2, var3, var4 - 1, true))
        {
            var10 = 3;
        }

        if (var5 == 4 && var1.isBlockNormalCubeDefault(var2 + 1, var3, var4, true))
        {
            var10 = 2;
        }

        if (var5 == 5 && var1.isBlockNormalCubeDefault(var2 - 1, var3, var4, true))
        {
            var10 = 1;
        }

        return var10;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        super.updateTick(par1World, par2, par3, par4, par5Random);

        if (par1World.getData(par2, par3, par4) == 0)
        {
            this.onPlace(par1World, par2, par3, par4);
        }
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        if (var1.getData(var2, var3, var4) == 0)
        {
            if (var1.isBlockNormalCubeDefault(var2 - 1, var3, var4, true))
            {
                var1.setData(var2, var3, var4, 1, 2);
            }
            else if (var1.isBlockNormalCubeDefault(var2 + 1, var3, var4, true))
            {
                var1.setData(var2, var3, var4, 2, 2);
            }
            else if (var1.isBlockNormalCubeDefault(var2, var3, var4 - 1, true))
            {
                var1.setData(var2, var3, var4, 3, 2);
            }
            else if (var1.isBlockNormalCubeDefault(var2, var3, var4 + 1, true))
            {
                var1.setData(var2, var3, var4, 4, 2);
            }
            else if (this.canPlaceTorchOn(var1, var2, var3 - 1, var4))
            {
                var1.setData(var2, var3, var4, 5, 2);
            }
        }

        this.dropTorchIfCantStay(var1, var2, var3, var4);
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        this.func_94397_d(var1, var2, var3, var4, var5);
    }

    protected boolean func_94397_d(World par1World, int par2, int par3, int par4, int par5)
    {
        if (this.dropTorchIfCantStay(par1World, par2, par3, par4))
        {
            int var6 = par1World.getData(par2, par3, par4);
            boolean var7 = false;

            if (!par1World.isBlockNormalCubeDefault(par2 - 1, par3, par4, true) && var6 == 1)
            {
                var7 = true;
            }

            if (!par1World.isBlockNormalCubeDefault(par2 + 1, par3, par4, true) && var6 == 2)
            {
                var7 = true;
            }

            if (!par1World.isBlockNormalCubeDefault(par2, par3, par4 - 1, true) && var6 == 3)
            {
                var7 = true;
            }

            if (!par1World.isBlockNormalCubeDefault(par2, par3, par4 + 1, true) && var6 == 4)
            {
                var7 = true;
            }

            if (!this.canPlaceTorchOn(par1World, par2, par3 - 1, par4) && var6 == 5)
            {
                var7 = true;
            }

            if (var7)
            {
                this.dropBlockAsItem(par1World, par2, par3, par4, par1World.getData(par2, par3, par4), 0);
                par1World.setAir(par2, par3, par4);
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return true;
        }
    }

    /**
     * Tests if the block can remain at its current location and will drop as an item if it is unable to stay. Returns
     * True if it can stay and False if it drops. Args: world, x, y, z
     */
    protected boolean dropTorchIfCantStay(World par1World, int par2, int par3, int par4)
    {
        if (!this.canPlace(par1World, par2, par3, par4))
        {
            if (par1World.getTypeId(par2, par3, par4) == this.id)
            {
                this.dropBlockAsItem(par1World, par2, par3, par4, par1World.getData(par2, par3, par4), 0);
                par1World.setAir(par2, par3, par4);
            }

            return false;
        }
        else
        {
            return true;
        }
    }

    public MovingObjectPosition a(World var1, int var2, int var3, int var4, Vec3D var5, Vec3D var6)
    {
        int var7 = var1.getData(var2, var3, var4) & 7;
        float var8 = 0.15F;

        if (var7 == 1)
        {
            this.setBlockBounds(0.0F, 0.2F, 0.5F - var8, var8 * 2.0F, 0.8F, 0.5F + var8);
        }
        else if (var7 == 2)
        {
            this.setBlockBounds(1.0F - var8 * 2.0F, 0.2F, 0.5F - var8, 1.0F, 0.8F, 0.5F + var8);
        }
        else if (var7 == 3)
        {
            this.setBlockBounds(0.5F - var8, 0.2F, 0.0F, 0.5F + var8, 0.8F, var8 * 2.0F);
        }
        else if (var7 == 4)
        {
            this.setBlockBounds(0.5F - var8, 0.2F, 1.0F - var8 * 2.0F, 0.5F + var8, 0.8F, 1.0F);
        }
        else
        {
            var8 = 0.1F;
            this.setBlockBounds(0.5F - var8, 0.0F, 0.5F - var8, 0.5F + var8, 0.6F, 0.5F + var8);
        }

        return super.a(var1, var2, var3, var4, var5, var6);
    }
}
