package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;

public class EntitySenses
{
    EntityInsentient entity;
    List seenEntities = new ArrayList();
    List unseenEntities = new ArrayList();

    public EntitySenses(EntityInsentient var1)
    {
        this.entity = var1;
    }

    /**
     * Clears canSeeCachePositive and canSeeCacheNegative.
     */
    public void clearSensingCache()
    {
        this.seenEntities.clear();
        this.unseenEntities.clear();
    }

    public boolean canSee(Entity var1)
    {
        if (this.seenEntities.contains(var1))
        {
            return true;
        }
        else if (this.unseenEntities.contains(var1))
        {
            return false;
        }
        else
        {
            this.entity.world.methodProfiler.a("canSee");
            boolean var2 = this.entity.canEntityBeSeen(var1);
            this.entity.world.methodProfiler.b();

            if (var2)
            {
                this.seenEntities.add(var1);
            }
            else
            {
                this.unseenEntities.add(var1);
            }

            return var2;
        }
    }
}
