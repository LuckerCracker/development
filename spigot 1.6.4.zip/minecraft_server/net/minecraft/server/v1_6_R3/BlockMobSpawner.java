package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockMobSpawner extends BlockContainer
{
    protected BlockMobSpawner(int par1)
    {
        super(par1, Material.STONE);
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityMobSpawner();
    }

    public int getDropType(int i, Random random, int j)
    {
        return 0;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 0;
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        super.dropNaturally(world, i, j, k, l, f, i1);
    }

    public int getExpDrop(World world, int data, int enchantmentLevel)
    {
        int j1 = 15 + world.random.nextInt(15) + world.random.nextInt(15);
        return j1;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }
}
