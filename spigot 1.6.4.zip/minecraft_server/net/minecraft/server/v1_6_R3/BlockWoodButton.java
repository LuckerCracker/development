package net.minecraft.server.v1_6_R3;

public class BlockWoodButton extends BlockButtonAbstract
{
    protected BlockWoodButton(int var1)
    {
        super(var1, true);
    }
}
