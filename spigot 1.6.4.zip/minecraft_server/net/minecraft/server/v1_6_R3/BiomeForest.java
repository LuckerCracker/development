package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BiomeForest extends BiomeBase
{
    public BiomeForest(int var1)
    {
        super(var1);
        this.spawnableCreatureList.add(new BiomeMeta(EntityWolf.class, 5, 4, 4));
        this.theBiomeDecorator.treesPerChunk = 10;
        this.theBiomeDecorator.grassPerChunk = 2;
    }

    /**
     * Gets a WorldGen appropriate for this biome.
     */
    public WorldGenerator getRandomWorldGenForTrees(Random var1)
    {
        return (WorldGenerator)(var1.nextInt(5) == 0 ? this.worldGeneratorForest : (var1.nextInt(10) == 0 ? this.worldGeneratorBigTree : this.worldGeneratorTrees));
    }
}
