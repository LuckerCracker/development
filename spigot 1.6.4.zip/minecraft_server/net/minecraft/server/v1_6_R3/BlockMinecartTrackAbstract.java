package net.minecraft.server.v1_6_R3;

import java.util.Random;

public abstract class BlockMinecartTrackAbstract extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    protected final boolean displayOnCreativeTab;

    public static final boolean d_(World var0, int var1, int var2, int var3)
    {
        return e_(var0.getTypeId(var1, var2, var3));
    }

    public static final boolean e_(int var0)
    {
        return var0 == Block.RAILS.id || var0 == Block.GOLDEN_RAIL.id || var0 == Block.DETECTOR_RAIL.id || var0 == Block.ACTIVATOR_RAIL.id;
    }

    protected BlockMinecartTrackAbstract(int var1, boolean var2)
    {
        super(var1, Material.ORIENTABLE);
        this.displayOnCreativeTab = var2;
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
        this.a(CreativeModeTab.e);
    }

    public boolean e()
    {
        return this.displayOnCreativeTab;
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World var1, int var2, int var3, int var4)
    {
        return null;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    public MovingObjectPosition a(World var1, int var2, int var3, int var4, Vec3D var5, Vec3D var6)
    {
        this.updateShape(var1, var2, var3, var4);
        return super.a(var1, var2, var3, var4, var5, var6);
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        int var5 = var1.getData(var2, var3, var4);

        if (var5 >= 2 && var5 <= 5)
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.625F, 1.0F);
        }
        else
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
        }
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 9;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random var1)
    {
        return 1;
    }

    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        return var1.doesBlockHaveSolidTopSurface(var2, var3 - 1, var4);
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        if (!var1.isStatic)
        {
            this.a(var1, var2, var3, var4, true);

            if (this.displayOnCreativeTab)
            {
                this.doPhysics(var1, var2, var3, var4, this.id);
            }
        }
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        if (!var1.isStatic)
        {
            int var6 = var1.getData(var2, var3, var4);
            int var7 = var6;

            if (this.displayOnCreativeTab)
            {
                var7 = var6 & 7;
            }

            boolean var8 = false;

            if (!var1.doesBlockHaveSolidTopSurface(var2, var3 - 1, var4))
            {
                var8 = true;
            }

            if (var7 == 2 && !var1.doesBlockHaveSolidTopSurface(var2 + 1, var3, var4))
            {
                var8 = true;
            }

            if (var7 == 3 && !var1.doesBlockHaveSolidTopSurface(var2 - 1, var3, var4))
            {
                var8 = true;
            }

            if (var7 == 4 && !var1.doesBlockHaveSolidTopSurface(var2, var3, var4 - 1))
            {
                var8 = true;
            }

            if (var7 == 5 && !var1.doesBlockHaveSolidTopSurface(var2, var3, var4 + 1))
            {
                var8 = true;
            }

            if (var8)
            {
                this.dropBlockAsItem(var1, var2, var3, var4, var1.getData(var2, var3, var4), 0);
                var1.setAir(var2, var3, var4);
            }
            else
            {
                this.a(var1, var2, var3, var4, var6, var7, var5);
            }
        }
    }

    protected void a(World var1, int var2, int var3, int var4, int var5, int var6, int var7) {}

    protected void a(World var1, int var2, int var3, int var4, boolean var5)
    {
        if (!var1.isStatic)
        {
            (new MinecartTrackLogic(this, var1, var2, var3, var4)).a(var1.isBlockIndirectlyPowered(var2, var3, var4), var5);
        }
    }

    /**
     * Returns the mobility information of the block, 0 = free, 1 = can't push but can move over, 2 = total immobility
     * and stop pistons
     */
    public int getMobilityFlag()
    {
        return 0;
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        int var7 = var6;

        if (this.displayOnCreativeTab)
        {
            var7 = var6 & 7;
        }

        super.remove(var1, var2, var3, var4, var5, var6);

        if (var7 == 2 || var7 == 3 || var7 == 4 || var7 == 5)
        {
            var1.applyPhysics(var2, var3 + 1, var4, var5);
        }

        if (this.displayOnCreativeTab)
        {
            var1.applyPhysics(var2, var3, var4, var5);
            var1.applyPhysics(var2, var3 - 1, var4, var5);
        }
    }
}
