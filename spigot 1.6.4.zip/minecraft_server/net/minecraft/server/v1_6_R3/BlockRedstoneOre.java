package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class BlockRedstoneOre extends Block
{
    private boolean glowing;

    public BlockRedstoneOre(int par1, boolean par2)
    {
        super(par1, Material.STONE);

        if (par2)
        {
            this.setTickRandomly(true);
        }

        this.glowing = par2;
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World par1World)
    {
        return 30;
    }

    public void attack(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        this.glow(world, i, j, k);
        super.attack(world, i, j, k, entityhuman);
    }

    /**
     * Called whenever an entity is walking on top of this block. Args: world, x, y, z, entity
     */
    public void onEntityWalking(World par1World, int par2, int par3, int par4, Entity par5Entity)
    {
        if (par5Entity instanceof EntityHuman)
        {
            PlayerInteractEvent var6 = CraftEventFactory.callPlayerInteractEvent((EntityHuman)par5Entity, Action.PHYSICAL, par2, par3, par4, -1, (ItemStack)null);

            if (!var6.isCancelled())
            {
                this.glow(par1World, par2, par3, par4);
                super.onEntityWalking(par1World, par2, par3, par4, par5Entity);
            }
        }
        else
        {
            EntityInteractEvent var7 = new EntityInteractEvent(par5Entity.getBukkitEntity(), par1World.getWorld().getBlockAt(par2, par3, par4));
            par1World.getServer().getPluginManager().callEvent(var7);

            if (!var7.isCancelled())
            {
                this.glow(par1World, par2, par3, par4);
                super.onEntityWalking(par1World, par2, par3, par4, par5Entity);
            }
        }
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        this.glow(world, i, j, k);
        return super.interact(world, i, j, k, entityhuman, l, f, f1, f2);
    }

    /**
     * The redstone ore glows.
     */
    private void glow(World par1World, int par2, int par3, int par4)
    {
        this.sparkle(par1World, par2, par3, par4);

        if (this.id == Block.REDSTONE_ORE.id)
        {
            par1World.setTypeIdUpdate(par2, par3, par4, Block.GLOWING_REDSTONE_ORE.id);
        }
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (this.id == Block.GLOWING_REDSTONE_ORE.id)
        {
            par1World.setTypeIdUpdate(par2, par3, par4, Block.REDSTONE_ORE.id);
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Item.REDSTONE.id;
    }

    public int getDropCount(int i, Random random)
    {
        return this.quantityDropped(random) + random.nextInt(i + 1);
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 4 + par1Random.nextInt(2);
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        super.dropNaturally(world, i, j, k, l, f, i1);
    }

    public int getExpDrop(World world, int l, int i1)
    {
        if (this.getDropType(l, world.random, i1) != this.id)
        {
            int j1 = 1 + world.random.nextInt(5);
            return j1;
        }
        else
        {
            return 0;
        }
    }

    /**
     * The redstone ore sparkles.
     */
    private void sparkle(World par1World, int par2, int par3, int par4)
    {
        Random var5 = par1World.random;
        double var6 = 0.0625D;

        for (int var8 = 0; var8 < 6; ++var8)
        {
            double var9 = (double)((float)par2 + var5.nextFloat());
            double var11 = (double)((float)par3 + var5.nextFloat());
            double var13 = (double)((float)par4 + var5.nextFloat());

            if (var8 == 0 && !par1World.isBlockOpaqueCube(par2, par3 + 1, par4))
            {
                var11 = (double)(par3 + 1) + var6;
            }

            if (var8 == 1 && !par1World.isBlockOpaqueCube(par2, par3 - 1, par4))
            {
                var11 = (double)(par3 + 0) - var6;
            }

            if (var8 == 2 && !par1World.isBlockOpaqueCube(par2, par3, par4 + 1))
            {
                var13 = (double)(par4 + 1) + var6;
            }

            if (var8 == 3 && !par1World.isBlockOpaqueCube(par2, par3, par4 - 1))
            {
                var13 = (double)(par4 + 0) - var6;
            }

            if (var8 == 4 && !par1World.isBlockOpaqueCube(par2 + 1, par3, par4))
            {
                var9 = (double)(par2 + 1) + var6;
            }

            if (var8 == 5 && !par1World.isBlockOpaqueCube(par2 - 1, par3, par4))
            {
                var9 = (double)(par2 + 0) - var6;
            }

            if (var9 < (double)par2 || var9 > (double)(par2 + 1) || var11 < 0.0D || var11 > (double)(par3 + 1) || var13 < (double)par4 || var13 > (double)(par4 + 1))
            {
                par1World.addParticle("reddust", var9, var11, var13, 0.0D, 0.0D, 0.0D);
            }
        }
    }

    /**
     * Returns an item stack containing a single instance of the current block type. 'i' is the block's subtype/damage
     * and is ignored for blocks which do not support subtypes. Blocks which cannot be harvested should return null.
     */
    protected ItemStack createStackedBlock(int par1)
    {
        return new ItemStack(Block.REDSTONE_ORE);
    }
}
