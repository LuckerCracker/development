package net.minecraft.server.v1_6_R3;

class EntitySelectorNearestAttackableTarget implements IEntitySelector
{
    final IEntitySelector c;

    final PathfinderGoalNearestAttackableTarget d;

    EntitySelectorNearestAttackableTarget(PathfinderGoalNearestAttackableTarget var1, IEntitySelector var2)
    {
        this.d = var1;
        this.c = var2;
    }

    /**
     * Return whether the specified entity is applicable to this filter.
     */
    public boolean isEntityApplicable(Entity var1)
    {
        return !(var1 instanceof EntityLiving) ? false : (this.c != null && !this.c.isEntityApplicable(var1) ? false : this.d.isSuitableTarget((EntityLiving)var1, false));
    }
}
