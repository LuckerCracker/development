package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;

public class CommandOp extends CommandAbstract
{
    public String getCommandName()
    {
        return "op";
    }

    public int a()
    {
        return 3;
    }

    public String c(ICommandListener var1)
    {
        return "commands.op.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length == 1 && var2[0].length() > 0)
        {
            MinecraftServer.getServer().getPlayerList().addOp(var2[0]);
            a(var1, "commands.op.success", new Object[] {var2[0]});
        }
        else
        {
            throw new ExceptionUsage("commands.op.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        if (var2.length == 1)
        {
            String var3 = var2[var2.length - 1];
            ArrayList var4 = new ArrayList();
            String[] var5 = MinecraftServer.getServer().getPlayers();
            int var6 = var5.length;

            for (int var7 = 0; var7 < var6; ++var7)
            {
                String var8 = var5[var7];

                if (!MinecraftServer.getServer().getPlayerList().isOp(var8) && a(var3, var8))
                {
                    var4.add(var8);
                }
            }

            return var4;
        }
        else
        {
            return null;
        }
    }
}
