package net.minecraft.server.v1_6_R3;

final class EnchantmentModifierProtection implements EnchantmentModifier
{
    public int a;
    public DamageSource b;

    private EnchantmentModifierProtection() {}

    public void calculateModifier(Enchantment var1, int var2)
    {
        this.a += var1.calcModifierDamage(var2, this.b);
    }

    EnchantmentModifierProtection(EmptyClass var1)
    {
        this();
    }
}
