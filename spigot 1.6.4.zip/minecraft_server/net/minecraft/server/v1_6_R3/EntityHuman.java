package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.craftbukkit.v1_6_R3.TrigMath;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftHumanEntity;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftItem;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerBedLeaveEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.scoreboard.Team;
import org.spigotmc.event.entity.EntityDismountEvent;

public abstract class EntityHuman extends EntityLiving implements ICommandListener {
	public PlayerInventory inventory = new PlayerInventory(this);
	private InventoryEnderChest enderChest = new InventoryEnderChest();
	public Container defaultContainer;
	public Container activeContainer;
	protected FoodMetaData foodData = new FoodMetaData();

	/** Equipment (armor and held item) for this entity. */
	protected int equipment;

	/** Whether this entity can pick up items from the ground. */
	public float canPickUpLoot;

	/** Whether this entity should NOT despawn. */
	public float persistenceRequired;
	protected final String name;
	public int isLeashed;
	public double leashedToEntity;
	public double field_110170_bx;
	public double by;
	public double bz;
	public double bA;
	public double bB;
	public boolean sleeping;
	public boolean fauxSleeping;
	public String spawnWorld = "";
	public ChunkCoordinates playerLocation;
	public int sleepTicks;
	public float bE;
	public float bF;
	private ChunkCoordinates tasks;
	private boolean targetTasks;

	/** Chances for each equipment piece from dropping when this entity dies. */
	private ChunkCoordinates equipmentDropChances;
	public PlayerAbilities abilities = new PlayerAbilities();
	public int oldLevel = -1;
	public int expLevel;
	public int expTotal;
	public float exp;
	private ItemStack itemInUse;

	/** How long to keep a specific target entity */
	private int itemInUseCount;
	protected float speedOnGround = 0.1F;
	protected float speedInAir = 0.02F;
	private int lookHelper;
	public EntityFishingHook hookedFish;

	public CraftHumanEntity getBukkitEntity() {
		return (CraftHumanEntity) super.getBukkitEntity();
	}

	public EntityHuman(World world, String s) {
		super(world);
		this.name = s;
		this.defaultContainer = new ContainerPlayer(this.inventory, !world.isStatic, this);
		this.activeContainer = this.defaultContainer;
		this.height = 1.62F;
		ChunkCoordinates chunkcoordinates = world.getSpawn();
		this.setPositionRotation((double) chunkcoordinates.x + 0.5D, (double) (chunkcoordinates.y + 1),
				(double) chunkcoordinates.z + 0.5D, 0.0F, 0.0F);
		this.field_70741_aB = 180.0F;
		this.maxFireTicks = 20;
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeMap().b(GenericAttributes.e).setValue(1.0D);
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(16, Byte.valueOf((byte) 0));
		this.datawatcher.addObject(17, Float.valueOf(0.0F));
		this.datawatcher.addObject(18, Integer.valueOf(0));
	}

	public boolean isUsingItem() {
		return this.itemInUse != null;
	}

	public void stopUsingItem() {
		if (this.itemInUse != null) {
			this.itemInUse.b(this.world, this, this.itemInUseCount);
		}

		this.clearItemInUse();
	}

	public void clearItemInUse() {
		this.itemInUse = null;
		this.itemInUseCount = 0;

		if (!this.world.isStatic) {
			this.setEating(false);
		}
	}

	public boolean isBlocking() {
		return this.isUsingItem() && Item.byId[this.itemInUse.id].c_(this.itemInUse) == EnumAnimation.BLOCK;
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		if (this.itemInUse != null) {
			ItemStack itemstack = this.inventory.getItemInHand();

			if (itemstack == this.itemInUse) {
				if (this.itemInUseCount <= 25 && this.itemInUseCount % 4 == 0) {
					this.updateItemUse(itemstack, 5);
				}

				if (--this.itemInUseCount == 0 && !this.world.isStatic) {
					this.eatGrassBonus();
				}
			} else {
				this.clearItemInUse();
			}
		}

		if (this.isLeashed > 0) {
			--this.isLeashed;
		}

		if (this.isSleeping()) {
			++this.sleepTicks;

			if (this.sleepTicks > 100) {
				this.sleepTicks = 100;
			}

			if (!this.world.isStatic) {
				if (!this.isInBed()) {
					this.wakeUpPlayer(true, true, false);
				} else if (this.world.isDaytime()) {
					this.wakeUpPlayer(false, true, true);
				}
			}
		} else if (this.sleepTicks > 0) {
			++this.sleepTicks;

			if (this.sleepTicks >= 110) {
				this.sleepTicks = 0;
			}
		}

		super.onUpdate();

		if (!this.world.isStatic && this.activeContainer != null && !this.activeContainer.a(this)) {
			this.closeInventory();
			this.activeContainer = this.defaultContainer;
		}

		if (this.isBurning() && this.abilities.isInvulnerable) {
			this.extinguish();
		}

		this.leashedToEntity = this.bz;
		this.field_110170_bx = this.bA;
		this.by = this.bB;
		double d0 = this.locX - this.bz;
		double d1 = this.locY - this.bA;
		double d2 = this.locZ - this.bB;
		double d3 = 10.0D;

		if (d0 > d3) {
			this.leashedToEntity = this.bz = this.locX;
		}

		if (d2 > d3) {
			this.by = this.bB = this.locZ;
		}

		if (d1 > d3) {
			this.field_110170_bx = this.bA = this.locY;
		}

		if (d0 < -d3) {
			this.leashedToEntity = this.bz = this.locX;
		}

		if (d2 < -d3) {
			this.by = this.bB = this.locZ;
		}

		if (d1 < -d3) {
			this.field_110170_bx = this.bA = this.locY;
		}

		this.bz += d0 * 0.25D;
		this.bB += d2 * 0.25D;
		this.bA += d1 * 0.25D;
		this.addStat(StatisticList.k, 1);

		if (this.vehicle == null) {
			this.equipmentDropChances = null;
		}

		if (!this.world.isStatic) {
			this.foodData.a(this);
		}
	}

	/**
	 * Return the amount of time this entity should stay in a portal before
	 * being transported.
	 */
	public int getMaxInPortalTime() {
		return this.abilities.isInvulnerable ? 0 : 80;
	}

	/**
	 * Return the amount of cooldown before this entity can use a portal again.
	 */
	public int getPortalCooldown() {
		return 10;
	}

	public void makeSound(String s, float f, float f1) {
		this.world.a(this, s, f, f1);
	}

	protected void updateItemUse(ItemStack itemstack, int i) {
		if (itemstack.o() == EnumAnimation.DRINK) {
			this.makeSound("random.drink", 0.5F, this.world.random.nextFloat() * 0.1F + 0.9F);
		}

		if (itemstack.o() == EnumAnimation.EAT) {
			for (int j = 0; j < i; ++j) {
				Vec3D vec3d = this.world.getVec3DPool().create(((double) this.random.nextFloat() - 0.5D) * 0.1D,
						Math.random() * 0.1D + 0.1D, 0.0D);
				vec3d.a(-this.pitch * (float) Math.PI / 180.0F);
				vec3d.b(-this.yaw * (float) Math.PI / 180.0F);
				Vec3D vec3d1 = this.world.getVec3DPool().create(((double) this.random.nextFloat() - 0.5D) * 0.3D,
						(double) (-this.random.nextFloat()) * 0.6D - 0.3D, 0.6D);
				vec3d1.a(-this.pitch * (float) Math.PI / 180.0F);
				vec3d1.b(-this.yaw * (float) Math.PI / 180.0F);
				vec3d1 = vec3d1.add(this.locX, this.locY + (double) this.getHeadHeight(), this.locZ);
				this.world.addParticle("iconcrack_" + itemstack.getItem().id, vec3d1.c, vec3d1.d, vec3d1.e, vec3d.c,
						vec3d.d + 0.05D, vec3d.e);
			}

			this.makeSound("random.eat", 0.5F + 0.5F * (float) this.random.nextInt(2),
					(this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
		}
	}

	/**
	 * This function applies the benefits of growing back wool and faster
	 * growing up to the acting entity. (This function is used in the
	 * AIEatGrass)
	 */
	protected void eatGrassBonus() {
		if (this.itemInUse != null) {
			this.updateItemUse(this.itemInUse, 16);
			int i = this.itemInUse.count;
			org.bukkit.inventory.ItemStack craftItem = CraftItemStack.asBukkitCopy(this.itemInUse);
			PlayerItemConsumeEvent event = new PlayerItemConsumeEvent((Player) this.getBukkitEntity(), craftItem);
			this.world.getServer().getPluginManager().callEvent(event);

			if (event.isCancelled()) {
				if (this instanceof EntityPlayer) {
					((EntityPlayer) this).playerConnection.sendPacket(
							new Packet103SetSlot(0, this.activeContainer.getSlotFromInventory(this.inventory,
									this.inventory.itemInHandIndex).index, this.itemInUse));
					((EntityPlayer) this).getBukkitEntity().updateInventory();
					((EntityPlayer) this).getBukkitEntity().updateScaledHealth();
				}

				return;
			}

			if (!craftItem.equals(event.getItem())) {
				CraftItemStack.asNMSCopy(event.getItem()).b(this.world, this);

				if (this instanceof EntityPlayer) {
					((EntityPlayer) this).playerConnection.sendPacket(
							new Packet103SetSlot(0, this.activeContainer.getSlotFromInventory(this.inventory,
									this.inventory.itemInHandIndex).index, this.itemInUse));
				}

				return;
			}

			ItemStack itemstack = this.itemInUse.b(this.world, this);

			if (itemstack != this.itemInUse || itemstack != null && itemstack.count != i) {
				this.inventory.items[this.inventory.itemInHandIndex] = itemstack;

				if (itemstack.count == 0) {
					this.inventory.items[this.inventory.itemInHandIndex] = null;
				}
			}

			this.clearItemInUse();
		}
	}

	protected boolean isMovementBlocked() {
		return this.getHealth() <= 0.0F || this.isSleeping();
	}

	public void closeInventory() {
		this.activeContainer = this.defaultContainer;
	}

	public void mount(Entity entity) {
		this.setPassengerOf(entity);
	}

	public void setPassengerOf(Entity entity) {
		if (this.vehicle != null && entity == null) {
			this.world.getServer().getPluginManager()
					.callEvent(new EntityDismountEvent(this.getBukkitEntity(), this.vehicle.getBukkitEntity()));
			Entity originalVehicle = this.vehicle;
			super.setPassengerOf(entity);

			if (!this.world.isStatic && this.vehicle == null) {
				this.dismountEntity(originalVehicle);
			}
		} else {
			super.setPassengerOf(entity);
		}
	}

	/**
	 * Handles updating while being ridden by an entity
	 */
	public void updateRidden() {
		if (!this.world.isStatic && this.isSneaking()) {
			this.mount((Entity) null);
			this.setSneaking(false);
		} else {
			double d0 = this.locX;
			double d1 = this.locY;
			double d2 = this.locZ;
			float f = this.yaw;
			float f1 = this.pitch;
			super.updateRidden();
			this.canPickUpLoot = this.persistenceRequired;
			this.persistenceRequired = 0.0F;
			this.checkMountedMovementStat(this.locX - d0, this.locY - d1, this.locZ - d2);

			if (this.vehicle instanceof EntityPig) {
				this.pitch = f1;
				this.yaw = f;
				this.renderYawOffset = ((EntityPig) this.vehicle).renderYawOffset;
			}
		}
	}

	protected void updateEntityActionState() {
		super.updateEntityActionState();
		this.updateArmSwingProgress();
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		if (this.equipment > 0) {
			--this.equipment;
		}

		if (this.world.difficulty == 0 && this.getHealth() < this.getMaxHealth()
				&& this.world.getGameRules().getBoolean("naturalRegeneration") && this.ticksLived % 20 * 12 == 0) {
			this.heal(1.0F, EntityRegainHealthEvent.RegainReason.REGEN);
		}

		this.inventory.k();
		this.canPickUpLoot = this.persistenceRequired;
		super.onLivingUpdate();
		AttributeInstance attributeinstance = this.getAttributeInstance(GenericAttributes.d);

		if (!this.world.isStatic) {
			attributeinstance.setValue((double) this.abilities.b());
		}

		this.jumpMovementFactor = this.speedInAir;

		if (this.isSprinting()) {
			this.jumpMovementFactor = (float) ((double) this.jumpMovementFactor + (double) this.speedInAir * 0.3D);
		}

		this.setAIMoveSpeed((float) attributeinstance.getValue());
		float f = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
		float f1 = (float) TrigMath.atan(-this.motY * 0.20000000298023224D) * 15.0F;

		if (f > 0.1F) {
			f = 0.1F;
		}

		if (!this.onGround || this.getHealth() <= 0.0F) {
			f = 0.0F;
		}

		if (this.onGround || this.getHealth() <= 0.0F) {
			f1 = 0.0F;
		}

		this.persistenceRequired += (f - this.persistenceRequired) * 0.4F;
		this.cameraPitch += (f1 - this.cameraPitch) * 0.8F;

		if (this.getHealth() > 0.0F) {
			AxisAlignedBB axisalignedbb = null;

			if (this.vehicle != null && !this.vehicle.dead) {
				axisalignedbb = this.boundingBox.func_111270_a(this.vehicle.boundingBox).grow(1.0D, 0.0D, 1.0D);
			} else {
				axisalignedbb = this.boundingBox.grow(1.0D, 0.5D, 1.0D);
			}

			List list = this.world.getEntities(this, axisalignedbb);

			if (list != null && this.canBeCollidedWith()) {
				for (int i = 0; i < list.size(); ++i) {
					Entity entity = (Entity) list.get(i);

					if (!entity.dead) {
						this.collideWithPlayer(entity);
					}
				}
			}
		}
	}

	private void collideWithPlayer(Entity entity) {
		entity.b_(this);
	}

	public int getScore() {
		return this.datawatcher.getInt(18);
	}

	public void setScore(int i) {
		this.datawatcher.watch(18, Integer.valueOf(i));
	}

	public void addScore(int i) {
		int j = this.getScore();
		this.datawatcher.watch(18, Integer.valueOf(j + i));
	}

	public void die(DamageSource damagesource) {
		super.die(damagesource);
		this.setSize(0.2F, 0.2F);
		this.setPosition(this.locX, this.locY, this.locZ);
		this.motY = 0.10000000149011612D;

		if (this.name.equals("Notch")) {
			this.dropPlayerItemWithRandomChoice(new ItemStack(Item.APPLE, 1), true);
		}

		if (!this.world.getGameRules().getBoolean("keepInventory")) {
			this.inventory.m();
		}

		if (damagesource != null) {
			this.motX = (double) (-MathHelper.cos((this.attackedAtYaw + this.yaw) * (float) Math.PI / 180.0F) * 0.1F);
			this.motZ = (double) (-MathHelper.sin((this.attackedAtYaw + this.yaw) * (float) Math.PI / 180.0F) * 0.1F);
		} else {
			this.motX = this.motZ = 0.0D;
		}

		this.height = 0.1F;
		this.addStat(StatisticList.y, 1);
	}

	/**
	 * Adds a value to the player score. Currently not actually used and the
	 * entity passed in does nothing. Args: entity, scoreToAdd
	 */
	public void addToPlayerScore(Entity entity, int i) {
		this.addScore(i);
		Collection collection = this.world.getServer().getScoreboardManager().getScoreboardScores(IScoreboardCriteria.e,
				this.getLocalizedName(), new ArrayList());

		if (entity instanceof EntityHuman) {
			this.addStat(StatisticList.A, 1);
			this.world.getServer().getScoreboardManager().getScoreboardScores(IScoreboardCriteria.d,
					this.getLocalizedName(), collection);
		} else {
			this.addStat(StatisticList.z, 1);
		}

		Iterator iterator = collection.iterator();

		while (iterator.hasNext()) {
			ScoreboardScore scoreboardscore = (ScoreboardScore) iterator.next();
			scoreboardscore.incrementScore();
		}
	}

	public EntityItem dropOneItem(boolean flag) {
		return this.dropPlayerItemWithRandomChoice(
				this.inventory.splitStack(this.inventory.itemInHandIndex,
						flag && this.inventory.getItemInHand() != null ? this.inventory.getItemInHand().count : 1),
				false);
	}

	public EntityItem drop(ItemStack itemstack) {
		return this.dropPlayerItemWithRandomChoice(itemstack, false);
	}

	public EntityItem dropPlayerItemWithRandomChoice(ItemStack itemstack, boolean flag) {
		if (itemstack == null) {
			return null;
		} else if (itemstack.count == 0) {
			return null;
		} else {
			EntityItem entityitem = new EntityItem(this.world, this.locX,
					this.locY - 0.30000001192092896D + (double) this.getHeadHeight(), this.locZ, itemstack);
			entityitem.pickupDelay = 40;
			float f = 0.1F;
			float f1;

			if (flag) {
				f1 = this.random.nextFloat() * 0.5F;
				float player = this.random.nextFloat() * (float) Math.PI * 2.0F;
				entityitem.motX = (double) (-MathHelper.sin(player) * f1);
				entityitem.motZ = (double) (MathHelper.cos(player) * f1);
				entityitem.motY = 0.20000000298023224D;
			} else {
				f = 0.3F;
				entityitem.motX = (double) (-MathHelper.sin(this.yaw / 180.0F * (float) Math.PI)
						* MathHelper.cos(this.pitch / 180.0F * (float) Math.PI) * f);
				entityitem.motZ = (double) (MathHelper.cos(this.yaw / 180.0F * (float) Math.PI)
						* MathHelper.cos(this.pitch / 180.0F * (float) Math.PI) * f);
				entityitem.motY = (double) (-MathHelper.sin(this.pitch / 180.0F * (float) Math.PI) * f + 0.1F);
				f = 0.02F;
				f1 = this.random.nextFloat() * (float) Math.PI * 2.0F;
				f *= this.random.nextFloat();
				entityitem.motX += Math.cos((double) f1) * (double) f;
				entityitem.motY += (double) ((this.random.nextFloat() - this.random.nextFloat()) * 0.1F);
				entityitem.motZ += Math.sin((double) f1) * (double) f;
			}

			Player player1 = (Player) this.getBukkitEntity();
			CraftItem drop = new CraftItem(this.world.getServer(), entityitem);
			PlayerDropItemEvent event = new PlayerDropItemEvent(player1, drop);
			this.world.getServer().getPluginManager().callEvent(event);

			if (event.isCancelled()) {
				player1.getInventory().addItem(new org.bukkit.inventory.ItemStack[] { drop.getItemStack() });
				return null;
			} else {
				this.joinEntityItemWithWorld(entityitem);
				this.addStat(StatisticList.v, 1);
				return entityitem;
			}
		}
	}

	protected void joinEntityItemWithWorld(EntityItem entityitem) {
		this.world.addEntity(entityitem);
	}

	public float getCurrentPlayerStrVsBlock(Block block, boolean flag) {
		float f = this.inventory.a(block);

		if (f > 1.0F) {
			int i = EnchantmentManager.getDigSpeedEnchantmentLevel(this);
			ItemStack itemstack = this.inventory.getItemInHand();

			if (i > 0 && itemstack != null) {
				float f1 = (float) (i * i + 1);

				if (!itemstack.canHarvestBlock(block) && f <= 1.0F) {
					f += f1 * 0.08F;
				} else {
					f += f1;
				}
			}
		}

		if (this.hasEffect(MobEffectList.FASTER_DIG)) {
			f *= 1.0F + (float) (this.getEffect(MobEffectList.FASTER_DIG).getAmplifier() + 1) * 0.2F;
		}

		if (this.hasEffect(MobEffectList.SLOWER_DIG)) {
			f *= 1.0F - (float) (this.getEffect(MobEffectList.SLOWER_DIG).getAmplifier() + 1) * 0.2F;
		}

		if (this.isInsideOfMaterial(Material.WATER) && !EnchantmentManager.hasWaterWorkerEnchantment(this)) {
			f /= 5.0F;
		}

		if (!this.onGround) {
			f /= 5.0F;
		}

		return f;
	}

	public boolean canHarvestBlock(Block block) {
		return this.inventory.b(block);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		super.readEntityFromNBT(nbttagcompound);
		NBTTagList nbttaglist = nbttagcompound.getList("Inventory");
		this.inventory.b(nbttaglist);
		this.inventory.itemInHandIndex = nbttagcompound.getInt("SelectedItemSlot");
		this.sleeping = nbttagcompound.getBoolean("Sleeping");
		this.sleepTicks = nbttagcompound.getShort("SleepTimer");
		this.exp = nbttagcompound.getFloat("XpP");
		this.expLevel = nbttagcompound.getInt("XpLevel");
		this.expTotal = nbttagcompound.getInt("XpTotal");
		this.setScore(nbttagcompound.getInt("Score"));

		if (this.sleeping) {
			this.playerLocation = new ChunkCoordinates(MathHelper.floor(this.locX), MathHelper.floor(this.locY),
					MathHelper.floor(this.locZ));
			this.wakeUpPlayer(true, true, false);
		}

		this.spawnWorld = nbttagcompound.getString("SpawnWorld");

		if ("".equals(this.spawnWorld)) {
			this.spawnWorld = ((org.bukkit.World) this.world.getServer().getWorlds().get(0)).getName();
		}

		if (nbttagcompound.hasKey("SpawnX") && nbttagcompound.hasKey("SpawnY") && nbttagcompound.hasKey("SpawnZ")) {
			this.tasks = new ChunkCoordinates(nbttagcompound.getInt("SpawnX"), nbttagcompound.getInt("SpawnY"),
					nbttagcompound.getInt("SpawnZ"));
			this.targetTasks = nbttagcompound.getBoolean("SpawnForced");
		}

		this.foodData.a(nbttagcompound);
		this.abilities.b(nbttagcompound);

		if (nbttagcompound.hasKey("EnderItems")) {
			NBTTagList nbttaglist1 = nbttagcompound.getList("EnderItems");
			this.enderChest.loadInventoryFromNBT(nbttaglist1);
		}
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		super.writeEntityToNBT(nbttagcompound);
		nbttagcompound.set("Inventory", this.inventory.a(new NBTTagList()));
		nbttagcompound.setInt("SelectedItemSlot", this.inventory.itemInHandIndex);
		nbttagcompound.setBoolean("Sleeping", this.sleeping);
		nbttagcompound.setShort("SleepTimer", (short) this.sleepTicks);
		nbttagcompound.setFloat("XpP", this.exp);
		nbttagcompound.setInt("XpLevel", this.expLevel);
		nbttagcompound.setInt("XpTotal", this.expTotal);
		nbttagcompound.setInt("Score", this.getScore());

		if (this.tasks != null) {
			nbttagcompound.setInt("SpawnX", this.tasks.x);
			nbttagcompound.setInt("SpawnY", this.tasks.y);
			nbttagcompound.setInt("SpawnZ", this.tasks.z);
			nbttagcompound.setBoolean("SpawnForced", this.targetTasks);
			nbttagcompound.setString("SpawnWorld", this.spawnWorld);
		}

		this.foodData.b(nbttagcompound);
		this.abilities.a(nbttagcompound);
		nbttagcompound.set("EnderItems", this.enderChest.saveInventoryToNBT());
	}

	public void openContainer(IInventory iinventory) {
	}

	public void openHopper(TileEntityHopper tileentityhopper) {
	}

	public void openMinecartHopper(EntityMinecartHopper entityminecarthopper) {
	}

	public void openHorseInventory(EntityHorse entityhorse, IInventory iinventory) {
	}

	public void startEnchanting(int i, int j, int k, String s) {
	}

	public void openAnvil(int i, int j, int k) {
	}

	public void startCrafting(int i, int j, int k) {
	}

	public float getHeadHeight() {
		return 0.12F;
	}

	protected void resetHeight() {
		this.height = 1.62F;
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else if (this.abilities.isInvulnerable && !damagesource.ignoresInvulnerability()) {
			return false;
		} else {
			this.entityAge = 0;

			if (this.getHealth() <= 0.0F) {
				return false;
			} else {
				if (this.isSleeping() && !this.world.isStatic) {
					this.wakeUpPlayer(true, true, false);
				}

				if (damagesource.isDifficultyScaled()) {
					if (this.world.difficulty == 0) {
						return false;
					}

					if (this.world.difficulty == 1) {
						f = f / 2.0F + 1.0F;
					}

					if (this.world.difficulty == 3) {
						f = f * 3.0F / 2.0F;
					}
				}

				Entity entity = damagesource.getEntity();

				if (entity instanceof EntityArrow && ((EntityArrow) entity).shooter != null) {
					entity = ((EntityArrow) entity).shooter;
				}

				this.addStat(StatisticList.x, Math.round(f * 10.0F));
				return super.attackEntityFrom(damagesource, f);
			}
		}
	}

	public boolean canAttackPlayer(EntityHuman entityhuman) {
		Team team;

		if (entityhuman instanceof EntityPlayer) {
			EntityPlayer thisPlayer = (EntityPlayer) entityhuman;
			team = thisPlayer.getBukkitEntity().getScoreboard().getPlayerTeam(thisPlayer.getBukkitEntity());

			if (team == null || team.allowFriendlyFire()) {
				return true;
			}
		} else {
			OfflinePlayer thisPlayer1 = entityhuman.world.getServer().getOfflinePlayer(entityhuman.name);
			team = entityhuman.world.getServer().getScoreboardManager().getMainScoreboard().getPlayerTeam(thisPlayer1);

			if (team == null || team.allowFriendlyFire()) {
				return true;
			}
		}

		return this instanceof EntityPlayer ? !team.hasPlayer(((EntityPlayer) this).getBukkitEntity())
				: !team.hasPlayer(this.world.getServer().getOfflinePlayer(this.name));
	}

	protected void damageArmor(float f) {
		this.inventory.a(f);
	}

	public int getTotalArmorValue() {
		return this.inventory.l();
	}

	public float getArmorVisibility() {
		int i = 0;
		ItemStack[] aitemstack = this.inventory.armor;
		int j = aitemstack.length;

		for (int k = 0; k < j; ++k) {
			ItemStack itemstack = aitemstack[k];

			if (itemstack != null) {
				++i;
			}
		}

		return (float) i / (float) this.inventory.armor.length;
	}

	protected void damageEntity(DamageSource damagesource, float f) {
		if (!this.isInvulnerable()) {
			if (!damagesource.ignoresArmor() && this.isBlocking() && f > 0.0F) {
				f = (1.0F + f) * 0.5F;
			}

			f = this.applyArmorCalculations(damagesource, f);
			f = this.applyPotionDamageCalculations(damagesource, f);
			float f1 = f;
			f = Math.max(f - this.getAbsorptionAmount(), 0.0F);
			this.setAbsorptionAmount(this.getAbsorptionAmount() - (f1 - f));

			if (f != 0.0F) {
				this.addExhaustion(damagesource.getHungerDamage());
				float f2 = this.getHealth();
				this.setHealth(this.getHealth() - f);
				this.func_110142_aN().func_94547_a(damagesource, f2, f);
			}
		}
	}

	public void openFurnace(TileEntityFurnace tileentityfurnace) {
	}

	public void openDispenser(TileEntityDispenser tileentitydispenser) {
	}

	public void openEditSign(TileEntity tileentity) {
	}

	public void openBrewingStand(TileEntityBrewingStand tileentitybrewingstand) {
	}

	public void openBeacon(TileEntityBeacon tileentitybeacon) {
	}

	public void openTrade(IMerchant imerchant, String s) {
	}

	public void openBook(ItemStack itemstack) {
	}

	public boolean interactWith(Entity entity) {
		ItemStack itemstack = this.getCurrentEquippedItem();
		ItemStack itemstack1 = itemstack != null ? itemstack.cloneItemStack() : null;

		if (!entity.c(this)) {
			if (itemstack != null && entity instanceof EntityLiving) {
				if (this.abilities.canInstantlyBuild) {
					itemstack = itemstack1;
				}

				if (itemstack.a(this, (EntityLiving) entity)) {
					if (itemstack.count == 0 && !this.abilities.canInstantlyBuild) {
						this.destroyCurrentEquippedItem();
					}

					return true;
				}
			}

			return false;
		} else {
			if (itemstack != null && itemstack == this.getCurrentEquippedItem()) {
				if (itemstack.count <= 0 && !this.abilities.canInstantlyBuild) {
					this.destroyCurrentEquippedItem();
				} else if (itemstack.count < itemstack1.count && this.abilities.canInstantlyBuild) {
					itemstack.count = itemstack1.count;
				}
			}

			return true;
		}
	}

	public ItemStack getCurrentEquippedItem() {
		return this.inventory.getItemInHand();
	}

	public void destroyCurrentEquippedItem() {
		this.inventory.setItem(this.inventory.itemInHandIndex, (ItemStack) null);
	}

	/**
	 * Returns the Y Offset of this entity.
	 */
	public double getYOffset() {
		return (double) (this.height - 0.5F);
	}

	public void attack(Entity entity) {
		if (entity.canAttackWithItem() && !entity.hitByEntity(this)) {
			float f = (float) this.getAttributeInstance(GenericAttributes.e).getValue();
			int i = 0;
			float f1 = 0.0F;

			if (entity instanceof EntityLiving) {
				f1 = EnchantmentManager.a((EntityLiving) this, (EntityLiving) entity);
				i += EnchantmentManager.getKnockbackEnchantmentLevel(this, (EntityLiving) entity);
			}

			if (this.isSprinting()) {
				++i;
			}

			if (f > 0.0F || f1 > 0.0F) {
				boolean flag = this.fallDistance > 0.0F && !this.onGround && !this.isOnLadder() && !this.isInWater()
						&& !this.hasEffect(MobEffectList.BLINDNESS) && this.vehicle == null
						&& entity instanceof EntityLiving;

				if (flag && f > 0.0F) {
					f *= 1.5F;
				}

				f += f1;
				boolean flag1 = false;
				int j = EnchantmentManager.getFireAspectEnchantmentLevel(this);

				if (entity instanceof EntityLiving && j > 0 && !entity.isBurning()) {
					flag1 = true;
					entity.setOnFire(1);
				}

				boolean flag2 = entity.attackEntityFrom(DamageSource.playerAttack(this), f);

				if (!flag2) {
					if (flag1) {
						entity.extinguish();
					}

					return;
				}

				if (flag2) {
					if (i > 0) {
						entity.addVelocity(
								(double) (-MathHelper.sin(this.yaw * (float) Math.PI / 180.0F) * (float) i * 0.5F),
								0.1D,
								(double) (MathHelper.cos(this.yaw * (float) Math.PI / 180.0F) * (float) i * 0.5F));
						this.motX *= 0.6D;
						this.motZ *= 0.6D;
						this.setSprinting(false);
					}

					if (flag) {
						this.onCriticalHit(entity);
					}

					if (f1 > 0.0F) {
						this.onEnchantmentCritical(entity);
					}

					if (f >= 18.0F) {
						this.triggerAchievement((Statistic) AchievementList.overkill);
					}

					this.setLastAttacker(entity);

					if (entity instanceof EntityLiving) {
						EnchantmentThorns.a(this, (EntityLiving) entity, this.random);
					}
				}

				ItemStack itemstack = this.getCurrentEquippedItem();
				Object object = entity;

				if (entity instanceof EntityComplexPart) {
					IComplex combustEvent = ((EntityComplexPart) entity).owner;

					if (combustEvent != null && combustEvent instanceof EntityLiving) {
						object = (EntityLiving) combustEvent;
					}
				}

				if (itemstack != null && object instanceof EntityLiving) {
					itemstack.a((EntityLiving) object, this);

					if (itemstack.count == 0) {
						this.destroyCurrentEquippedItem();
					}
				}

				if (entity instanceof EntityLiving) {
					this.addStat(StatisticList.w, Math.round(f * 10.0F));

					if (j > 0 && flag2) {
						EntityCombustByEntityEvent var12 = new EntityCombustByEntityEvent(this.getBukkitEntity(),
								entity.getBukkitEntity(), j * 4);
						Bukkit.getPluginManager().callEvent(var12);

						if (!var12.isCancelled()) {
							entity.setOnFire(var12.getDuration());
						}
					} else if (flag1) {
						entity.extinguish();
					}
				}

				this.addExhaustion(0.3F);
			}
		}
	}

	public void onCriticalHit(Entity entity) {
	}

	public void onEnchantmentCritical(Entity entity) {
	}

	public void die() {
		super.die();
		this.defaultContainer.b(this);

		if (this.activeContainer != null) {
			this.activeContainer.b(this);
		}
	}

	public boolean inBlock() {
		return !this.sleeping && super.inBlock();
	}

	public EnumBedResult sleepInBedAt(int i, int j, int k) {
		if (!this.world.isStatic) {
			if (this.isSleeping() || !this.isAlive()) {
				return EnumBedResult.OTHER_PROBLEM;
			}

			if (!this.world.worldProvider.isSurfaceWorld()) {
				return EnumBedResult.NOT_POSSIBLE_HERE;
			}

			if (this.world.isDaytime()) {
				return EnumBedResult.NOT_POSSIBLE_NOW;
			}

			if (Math.abs(this.locX - (double) i) > 3.0D || Math.abs(this.locY - (double) j) > 2.0D
					|| Math.abs(this.locZ - (double) k) > 3.0D) {
				return EnumBedResult.TOO_FAR_AWAY;
			}

			double d0 = 8.0D;
			double d1 = 5.0D;
			List list = this.world.getEntitiesWithinAABB(EntityMonster.class,
					AxisAlignedBB.getAABBPool().getAABB((double) i - d0, (double) j - d1, (double) k - d0,
							(double) i + d0, (double) j + d1, (double) k + d0));

			if (!list.isEmpty()) {
				return EnumBedResult.NOT_SAFE;
			}
		}

		if (this.isRiding()) {
			this.mount((Entity) null);
		}

		if (this.getBukkitEntity() instanceof Player) {
			Player l = (Player) this.getBukkitEntity();
			org.bukkit.block.Block i1 = this.world.getWorld().getBlockAt(i, j, k);
			PlayerBedEnterEvent f = new PlayerBedEnterEvent(l, i1);
			this.world.getServer().getPluginManager().callEvent(f);

			if (f.isCancelled()) {
				return EnumBedResult.OTHER_PROBLEM;
			}
		}

		this.setSize(0.2F, 0.2F);
		this.height = 0.2F;

		if (this.world.isLoaded(i, j, k)) {
			int l1 = this.world.getData(i, j, k);
			int i11 = BlockBed.getDirection(l1);
			float f1 = 0.5F;

			switch (i11) {
			case 0:
				f1 = 0.9F;
				break;

			case 1:
				f1 = 0.1F;
				break;

			case 2:
				f1 = 0.1F;
				break;

			case 3:
				f1 = 0.9F;
			}

			this.func_71013_b(i11);
			this.setPosition((double) ((float) i + f1), (double) ((float) j + 0.9375F), (double) ((float) k + f1));
		} else {
			this.setPosition((double) ((float) i + 0.5F), (double) ((float) j + 0.9375F), (double) ((float) k + 0.5F));
		}

		this.sleeping = true;
		this.sleepTicks = 0;
		this.playerLocation = new ChunkCoordinates(i, j, k);
		this.motX = this.motZ = this.motY = 0.0D;

		if (!this.world.isStatic) {
			this.world.everyoneSleeping();
		}

		return EnumBedResult.OK;
	}

	private void func_71013_b(int i) {
		this.bE = 0.0F;
		this.bF = 0.0F;

		switch (i) {
		case 0:
			this.bF = -1.8F;
			break;

		case 1:
			this.bE = 1.8F;
			break;

		case 2:
			this.bF = 1.8F;
			break;

		case 3:
			this.bE = -1.8F;
		}
	}

	public void wakeUpPlayer(boolean flag, boolean flag1, boolean flag2) {
		this.setSize(0.6F, 1.8F);
		this.resetHeight();
		ChunkCoordinates chunkcoordinates = this.playerLocation;
		ChunkCoordinates chunkcoordinates1 = this.playerLocation;

		if (chunkcoordinates != null
				&& this.world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) == Block.BED.id) {
			BlockBed.setBedOccupied(this.world, chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z, false);
			chunkcoordinates1 = BlockBed.getNearestEmptyChunkCoordinates(this.world, chunkcoordinates.x,
					chunkcoordinates.y, chunkcoordinates.z, 0);

			if (chunkcoordinates1 == null) {
				chunkcoordinates1 = new ChunkCoordinates(chunkcoordinates.x, chunkcoordinates.y + 1,
						chunkcoordinates.z);
			}

			this.setPosition((double) ((float) chunkcoordinates1.x + 0.5F),
					(double) ((float) chunkcoordinates1.y + this.height + 0.1F),
					(double) ((float) chunkcoordinates1.z + 0.5F));
		}

		this.sleeping = false;

		if (!this.world.isStatic && flag1) {
			this.world.everyoneSleeping();
		}

		if (this.getBukkitEntity() instanceof Player) {
			Player player = (Player) this.getBukkitEntity();
			org.bukkit.block.Block bed;

			if (chunkcoordinates != null) {
				bed = this.world.getWorld().getBlockAt(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z);
			} else {
				bed = this.world.getWorld().getBlockAt(player.getLocation());
			}

			PlayerBedLeaveEvent event = new PlayerBedLeaveEvent(player, bed);
			this.world.getServer().getPluginManager().callEvent(event);
		}

		if (flag) {
			this.sleepTicks = 0;
		} else {
			this.sleepTicks = 100;
		}

		if (flag2) {
			this.setRespawnPosition(this.playerLocation, false);
		}
	}

	private boolean isInBed() {
		return this.world.getTypeId(this.playerLocation.x, this.playerLocation.y, this.playerLocation.z) == Block.BED.id;
	}

	public static ChunkCoordinates getBed(World world, ChunkCoordinates chunkcoordinates, boolean flag) {
		IChunkProvider ichunkprovider = world.getChunkProvider();
		ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z - 3 >> 4);
		ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z - 3 >> 4);
		ichunkprovider.getChunkAt(chunkcoordinates.x - 3 >> 4, chunkcoordinates.z + 3 >> 4);
		ichunkprovider.getChunkAt(chunkcoordinates.x + 3 >> 4, chunkcoordinates.z + 3 >> 4);

		if (world.getTypeId(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z) == Block.BED.id) {
			ChunkCoordinates material1 = BlockBed.getNearestEmptyChunkCoordinates(world, chunkcoordinates.x,
					chunkcoordinates.y, chunkcoordinates.z, 0);
			return material1;
		} else {
			Material material = world.getMaterial(chunkcoordinates.x, chunkcoordinates.y, chunkcoordinates.z);
			Material material1 = world.getMaterial(chunkcoordinates.x, chunkcoordinates.y + 1, chunkcoordinates.z);
			boolean flag1 = !material.isBuildable() && !material.isLiquid();
			boolean flag2 = !material1.isBuildable() && !material1.isLiquid();
			return flag && flag1 && flag2 ? chunkcoordinates : null;
		}
	}

	public boolean isSleeping() {
		return this.sleeping;
	}

	public boolean isDeeplySleeping() {
		return this.sleeping && this.sleepTicks >= 100;
	}

	protected void setHideCape(int i, boolean flag) {
		byte b0 = this.datawatcher.getByte(16);

		if (flag) {
			this.datawatcher.watch(16, Byte.valueOf((byte) (b0 | 1 << i)));
		} else {
			this.datawatcher.watch(16, Byte.valueOf((byte) (b0 & ~(1 << i))));
		}
	}

	public void setCustomNameTag(String s) {
	}

	public ChunkCoordinates getBed() {
		return this.tasks;
	}

	public boolean isRespawnForced() {
		return this.targetTasks;
	}

	public void setRespawnPosition(ChunkCoordinates chunkcoordinates, boolean flag) {
		if (chunkcoordinates != null) {
			this.tasks = new ChunkCoordinates(chunkcoordinates);
			this.targetTasks = flag;
			this.spawnWorld = this.world.worldData.getName();
		} else {
			this.tasks = null;
			this.targetTasks = false;
			this.spawnWorld = "";
		}
	}

	public void triggerAchievement(Statistic statistic) {
		this.addStat(statistic, 1);
	}

	public void addStat(Statistic statistic, int i) {
	}

	protected void jump() {
		super.jump();
		this.addStat(StatisticList.u, 1);

		if (this.isSprinting()) {
			this.addExhaustion(0.8F);
		} else {
			this.addExhaustion(0.2F);
		}
	}

	public void moveEntityWithHeading(float f, float f1) {
		double d0 = this.locX;
		double d1 = this.locY;
		double d2 = this.locZ;

		if (this.abilities.isFlying && this.vehicle == null) {
			double d3 = this.motY;
			float f2 = this.jumpMovementFactor;
			this.jumpMovementFactor = this.abilities.a();
			super.moveEntityWithHeading(f, f1);
			this.motY = d3 * 0.6D;
			this.jumpMovementFactor = f2;
		} else {
			super.moveEntityWithHeading(f, f1);
		}

		this.checkMovement(this.locX - d0, this.locY - d1, this.locZ - d2);
	}

	public float getAIMoveSpeed() {
		return (float) this.getAttributeInstance(GenericAttributes.d).getValue();
	}

	public void checkMovement(double d0, double d1, double d2) {
		if (this.vehicle == null) {
			int i;

			if (this.isInsideOfMaterial(Material.WATER)) {
				i = Math.round(MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2) * 100.0F);

				if (i > 0) {
					this.addStat(StatisticList.q, i);
					this.addExhaustion(0.015F * (float) i * 0.01F);
				}
			} else if (this.isInWater()) {
				i = Math.round(MathHelper.sqrt(d0 * d0 + d2 * d2) * 100.0F);

				if (i > 0) {
					this.addStat(StatisticList.m, i);
					this.addExhaustion(0.015F * (float) i * 0.01F);
				}
			} else if (this.isOnLadder()) {
				if (d1 > 0.0D) {
					this.addStat(StatisticList.o, (int) Math.round(d1 * 100.0D));
				}
			} else if (this.onGround) {
				i = Math.round(MathHelper.sqrt(d0 * d0 + d2 * d2) * 100.0F);

				if (i > 0) {
					this.addStat(StatisticList.l, i);

					if (this.isSprinting()) {
						this.addExhaustion(0.099999994F * (float) i * 0.01F);
					} else {
						this.addExhaustion(0.01F * (float) i * 0.01F);
					}
				}
			} else {
				i = Math.round(MathHelper.sqrt(d0 * d0 + d2 * d2) * 100.0F);

				if (i > 25) {
					this.addStat(StatisticList.p, i);
				}
			}
		}
	}

	private void checkMountedMovementStat(double d0, double d1, double d2) {
		if (this.vehicle != null) {
			int i = Math.round(MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2) * 100.0F);

			if (i > 0) {
				if (this.vehicle instanceof EntityMinecartAbstract) {
					this.addStat(StatisticList.r, i);

					if (this.equipmentDropChances == null) {
						this.equipmentDropChances = new ChunkCoordinates(MathHelper.floor(this.locX),
								MathHelper.floor(this.locY), MathHelper.floor(this.locZ));
					} else if ((double) this.equipmentDropChances.getDistanceSquared(MathHelper.floor(this.locX),
							MathHelper.floor(this.locY), MathHelper.floor(this.locZ)) >= 1000000.0D) {
						this.addStat((Statistic) AchievementList.onARail, 1);
					}
				} else if (this.vehicle instanceof EntityBoat) {
					this.addStat(StatisticList.s, i);
				} else if (this.vehicle instanceof EntityPig) {
					this.addStat(StatisticList.t, i);
				}
			}
		}
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float f) {
		if (!this.abilities.canFly) {
			if (f >= 2.0F) {
				this.addStat(StatisticList.n, (int) Math.round((double) f * 100.0D));
			}

			super.fall(f);
		}
	}

	public void onKillEntity(EntityLiving entityliving) {
		if (entityliving instanceof IMonster) {
			this.triggerAchievement((Statistic) AchievementList.killEnemy);
		}
	}

	/**
	 * Sets the Entity inside a web block.
	 */
	public void setInWeb() {
		if (!this.abilities.isFlying) {
			super.setInWeb();
		}
	}

	public ItemStack getCurrentArmor(int i) {
		return this.inventory.f(i);
	}

	public void giveExp(int i) {
		this.addScore(i);
		int j = Integer.MAX_VALUE - this.expTotal;

		if (i > j) {
			i = j;
		}

		this.exp += (float) i / (float) this.getExpToLevel();

		for (this.expTotal += i; this.exp >= 1.0F; this.exp /= (float) this.getExpToLevel()) {
			this.exp = (this.exp - 1.0F) * (float) this.getExpToLevel();
			this.levelDown(1);
		}
	}

	public void levelDown(int i) {
		this.expLevel += i;

		if (this.expLevel < 0) {
			this.expLevel = 0;
			this.exp = 0.0F;
			this.expTotal = 0;
		}

		if (i > 0 && this.expLevel % 5 == 0 && (float) this.lookHelper < (float) this.ticksLived - 100.0F) {
			float f = this.expLevel > 30 ? 1.0F : (float) this.expLevel / 30.0F;
			this.world.makeSound(this, "random.levelup", f * 0.75F, 1.0F);
			this.lookHelper = this.ticksLived;
		}
	}

	public int getExpToLevel() {
		return this.expLevel >= 30 ? 62 + (this.expLevel - 30) * 7
				: (this.expLevel >= 15 ? 17 + (this.expLevel - 15) * 3 : 17);
	}

	public void addExhaustion(float f) {
		if (!this.abilities.isInvulnerable && !this.world.isStatic) {
			this.foodData.a(f);
		}
	}

	public FoodMetaData getFoodData() {
		return this.foodData;
	}

	public boolean canEat(boolean flag) {
		return (flag || this.foodData.c()) && !this.abilities.isInvulnerable;
	}

	public boolean shouldHeal() {
		return this.getHealth() > 0.0F && this.getHealth() < this.getMaxHealth();
	}

	public void setItemInUse(ItemStack itemstack, int i) {
		if (itemstack != this.itemInUse) {
			this.itemInUse = itemstack;
			this.itemInUseCount = i;

			if (!this.world.isStatic) {
				this.setEating(true);
			}
		}
	}

	public boolean isCurrentToolAdventureModeExempt(int i, int j, int k) {
		if (this.abilities.mayBuild) {
			return true;
		} else {
			int l = this.world.getTypeId(i, j, k);

			if (l > 0) {
				Block block = Block.byId[l];

				if (block.material.isAdventureModeExempt()) {
					return true;
				}

				if (this.getCurrentEquippedItem() != null) {
					ItemStack itemstack = this.getCurrentEquippedItem();

					if (itemstack.canHarvestBlock(block) || itemstack.getStrVsBlock(block) > 1.0F) {
						return true;
					}
				}
			}

			return false;
		}
	}

	public boolean canPlayerEdit(int i, int j, int k, int l, ItemStack itemstack) {
		return this.abilities.mayBuild ? true : (itemstack != null ? itemstack.canEditBlocks() : false);
	}

	protected int getExpValue(EntityHuman entityhuman) {
		if (this.world.getGameRules().getBoolean("keepInventory")) {
			return 0;
		} else {
			int i = this.expLevel * 7;
			return i > 100 ? 100 : i;
		}
	}

	protected boolean alwaysGivesExp() {
		return true;
	}

	public String getLocalizedName() {
		return this.name;
	}

	public void copyTo(EntityHuman entityhuman, boolean flag) {
		if (flag) {
			this.inventory.b(entityhuman.inventory);
			this.setHealth(entityhuman.getHealth());
			this.foodData = entityhuman.foodData;
			this.expLevel = entityhuman.expLevel;
			this.expTotal = entityhuman.expTotal;
			this.exp = entityhuman.exp;
			this.setScore(entityhuman.getScore());
			this.teleportDirection = entityhuman.teleportDirection;
		} else if (this.world.getGameRules().getBoolean("keepInventory")) {
			this.inventory.b(entityhuman.inventory);
			this.expLevel = entityhuman.expLevel;
			this.expTotal = entityhuman.expTotal;
			this.exp = entityhuman.exp;
			this.setScore(entityhuman.getScore());
		}

		this.enderChest = entityhuman.enderChest;
	}

	/**
	 * returns if this entity triggers Block.onEntityWalking on the blocks they
	 * walk on. used for spiders and wolves to prevent them from trampling crops
	 */
	protected boolean canTriggerWalking() {
		return !this.abilities.isFlying;
	}

	public void updateAbilities() {
	}

	public void setGameType(EnumGamemode enumgamemode) {
	}

	public String getName() {
		return this.name;
	}

	public World getEntityWorld() {
		return this.world;
	}

	public InventoryEnderChest getEnderChest() {
		return this.enderChest;
	}

	public ItemStack getEquipment(int i) {
		return i == 0 ? this.inventory.getItemInHand() : this.inventory.armor[i - 1];
	}

	/**
	 * Returns the item that this EntityLiving is holding, if any.
	 */
	public ItemStack getHeldItem() {
		return this.inventory.getItemInHand();
	}

	public void setEquipment(int i, ItemStack itemstack) {
		this.inventory.armor[i] = itemstack;
	}

	public ItemStack[] getEquipment() {
		return this.inventory.armor;
	}

	public boolean isPushedByWater() {
		return !this.abilities.isFlying;
	}

	public Scoreboard getScoreboard() {
		return this.world.getScoreboard();
	}

	public ScoreboardTeamBase getScoreboardTeam() {
		return this.getScoreboard().getPlayerTeam(this.name);
	}

	public String getScoreboardDisplayName() {
		return ScoreboardTeam.getPlayerDisplayName(this.getScoreboardTeam(), this.name);
	}

	public void setAbsorptionAmount(float f) {
		if (f < 0.0F) {
			f = 0.0F;
		}

		this.getDataWatcher().watch(17, Float.valueOf(f));
	}

	public float getAbsorptionAmount() {
		return this.getDataWatcher().getFloat(17);
	}
}
