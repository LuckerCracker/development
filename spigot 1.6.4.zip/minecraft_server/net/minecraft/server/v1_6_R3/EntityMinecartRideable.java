package net.minecraft.server.v1_6_R3;

public class EntityMinecartRideable extends EntityMinecartAbstract
{
    public EntityMinecartRideable(World var1)
    {
        super(var1);
    }

    public EntityMinecartRideable(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public boolean c(EntityHuman var1)
    {
        if (this.passenger != null && this.passenger instanceof EntityHuman && this.passenger != var1)
        {
            return true;
        }
        else if (this.passenger != null && this.passenger != var1)
        {
            return false;
        }
        else
        {
            if (!this.world.isStatic)
            {
                var1.mount(this);
            }

            return true;
        }
    }

    public int getType()
    {
        return 0;
    }
}
