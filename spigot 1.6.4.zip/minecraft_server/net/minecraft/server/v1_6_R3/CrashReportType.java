package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportType implements Callable
{
    final DedicatedServer a;

    CrashReportType(DedicatedServer var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return "Dedicated Server (map_server.txt)";
    }

    public Object call()
    {
        return this.a();
    }
}
