package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryBrewer;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public class ContainerBrewingStand extends Container {
	private TileEntityBrewingStand brewingStand;

	/** Instance of Slot. */
	private final Slot theSlot;
	private int brewTime;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public ContainerBrewingStand(PlayerInventory playerinventory, TileEntityBrewingStand tileentitybrewingstand) {
		this.player = playerinventory;
		this.brewingStand = tileentitybrewingstand;
		this.addSlotToContainer(new SlotPotionBottle(playerinventory.player, tileentitybrewingstand, 0, 56, 46));
		this.addSlotToContainer(new SlotPotionBottle(playerinventory.player, tileentitybrewingstand, 1, 79, 53));
		this.addSlotToContainer(new SlotPotionBottle(playerinventory.player, tileentitybrewingstand, 2, 102, 46));
		this.theSlot = this.addSlotToContainer(new SlotBrewing(this, tileentitybrewingstand, 3, 79, 17));
		int i;

		for (i = 0; i < 3; ++i) {
			for (int j = 0; j < 9; ++j) {
				this.addSlotToContainer(new Slot(playerinventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
			}
		}

		for (i = 0; i < 9; ++i) {
			this.addSlotToContainer(new Slot(playerinventory, i, 8 + i * 18, 142));
		}
	}

	public void addSlotListener(ICrafting icrafting) {
		super.addSlotListener(icrafting);
		icrafting.setContainerData(this, 0, this.brewingStand.getBrewTime());
	}

	/**
	 * Looks for changes made in the container, sends them to every listener.
	 */
	public void detectAndSendChanges() {
		super.detectAndSendChanges();

		for (int var1 = 0; var1 < this.listeners.size(); ++var1) {
			ICrafting var2 = (ICrafting) this.listeners.get(var1);

			if (this.brewTime != this.brewingStand.getBrewTime()) {
				var2.setContainerData(this, 0, this.brewingStand.getBrewTime());
			}
		}

		this.brewTime = this.brewingStand.getBrewTime();
	}

	public boolean a(EntityHuman entityhuman) {
		return !this.checkReachable ? true : this.brewingStand.a(entityhuman);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if ((i < 0 || i > 2) && i != 3) {
				if (!this.theSlot.getHasStack() && this.theSlot.isAllowed(itemstack1)) {
					if (!this.mergeItemStack(itemstack1, 3, 4, false)) {
						return null;
					}
				} else if (SlotPotionBottle.b_(itemstack)) {
					if (!this.mergeItemStack(itemstack1, 0, 3, false)) {
						return null;
					}
				} else if (i >= 4 && i < 31) {
					if (!this.mergeItemStack(itemstack1, 31, 40, false)) {
						return null;
					}
				} else if (i >= 31 && i < 40) {
					if (!this.mergeItemStack(itemstack1, 4, 31, false)) {
						return null;
					}
				} else if (!this.mergeItemStack(itemstack1, 4, 40, false)) {
					return null;
				}
			} else {
				if (!this.mergeItemStack(itemstack1, 4, 40, true)) {
					return null;
				}

				slot.onSlotChange(itemstack1, itemstack);
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			CraftInventoryBrewer inventory = new CraftInventoryBrewer(this.brewingStand);
			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(), inventory, this);
			return this.bukkitEntity;
		}
	}
}
