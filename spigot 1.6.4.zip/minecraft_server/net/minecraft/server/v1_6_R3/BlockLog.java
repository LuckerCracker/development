package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockLog extends BlockRotatable
{
    /** The type of tree this log came from. */
    public static final String[] woodType = new String[] {"oak", "spruce", "birch", "jungle"};

    protected BlockLog(int par1)
    {
        super(par1, Material.WOOD);
        this.a(CreativeModeTab.b);
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 1;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Block.LOG.id;
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        byte var7 = 4;
        int var8 = var7 + 1;

        if (var1.checkChunksExist(var2 - var8, var3 - var8, var4 - var8, var2 + var8, var3 + var8, var4 + var8))
        {
            for (int var9 = -var7; var9 <= var7; ++var9)
            {
                for (int var10 = -var7; var10 <= var7; ++var10)
                {
                    for (int var11 = -var7; var11 <= var7; ++var11)
                    {
                        int var12 = var1.getTypeId(var2 + var9, var3 + var10, var4 + var11);

                        if (var12 == Block.LEAVES.id)
                        {
                            int var13 = var1.getData(var2 + var9, var3 + var10, var4 + var11);

                            if ((var13 & 8) == 0)
                            {
                                var1.setData(var2 + var9, var3 + var10, var4 + var11, var13 | 8, 4);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * returns a number between 0 and 3
     */
    public static int limitToValidMetadata(int par0)
    {
        return par0 & 3;
    }
}
