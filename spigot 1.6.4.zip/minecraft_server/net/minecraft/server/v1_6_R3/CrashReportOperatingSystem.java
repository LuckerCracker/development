package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportOperatingSystem implements Callable
{
    final CrashReport a;

    CrashReportOperatingSystem(CrashReport var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ") version " + System.getProperty("os.version");
    }

    public Object call()
    {
        return this.a();
    }
}
