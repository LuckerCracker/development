package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.entity.EntityTargetEvent;

public class EntityPigZombie extends EntityZombie {
	private static final UUID field_110189_bq = UUID.fromString("49455A49-7EC5-45BA-B886-3B90B23A1718");
	private static final AttributeModifier field_110190_br = (new AttributeModifier(field_110189_bq,
			"Attacking speed boost", 0.45D, 0)).setSaved(false);
	public int angerLevel;
	private int soundDelay;
	private Entity field_110191_bu;

	public EntityPigZombie(World par1World) {
		super(par1World);
		this.fireProof = true;
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(field_110186_bp).setValue(0.0D);
		this.getAttributeInstance(GenericAttributes.d).setValue(0.5D);
		this.getAttributeInstance(GenericAttributes.e).setValue(5.0D);
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	protected boolean isAIEnabled() {
		return false;
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		if (this.field_110191_bu != this.target && !this.world.isStatic) {
			AttributeInstance var1 = this.getAttributeInstance(GenericAttributes.d);
			var1.removeModifier(field_110190_br);

			if (this.target != null) {
				var1.applyModifier(field_110190_br);
			}
		}

		this.field_110191_bu = this.target;

		if (this.soundDelay > 0 && --this.soundDelay == 0) {
			this.makeSound("mob.zombiepig.zpigangry", this.getSoundVolume() * 2.0F,
					((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) * 1.8F);
		}

		super.onUpdate();
	}

	public boolean canSpawn() {
		return this.world.difficulty > 0 && this.world.checkNoEntityCollision(this.boundingBox)
				&& this.world.getCubes(this, this.boundingBox).isEmpty()
				&& !this.world.containsLiquid(this.boundingBox);
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setShort("Anger", (short) this.angerLevel);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.angerLevel = par1NBTTagCompound.getShort("Anger");
	}

	protected Entity findTarget() {
		return this.angerLevel == 0 ? null : super.findTarget();
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else {
			Entity entity = damagesource.getEntity();

			if (entity instanceof EntityHuman) {
				List list = this.world.getEntities(this, this.boundingBox.grow(32.0D, 32.0D, 32.0D));

				for (int i = 0; i < list.size(); ++i) {
					Entity entity1 = (Entity) list.get(i);

					if (entity1 instanceof EntityPigZombie) {
						EntityPigZombie entitypigzombie = (EntityPigZombie) entity1;
						entitypigzombie.becomeAngryAt(entity);
					}
				}

				this.becomeAngryAt(entity);
			}

			return super.attackEntityFrom(damagesource, f);
		}
	}

	/**
	 * Causes this PigZombie to become angry at the supplied Entity (which will
	 * be a player).
	 */
	private void becomeAngryAt(Entity par1Entity) {
		CraftEntity var2 = par1Entity == null ? null : par1Entity.getBukkitEntity();
		EntityTargetEvent var3 = new EntityTargetEvent(this.getBukkitEntity(), var2,
				EntityTargetEvent.TargetReason.PIG_ZOMBIE_TARGET);
		this.world.getServer().getPluginManager().callEvent(var3);

		if (!var3.isCancelled()) {
			if (var3.getTarget() == null) {
				this.target = null;
			} else {
				par1Entity = ((CraftEntity) var3.getTarget()).getHandle();
				this.target = par1Entity;
				this.angerLevel = 400 + this.random.nextInt(400);
				this.soundDelay = this.random.nextInt(40);
			}
		}
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return "mob.zombiepig.zpig";
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.zombiepig.zpighurt";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.zombiepig.zpigdeath";
	}

	protected void dropDeathLoot(boolean flag, int i) {
		ArrayList loot = new ArrayList();
		int j = this.random.nextInt(2 + i);

		if (j > 0) {
			loot.add(CraftItemStack.asNewCraftStack(Item.ROTTEN_FLESH, j));
		}

		j = this.random.nextInt(2 + i);

		if (j > 0) {
			loot.add(CraftItemStack.asNewCraftStack(Item.GOLD_NUGGET, j));
		}

		if (this.lastDamageByPlayerTime > 0) {
			int k = this.random.nextInt(200) - i;

			if (k < 5) {
				ItemStack itemstack = this.l(k <= 0 ? 1 : 0);

				if (itemstack != null) {
					loot.add(CraftItemStack.asCraftMirror(itemstack));
				}
			}
		}

		CraftEventFactory.callEntityDeathEvent(this, loot);
	}

	public boolean a(EntityHuman entityhuman) {
		return false;
	}

	protected ItemStack l(int i) {
		return new ItemStack(Item.GOLD_INGOT.id, 1, 0);
	}

	protected int getLootId() {
		return Item.ROTTEN_FLESH.id;
	}

	/**
	 * Makes entity wear random armor based on difficulty
	 */
	protected void addRandomArmor() {
		this.setEquipment(0, new ItemStack(Item.GOLD_SWORD));
	}

	public GroupDataEntity a(GroupDataEntity groupdataentity) {
		super.a(groupdataentity);
		this.setVillager(false);
		return groupdataentity;
	}
}
