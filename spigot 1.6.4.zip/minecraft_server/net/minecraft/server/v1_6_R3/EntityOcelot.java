package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntityOcelot extends EntityTameableAnimal {
	/**
	 * The tempt AI task for this mob, used to prevent taming while it is
	 * fleeing.
	 */
	private PathfinderGoalTempt aiTempt;

	public EntityOcelot(World par1World) {
		super(par1World);
		this.setSize(0.6F, 0.8F);
		this.getNavigation().a(true);
		this.goalSelector.a(1, new PathfinderGoalFloat(this));
		this.goalSelector.a(2, this.inLove);
		this.goalSelector.a(3, this.aiTempt = new PathfinderGoalTempt(this, 0.6D, Item.RAW_FISH.id, true));
		this.goalSelector.a(4, new PathfinderGoalAvoidPlayer(this, EntityHuman.class, 16.0F, 0.8D, 1.33D));
		this.goalSelector.a(5, new PathfinderGoalFollowOwner(this, 1.0D, 10.0F, 5.0F));
		this.goalSelector.a(6, new PathfinderGoalJumpOnBlock(this, 1.33D));
		this.goalSelector.a(7, new PathfinderGoalLeapAtTarget(this, 0.3F));
		this.goalSelector.a(8, new PathfinderGoalOcelotAttack(this));
		this.goalSelector.a(9, new PathfinderGoalBreed(this, 0.8D));
		this.goalSelector.a(10, new PathfinderGoalRandomStroll(this, 0.8D));
		this.goalSelector.a(11, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 10.0F));
		this.targetSelector.a(1, new PathfinderGoalRandomTargetNonTamed(this, EntityChicken.class, 750, false));
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(18, Byte.valueOf((byte) 0));
	}

	/**
	 * main AI tick function, replaces updateEntityActionState
	 */
	public void updateAITick() {
		if (this.getControllerMove().a()) {
			double var1 = this.getControllerMove().b();

			if (var1 == 0.6D) {
				this.setSneaking(true);
				this.setSprinting(false);
			} else if (var1 == 1.33D) {
				this.setSneaking(false);
				this.setSprinting(true);
			} else {
				this.setSneaking(false);
				this.setSprinting(false);
			}
		} else {
			this.setSneaking(false);
			this.setSprinting(false);
		}
	}

	protected boolean isTypeNotPersistent() {
		return !this.isTamed();
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	public boolean isAIEnabled() {
		return true;
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.a).setValue(10.0D);
		this.getAttributeInstance(GenericAttributes.d).setValue(0.30000001192092896D);
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float par1) {
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setInt("CatType", this.getCatType());
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.setCatType(par1NBTTagCompound.getInt("CatType"));
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return this.isTamed() ? (this.isInLove() ? "mob.cat.purr"
				: (this.random.nextInt(4) == 0 ? "mob.cat.purreow" : "mob.cat.meow")) : "";
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.cat.hitt";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.cat.hitt";
	}

	/**
	 * Returns the volume for the sounds this mob makes.
	 */
	protected float getSoundVolume() {
		return 0.4F;
	}

	protected int getLootId() {
		return Item.LEATHER.id;
	}

	public boolean attackEntityAsMob(Entity par1Entity) {
		return par1Entity.attackEntityFrom(DamageSource.mobAttack(this), 3.0F);
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else {
			this.inLove.setSitting(false);
			return super.attackEntityFrom(damagesource, f);
		}
	}

	protected void dropDeathLoot(boolean flag, int i) {
		CraftEventFactory.callEntityDeathEvent(this);
	}

	public boolean a(EntityHuman entityhuman) {
		ItemStack itemstack = entityhuman.inventory.getItemInHand();

		if (this.isTamed()) {
			if (entityhuman.getName().equalsIgnoreCase(this.getOwnerName()) && !this.world.isStatic
					&& !this.isBreedingItem(itemstack)) {
				this.inLove.setSitting(!this.isSitting());
			}
		} else if (this.aiTempt.f() && itemstack != null && itemstack.id == Item.RAW_FISH.id
				&& entityhuman.getDistanceSqToEntity(this) < 9.0D) {
			if (!entityhuman.abilities.canInstantlyBuild) {
				--itemstack.count;
			}

			if (itemstack.count <= 0) {
				entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack) null);
			}

			if (!this.world.isStatic) {
				if (this.random.nextInt(3) == 0
						&& !CraftEventFactory.callEntityTameEvent(this, entityhuman).isCancelled()) {
					this.setTamed(true);
					this.setCatType(1 + this.world.random.nextInt(3));
					this.setOwnerName(entityhuman.getName());
					this.i(true);
					this.inLove.setSitting(true);
					this.world.broadcastEntityEffect(this, (byte) 7);
				} else {
					this.i(false);
					this.world.broadcastEntityEffect(this, (byte) 6);
				}
			}

			return true;
		}

		return super.a(entityhuman);
	}

	/**
	 * This function is used when two same-species animals in 'love mode' breed
	 * to generate the new baby animal.
	 */
	public EntityOcelot spawnBabyAnimal(EntityAgeable par1EntityAgeable) {
		EntityOcelot var2 = new EntityOcelot(this.world);

		if (this.isTamed()) {
			var2.setOwnerName(this.getOwnerName());
			var2.setTamed(true);
			var2.setCatType(this.getCatType());
		}

		return var2;
	}

	/**
	 * Checks if the parameter is an item which this animal can be fed to breed
	 * it (wheat, carrots or seeds depending on the animal type)
	 */
	public boolean isBreedingItem(ItemStack par1ItemStack) {
		return par1ItemStack != null && par1ItemStack.id == Item.RAW_FISH.id;
	}

	public boolean mate(EntityAnimal entityanimal) {
		if (entityanimal == this) {
			return false;
		} else if (!this.isTamed()) {
			return false;
		} else if (!(entityanimal instanceof EntityOcelot)) {
			return false;
		} else {
			EntityOcelot entityocelot = (EntityOcelot) entityanimal;
			return !entityocelot.isTamed() ? false : this.isInLove() && entityocelot.isInLove();
		}
	}

	public int getCatType() {
		return this.datawatcher.getByte(18);
	}

	public void setCatType(int i) {
		this.datawatcher.watch(18, Byte.valueOf((byte) i));
	}

	public boolean canSpawn() {
		if (this.world.random.nextInt(3) == 0) {
			return false;
		} else {
			if (this.world.checkNoEntityCollision(this.boundingBox)
					&& this.world.getCubes(this, this.boundingBox).isEmpty()
					&& !this.world.containsLiquid(this.boundingBox)) {
				int i = MathHelper.floor(this.locX);
				int j = MathHelper.floor(this.boundingBox.minY);
				int k = MathHelper.floor(this.locZ);

				if (j < 63) {
					return false;
				}

				int l = this.world.getTypeId(i, j - 1, k);

				if (l == Block.GRASS.id || l == Block.LEAVES.id) {
					return true;
				}
			}

			return false;
		}
	}

	public String getLocalizedName() {
		return this.hasCustomName() ? this.getCustomName()
				: (this.isTamed() ? "entity.Cat.name" : super.getLocalizedName());
	}

	public GroupDataEntity a(GroupDataEntity groupdataentity) {
		groupdataentity = super.a(groupdataentity);

		if (this.world.random.nextInt(7) == 0) {
			for (int i = 0; i < 2; ++i) {
				EntityOcelot entityocelot = new EntityOcelot(this.world);
				entityocelot.setPositionRotation(this.locX, this.locY, this.locZ, this.yaw, 0.0F);
				entityocelot.setAge(-24000);
				this.world.addEntity(entityocelot);
			}
		}

		return groupdataentity;
	}

	public EntityAgeable createChild(EntityAgeable entityageable) {
		return this.spawnBabyAnimal(entityageable);
	}
}
