package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class BlockCauldron extends Block
{
    public BlockCauldron(int par1)
    {
        super(par1, Material.ORE);
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World par1World, int par2, int par3, int par4, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity)
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.3125F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        float var8 = 0.125F;
        this.setBlockBounds(0.0F, 0.0F, 0.0F, var8, 1.0F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var8);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBounds(1.0F - var8, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBounds(0.0F, 0.0F, 1.0F - var8, 1.0F, 1.0F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBoundsForItemRender();
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 24;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            ItemStack var10 = var5.inventory.getItemInHand();

            if (var10 == null)
            {
                return true;
            }
            else
            {
                int var11 = var1.getData(var2, var3, var4);
                int var12 = func_111045_h_(var11);

                if (var10.id == Item.WATER_BUCKET.id)
                {
                    if (var12 < 3)
                    {
                        if (!var5.abilities.canInstantlyBuild)
                        {
                            var5.inventory.setItem(var5.inventory.itemInHandIndex, new ItemStack(Item.BUCKET));
                        }

                        var1.setData(var2, var3, var4, 3, 2);
                        var1.func_96440_m(var2, var3, var4, this.id);
                    }

                    return true;
                }
                else
                {
                    if (var10.id == Item.GLASS_BOTTLE.id)
                    {
                        if (var12 > 0)
                        {
                            ItemStack var13 = new ItemStack(Item.POTION, 1, 0);

                            if (!var5.inventory.pickup(var13))
                            {
                                var1.addEntity(new EntityItem(var1, (double)var2 + 0.5D, (double)var3 + 1.5D, (double)var4 + 0.5D, var13));
                            }
                            else if (var5 instanceof EntityPlayer)
                            {
                                ((EntityPlayer)var5).updateInventory(var5.defaultContainer);
                            }

                            --var10.count;

                            if (var10.count <= 0)
                            {
                                var5.inventory.setItem(var5.inventory.itemInHandIndex, (ItemStack)null);
                            }

                            var1.setData(var2, var3, var4, var12 - 1, 2);
                            var1.func_96440_m(var2, var3, var4, this.id);
                        }
                    }
                    else if (var12 > 0 && var10.getItem() instanceof ItemArmor && ((ItemArmor)var10.getItem()).getArmorMaterial() == EnumArmorMaterial.CLOTH)
                    {
                        ItemArmor var14 = (ItemArmor)var10.getItem();
                        var14.removeColor(var10);
                        var1.setData(var2, var3, var4, var12 - 1, 2);
                        var1.func_96440_m(var2, var3, var4, this.id);
                        return true;
                    }

                    return true;
                }
            }
        }
    }

    /**
     * currently only used by BlockCauldron to incrament meta-data during rain
     */
    public void fillWithRain(World par1World, int par2, int par3, int par4)
    {
        if (par1World.random.nextInt(20) == 1)
        {
            int var5 = par1World.getData(par2, par3, par4);

            if (var5 < 3)
            {
                par1World.setData(par2, par3, par4, var5 + 1, 2);
            }
        }
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Item.CAULDRON.id;
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        int var6 = par1World.getData(par2, par3, par4);
        return func_111045_h_(var6);
    }

    public static int func_111045_h_(int par0)
    {
        return par0;
    }
}
