package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandDifficulty extends CommandAbstract
{
    private static final String[] difficulties = new String[] {"options.difficulty.peaceful", "options.difficulty.easy", "options.difficulty.normal", "options.difficulty.hard"};

    public String getCommandName()
    {
        return "difficulty";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.difficulty.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length > 0)
        {
            int var3 = this.f(var1, var2[0]);
            MinecraftServer.getServer().c(var3);
            a(var1, "commands.difficulty.success", new Object[] {ChatMessage.e(difficulties[var3])});
        }
        else
        {
            throw new ExceptionUsage("commands.difficulty.usage", new Object[0]);
        }
    }

    protected int f(ICommandListener var1, String var2)
    {
        return !var2.equalsIgnoreCase("peaceful") && !var2.equalsIgnoreCase("p") ? (!var2.equalsIgnoreCase("easy") && !var2.equalsIgnoreCase("e") ? (!var2.equalsIgnoreCase("normal") && !var2.equalsIgnoreCase("n") ? (!var2.equalsIgnoreCase("hard") && !var2.equalsIgnoreCase("h") ? a(var1, var2, 0, 3) : 3) : 2) : 1) : 0;
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, new String[] {"peaceful", "easy", "normal", "hard"}): null;
    }
}
