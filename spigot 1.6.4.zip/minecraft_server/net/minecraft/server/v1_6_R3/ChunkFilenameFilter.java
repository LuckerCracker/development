package net.minecraft.server.v1_6_R3;

import java.io.File;
import java.io.FilenameFilter;

class ChunkFilenameFilter implements FilenameFilter
{
    final WorldLoaderServer a;

    ChunkFilenameFilter(WorldLoaderServer var1)
    {
        this.a = var1;
    }

    public boolean accept(File var1, String var2)
    {
        return var2.endsWith(".mcr");
    }
}
