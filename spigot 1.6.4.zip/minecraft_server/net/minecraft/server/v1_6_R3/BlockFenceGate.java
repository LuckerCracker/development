package net.minecraft.server.v1_6_R3;

public class BlockFenceGate extends BlockDirectional
{
    public BlockFenceGate(int par1)
    {
        super(par1, Material.WOOD);
        this.a(CreativeModeTab.d);
    }

    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        return !var1.getMaterial(var2, var3 - 1, var4).isBuildable() ? false : super.canPlace(var1, var2, var3, var4);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4);
        return isFenceGateOpen(var5) ? null : (var5 != 2 && var5 != 0 ? AxisAlignedBB.getAABBPool().getAABB((double)((float)par2 + 0.375F), (double)par3, (double)par4, (double)((float)par2 + 0.625F), (double)((float)par3 + 1.5F), (double)(par4 + 1)) : AxisAlignedBB.getAABBPool().getAABB((double)par2, (double)par3, (double)((float)par4 + 0.375F), (double)(par2 + 1), (double)((float)par3 + 1.5F), (double)((float)par4 + 0.625F)));
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        int var5 = getDirection(var1.getData(var2, var3, var4));

        if (var5 != 2 && var5 != 0)
        {
            this.setBlockBounds(0.375F, 0.0F, 0.0F, 0.625F, 1.0F, 1.0F);
        }
        else
        {
            this.setBlockBounds(0.0F, 0.0F, 0.375F, 1.0F, 1.0F, 0.625F);
        }
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public boolean getBlocksMovement(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return isFenceGateOpen(par1IBlockAccess.getData(par2, par3, par4));
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 21;
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        int var7 = (MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3) % 4;
        var1.setData(var2, var3, var4, var7, 2);
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        int var10 = var1.getData(var2, var3, var4);

        if (isFenceGateOpen(var10))
        {
            var1.setData(var2, var3, var4, var10 & -5, 2);
        }
        else
        {
            int var11 = (MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3) % 4;
            int var12 = getDirection(var10);

            if (var12 == (var11 + 2) % 4)
            {
                var10 = var11;
            }

            var1.setData(var2, var3, var4, var10 | 4, 2);
        }

        var1.a(var5, 1003, var2, var3, var4, 0);
        return true;
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        if (!var1.isStatic)
        {
            int var6 = var1.getData(var2, var3, var4);
            boolean var7 = var1.isBlockIndirectlyPowered(var2, var3, var4);

            if (var7 || var5 > 0 && Block.byId[var5].isPowerSource())
            {
                if (var7 && !isFenceGateOpen(var6))
                {
                    var1.setData(var2, var3, var4, var6 | 4, 2);
                    var1.a((EntityHuman)null, 1003, var2, var3, var4, 0);
                }
                else if (!var7 && isFenceGateOpen(var6))
                {
                    var1.setData(var2, var3, var4, var6 & -5, 2);
                    var1.a((EntityHuman)null, 1003, var2, var3, var4, 0);
                }
            }
        }
    }

    /**
     * Returns if the fence gate is open according to its metadata.
     */
    public static boolean isFenceGateOpen(int par0)
    {
        return (par0 & 4) != 0;
    }
}
