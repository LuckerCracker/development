package net.minecraft.server.v1_6_R3;

import java.util.HashSet;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.event.entity.EntityPortalEnterEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.event.world.PortalCreateEvent$CreateReason;

public class BlockPortal extends BlockHalfTransparant
{
    public BlockPortal(int par1)
    {
        super(par1, "portal", Material.PORTAL, false);
        this.setTickRandomly(true);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        super.updateTick(par1World, par2, par3, par4, par5Random);

        if (par1World.worldProvider.isSurfaceWorld() && par5Random.nextInt(2000) < par1World.difficulty)
        {
            int var6;

            for (var6 = par3; !par1World.doesBlockHaveSolidTopSurface(par2, var6, par4) && var6 > 0; --var6)
            {
                ;
            }

            if (var6 > 0 && !par1World.isBlockNormalCube(par2, var6 + 1, par4))
            {
                Entity var7 = ItemMonsterEgg.a(par1World, 57, (double)par2 + 0.5D, (double)var6 + 1.1D, (double)par4 + 0.5D);

                if (var7 != null)
                {
                    var7.portalCooldown = var7.getPortalCooldown();
                }
            }
        }
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return null;
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        float f;
        float f1;

        if (iblockaccess.getTypeId(i - 1, j, k) != this.id && iblockaccess.getTypeId(i + 1, j, k) != this.id)
        {
            f = 0.125F;
            f1 = 0.5F;
            this.setBlockBounds(0.5F - f, 0.0F, 0.5F - f1, 0.5F + f, 1.0F, 0.5F + f1);
        }
        else
        {
            f = 0.5F;
            f1 = 0.125F;
            this.setBlockBounds(0.5F - f, 0.0F, 0.5F - f1, 0.5F + f, 1.0F, 0.5F + f1);
        }
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Checks to see if this location is valid to create a portal and will return True if it does. Args: world, x, y, z
     */
    public boolean tryToCreatePortal(World par1World, int par2, int par3, int par4)
    {
        byte var5 = 0;
        byte var6 = 0;

        if (par1World.getTypeId(par2 - 1, par3, par4) == Block.OBSIDIAN.id || par1World.getTypeId(par2 + 1, par3, par4) == Block.OBSIDIAN.id)
        {
            var5 = 1;
        }

        if (par1World.getTypeId(par2, par3, par4 - 1) == Block.OBSIDIAN.id || par1World.getTypeId(par2, par3, par4 + 1) == Block.OBSIDIAN.id)
        {
            var6 = 1;
        }

        if (var5 == var6)
        {
            return false;
        }
        else
        {
            HashSet var7 = new HashSet();
            CraftWorld var8 = par1World.getWorld();

            if (par1World.getTypeId(par2 - var5, par3, par4 - var6) == 0)
            {
                par2 -= var5;
                par4 -= var6;
            }

            int var9;
            int var10;

            for (var9 = -1; var9 <= 2; ++var9)
            {
                for (var10 = -1; var10 <= 3; ++var10)
                {
                    boolean var11 = var9 == -1 || var9 == 2 || var10 == -1 || var10 == 3;

                    if (var9 != -1 && var9 != 2 || var10 != -1 && var10 != 3)
                    {
                        int var12 = par1World.getTypeId(par2 + var5 * var9, par3 + var10, par4 + var6 * var9);

                        if (var11)
                        {
                            if (var12 != Block.OBSIDIAN.id)
                            {
                                return false;
                            }

                            var7.add(var8.getBlockAt(par2 + var5 * var9, par3 + var10, par4 + var6 * var9));
                        }
                        else if (var12 != 0 && var12 != Block.FIRE.id)
                        {
                            return false;
                        }
                    }
                }
            }

            for (var9 = 0; var9 < 2; ++var9)
            {
                for (var10 = 0; var10 < 3; ++var10)
                {
                    var7.add(var8.getBlockAt(par2 + var5 * var9, par3 + var10, par4 + var6 * var9));
                }
            }

            PortalCreateEvent var13 = new PortalCreateEvent(var7, var8, PortalCreateEvent$CreateReason.FIRE);
            par1World.getServer().getPluginManager().callEvent(var13);

            if (var13.isCancelled())
            {
                return false;
            }
            else
            {
                for (var9 = 0; var9 < 2; ++var9)
                {
                    for (var10 = 0; var10 < 3; ++var10)
                    {
                        par1World.setTypeIdAndData(par2 + var5 * var9, par3 + var10, par4 + var6 * var9, Block.PORTAL.id, 0, 2);
                    }
                }

                return true;
            }
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        byte b0 = 0;
        byte b1 = 1;

        if (world.getTypeId(i - 1, j, k) == this.id || world.getTypeId(i + 1, j, k) == this.id)
        {
            b0 = 1;
            b1 = 0;
        }

        int i1;

        for (i1 = j; world.getTypeId(i, i1 - 1, k) == this.id; --i1)
        {
            ;
        }

        if (world.getTypeId(i, i1 - 1, k) != Block.OBSIDIAN.id)
        {
            world.setAir(i, j, k);
        }
        else
        {
            int j1;

            for (j1 = 1; j1 < 4 && world.getTypeId(i, i1 + j1, k) == this.id; ++j1)
            {
                ;
            }

            if (j1 == 3 && world.getTypeId(i, i1 + j1, k) == Block.OBSIDIAN.id)
            {
                boolean flag = world.getTypeId(i - 1, j, k) == this.id || world.getTypeId(i + 1, j, k) == this.id;
                boolean flag1 = world.getTypeId(i, j, k - 1) == this.id || world.getTypeId(i, j, k + 1) == this.id;

                if (flag && flag1)
                {
                    world.setAir(i, j, k);
                }
                else if ((world.getTypeId(i + b0, j, k + b1) != Block.OBSIDIAN.id || world.getTypeId(i - b0, j, k - b1) != this.id) && (world.getTypeId(i - b0, j, k - b1) != Block.OBSIDIAN.id || world.getTypeId(i + b0, j, k + b1) != this.id))
                {
                    world.setAir(i, j, k);
                }
            }
            else
            {
                world.setAir(i, j, k);
            }
        }
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 0;
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void onEntityCollidedWithBlock(World par1World, int par2, int par3, int par4, Entity par5Entity)
    {
        if (par5Entity.vehicle == null && par5Entity.passenger == null)
        {
            EntityPortalEnterEvent var6 = new EntityPortalEnterEvent(par5Entity.getBukkitEntity(), new Location(par1World.getWorld(), (double)par2, (double)par3, (double)par4));
            par1World.getServer().getPluginManager().callEvent(var6);
            par5Entity.setInPortal();
        }
    }
}
