package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityTargetEvent;

public class EntitySpider extends EntityMonster {
	public EntitySpider(World par1World) {
		super(par1World);
		this.setSize(1.4F, 0.9F);
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(16, new Byte((byte) 0));
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		super.onUpdate();

		if (!this.world.isStatic) {
			this.setBesideClimbableBlock(this.positionChanged);
		}
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.a).setValue(16.0D);
		this.getAttributeInstance(GenericAttributes.d).setValue(0.800000011920929D);
	}

	protected Entity findTarget() {
		float f = this.getBrightness(1.0F);

		if (f < 0.5F) {
			double d0 = 16.0D;
			return this.world.findNearbyVulnerablePlayer(this, d0);
		} else {
			return null;
		}
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return "mob.spider.say";
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.spider.say";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.spider.death";
	}

	/**
	 * Plays step sound at given x, y, z for the entity
	 */
	protected void playStepSound(int par1, int par2, int par3, int par4) {
		this.makeSound("mob.spider.step", 0.15F, 1.0F);
	}

	/**
	 * Basic mob attack. Default to touch of death in EntityCreature. Overridden
	 * by each mob to define their attack.
	 */
	protected void attackEntity(Entity par1Entity, float par2) {
		float var3 = this.getBrightness(1.0F);

		if (var3 > 0.5F && this.random.nextInt(100) == 0) {
			EntityTargetEvent var4 = new EntityTargetEvent(this.getBukkitEntity(), (org.bukkit.entity.Entity) null,
					EntityTargetEvent.TargetReason.FORGOT_TARGET);
			this.world.getServer().getPluginManager().callEvent(var4);

			if (!var4.isCancelled()) {
				if (var4.getTarget() == null) {
					this.target = null;
				} else {
					this.target = ((CraftEntity) var4.getTarget()).getHandle();
				}

				return;
			}
		} else if (par2 > 2.0F && par2 < 6.0F && this.random.nextInt(10) == 0) {
			if (this.onGround) {
				double var5 = par1Entity.locX - this.locX;
				double var7 = par1Entity.locZ - this.locZ;
				float var9 = MathHelper.sqrt(var5 * var5 + var7 * var7);
				this.motX = var5 / (double) var9 * 0.5D * 0.800000011920929D + this.motX * 0.20000000298023224D;
				this.motZ = var7 / (double) var9 * 0.5D * 0.800000011920929D + this.motZ * 0.20000000298023224D;
				this.motY = 0.4000000059604645D;
			}
		} else {
			super.attackEntity(par1Entity, par2);
		}
	}

	protected int getLootId() {
		return Item.STRING.id;
	}

	protected void dropDeathLoot(boolean flag, int i) {
		ArrayList loot = new ArrayList();
		int k = this.random.nextInt(3);

		if (i > 0) {
			k += this.random.nextInt(i + 1);
		}

		if (k > 0) {
			loot.add(new org.bukkit.inventory.ItemStack(Item.STRING.id, k));
		}

		if (flag && (this.random.nextInt(3) == 0 || this.random.nextInt(1 + i) > 0)) {
			loot.add(new org.bukkit.inventory.ItemStack(Item.SPIDER_EYE.id, 1));
		}

		CraftEventFactory.callEntityDeathEvent(this, loot);
	}

	/**
	 * returns true if this entity is by a ladder, false otherwise
	 */
	public boolean isOnLadder() {
		return this.isBesideClimbableBlock();
	}

	/**
	 * Sets the Entity inside a web block.
	 */
	public void setInWeb() {
	}

	public EnumMonsterType getMonsterType() {
		return EnumMonsterType.ARTHROPOD;
	}

	public boolean isPotionApplicable(MobEffect mobeffect) {
		return mobeffect.getEffectId() == MobEffectList.POISON.id ? false : super.isPotionApplicable(mobeffect);
	}

	/**
	 * Returns true if the WatchableObject (Byte) is 0x01 otherwise returns
	 * false. The WatchableObject is updated using setBesideClimableBlock.
	 */
	public boolean isBesideClimbableBlock() {
		return (this.datawatcher.getByte(16) & 1) != 0;
	}

	/**
	 * Updates the WatchableObject (Byte) created in entityInit(), setting it to
	 * 0x01 if par1 is true or 0x00 if it is false.
	 */
	public void setBesideClimbableBlock(boolean par1) {
		byte var2 = this.datawatcher.getByte(16);

		if (par1) {
			var2 = (byte) (var2 | 1);
		} else {
			var2 &= -2;
		}

		this.datawatcher.watch(16, Byte.valueOf(var2));
	}

	public GroupDataEntity a(GroupDataEntity groupdataentity) {
		Object object = super.a(groupdataentity);

		if (this.world.random.nextInt(100) == 0) {
			EntitySkeleton i = new EntitySkeleton(this.world);
			i.setPositionRotation(this.locX, this.locY, this.locZ, this.yaw, 0.0F);
			i.a((GroupDataEntity) null);
			this.world.addEntity(i);
			i.mount(this);
		}

		if (object == null) {
			object = new GroupDataSpider();

			if (this.world.difficulty > 2 && this.world.random.nextFloat() < 0.1F
					* this.world.getLocationTensionFactor(this.locX, this.locY, this.locZ)) {
				((GroupDataSpider) object).a(this.world.random);
			}
		}

		if (object instanceof GroupDataSpider) {
			int i1 = ((GroupDataSpider) object).a;

			if (i1 > 0 && MobEffectList.byId[i1] != null) {
				this.addEffect(new MobEffect(i1, Integer.MAX_VALUE));
			}
		}

		return (GroupDataEntity) object;
	}
}
