package net.minecraft.server.v1_6_R3;

public class EnchantmentInstance extends WeightedRandomChoice
{
    public final Enchantment enchantment;
    public final int level;

    public EnchantmentInstance(Enchantment var1, int var2)
    {
        super(var1.getRandomWeight());
        this.enchantment = var1;
        this.level = var2;
    }

    public EnchantmentInstance(int var1, int var2)
    {
        this(Enchantment.byId[var1], var2);
    }
}
