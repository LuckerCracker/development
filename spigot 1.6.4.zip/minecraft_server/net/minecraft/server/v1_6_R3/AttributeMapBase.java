package net.minecraft.server.v1_6_R3;

import com.google.common.collect.Multimap;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public abstract class AttributeMapBase
{
    protected final Map a = new HashMap();
    protected final Map b = new InsensitiveStringMap();

    public AttributeInstance a(IAttribute var1)
    {
        return (AttributeInstance)this.a.get(var1);
    }

    public AttributeInstance a(String var1)
    {
        return (AttributeInstance)this.b.get(var1);
    }

    public abstract AttributeInstance b(IAttribute var1);

    public Collection a()
    {
        return this.b.values();
    }

    public void a(AttributeModifiable var1) {}

    public void a(Multimap var1)
    {
        Iterator var2 = var1.entries().iterator();

        while (var2.hasNext())
        {
            Entry var3 = (Entry)var2.next();
            AttributeInstance var4 = this.a((String)var3.getKey());

            if (var4 != null)
            {
                var4.removeModifier((AttributeModifier)var3.getValue());
            }
        }
    }

    public void b(Multimap var1)
    {
        Iterator var2 = var1.entries().iterator();

        while (var2.hasNext())
        {
            Entry var3 = (Entry)var2.next();
            AttributeInstance var4 = this.a((String)var3.getKey());

            if (var4 != null)
            {
                var4.removeModifier((AttributeModifier)var3.getValue());
                var4.applyModifier((AttributeModifier)var3.getValue());
            }
        }
    }
}
