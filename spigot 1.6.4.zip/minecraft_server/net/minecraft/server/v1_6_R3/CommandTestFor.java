package net.minecraft.server.v1_6_R3;

public class CommandTestFor extends CommandAbstract
{
    public String getCommandName()
    {
        return "testfor";
    }

    public int a()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.testfor.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length != 1)
        {
            throw new ExceptionUsage("commands.testfor.usage", new Object[0]);
        }
        else if (!(var1 instanceof TileEntityCommand))
        {
            throw new CommandException("commands.testfor.failed", new Object[0]);
        }
        else
        {
            d(var1, var2[0]);
        }
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return var2 == 0;
    }
}
