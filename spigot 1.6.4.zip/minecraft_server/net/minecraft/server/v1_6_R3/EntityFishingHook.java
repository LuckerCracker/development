package net.minecraft.server.v1_6_R3;

import java.util.List;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Fish;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerFishEvent.State;

public class EntityFishingHook extends Entity
{
    private int fire = -1;
    private int firstUpdate = -1;
    private int entityRiderPitchDelta = -1;
    private int entityRiderYawDelta;
    private boolean invulnerable;
    public int a;
    public EntityHuman owner;
    private int entityUniqueID;
    private int j;
    private int au;
    public Entity hooked;
    private int av;
    private double aw;
    private double ax;
    private double ay;
    private double az;
    private double aA;

    public EntityFishingHook(World world)
    {
        super(world);
        this.setSize(0.25F, 0.25F);
        this.ignoreFrustumCheck = true;
    }

    public EntityFishingHook(World world, EntityHuman entityhuman)
    {
        super(world);
        this.ignoreFrustumCheck = true;
        this.owner = entityhuman;
        this.owner.hookedFish = this;
        this.setSize(0.25F, 0.25F);
        this.setPositionRotation(entityhuman.locX, entityhuman.locY + 1.62D - (double)entityhuman.height, entityhuman.locZ, entityhuman.yaw, entityhuman.pitch);
        this.locX -= (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.locY -= 0.10000000149011612D;
        this.locZ -= (double)(MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.height = 0.0F;
        float f = 0.4F;
        this.motX = (double)(-MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * f);
        this.motZ = (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * f);
        this.motY = (double)(-MathHelper.sin(this.pitch / 180.0F * (float)Math.PI) * f);
        this.c(this.motX, this.motY, this.motZ, 1.5F, 1.0F);
    }

    protected void entityInit() {}

    public void c(double d0, double d1, double d2, float f, float f1)
    {
        float f2 = MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= (double)f2;
        d1 /= (double)f2;
        d2 /= (double)f2;
        d0 += this.random.nextGaussian() * 0.007499999832361937D * (double)f1;
        d1 += this.random.nextGaussian() * 0.007499999832361937D * (double)f1;
        d2 += this.random.nextGaussian() * 0.007499999832361937D * (double)f1;
        d0 *= (double)f;
        d1 *= (double)f;
        d2 *= (double)f;
        this.motX = d0;
        this.motY = d1;
        this.motZ = d2;
        float f3 = MathHelper.sqrt(d0 * d0 + d2 * d2);
        this.lastYaw = this.yaw = (float)(Math.atan2(d0, d2) * 180.0D / Math.PI);
        this.lastPitch = this.pitch = (float)(Math.atan2(d1, (double)f3) * 180.0D / Math.PI);
        this.entityUniqueID = 0;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (this.av > 0)
        {
            double d0 = this.locX + (this.aw - this.locX) / (double)this.av;
            double d1 = this.locY + (this.ax - this.locY) / (double)this.av;
            double d2 = this.locZ + (this.ay - this.locZ) / (double)this.av;
            double d3 = MathHelper.wrapAngleTo180_double(this.az - (double)this.yaw);
            this.yaw = (float)((double)this.yaw + d3 / (double)this.av);
            this.pitch = (float)((double)this.pitch + (this.aA - (double)this.pitch) / (double)this.av);
            --this.av;
            this.setPosition(d0, d1, d2);
            this.setRotation(this.yaw, this.pitch);
        }
        else
        {
            if (!this.world.isStatic)
            {
                ItemStack vec3d = this.owner.getCurrentEquippedItem();

                if (this.owner.dead || !this.owner.isAlive() || vec3d == null || vec3d.getItem() != Item.FISHING_ROD || this.getDistanceSqToEntity(this.owner) > 1024.0D)
                {
                    this.die();
                    this.owner.hookedFish = null;
                    return;
                }

                if (this.hooked != null)
                {
                    if (!this.hooked.dead)
                    {
                        this.locX = this.hooked.locX;
                        this.locY = this.hooked.boundingBox.minY + (double)this.hooked.length * 0.8D;
                        this.locZ = this.hooked.locZ;
                        return;
                    }

                    this.hooked = null;
                }
            }

            if (this.a > 0)
            {
                --this.a;
            }

            if (this.invulnerable)
            {
                int var34 = this.world.getTypeId(this.fire, this.firstUpdate, this.entityRiderPitchDelta);

                if (var34 == this.entityRiderYawDelta)
                {
                    ++this.entityUniqueID;

                    if (this.entityUniqueID == 1200)
                    {
                        this.die();
                    }

                    return;
                }

                this.invulnerable = false;
                this.motX *= (double)(this.random.nextFloat() * 0.2F);
                this.motY *= (double)(this.random.nextFloat() * 0.2F);
                this.motZ *= (double)(this.random.nextFloat() * 0.2F);
                this.entityUniqueID = 0;
                this.j = 0;
            }
            else
            {
                ++this.j;
            }

            Vec3D var35 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
            Vec3D vec3d1 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
            MovingObjectPosition movingobjectposition = this.world.a(var35, vec3d1);
            var35 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
            vec3d1 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);

            if (movingobjectposition != null)
            {
                vec3d1 = this.world.getVec3DPool().create(movingobjectposition.pos.c, movingobjectposition.pos.d, movingobjectposition.pos.e);
            }

            Entity entity = null;
            List list = this.world.getEntities(this, this.boundingBox.addCoord(this.motX, this.motY, this.motZ).grow(1.0D, 1.0D, 1.0D));
            double d4 = 0.0D;
            double d5;

            for (int f1 = 0; f1 < list.size(); ++f1)
            {
                Entity f2 = (Entity)list.get(f1);

                if (f2.canBeCollidedWith() && (f2 != this.owner || this.j >= 5))
                {
                    float b0 = 0.3F;
                    AxisAlignedBB axisalignedbb = f2.boundingBox.grow((double)b0, (double)b0, (double)b0);
                    MovingObjectPosition movingobjectposition1 = axisalignedbb.a(var35, vec3d1);

                    if (movingobjectposition1 != null)
                    {
                        d5 = var35.distanceSquared(movingobjectposition1.pos);

                        if (d5 < d4 || d4 == 0.0D)
                        {
                            entity = f2;
                            d4 = d5;
                        }
                    }
                }
            }

            if (entity != null)
            {
                movingobjectposition = new MovingObjectPosition(entity);
            }

            if (movingobjectposition != null)
            {
                CraftEventFactory.callProjectileHitEvent(this);

                if (movingobjectposition.entity != null)
                {
                    if (movingobjectposition.entity.attackEntityFrom(DamageSource.projectile(this, this.owner), 0.0F))
                    {
                        this.hooked = movingobjectposition.entity;
                    }
                }
                else
                {
                    this.invulnerable = true;
                }
            }

            if (!this.invulnerable)
            {
                this.move(this.motX, this.motY, this.motZ);
                float var36 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
                this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);

                for (this.pitch = (float)(Math.atan2(this.motY, (double)var36) * 180.0D / Math.PI); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
                {
                    ;
                }

                while (this.pitch - this.lastPitch >= 180.0F)
                {
                    this.lastPitch += 360.0F;
                }

                while (this.yaw - this.lastYaw < -180.0F)
                {
                    this.lastYaw -= 360.0F;
                }

                while (this.yaw - this.lastYaw >= 180.0F)
                {
                    this.lastYaw += 360.0F;
                }

                this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
                this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
                float var37 = 0.92F;

                if (this.onGround || this.positionChanged)
                {
                    var37 = 0.5F;
                }

                byte var38 = 5;
                double d6 = 0.0D;

                for (int f3 = 0; f3 < var38; ++f3)
                {
                    double d7 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(f3 + 0) / (double)var38 - 0.125D + 0.125D;
                    double d8 = this.boundingBox.minY + (this.boundingBox.maxY - this.boundingBox.minY) * (double)(f3 + 1) / (double)var38 - 0.125D + 0.125D;
                    AxisAlignedBB axisalignedbb1 = AxisAlignedBB.getAABBPool().getAABB(this.boundingBox.minX, d7, this.boundingBox.minZ, this.boundingBox.maxX, d8, this.boundingBox.maxZ);

                    if (this.world.isAABBInMaterial(axisalignedbb1, Material.WATER))
                    {
                        d6 += 1.0D / (double)var38;
                    }
                }

                if (d6 > 0.0D)
                {
                    if (this.au > 0)
                    {
                        --this.au;
                    }
                    else if (this.random.nextDouble() < ((Fish)this.getBukkitEntity()).getBiteChance())
                    {
                        this.au = this.random.nextInt(30) + 10;
                        this.motY -= 0.20000000298023224D;
                        this.makeSound("random.splash", 0.25F, 1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.4F);
                        float var39 = (float)MathHelper.floor(this.boundingBox.minY);
                        int l;
                        float f5;
                        float f4;

                        for (l = 0; (float)l < 1.0F + this.width * 20.0F; ++l)
                        {
                            f5 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            f4 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            this.world.addParticle("bubble", this.locX + (double)f5, (double)(var39 + 1.0F), this.locZ + (double)f4, this.motX, this.motY - (double)(this.random.nextFloat() * 0.2F), this.motZ);
                        }

                        for (l = 0; (float)l < 1.0F + this.width * 20.0F; ++l)
                        {
                            f5 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            f4 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            this.world.addParticle("splash", this.locX + (double)f5, (double)(var39 + 1.0F), this.locZ + (double)f4, this.motX, this.motY, this.motZ);
                        }
                    }
                }

                if (this.au > 0)
                {
                    this.motY -= (double)(this.random.nextFloat() * this.random.nextFloat() * this.random.nextFloat()) * 0.2D;
                }

                d5 = d6 * 2.0D - 1.0D;
                this.motY += 0.03999999910593033D * d5;

                if (d6 > 0.0D)
                {
                    var37 = (float)((double)var37 * 0.9D);
                    this.motY *= 0.8D;
                }

                this.motX *= (double)var37;
                this.motY *= (double)var37;
                this.motZ *= (double)var37;
                this.setPosition(this.locX, this.locY, this.locZ);
            }
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("xTile", (short)this.fire);
        nbttagcompound.setShort("yTile", (short)this.firstUpdate);
        nbttagcompound.setShort("zTile", (short)this.entityRiderPitchDelta);
        nbttagcompound.setByte("inTile", (byte)this.entityRiderYawDelta);
        nbttagcompound.setByte("shake", (byte)this.a);
        nbttagcompound.setByte("inGround", (byte)(this.invulnerable ? 1 : 0));
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        this.fire = nbttagcompound.getShort("xTile");
        this.firstUpdate = nbttagcompound.getShort("yTile");
        this.entityRiderPitchDelta = nbttagcompound.getShort("zTile");
        this.entityRiderYawDelta = nbttagcompound.getByte("inTile") & 255;
        this.a = nbttagcompound.getByte("shake") & 255;
        this.invulnerable = nbttagcompound.getByte("inGround") == 1;
    }

    public int c()
    {
        if (this.world.isStatic)
        {
            return 0;
        }
        else
        {
            byte b0 = 0;
            PlayerFishEvent playerFishEvent;

            if (this.hooked != null)
            {
                playerFishEvent = new PlayerFishEvent((Player)this.owner.getBukkitEntity(), this.hooked.getBukkitEntity(), (Fish)this.getBukkitEntity(), PlayerFishEvent.State.CAUGHT_ENTITY);
                this.world.getServer().getPluginManager().callEvent(playerFishEvent);

                if (playerFishEvent.isCancelled())
                {
                    this.die();
                    this.owner.hookedFish = null;
                    return 0;
                }

                double d0 = this.owner.locX - this.locX;
                double d1 = this.owner.locY - this.locY;
                double d2 = this.owner.locZ - this.locZ;
                double d3 = (double)MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
                double d4 = 0.1D;
                this.hooked.motX += d0 * d4;
                this.hooked.motY += d1 * d4 + (double)MathHelper.sqrt(d3) * 0.08D;
                this.hooked.motZ += d2 * d4;
                b0 = 3;
            }
            else if (this.au > 0)
            {
                EntityItem playerFishEvent2 = new EntityItem(this.world, this.locX, this.locY, this.locZ, new ItemStack(Item.RAW_FISH));
                PlayerFishEvent playerFishEvent1 = new PlayerFishEvent((Player)this.owner.getBukkitEntity(), playerFishEvent2.getBukkitEntity(), (Fish)this.getBukkitEntity(), PlayerFishEvent.State.CAUGHT_FISH);
                playerFishEvent1.setExpToDrop(this.random.nextInt(6) + 1);
                this.world.getServer().getPluginManager().callEvent(playerFishEvent1);

                if (playerFishEvent1.isCancelled())
                {
                    this.die();
                    this.owner.hookedFish = null;
                    return 0;
                }

                double d5 = this.owner.locX - this.locX;
                double d6 = this.owner.locY - this.locY;
                double d7 = this.owner.locZ - this.locZ;
                double d8 = (double)MathHelper.sqrt(d5 * d5 + d6 * d6 + d7 * d7);
                double d9 = 0.1D;
                playerFishEvent2.motX = d5 * d9;
                playerFishEvent2.motY = d6 * d9 + (double)MathHelper.sqrt(d8) * 0.08D;
                playerFishEvent2.motZ = d7 * d9;
                this.world.addEntity(playerFishEvent2);
                this.owner.addStat(StatisticList.B, 1);
                this.owner.world.addEntity(new EntityExperienceOrb(this.owner.world, this.owner.locX, this.owner.locY + 0.5D, this.owner.locZ + 0.5D, playerFishEvent1.getExpToDrop()));
                b0 = 1;
            }

            if (this.invulnerable)
            {
                playerFishEvent = new PlayerFishEvent((Player)this.owner.getBukkitEntity(), (org.bukkit.entity.Entity)null, (Fish)this.getBukkitEntity(), PlayerFishEvent.State.IN_GROUND);
                this.world.getServer().getPluginManager().callEvent(playerFishEvent);

                if (playerFishEvent.isCancelled())
                {
                    this.die();
                    this.owner.hookedFish = null;
                    return 0;
                }

                b0 = 2;
            }

            if (b0 == 0)
            {
                playerFishEvent = new PlayerFishEvent((Player)this.owner.getBukkitEntity(), (org.bukkit.entity.Entity)null, (Fish)this.getBukkitEntity(), PlayerFishEvent.State.FAILED_ATTEMPT);
                this.world.getServer().getPluginManager().callEvent(playerFishEvent);
            }

            this.die();
            this.owner.hookedFish = null;
            return b0;
        }
    }

    public void die()
    {
        super.die();

        if (this.owner != null)
        {
            this.owner.hookedFish = null;
        }
    }
}
