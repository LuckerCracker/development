package net.minecraft.server.v1_6_R3;

import com.google.common.collect.Lists;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonArray;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonDeserializationContext;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonDeserializer;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonElement;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonObject;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonParseException;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonPrimitive;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonSerializationContext;
import org.bukkit.craftbukkit.libs.com.google.gson.JsonSerializer;

public class ChatSerializer implements JsonDeserializer, JsonSerializer
{
    public ChatMessage a(JsonElement var1, Type var2, JsonDeserializationContext var3)
    {
        ChatMessage var4 = new ChatMessage();
        JsonObject var5 = (JsonObject)var1;
        JsonElement var6 = var5.get("text");
        JsonElement var7 = var5.get("translate");
        JsonElement var8 = var5.get("color");
        JsonElement var9 = var5.get("bold");
        JsonElement var10 = var5.get("italic");
        JsonElement var11 = var5.get("underlined");
        JsonElement var12 = var5.get("obfuscated");

        if (var8 != null && var8.isJsonPrimitive())
        {
            EnumChatFormat var13 = EnumChatFormat.b(var8.getAsString());

            if (var13 == null || !var13.c())
            {
                throw new JsonParseException("Given color (" + var8.getAsString() + ") is not a valid selection");
            }

            var4.a(var13);
        }

        if (var9 != null && var9.isJsonPrimitive())
        {
            var4.a(Boolean.valueOf(var9.getAsBoolean()));
        }

        if (var10 != null && var10.isJsonPrimitive())
        {
            var4.b(Boolean.valueOf(var10.getAsBoolean()));
        }

        if (var11 != null && var11.isJsonPrimitive())
        {
            var4.c(Boolean.valueOf(var11.getAsBoolean()));
        }

        if (var12 != null && var12.isJsonPrimitive())
        {
            var4.d(Boolean.valueOf(var12.getAsBoolean()));
        }

        if (var6 != null)
        {
            if (var6.isJsonArray())
            {
                JsonArray var17 = var6.getAsJsonArray();
                Iterator var14 = var17.iterator();

                while (var14.hasNext())
                {
                    JsonElement var15 = (JsonElement)var14.next();

                    if (var15.isJsonPrimitive())
                    {
                        var4.a(var15.getAsString());
                    }
                    else if (var15.isJsonObject())
                    {
                        var4.a(this.a(var15, var2, var3));
                    }
                }
            }
            else if (var6.isJsonPrimitive())
            {
                var4.a(var6.getAsString());
            }
        }
        else if (var7 != null && var7.isJsonPrimitive())
        {
            JsonElement var18 = var5.get("using");

            if (var18 != null)
            {
                if (var18.isJsonArray())
                {
                    ArrayList var19 = Lists.newArrayList();
                    Iterator var20 = var18.getAsJsonArray().iterator();

                    while (var20.hasNext())
                    {
                        JsonElement var16 = (JsonElement)var20.next();

                        if (var16.isJsonPrimitive())
                        {
                            var19.add(var16.getAsString());
                        }
                        else if (var16.isJsonObject())
                        {
                            var19.add(this.a(var16, var2, var3));
                        }
                    }

                    var4.a(var7.getAsString(), var19.toArray());
                }
                else if (var18.isJsonPrimitive())
                {
                    var4.a(var7.getAsString(), new Object[] {var18.getAsString()});
                }
            }
            else
            {
                var4.b(var7.getAsString());
            }
        }

        return var4;
    }

    public JsonElement a(ChatMessage var1, Type var2, JsonSerializationContext var3)
    {
        JsonObject var4 = new JsonObject();

        if (var1.a() != null)
        {
            var4.addProperty("color", var1.a().d());
        }

        if (var1.b() != null)
        {
            var4.addProperty("bold", var1.b());
        }

        if (var1.c() != null)
        {
            var4.addProperty("italic", var1.c());
        }

        if (var1.d() != null)
        {
            var4.addProperty("underlined", var1.d());
        }

        if (var1.e() != null)
        {
            var4.addProperty("obfuscated", var1.e());
        }

        if (var1.f() != null)
        {
            var4.addProperty("text", var1.f());
        }
        else if (var1.g() != null)
        {
            var4.addProperty("translate", var1.g());

            if (var1.h() != null && !var1.h().isEmpty())
            {
                var4.add("using", this.b(var1, var2, var3));
            }
        }
        else if (var1.h() != null && !var1.h().isEmpty())
        {
            var4.add("text", this.b(var1, var2, var3));
        }

        return var4;
    }

    private JsonArray b(ChatMessage var1, Type var2, JsonSerializationContext var3)
    {
        JsonArray var4 = new JsonArray();
        Iterator var5 = var1.h().iterator();

        while (var5.hasNext())
        {
            ChatMessage var6 = (ChatMessage)var5.next();

            if (var6.f() != null)
            {
                var4.add(new JsonPrimitive(var6.f()));
            }
            else
            {
                var4.add(this.a(var6, var2, var3));
            }
        }

        return var4;
    }

    public Object deserialize(JsonElement var1, Type var2, JsonDeserializationContext var3)
    {
        return this.a(var1, var2, var3);
    }

    public JsonElement serialize(Object var1, Type var2, JsonSerializationContext var3)
    {
        return this.a((ChatMessage)var1, var2, var3);
    }
}
