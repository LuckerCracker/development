package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.List;
import org.bukkit.entity.Hanging;
import org.bukkit.entity.Painting;
import org.bukkit.event.Event;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.hanging.HangingBreakEvent$RemoveCause;
import org.bukkit.event.painting.PaintingBreakByEntityEvent;
import org.bukkit.event.painting.PaintingBreakEvent;
import org.bukkit.event.painting.PaintingBreakEvent$RemoveCause;

public abstract class EntityHanging extends Entity
{
    private int tickCounter1;
    public int direction;

    /** Entity motion X */
    public int motionX;

    /** Entity motion Y */
    public int motionY;

    /** Entity motion Z */
    public int motionZ;

    public EntityHanging(World par1World)
    {
        super(par1World);
        this.height = 0.0F;
        this.setSize(0.5F, 0.5F);
    }

    public EntityHanging(World par1World, int par2, int par3, int par4, int par5)
    {
        this(par1World);
        this.motionX = par2;
        this.motionY = par3;
        this.motionZ = par4;
    }

    protected void entityInit() {}

    public void setDirection(int i)
    {
        this.direction = i;
        this.lastYaw = this.yaw = (float)(i * 90);
        float f = (float)this.getWidthPixels();
        float f1 = (float)this.getHeightPixels();
        float f2 = (float)this.getWidthPixels();

        if (i != 2 && i != 0)
        {
            f = 0.5F;
        }
        else
        {
            f2 = 0.5F;
            this.yaw = this.lastYaw = (float)(Direction.rotateOpposite[i] * 90);
        }

        f /= 32.0F;
        f1 /= 32.0F;
        f2 /= 32.0F;
        float f3 = (float)this.motionX + 0.5F;
        float f4 = (float)this.motionY + 0.5F;
        float f5 = (float)this.motionZ + 0.5F;
        float f6 = 0.5625F;

        if (i == 2)
        {
            f5 -= f6;
        }

        if (i == 1)
        {
            f3 -= f6;
        }

        if (i == 0)
        {
            f5 += f6;
        }

        if (i == 3)
        {
            f3 += f6;
        }

        if (i == 2)
        {
            f3 -= this.func_70517_b(this.getWidthPixels());
        }

        if (i == 1)
        {
            f5 += this.func_70517_b(this.getWidthPixels());
        }

        if (i == 0)
        {
            f3 += this.func_70517_b(this.getWidthPixels());
        }

        if (i == 3)
        {
            f5 -= this.func_70517_b(this.getWidthPixels());
        }

        f4 += this.func_70517_b(this.getHeightPixels());
        this.setPosition((double)f3, (double)f4, (double)f5);
        float f7 = -0.03125F;
        this.boundingBox.setBounds((double)(f3 - f - f7), (double)(f4 - f1 - f7), (double)(f5 - f2 - f7), (double)(f3 + f + f7), (double)(f4 + f1 + f7), (double)(f5 + f2 + f7));
    }

    private float func_70517_b(int par1)
    {
        return par1 == 32 ? 0.5F : (par1 == 64 ? 0.5F : 0.0F);
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        this.lastX = this.locX;
        this.lastY = this.locY;
        this.lastZ = this.locZ;

        if (this.tickCounter1++ == 100 && !this.world.isStatic)
        {
            this.tickCounter1 = 0;

            if (!this.dead && !this.survives())
            {
                Material var1 = this.world.getMaterial((int)this.locX, (int)this.locY, (int)this.locZ);
                HangingBreakEvent$RemoveCause var2;

                if (!var1.equals(Material.AIR))
                {
                    var2 = HangingBreakEvent$RemoveCause.OBSTRUCTION;
                }
                else
                {
                    var2 = HangingBreakEvent$RemoveCause.PHYSICS;
                }

                HangingBreakEvent var3 = new HangingBreakEvent((Hanging)this.getBukkitEntity(), var2);
                this.world.getServer().getPluginManager().callEvent(var3);
                PaintingBreakEvent var4 = null;

                if (this instanceof EntityPainting)
                {
                    var4 = new PaintingBreakEvent((Painting)this.getBukkitEntity(), PaintingBreakEvent$RemoveCause.valueOf(var2.name()));
                    var4.setCancelled(var3.isCancelled());
                    this.world.getServer().getPluginManager().callEvent(var4);
                }

                if (this.dead || var3.isCancelled() || var4 != null && var4.isCancelled())
                {
                    return;
                }

                this.die();
                this.onBroken((Entity)null);
            }
        }
    }

    public boolean survives()
    {
        if (!this.world.getCubes(this, this.boundingBox).isEmpty())
        {
            return false;
        }
        else
        {
            int i = Math.max(1, this.getWidthPixels() / 16);
            int j = Math.max(1, this.getHeightPixels() / 16);
            int k = this.motionX;
            int l = this.motionY;
            int i1 = this.motionZ;

            if (this.direction == 2)
            {
                k = MathHelper.floor(this.locX - (double)((float)this.getWidthPixels() / 32.0F));
            }

            if (this.direction == 1)
            {
                i1 = MathHelper.floor(this.locZ - (double)((float)this.getWidthPixels() / 32.0F));
            }

            if (this.direction == 0)
            {
                k = MathHelper.floor(this.locX - (double)((float)this.getWidthPixels() / 32.0F));
            }

            if (this.direction == 3)
            {
                i1 = MathHelper.floor(this.locZ - (double)((float)this.getWidthPixels() / 32.0F));
            }

            l = MathHelper.floor(this.locY - (double)((float)this.getHeightPixels() / 32.0F));

            for (int list = 0; list < i; ++list)
            {
                for (int iterator = 0; iterator < j; ++iterator)
                {
                    Material entity;

                    if (this.direction != 2 && this.direction != 0)
                    {
                        entity = this.world.getMaterial(this.motionX, l + iterator, i1 + list);
                    }
                    else
                    {
                        entity = this.world.getMaterial(k + list, l + iterator, this.motionZ);
                    }

                    if (!entity.isBuildable())
                    {
                        return false;
                    }
                }
            }

            List var9 = this.world.getEntities(this, this.boundingBox);
            Iterator var10 = var9.iterator();

            while (var10.hasNext())
            {
                Entity var11 = (Entity)var10.next();

                if (var11 instanceof EntityHanging)
                {
                    return false;
                }
            }

            return true;
        }
    }

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
        return true;
    }

    /**
     * Called when a player attacks an entity. If this returns true the attack will not happen.
     */
    public boolean hitByEntity(Entity par1Entity)
    {
        return par1Entity instanceof EntityHuman ? this.attackEntityFrom(DamageSource.playerAttack((EntityHuman)par1Entity), 0.0F) : false;
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else
        {
            if (!this.dead && !this.world.isStatic)
            {
                Object event = new HangingBreakEvent((Hanging)this.getBukkitEntity(), HangingBreakEvent$RemoveCause.DEFAULT);
                PaintingBreakByEntityEvent paintingEvent = null;

                if (damagesource.getEntity() != null)
                {
                    event = new HangingBreakByEntityEvent((Hanging)this.getBukkitEntity(), damagesource.getEntity() == null ? null : damagesource.getEntity().getBukkitEntity());

                    if (this instanceof EntityPainting)
                    {
                        paintingEvent = new PaintingBreakByEntityEvent((Painting)this.getBukkitEntity(), damagesource.getEntity() == null ? null : damagesource.getEntity().getBukkitEntity());
                    }
                }
                else if (damagesource.isExplosion())
                {
                    event = new HangingBreakEvent((Hanging)this.getBukkitEntity(), HangingBreakEvent$RemoveCause.EXPLOSION);
                }

                this.world.getServer().getPluginManager().callEvent((Event)event);

                if (paintingEvent != null)
                {
                    paintingEvent.setCancelled(((HangingBreakEvent)event).isCancelled());
                    this.world.getServer().getPluginManager().callEvent(paintingEvent);
                }

                if (this.dead || ((HangingBreakEvent)event).isCancelled() || paintingEvent != null && paintingEvent.isCancelled())
                {
                    return true;
                }

                this.die();
                this.setBeenAttacked();
                this.onBroken(damagesource.getEntity());
            }

            return true;
        }
    }

    public void move(double d0, double d1, double d2)
    {
        if (!this.world.isStatic && !this.dead && d0 * d0 + d1 * d1 + d2 * d2 > 0.0D)
        {
            if (this.dead)
            {
                return;
            }

            this.die();
            this.onBroken((Entity)null);
        }
    }

    /**
     * Adds to the current velocity of the entity. Args: x, y, z
     */
    public void addVelocity(double par1, double par3, double par5) {}

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        par1NBTTagCompound.setByte("Direction", (byte)this.direction);
        par1NBTTagCompound.setInt("TileX", this.motionX);
        par1NBTTagCompound.setInt("TileY", this.motionY);
        par1NBTTagCompound.setInt("TileZ", this.motionZ);

        switch (this.direction)
        {
            case 0:
                par1NBTTagCompound.setByte("Dir", (byte)2);
                break;

            case 1:
                par1NBTTagCompound.setByte("Dir", (byte)1);
                break;

            case 2:
                par1NBTTagCompound.setByte("Dir", (byte)0);
                break;

            case 3:
                par1NBTTagCompound.setByte("Dir", (byte)3);
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        if (par1NBTTagCompound.hasKey("Direction"))
        {
            this.direction = par1NBTTagCompound.getByte("Direction");
        }
        else
        {
            switch (par1NBTTagCompound.getByte("Dir"))
            {
                case 0:
                    this.direction = 2;
                    break;

                case 1:
                    this.direction = 1;
                    break;

                case 2:
                    this.direction = 0;
                    break;

                case 3:
                    this.direction = 3;
            }
        }

        this.motionX = par1NBTTagCompound.getInt("TileX");
        this.motionY = par1NBTTagCompound.getInt("TileY");
        this.motionZ = par1NBTTagCompound.getInt("TileZ");
        this.setDirection(this.direction);
    }

    public abstract int getWidthPixels();

    public abstract int getHeightPixels();

    protected boolean shouldSetPosAfterLoading()
    {
        return false;
    }

    /**
     * Called when this entity is broken. Entity parameter may be null.
     */
    public abstract void onBroken(Entity var1);
}
