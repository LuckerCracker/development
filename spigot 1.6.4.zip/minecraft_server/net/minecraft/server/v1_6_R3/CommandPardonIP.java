package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.regex.Matcher;

public class CommandPardonIP extends CommandAbstract
{
    public String getCommandName()
    {
        return "pardon-ip";
    }

    public int a()
    {
        return 3;
    }

    public boolean a(ICommandListener var1)
    {
        return MinecraftServer.getServer().getPlayerList().getIPBans().isEnabled() && super.a(var1);
    }

    public String c(ICommandListener var1)
    {
        return "commands.unbanip.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length == 1 && var2[0].length() > 1)
        {
            Matcher var3 = CommandBanIp.a.matcher(var2[0]);

            if (var3.matches())
            {
                MinecraftServer.getServer().getPlayerList().getIPBans().remove(var2[0]);
                a(var1, "commands.unbanip.success", new Object[] {var2[0]});
            }
            else
            {
                throw new ExceptionInvalidSyntax("commands.unbanip.invalid", new Object[0]);
            }
        }
        else
        {
            throw new ExceptionUsage("commands.unbanip.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, MinecraftServer.getServer().getPlayerList().getIPBans().getEntries().keySet()) : null;
    }
}
