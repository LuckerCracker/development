package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityTargetEvent;

public abstract class EntityMonster extends EntityCreature implements IMonster {
	public EntityMonster(World world) {
		super(world);
		this.experienceValue = 5;
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		this.updateArmSwingProgress();
		float f = this.getBrightness(1.0F);

		if (f > 0.5F) {
			this.entityAge += 2;
		}

		super.onLivingUpdate();
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		super.onUpdate();

		if (!this.world.isStatic && this.world.difficulty == 0) {
			this.die();
		}
	}

	protected Entity findTarget() {
		EntityHuman entityhuman = this.world.findNearbyVulnerablePlayer(this, 16.0D);
		return entityhuman != null && this.canEntityBeSeen(entityhuman) ? entityhuman : null;
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else if (!super.attackEntityFrom(damagesource, f)) {
			return false;
		} else {
			Entity entity = damagesource.getEntity();

			if (this.passenger != entity && this.vehicle != entity) {
				if (entity != this) {
					if (entity != this.target && (this instanceof EntityBlaze || this instanceof EntityEnderman
							|| this instanceof EntitySpider || this instanceof EntityGiantZombie
							|| this instanceof EntitySilverfish)) {
						EntityTargetEvent event = CraftEventFactory.callEntityTargetEvent(this, entity,
								EntityTargetEvent.TargetReason.TARGET_ATTACKED_ENTITY);

						if (!event.isCancelled()) {
							if (event.getTarget() == null) {
								this.target = null;
							} else {
								this.target = ((CraftEntity) event.getTarget()).getHandle();
							}
						}
					} else {
						this.target = entity;
					}
				}

				return true;
			} else {
				return true;
			}
		}
	}

	public boolean attackEntityAsMob(Entity entity) {
		float f = (float) this.getAttributeInstance(GenericAttributes.e).getValue();
		int i = 0;

		if (entity instanceof EntityLiving) {
			f += EnchantmentManager.a((EntityLiving) this, (EntityLiving) entity);
			i += EnchantmentManager.getKnockbackEnchantmentLevel(this, (EntityLiving) entity);
		}

		boolean flag = entity.attackEntityFrom(DamageSource.mobAttack(this), f);

		if (flag) {
			if (i > 0) {
				entity.addVelocity((double) (-MathHelper.sin(this.yaw * (float) Math.PI / 180.0F) * (float) i * 0.5F),
						0.1D, (double) (MathHelper.cos(this.yaw * (float) Math.PI / 180.0F) * (float) i * 0.5F));
				this.motX *= 0.6D;
				this.motZ *= 0.6D;
			}

			int j = EnchantmentManager.getFireAspectEnchantmentLevel(this);

			if (j > 0) {
				entity.setOnFire(j * 4);
			}

			if (entity instanceof EntityLiving) {
				EnchantmentThorns.a(this, (EntityLiving) entity, this.random);
			}
		}

		return flag;
	}

	/**
	 * Basic mob attack. Default to touch of death in EntityCreature. Overridden
	 * by each mob to define their attack.
	 */
	protected void attackEntity(Entity entity, float f) {
		if (this.attackTicks <= 0 && f < 2.0F && entity.boundingBox.maxY > this.boundingBox.minY
				&& entity.boundingBox.minY < this.boundingBox.maxY) {
			this.attackTicks = 20;
			this.attackEntityAsMob(entity);
		}
	}

	/**
	 * Takes a coordinate in and returns a weight to determine how likely this
	 * creature will try to path to the block. Args: x, y, z
	 */
	public float getBlockPathWeight(int i, int j, int k) {
		return 0.5F - this.world.getLightBrightness(i, j, k);
	}

	protected boolean i_() {
		int i = MathHelper.floor(this.locX);
		int j = MathHelper.floor(this.boundingBox.minY);
		int k = MathHelper.floor(this.locZ);

		if (this.world.getSavedLightValue(EnumSkyBlock.SKY, i, j, k) > this.random.nextInt(32)) {
			return false;
		} else {
			int l = this.world.getLightLevel(i, j, k);

			if (this.world.isThundering()) {
				int i1 = this.world.skylightSubtracted;
				this.world.skylightSubtracted = 10;
				l = this.world.getLightLevel(i, j, k);
				this.world.skylightSubtracted = i1;
			}

			return l <= this.random.nextInt(8);
		}
	}

	public boolean canSpawn() {
		return this.world.difficulty > 0 && this.i_() && super.canSpawn();
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeMap().b(GenericAttributes.e);
	}
}
