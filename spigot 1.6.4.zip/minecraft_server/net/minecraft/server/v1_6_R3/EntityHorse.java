package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.List;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.HorseJumpEvent;

public class EntityHorse extends EntityAnimal implements IInventoryListener {
	private static final IEntitySelector horseBreedingSelector = new EntitySelectorHorse();
	public static final IAttribute attributeJumpStrength = (new AttributeRanged("horse.jumpStrength", 0.7D, 0.0D, 2.0D))
			.a("Jump Strength").setShouldWatch(true);
	private static final String[] horseArmorTextures = new String[] { null,
			"textures/entity/horse/armor/horse_armor_iron.png", "textures/entity/horse/armor/horse_armor_gold.png",
			"textures/entity/horse/armor/horse_armor_diamond.png" };
	private static final String[] field_110273_bx = new String[] { "", "meo", "goo", "dio" };
	private static final int[] armorValues = new int[] { 0, 5, 7, 11 };
	private static final String[] horseTextures = new String[] { "textures/entity/horse/horse_white.png",
			"textures/entity/horse/horse_creamy.png", "textures/entity/horse/horse_chestnut.png",
			"textures/entity/horse/horse_brown.png", "textures/entity/horse/horse_black.png",
			"textures/entity/horse/horse_gray.png", "textures/entity/horse/horse_darkbrown.png" };
	private static final String[] field_110269_bA = new String[] { "hwh", "hcr", "hch", "hbr", "hbl", "hgr", "hdb" };
	private static final String[] horseMarkingTextures = new String[] { null,
			"textures/entity/horse/horse_markings_white.png", "textures/entity/horse/horse_markings_whitefield.png",
			"textures/entity/horse/horse_markings_whitedots.png",
			"textures/entity/horse/horse_markings_blackdots.png" };
	private static final String[] field_110292_bC = new String[] { "", "wo_", "wmo", "wdo", "bdo" };
	private int eatingHaystackCounter;
	private int openMouthCounter;
	private int jumpRearingCounter;
	public int field_110278_bp;
	public int field_110279_bq;
	protected boolean horseJumping;
	public InventoryHorseChest inventoryChest;
	private boolean hasReproduced;

	/**
	 * "The higher this value, the more likely the horse is to be tamed next
	 * time a player rides it."
	 */
	protected int temper;
	protected float jumpPower;
	private boolean field_110294_bI;
	private float headLean;
	private float prevHeadLean;
	private float rearingAmount;
	private float prevRearingAmount;
	private float mouthOpenness;
	private float prevMouthOpenness;
	private int field_110285_bP;
	private String field_110286_bQ;
	private String[] field_110280_bR = new String[3];
	public int maxDomestication = 100;

	public EntityHorse(World par1World) {
		super(par1World);
		this.setSize(1.4F, 1.6F);
		this.fireProof = false;
		this.setHasChest(false);
		this.getNavigation().a(true);
		this.goalSelector.a(0, new PathfinderGoalFloat(this));
		this.goalSelector.a(1, new PathfinderGoalPanic(this, 1.2D));
		this.goalSelector.a(1, new PathfinderGoalTame(this, 1.2D));
		this.goalSelector.a(2, new PathfinderGoalBreed(this, 1.0D));
		this.goalSelector.a(4, new PathfinderGoalFollowParent(this, 1.0D));
		this.goalSelector.a(6, new PathfinderGoalRandomStroll(this, 0.7D));
		this.goalSelector.a(7, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 6.0F));
		this.goalSelector.a(8, new PathfinderGoalRandomLookaround(this));
		this.loadChest();
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(16, Integer.valueOf(0));
		this.datawatcher.addObject(19, Byte.valueOf((byte) 0));
		this.datawatcher.addObject(20, Integer.valueOf(0));
		this.datawatcher.addObject(21, String.valueOf(""));
		this.datawatcher.addObject(22, Integer.valueOf(0));
	}

	public void setType(int i) {
		this.datawatcher.watch(19, Byte.valueOf((byte) i));
		this.func_110230_cF();
	}

	public int getType() {
		return this.datawatcher.getByte(19);
	}

	public void setVariant(int i) {
		this.datawatcher.watch(20, Integer.valueOf(i));
		this.func_110230_cF();
	}

	public int getVariant() {
		return this.datawatcher.getInt(20);
	}

	public String getLocalizedName() {
		if (this.hasCustomName()) {
			return this.getCustomName();
		} else {
			int i = this.getType();

			switch (i) {
			case 0:
			default:
				return LocaleI18n.get("entity.horse.name");

			case 1:
				return LocaleI18n.get("entity.donkey.name");

			case 2:
				return LocaleI18n.get("entity.mule.name");

			case 3:
				return LocaleI18n.get("entity.zombiehorse.name");

			case 4:
				return LocaleI18n.get("entity.skeletonhorse.name");
			}
		}
	}

	private boolean getHorseWatchableBoolean(int par1) {
		return (this.datawatcher.getInt(16) & par1) != 0;
	}

	private void setHorseWatchableBoolean(int par1, boolean par2) {
		int var3 = this.datawatcher.getInt(16);

		if (par2) {
			this.datawatcher.watch(16, Integer.valueOf(var3 | par1));
		} else {
			this.datawatcher.watch(16, Integer.valueOf(var3 & ~par1));
		}
	}

	public boolean isAdultHorse() {
		return !this.isBaby();
	}

	public boolean isTame() {
		return this.getHorseWatchableBoolean(2);
	}

	public boolean func_110253_bW() {
		return this.isAdultHorse();
	}

	public String getOwnerName() {
		return this.datawatcher.getString(21);
	}

	public void setOwnerName(String s) {
		this.datawatcher.watch(21, s);
	}

	public float getHorseSize() {
		int var1 = this.getAge();
		return var1 >= 0 ? 1.0F : 0.5F + (float) (-24000 - var1) / -24000.0F * 0.5F;
	}

	/**
	 * "Sets the scale for an ageable entity according to the boolean parameter,
	 * which says if it's a child."
	 */
	public void setScaleForAge(boolean par1) {
		if (par1) {
			this.setScale(this.getHorseSize());
		} else {
			this.setScale(1.0F);
		}
	}

	public boolean isHorseJumping() {
		return this.horseJumping;
	}

	public void setTame(boolean flag) {
		this.setHorseWatchableBoolean(2, flag);
	}

	public void setHorseJumping(boolean par1) {
		this.horseJumping = par1;
	}

	public boolean allowLeashing() {
		return !this.func_110256_cu() && super.allowLeashing();
	}

	protected void func_142017_o(float par1) {
		if (par1 > 6.0F && this.isEatingHaystack()) {
			this.setEatingHaystack(false);
		}
	}

	public boolean hasChest() {
		return this.getHorseWatchableBoolean(8);
	}

	public int func_110241_cb() {
		return this.datawatcher.getInt(22);
	}

	/**
	 * 0 = iron, 1 = gold, 2 = diamond
	 */
	public int getHorseArmorIndex(ItemStack par1ItemStack) {
		return par1ItemStack == null ? 0
				: (par1ItemStack.id == Item.HORSE_ARMOR_IRON.id ? 1
						: (par1ItemStack.id == Item.HORSE_ARMOR_GOLD.id ? 2
								: (par1ItemStack.id == Item.HORSE_ARMOR_DIAMOND.id ? 3 : 0)));
	}

	public boolean isEatingHaystack() {
		return this.getHorseWatchableBoolean(32);
	}

	public boolean isRearing() {
		return this.getHorseWatchableBoolean(64);
	}

	public boolean func_110205_ce() {
		return this.getHorseWatchableBoolean(16);
	}

	public boolean getHasReproduced() {
		return this.hasReproduced;
	}

	public void func_110236_r(int par1) {
		this.datawatcher.watch(22, Integer.valueOf(par1));
		this.func_110230_cF();
	}

	public void func_110242_l(boolean par1) {
		this.setHorseWatchableBoolean(16, par1);
	}

	public void setHasChest(boolean flag) {
		this.setHorseWatchableBoolean(8, flag);
	}

	public void setHasReproduced(boolean par1) {
		this.hasReproduced = par1;
	}

	public void setHorseSaddled(boolean par1) {
		this.setHorseWatchableBoolean(4, par1);
	}

	public int getTemper() {
		return this.temper;
	}

	public void setTemper(int i) {
		this.temper = i;
	}

	public int increaseTemper(int par1) {
		int var2 = MathHelper.clamp_int(this.getTemper() + par1, 0, this.getMaxDomestication());
		this.setTemper(var2);
		return var2;
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		Entity entity = damagesource.getEntity();
		return this.passenger != null && this.passenger.equals(entity) ? false : super.attackEntityFrom(damagesource, f);
	}

	/**
	 * Returns the current armor value as determined by a call to
	 * InventoryPlayer.getTotalArmorValue
	 */
	public int getTotalArmorValue() {
		return armorValues[this.func_110241_cb()];
	}

	/**
	 * Returns true if this entity should push and be pushed by other entities
	 * when colliding.
	 */
	public boolean canBePushed() {
		return this.passenger == null;
	}

	public boolean prepareChunkForSpawn() {
		int var1 = MathHelper.floor(this.locX);
		int var2 = MathHelper.floor(this.locZ);
		this.world.getBiome(var1, var2);
		return true;
	}

	public void dropChests() {
		if (!this.world.isStatic && this.hasChest()) {
			this.dropItem(Block.CHEST.id, 1);
			this.setHasChest(false);
		}
	}

	private void func_110266_cB() {
		this.openHorseMouth();
		this.world.makeSound(this, "eating", 1.0F, 1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.2F);
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float par1) {
		if (par1 > 1.0F) {
			this.makeSound("mob.horse.land", 0.4F, 1.0F);
		}

		int var2 = MathHelper.ceiling_float_int(par1 * 0.5F - 3.0F);

		if (var2 > 0) {
			EntityDamageEvent var3 = CraftEventFactory.callEntityDamageEvent((Entity) null, this,
					EntityDamageEvent.DamageCause.FALL, (double) var2);

			if (!var3.isCancelled()) {
				float var4 = (float) var3.getDamage();

				if (var4 > 0.0F) {
					this.getBukkitEntity().setLastDamageCause(var3);
					this.attackEntityFrom(DamageSource.FALL, var4);
				}
			}

			if (this.passenger != null) {
				EntityDamageEvent var6 = CraftEventFactory.callEntityDamageEvent((Entity) null, this.passenger,
						EntityDamageEvent.DamageCause.FALL, (double) var2);

				if (!var6.isCancelled() && this.passenger != null) {
					float var5 = (float) var6.getDamage();

					if (var5 > 0.0F) {
						this.passenger.getBukkitEntity().setLastDamageCause(var6);
						this.passenger.attackEntityFrom(DamageSource.FALL, var5);
					}
				}
			}

			int var7 = this.world.getTypeId(MathHelper.floor(this.locX),
					MathHelper.floor(this.locY - 0.2D - (double) this.lastYaw), MathHelper.floor(this.locZ));

			if (var7 > 0) {
				StepSound var8 = Block.byId[var7].stepSound;
				this.world.makeSound(this, var8.getStepSound(), var8.getVolume1() * 0.5F, var8.getVolume2() * 0.75F);
			}
		}
	}

	private int func_110225_cC() {
		int var1 = this.getType();
		return this.hasChest() ? 17 : 2;
	}

	public void loadChest() {
		InventoryHorseChest inventoryhorsechest = this.inventoryChest;
		this.inventoryChest = new InventoryHorseChest("HorseChest", this.func_110225_cC(), this);
		this.inventoryChest.a(this.getLocalizedName());

		if (inventoryhorsechest != null) {
			inventoryhorsechest.b(this);
			int i = Math.min(inventoryhorsechest.getSize(), this.inventoryChest.getSize());

			for (int j = 0; j < i; ++j) {
				ItemStack itemstack = inventoryhorsechest.getItem(j);

				if (itemstack != null) {
					this.inventoryChest.setItem(j, itemstack.cloneItemStack());
				}
			}

			inventoryhorsechest = null;
		}

		this.inventoryChest.a(this);
		this.func_110232_cE();
	}

	private void func_110232_cE() {
		if (!this.world.isStatic) {
			this.setHorseSaddled(this.inventoryChest.getItem(0) != null);

			if (this.func_110259_cr()) {
				this.func_110236_r(this.getHorseArmorIndex(this.inventoryChest.getItem(1)));
			}
		}
	}

	public void a(InventorySubcontainer inventorysubcontainer) {
		int i = this.func_110241_cb();
		boolean flag = this.isHorseSaddled();
		this.func_110232_cE();

		if (this.ticksLived > 20) {
			if (i == 0 && i != this.func_110241_cb()) {
				this.makeSound("mob.horse.armor", 0.5F, 1.0F);
			}

			if (!flag && this.isHorseSaddled()) {
				this.makeSound("mob.horse.leather", 0.5F, 1.0F);
			}
		}
	}

	public boolean canSpawn() {
		this.prepareChunkForSpawn();
		return super.canSpawn();
	}

	protected EntityHorse getClosestHorse(Entity par1Entity, double par2) {
		double var4 = Double.MAX_VALUE;
		Entity var6 = null;
		List var7 = this.world.getEntities(par1Entity, par1Entity.boundingBox.addCoord(par2, par2, par2),
				horseBreedingSelector);
		Iterator var8 = var7.iterator();

		while (var8.hasNext()) {
			Entity var9 = (Entity) var8.next();
			double var10 = var9.getDistanceSq(par1Entity.locX, par1Entity.locY, par1Entity.locZ);

			if (var10 < var4) {
				var6 = var9;
				var4 = var10;
			}
		}

		return (EntityHorse) var6;
	}

	public double getJumpStrength() {
		return this.getAttributeInstance(attributeJumpStrength).getValue();
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		this.openHorseMouth();
		int var1 = this.getType();
		return var1 == 3 ? "mob.horse.zombie.death"
				: (var1 == 4 ? "mob.horse.skeleton.death"
						: (var1 != 1 && var1 != 2 ? "mob.horse.death" : "mob.horse.donkey.death"));
	}

	protected int getLootId() {
		boolean flag = this.random.nextInt(4) == 0;
		int i = this.getType();
		return i == 4 ? Item.BONE.id : (i == 3 ? (flag ? 0 : Item.ROTTEN_FLESH.id) : Item.LEATHER.id);
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		this.openHorseMouth();

		if (this.random.nextInt(3) == 0) {
			this.makeHorseRear();
		}

		int var1 = this.getType();
		return var1 == 3 ? "mob.horse.zombie.hit"
				: (var1 == 4 ? "mob.horse.skeleton.hit"
						: (var1 != 1 && var1 != 2 ? "mob.horse.hit" : "mob.horse.donkey.hit"));
	}

	public boolean isHorseSaddled() {
		return this.getHorseWatchableBoolean(4);
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		this.openHorseMouth();

		if (this.random.nextInt(10) == 0 && !this.isMovementBlocked()) {
			this.makeHorseRear();
		}

		int var1 = this.getType();
		return var1 == 3 ? "mob.horse.zombie.idle"
				: (var1 == 4 ? "mob.horse.skeleton.idle"
						: (var1 != 1 && var1 != 2 ? "mob.horse.idle" : "mob.horse.donkey.idle"));
	}

	protected String getAngrySoundName() {
		this.openHorseMouth();
		this.makeHorseRear();
		int var1 = this.getType();
		return var1 != 3 && var1 != 4 ? (var1 != 1 && var1 != 2 ? "mob.horse.angry" : "mob.horse.donkey.angry") : null;
	}

	/**
	 * Plays step sound at given x, y, z for the entity
	 */
	protected void playStepSound(int par1, int par2, int par3, int par4) {
		StepSound var5 = Block.byId[par4].stepSound;

		if (this.world.getTypeId(par1, par2 + 1, par3) == Block.SNOW.id) {
			var5 = Block.SNOW.stepSound;
		}

		if (!Block.byId[par4].material.isLiquid()) {
			int var6 = this.getType();

			if (this.passenger != null && var6 != 1 && var6 != 2) {
				++this.field_110285_bP;

				if (this.field_110285_bP > 5 && this.field_110285_bP % 3 == 0) {
					this.makeSound("mob.horse.gallop", var5.getVolume1() * 0.15F, var5.getVolume2());

					if (var6 == 0 && this.random.nextInt(10) == 0) {
						this.makeSound("mob.horse.breathe", var5.getVolume1() * 0.6F, var5.getVolume2());
					}
				} else if (this.field_110285_bP <= 5) {
					this.makeSound("mob.horse.wood", var5.getVolume1() * 0.15F, var5.getVolume2());
				}
			} else if (var5 == Block.soundWoodFootstep) {
				this.makeSound("mob.horse.soft", var5.getVolume1() * 0.15F, var5.getVolume2());
			} else {
				this.makeSound("mob.horse.wood", var5.getVolume1() * 0.15F, var5.getVolume2());
			}
		}
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeMap().b(attributeJumpStrength);
		this.getAttributeInstance(GenericAttributes.a).setValue(53.0D);
		this.getAttributeInstance(GenericAttributes.d).setValue(0.22499999403953552D);
	}

	/**
	 * Will return how many at most can spawn in a chunk at once.
	 */
	public int getMaxSpawnedInChunk() {
		return 6;
	}

	public int getMaxDomestication() {
		return this.maxDomestication;
	}

	/**
	 * Returns the volume for the sounds this mob makes.
	 */
	protected float getSoundVolume() {
		return 0.8F;
	}

	/**
	 * Get number of ticks, at least during which the living entity will be
	 * silent.
	 */
	public int getTalkInterval() {
		return 400;
	}

	private void func_110230_cF() {
		this.field_110286_bQ = null;
	}

	public void f(EntityHuman entityhuman) {
		if (!this.world.isStatic && (this.passenger == null || this.passenger == entityhuman) && this.isTame()) {
			this.inventoryChest.a(this.getLocalizedName());
			entityhuman.openHorseInventory(this, this.inventoryChest);
		}
	}

	public boolean a(EntityHuman entityhuman) {
		ItemStack itemstack = entityhuman.inventory.getItemInHand();

		if (itemstack != null && itemstack.id == Item.MONSTER_EGG.id) {
			return super.a(entityhuman);
		} else if (!this.isTame() && this.func_110256_cu()) {
			return false;
		} else if (this.isTame() && this.isAdultHorse() && entityhuman.isSneaking()) {
			this.f(entityhuman);
			return true;
		} else if (this.func_110253_bW() && this.passenger != null) {
			return super.a(entityhuman);
		} else {
			if (itemstack != null) {
				boolean flag = false;

				if (this.func_110259_cr()) {
					byte f = -1;

					if (itemstack.id == Item.HORSE_ARMOR_IRON.id) {
						f = 1;
					} else if (itemstack.id == Item.HORSE_ARMOR_GOLD.id) {
						f = 2;
					} else if (itemstack.id == Item.HORSE_ARMOR_DIAMOND.id) {
						f = 3;
					}

					if (f >= 0) {
						if (!this.isTame()) {
							this.makeHorseRearWithSound();
							return true;
						}

						this.f(entityhuman);
						return true;
					}
				}

				if (!flag && !this.func_110256_cu()) {
					float var7 = 0.0F;
					short short1 = 0;
					byte b1 = 0;

					if (itemstack.id == Item.WHEAT.id) {
						var7 = 2.0F;
						short1 = 60;
						b1 = 3;
					} else if (itemstack.id == Item.SUGAR.id) {
						var7 = 1.0F;
						short1 = 30;
						b1 = 3;
					} else if (itemstack.id == Item.BREAD.id) {
						var7 = 7.0F;
						short1 = 180;
						b1 = 3;
					} else if (itemstack.id == Block.HAY_BLOCK.id) {
						var7 = 20.0F;
						short1 = 180;
					} else if (itemstack.id == Item.APPLE.id) {
						var7 = 3.0F;
						short1 = 60;
						b1 = 3;
					} else if (itemstack.id == Item.CARROT_GOLDEN.id) {
						var7 = 4.0F;
						short1 = 60;
						b1 = 5;

						if (this.isTame() && this.getAge() == 0) {
							flag = true;
							this.func_110196_bT();
						}
					} else if (itemstack.id == Item.GOLDEN_APPLE.id) {
						var7 = 10.0F;
						short1 = 240;
						b1 = 10;

						if (this.isTame() && this.getAge() == 0) {
							flag = true;
							this.func_110196_bT();
						}
					}

					if (this.getHealth() < this.getMaxHealth() && var7 > 0.0F) {
						this.heal(var7);
						flag = true;
					}

					if (!this.isAdultHorse() && short1 > 0) {
						this.addGrowth(short1);
						flag = true;
					}

					if (b1 > 0 && (flag || !this.isTame()) && b1 < this.getMaxDomestication()) {
						flag = true;
						this.increaseTemper(b1);
					}

					if (flag) {
						this.func_110266_cB();
					}
				}

				if (!this.isTame() && !flag) {
					if (itemstack != null && itemstack.a(entityhuman, (EntityLiving) this)) {
						return true;
					}

					this.makeHorseRearWithSound();
					return true;
				}

				if (!flag && this.func_110229_cs() && !this.hasChest() && itemstack.id == Block.CHEST.id) {
					this.setHasChest(true);
					this.makeSound("mob.chickenplop", 1.0F,
							(this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
					flag = true;
					this.loadChest();
				}

				if (!flag && this.func_110253_bW() && !this.isHorseSaddled() && itemstack.id == Item.SADDLE.id) {
					this.f(entityhuman);
					return true;
				}

				if (flag) {
					if (!entityhuman.abilities.canInstantlyBuild && --itemstack.count == 0) {
						entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack) null);
					}

					return true;
				}
			}

			if (this.func_110253_bW() && this.passenger == null) {
				if (itemstack != null && itemstack.a(entityhuman, (EntityLiving) this)) {
					return true;
				} else {
					this.h(entityhuman);
					return true;
				}
			} else {
				return super.a(entityhuman);
			}
		}
	}

	private void h(EntityHuman entityhuman) {
		entityhuman.yaw = this.yaw;
		entityhuman.pitch = this.pitch;
		this.setEatingHaystack(false);
		this.setRearing(false);

		if (!this.world.isStatic) {
			entityhuman.mount(this);
		}
	}

	public boolean func_110259_cr() {
		return this.getType() == 0;
	}

	public boolean func_110229_cs() {
		int var1 = this.getType();
		return var1 == 2 || var1 == 1;
	}

	/**
	 * Dead and sleeping entities cannot move
	 */
	protected boolean isMovementBlocked() {
		return this.passenger != null && this.isHorseSaddled() ? true : this.isEatingHaystack() || this.isRearing();
	}

	public boolean func_110256_cu() {
		int var1 = this.getType();
		return var1 == 3 || var1 == 4;
	}

	public boolean func_110222_cv() {
		return this.func_110256_cu() || this.getType() == 2;
	}

	/**
	 * Checks if the parameter is an item which this animal can be fed to breed
	 * it (wheat, carrots or seeds depending on the animal type)
	 */
	public boolean isBreedingItem(ItemStack par1ItemStack) {
		return false;
	}

	private void func_110210_cH() {
		this.field_110278_bp = 1;
	}

	public void die(DamageSource damagesource) {
		super.die(damagesource);

		if (!this.world.isStatic) {
			this.dropChestItems();
		}
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		if (this.random.nextInt(200) == 0) {
			this.func_110210_cH();
		}

		super.onLivingUpdate();

		if (!this.world.isStatic) {
			if (this.random.nextInt(900) == 0 && this.deathTicks == 0) {
				this.heal(1.0F);
			}

			if (!this.isEatingHaystack() && this.passenger == null && this.random.nextInt(300) == 0
					&& this.world.getTypeId(MathHelper.floor(this.locX), MathHelper.floor(this.locY) - 1,
							MathHelper.floor(this.locZ)) == Block.GRASS.id) {
				this.setEatingHaystack(true);
			}

			if (this.isEatingHaystack() && ++this.eatingHaystackCounter > 50) {
				this.eatingHaystackCounter = 0;
				this.setEatingHaystack(false);
			}

			if (this.func_110205_ce() && !this.isAdultHorse() && !this.isEatingHaystack()) {
				EntityHorse var1 = this.getClosestHorse(this, 16.0D);

				if (var1 != null && this.getDistanceSqToEntity(var1) > 4.0D) {
					PathEntity var2 = this.world.findPath(this, var1, 16.0F, true, false, false, true);
					this.setPathEntity(var2);
				}
			}
		}
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		super.onUpdate();

		if (this.world.isStatic && this.datawatcher.hasObjectChanged()) {
			this.datawatcher.func_111144_e();
			this.func_110230_cF();
		}

		if (this.openMouthCounter > 0 && ++this.openMouthCounter > 30) {
			this.openMouthCounter = 0;
			this.setHorseWatchableBoolean(128, false);
		}

		if (!this.world.isStatic && this.jumpRearingCounter > 0 && ++this.jumpRearingCounter > 20) {
			this.jumpRearingCounter = 0;
			this.setRearing(false);
		}

		if (this.field_110278_bp > 0 && ++this.field_110278_bp > 8) {
			this.field_110278_bp = 0;
		}

		if (this.field_110279_bq > 0) {
			++this.field_110279_bq;

			if (this.field_110279_bq > 300) {
				this.field_110279_bq = 0;
			}
		}

		this.prevHeadLean = this.headLean;

		if (this.isEatingHaystack()) {
			this.headLean += (1.0F - this.headLean) * 0.4F + 0.05F;

			if (this.headLean > 1.0F) {
				this.headLean = 1.0F;
			}
		} else {
			this.headLean += (0.0F - this.headLean) * 0.4F - 0.05F;

			if (this.headLean < 0.0F) {
				this.headLean = 0.0F;
			}
		}

		this.prevRearingAmount = this.rearingAmount;

		if (this.isRearing()) {
			this.prevHeadLean = this.headLean = 0.0F;
			this.rearingAmount += (1.0F - this.rearingAmount) * 0.4F + 0.05F;

			if (this.rearingAmount > 1.0F) {
				this.rearingAmount = 1.0F;
			}
		} else {
			this.field_110294_bI = false;
			this.rearingAmount += (0.8F * this.rearingAmount * this.rearingAmount * this.rearingAmount
					- this.rearingAmount) * 0.6F - 0.05F;

			if (this.rearingAmount < 0.0F) {
				this.rearingAmount = 0.0F;
			}
		}

		this.prevMouthOpenness = this.mouthOpenness;

		if (this.getHorseWatchableBoolean(128)) {
			this.mouthOpenness += (1.0F - this.mouthOpenness) * 0.7F + 0.05F;

			if (this.mouthOpenness > 1.0F) {
				this.mouthOpenness = 1.0F;
			}
		} else {
			this.mouthOpenness += (0.0F - this.mouthOpenness) * 0.7F - 0.05F;

			if (this.mouthOpenness < 0.0F) {
				this.mouthOpenness = 0.0F;
			}
		}
	}

	private void openHorseMouth() {
		if (!this.world.isStatic) {
			this.openMouthCounter = 1;
			this.setHorseWatchableBoolean(128, true);
		}
	}

	private boolean func_110200_cJ() {
		return this.passenger == null && this.vehicle == null && this.isTame() && this.isAdultHorse()
				&& !this.func_110222_cv() && this.getHealth() >= this.getMaxHealth();
	}

	public void setEating(boolean par1) {
		this.setHorseWatchableBoolean(32, par1);
	}

	public void setEatingHaystack(boolean par1) {
		this.setEating(par1);
	}

	public void setRearing(boolean par1) {
		if (par1) {
			this.setEatingHaystack(false);
		}

		this.setHorseWatchableBoolean(64, par1);
	}

	private void makeHorseRear() {
		if (!this.world.isStatic) {
			this.jumpRearingCounter = 1;
			this.setRearing(true);
		}
	}

	public void makeHorseRearWithSound() {
		this.makeHorseRear();
		String var1 = this.getAngrySoundName();

		if (var1 != null) {
			this.makeSound(var1, this.getSoundVolume(), this.getSoundPitch());
		}
	}

	public void dropChestItems() {
		this.a(this, this.inventoryChest);
		this.dropChests();
	}

	private void a(Entity entity, InventoryHorseChest inventoryhorsechest) {
		if (inventoryhorsechest != null && !this.world.isStatic) {
			for (int i = 0; i < inventoryhorsechest.getSize(); ++i) {
				ItemStack itemstack = inventoryhorsechest.getItem(i);

				if (itemstack != null) {
					this.entityDropItem(itemstack, 0.0F);
				}
			}
		}
	}

	public boolean g(EntityHuman entityhuman) {
		this.setOwnerName(entityhuman.getName());
		this.setTame(true);
		return true;
	}

	/**
	 * Moves the entity based on the specified heading. Args: strafe, forward
	 */
	public void moveEntityWithHeading(float par1, float par2) {
		if (this.passenger != null && this.isHorseSaddled()) {
			this.lastYaw = this.yaw = this.passenger.yaw;
			this.pitch = this.passenger.pitch * 0.5F;
			this.setRotation(this.yaw, this.pitch);
			this.rotationYawHead = this.renderYawOffset = this.yaw;
			par1 = ((EntityLiving) this.passenger).moveStrafing * 0.5F;
			par2 = ((EntityLiving) this.passenger).moveForward;

			if (par2 <= 0.0F) {
				par2 *= 0.25F;
				this.field_110285_bP = 0;
			}

			if (this.onGround && this.jumpPower == 0.0F && this.isRearing() && !this.field_110294_bI) {
				par1 = 0.0F;
				par2 = 0.0F;
			}

			if (this.jumpPower > 0.0F && !this.isHorseJumping() && this.onGround) {
				this.motY = this.getJumpStrength() * (double) this.jumpPower;

				if (this.hasEffect(MobEffectList.JUMP)) {
					this.motY += (double) ((float) (this.getEffect(MobEffectList.JUMP).getAmplifier() + 1) * 0.1F);
				}

				this.setHorseJumping(true);
				this.isAirBorne = true;

				if (par2 > 0.0F) {
					float var3 = MathHelper.sin(this.yaw * (float) Math.PI / 180.0F);
					float var4 = MathHelper.cos(this.yaw * (float) Math.PI / 180.0F);
					this.motX += (double) (-0.4F * var3 * this.jumpPower);
					this.motZ += (double) (0.4F * var4 * this.jumpPower);
					this.makeSound("mob.horse.jump", 0.4F, 1.0F);
				}

				this.jumpPower = 0.0F;
			}

			this.stepHeight = 1.0F;
			this.jumpMovementFactor = this.getAIMoveSpeed() * 0.1F;

			if (!this.world.isStatic) {
				this.setAIMoveSpeed((float) this.getAttributeInstance(GenericAttributes.d).getValue());
				super.moveEntityWithHeading(par1, par2);
			}

			if (this.onGround) {
				this.jumpPower = 0.0F;
				this.setHorseJumping(false);
			}

			this.prevLimbSwingAmount = this.limbSwingAmount;
			double var5 = this.locX - this.lastX;
			double var7 = this.locZ - this.lastZ;
			float var9 = MathHelper.sqrt(var5 * var5 + var7 * var7) * 4.0F;

			if (var9 > 1.0F) {
				var9 = 1.0F;
			}

			this.limbSwingAmount += (var9 - this.limbSwingAmount) * 0.4F;
			this.limbSwing += this.limbSwingAmount;
		} else {
			this.stepHeight = 0.5F;
			this.jumpMovementFactor = 0.02F;
			super.moveEntityWithHeading(par1, par2);
		}
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setBoolean("EatingHaystack", this.isEatingHaystack());
		par1NBTTagCompound.setBoolean("ChestedHorse", this.hasChest());
		par1NBTTagCompound.setBoolean("HasReproduced", this.getHasReproduced());
		par1NBTTagCompound.setBoolean("Bred", this.func_110205_ce());
		par1NBTTagCompound.setInt("Type", this.getType());
		par1NBTTagCompound.setInt("Variant", this.getVariant());
		par1NBTTagCompound.setInt("Temper", this.getTemper());
		par1NBTTagCompound.setBoolean("Tame", this.isTame());
		par1NBTTagCompound.setString("OwnerName", this.getOwnerName());
		par1NBTTagCompound.setInt("Bukkit.MaxDomestication", this.maxDomestication);

		if (this.hasChest()) {
			NBTTagList var2 = new NBTTagList();

			for (int var3 = 2; var3 < this.inventoryChest.getSize(); ++var3) {
				ItemStack var4 = this.inventoryChest.getItem(var3);

				if (var4 != null) {
					NBTTagCompound var5 = new NBTTagCompound();
					var5.setByte("Slot", (byte) var3);
					var4.save(var5);
					var2.add(var5);
				}
			}

			par1NBTTagCompound.set("Items", var2);
		}

		if (this.inventoryChest.getItem(1) != null) {
			par1NBTTagCompound.set("ArmorItem", this.inventoryChest.getItem(1).save(new NBTTagCompound("ArmorItem")));
		}

		if (this.inventoryChest.getItem(0) != null) {
			par1NBTTagCompound.set("SaddleItem", this.inventoryChest.getItem(0).save(new NBTTagCompound("SaddleItem")));
		}
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.setEatingHaystack(par1NBTTagCompound.getBoolean("EatingHaystack"));
		this.func_110242_l(par1NBTTagCompound.getBoolean("Bred"));
		this.setHasChest(par1NBTTagCompound.getBoolean("ChestedHorse"));
		this.setHasReproduced(par1NBTTagCompound.getBoolean("HasReproduced"));
		this.setType(par1NBTTagCompound.getInt("Type"));
		this.setVariant(par1NBTTagCompound.getInt("Variant"));
		this.setTemper(par1NBTTagCompound.getInt("Temper"));
		this.setTame(par1NBTTagCompound.getBoolean("Tame"));

		if (par1NBTTagCompound.hasKey("OwnerName")) {
			this.setOwnerName(par1NBTTagCompound.getString("OwnerName"));
		}

		if (par1NBTTagCompound.hasKey("Bukkit.MaxDomestication")) {
			this.maxDomestication = par1NBTTagCompound.getInt("Bukkit.MaxDomestication");
		}

		AttributeInstance var2 = this.getAttributeMap().a("Speed");

		if (var2 != null) {
			this.getAttributeInstance(GenericAttributes.d).setValue(var2.getBaseValue() * 0.25D);
		}

		if (this.hasChest()) {
			NBTTagList var3 = par1NBTTagCompound.getList("Items");
			this.loadChest();

			for (int var4 = 0; var4 < var3.size(); ++var4) {
				NBTTagCompound var5 = (NBTTagCompound) var3.get(var4);
				int var6 = var5.getByte("Slot") & 255;

				if (var6 >= 2 && var6 < this.inventoryChest.getSize()) {
					this.inventoryChest.setItem(var6, ItemStack.createStack(var5));
				}
			}
		}

		ItemStack var7;

		if (par1NBTTagCompound.hasKey("ArmorItem")) {
			var7 = ItemStack.createStack(par1NBTTagCompound.getCompound("ArmorItem"));

			if (var7 != null && func_110211_v(var7.id)) {
				this.inventoryChest.setItem(1, var7);
			}
		}

		if (par1NBTTagCompound.hasKey("SaddleItem")) {
			var7 = ItemStack.createStack(par1NBTTagCompound.getCompound("SaddleItem"));

			if (var7 != null && var7.id == Item.SADDLE.id) {
				this.inventoryChest.setItem(0, var7);
			}
		} else if (par1NBTTagCompound.getBoolean("Saddle")) {
			this.inventoryChest.setItem(0, new ItemStack(Item.SADDLE));
		}

		this.func_110232_cE();
	}

	public boolean mate(EntityAnimal entityanimal) {
		if (entityanimal == this) {
			return false;
		} else if (entityanimal.getClass() != this.getClass()) {
			return false;
		} else {
			EntityHorse entityhorse = (EntityHorse) entityanimal;

			if (this.func_110200_cJ() && entityhorse.func_110200_cJ()) {
				int i = this.getType();
				int j = entityhorse.getType();
				return i == j || i == 0 && j == 1 || i == 1 && j == 0;
			} else {
				return false;
			}
		}
	}

	public EntityAgeable createChild(EntityAgeable entityageable) {
		EntityHorse entityhorse = (EntityHorse) entityageable;
		EntityHorse entityhorse1 = new EntityHorse(this.world);
		int i = this.getType();
		int j = entityhorse.getType();
		int k = 0;

		if (i == j) {
			k = i;
		} else if (i == 0 && j == 1 || i == 1 && j == 0) {
			k = 2;
		}

		if (k == 0) {
			int l = this.random.nextInt(9);
			int i1;

			if (l < 4) {
				i1 = this.getVariant() & 255;
			} else if (l < 8) {
				i1 = entityhorse.getVariant() & 255;
			} else {
				i1 = this.random.nextInt(7);
			}

			int j1 = this.random.nextInt(5);

			if (j1 < 4) {
				i1 |= this.getVariant() & 65280;
			} else if (j1 < 8) {
				i1 |= entityhorse.getVariant() & 65280;
			} else {
				i1 |= this.random.nextInt(5) << 8 & 65280;
			}

			entityhorse1.setVariant(i1);
		}

		entityhorse1.setType(k);
		double d0 = this.getAttributeInstance(GenericAttributes.a).getBaseValue()
				+ entityageable.getAttributeInstance(GenericAttributes.a).getBaseValue()
				+ (double) this.func_110267_cL();
		entityhorse1.getAttributeInstance(GenericAttributes.a).setValue(d0 / 3.0D);
		double d1 = this.getAttributeInstance(attributeJumpStrength).getBaseValue()
				+ entityageable.getAttributeInstance(attributeJumpStrength).getBaseValue() + this.func_110245_cM();
		entityhorse1.getAttributeInstance(attributeJumpStrength).setValue(d1 / 3.0D);
		double d2 = this.getAttributeInstance(GenericAttributes.d).getBaseValue()
				+ entityageable.getAttributeInstance(GenericAttributes.d).getBaseValue() + this.func_110203_cN();
		entityhorse1.getAttributeInstance(GenericAttributes.d).setValue(d2 / 3.0D);
		return entityhorse1;
	}

	public GroupDataEntity a(GroupDataEntity groupdataentity) {
		Object object = super.a(groupdataentity);
		boolean flag = false;
		int i = 0;
		int j;

		if (object instanceof GroupDataHorse) {
			j = ((GroupDataHorse) object).a;
			i = ((GroupDataHorse) object).b & 255 | this.random.nextInt(5) << 8;
		} else {
			if (this.random.nextInt(10) == 0) {
				j = 1;
			} else {
				int k = this.random.nextInt(7);
				int l = this.random.nextInt(5);
				j = 0;
				i = k | l << 8;
			}

			object = new GroupDataHorse(j, i);
		}

		this.setType(j);
		this.setVariant(i);

		if (this.random.nextInt(5) == 0) {
			this.setAge(-24000);
		}

		if (j != 4 && j != 3) {
			this.getAttributeInstance(GenericAttributes.a).setValue((double) this.func_110267_cL());

			if (j == 0) {
				this.getAttributeInstance(GenericAttributes.d).setValue(this.func_110203_cN());
			} else {
				this.getAttributeInstance(GenericAttributes.d).setValue(0.17499999701976776D);
			}
		} else {
			this.getAttributeInstance(GenericAttributes.a).setValue(15.0D);
			this.getAttributeInstance(GenericAttributes.d).setValue(0.20000000298023224D);
		}

		if (j != 2 && j != 1) {
			this.getAttributeInstance(attributeJumpStrength).setValue(this.func_110245_cM());
		} else {
			this.getAttributeInstance(attributeJumpStrength).setValue(0.5D);
		}

		this.setHealth(this.getMaxHealth());
		return (GroupDataEntity) object;
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	protected boolean isAIEnabled() {
		return true;
	}

	public void setJumpPower(int par1) {
		if (this.isHorseSaddled()) {
			if (par1 < 0) {
				par1 = 0;
			}

			float var2;

			if (par1 >= 90) {
				var2 = 1.0F;
			} else {
				var2 = 0.4F + 0.4F * (float) par1 / 90.0F;
			}

			HorseJumpEvent var3 = CraftEventFactory.callHorseJumpEvent(this, var2);

			if (!var3.isCancelled()) {
				this.field_110294_bI = true;
				this.makeHorseRear();
				this.jumpPower = var3.getPower();
			}
		}
	}

	public void updateRiderPosition() {
		super.updateRiderPosition();

		if (this.prevRearingAmount > 0.0F) {
			float var1 = MathHelper.sin(this.renderYawOffset * (float) Math.PI / 180.0F);
			float var2 = MathHelper.cos(this.renderYawOffset * (float) Math.PI / 180.0F);
			float var3 = 0.7F * this.prevRearingAmount;
			float var4 = 0.15F * this.prevRearingAmount;
			this.passenger.setPosition(this.locX + (double) (var3 * var1),
					this.locY + this.getMountedYOffset() + this.passenger.getYOffset() + (double) var4,
					this.locZ - (double) (var3 * var2));

			if (this.passenger instanceof EntityLiving) {
				((EntityLiving) this.passenger).renderYawOffset = this.renderYawOffset;
			}
		}
	}

	private float func_110267_cL() {
		return 15.0F + (float) this.random.nextInt(8) + (float) this.random.nextInt(9);
	}

	private double func_110245_cM() {
		return 0.4000000059604645D + this.random.nextDouble() * 0.2D + this.random.nextDouble() * 0.2D
				+ this.random.nextDouble() * 0.2D;
	}

	private double func_110203_cN() {
		return (0.44999998807907104D + this.random.nextDouble() * 0.3D + this.random.nextDouble() * 0.3D
				+ this.random.nextDouble() * 0.3D) * 0.25D;
	}

	public static boolean func_110211_v(int par0) {
		return par0 == Item.HORSE_ARMOR_IRON.id || par0 == Item.HORSE_ARMOR_GOLD.id
				|| par0 == Item.HORSE_ARMOR_DIAMOND.id;
	}

	/**
	 * returns true if this entity is by a ladder, false otherwise
	 */
	public boolean isOnLadder() {
		return false;
	}
}
