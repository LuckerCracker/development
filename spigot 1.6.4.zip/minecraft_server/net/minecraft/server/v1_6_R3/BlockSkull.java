package net.minecraft.server.v1_6_R3;

import java.util.Random;

import org.bukkit.craftbukkit.v1_6_R3.util.BlockStateListPopulator;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class BlockSkull extends BlockContainer {
	protected BlockSkull(int par1) {
		super(par1, Material.ORIENTABLE);
		this.setBlockBounds(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
	}

	/**
	 * The type of render function that is called for this block
	 */
	public int getRenderType() {
		return -1;
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube? This determines whether
	 * or not to render the shared face of two adjacent blocks and also whether
	 * the player can attach torches, redstone wire, etc to this block.
	 */
	public boolean isOpaqueCube() {
		return false;
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False
	 * (examples: signs, buttons, stairs, etc)
	 */
	public boolean renderAsNormalBlock() {
		return false;
	}

	public void updateShape(IBlockAccess iblockaccess, int i, int j, int k) {
		int l = iblockaccess.getData(i, j, k) & 7;

		switch (l) {
		case 1:
		default:
			this.setBlockBounds(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
			break;

		case 2:
			this.setBlockBounds(0.25F, 0.25F, 0.5F, 0.75F, 0.75F, 1.0F);
			break;

		case 3:
			this.setBlockBounds(0.25F, 0.25F, 0.0F, 0.75F, 0.75F, 0.5F);
			break;

		case 4:
			this.setBlockBounds(0.5F, 0.25F, 0.25F, 1.0F, 0.75F, 0.75F);
			break;

		case 5:
			this.setBlockBounds(0.0F, 0.25F, 0.25F, 0.5F, 0.75F, 0.75F);
		}
	}

	/**
	 * Returns a bounding box from the pool of bounding boxes (this means this
	 * box can change after the pool has been cleared to be reused)
	 */
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4) {
		this.updateShape(par1World, par2, par3, par4);
		return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
	}

	public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack) {
		int l = MathHelper.floor((double) (entityliving.yaw * 4.0F / 360.0F) + 2.5D) & 3;
		world.setData(i, j, k, l, 2);
	}

	/**
	 * Returns a new instance of a block's tile entity class. Called on placing
	 * the block.
	 */
	public TileEntity createNewTileEntity(World par1World) {
		return new TileEntitySkull();
	}

	public int getDropData(World world, int i, int j, int k) {
		TileEntity tileentity = world.getTileEntity(i, j, k);
		return tileentity != null && tileentity instanceof TileEntitySkull
				? ((TileEntitySkull) tileentity).getSkullType() : super.getDropData(world, i, j, k);
	}

	public int getDropData(int i) {
		return i;
	}

	public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1) {
		if (world.random.nextFloat() < f) {
			ItemStack itemstack = new ItemStack(Item.SKULL.id, 1, this.getDropData(world, i, j, k));
			TileEntitySkull tileentityskull = (TileEntitySkull) world.getTileEntity(i, j, k);

			if (tileentityskull.getSkullType() == 3 && tileentityskull.getExtraType() != null
					&& tileentityskull.getExtraType().length() > 0) {
				itemstack.setTag(new NBTTagCompound());
				itemstack.getTag().setString("SkullOwner", tileentityskull.getExtraType());
			}

			this.dropBlockAsItem_do(world, i, j, k, itemstack);
		}
	}

	public void a(World world, int i, int j, int k, int l, EntityHuman entityhuman) {
		if (entityhuman.abilities.canInstantlyBuild) {
			l |= 8;
			world.setData(i, j, k, l, 4);
		}

		super.a(world, i, j, k, l, entityhuman);
	}

	public void remove(World world, int i, int j, int k, int l, int i1) {
		if (!world.isStatic) {
			super.remove(world, i, j, k, l, i1);
		}
	}

	public int getDropType(int i, Random random, int j) {
		return Item.SKULL.id;
	}

	/**
	 * This method attempts to create a wither at the given location and skull
	 */
	public void makeWither(World par1World, int par2, int par3, int par4, TileEntitySkull par5TileEntitySkull) {
		if (par5TileEntitySkull.getSkullType() == 1 && par3 >= 2 && par1World.difficulty > 0 && !par1World.isStatic) {
			int var6 = Block.SOUL_SAND.id;
			int var7;
			BlockStateListPopulator var8;
			EntityWither var9;
			int var10;

			for (var7 = -2; var7 <= 0; ++var7) {
				if (par1World.getTypeId(par2, par3 - 1, par4 + var7) == var6
						&& par1World.getTypeId(par2, par3 - 1, par4 + var7 + 1) == var6
						&& par1World.getTypeId(par2, par3 - 2, par4 + var7 + 1) == var6
						&& par1World.getTypeId(par2, par3 - 1, par4 + var7 + 2) == var6
						&& this.func_82528_d(par1World, par2, par3, par4 + var7, 1)
						&& this.func_82528_d(par1World, par2, par3, par4 + var7 + 1, 1)
						&& this.func_82528_d(par1World, par2, par3, par4 + var7 + 2, 1)) {
					var8 = new BlockStateListPopulator(par1World.getWorld());
					par1World.setData(par2, par3, par4 + var7, 8, 2);
					par1World.setData(par2, par3, par4 + var7 + 1, 8, 2);
					par1World.setData(par2, par3, par4 + var7 + 2, 8, 2);
					var8.setTypeId(par2, par3, par4 + var7, 0);
					var8.setTypeId(par2, par3, par4 + var7 + 1, 0);
					var8.setTypeId(par2, par3, par4 + var7 + 2, 0);
					var8.setTypeId(par2, par3 - 1, par4 + var7, 0);
					var8.setTypeId(par2, par3 - 1, par4 + var7 + 1, 0);
					var8.setTypeId(par2, par3 - 1, par4 + var7 + 2, 0);
					var8.setTypeId(par2, par3 - 2, par4 + var7 + 1, 0);

					if (!par1World.isStatic) {
						var9 = new EntityWither(par1World);
						var9.setPositionRotation((double) par2 + 0.5D, (double) par3 - 1.45D,
								(double) (par4 + var7) + 1.5D, 90.0F, 0.0F);
						var9.renderYawOffset = 90.0F;
						var9.func_82206_m();

						if (par1World.addEntity(var9, CreatureSpawnEvent.SpawnReason.BUILD_WITHER)) {
							var8.updateList();
						}
					}

					for (var10 = 0; var10 < 120; ++var10) {
						par1World.addParticle("snowballpoof", (double) par2 + par1World.random.nextDouble(),
								(double) (par3 - 2) + par1World.random.nextDouble() * 3.9D,
								(double) (par4 + var7 + 1) + par1World.random.nextDouble(), 0.0D, 0.0D, 0.0D);
					}

					return;
				}
			}

			for (var7 = -2; var7 <= 0; ++var7) {
				if (par1World.getTypeId(par2 + var7, par3 - 1, par4) == var6
						&& par1World.getTypeId(par2 + var7 + 1, par3 - 1, par4) == var6
						&& par1World.getTypeId(par2 + var7 + 1, par3 - 2, par4) == var6
						&& par1World.getTypeId(par2 + var7 + 2, par3 - 1, par4) == var6
						&& this.func_82528_d(par1World, par2 + var7, par3, par4, 1)
						&& this.func_82528_d(par1World, par2 + var7 + 1, par3, par4, 1)
						&& this.func_82528_d(par1World, par2 + var7 + 2, par3, par4, 1)) {
					var8 = new BlockStateListPopulator(par1World.getWorld());
					par1World.setData(par2 + var7, par3, par4, 8, 2);
					par1World.setData(par2 + var7 + 1, par3, par4, 8, 2);
					par1World.setData(par2 + var7 + 2, par3, par4, 8, 2);
					var8.setTypeId(par2 + var7, par3, par4, 0);
					var8.setTypeId(par2 + var7 + 1, par3, par4, 0);
					var8.setTypeId(par2 + var7 + 2, par3, par4, 0);
					var8.setTypeId(par2 + var7, par3 - 1, par4, 0);
					var8.setTypeId(par2 + var7 + 1, par3 - 1, par4, 0);
					var8.setTypeId(par2 + var7 + 2, par3 - 1, par4, 0);
					var8.setTypeId(par2 + var7 + 1, par3 - 2, par4, 0);

					if (!par1World.isStatic) {
						var9 = new EntityWither(par1World);
						var9.setPositionRotation((double) (par2 + var7) + 1.5D, (double) par3 - 1.45D,
								(double) par4 + 0.5D, 0.0F, 0.0F);
						var9.func_82206_m();

						if (par1World.addEntity(var9, CreatureSpawnEvent.SpawnReason.BUILD_WITHER)) {
							var8.updateList();
						}
					}

					for (var10 = 0; var10 < 120; ++var10) {
						par1World.addParticle("snowballpoof",
								(double) (par2 + var7 + 1) + par1World.random.nextDouble(),
								(double) (par3 - 2) + par1World.random.nextDouble() * 3.9D,
								(double) par4 + par1World.random.nextDouble(), 0.0D, 0.0D, 0.0D);
					}

					return;
				}
			}
		}
	}

	private boolean func_82528_d(World par1World, int par2, int par3, int par4, int par5) {
		if (par1World.getTypeId(par2, par3, par4) != this.id) {
			return false;
		} else {
			TileEntity var6 = par1World.getTileEntity(par2, par3, par4);
			return var6 != null && var6 instanceof TileEntitySkull ? ((TileEntitySkull) var6).getSkullType() == par5
					: false;
		}
	}
}
