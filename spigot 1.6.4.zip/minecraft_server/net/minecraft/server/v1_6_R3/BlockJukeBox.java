package net.minecraft.server.v1_6_R3;

public class BlockJukeBox extends BlockContainer
{
    protected BlockJukeBox(int par1)
    {
        super(par1, Material.WOOD);
        this.a(CreativeModeTab.c);
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.getData(var2, var3, var4) == 0)
        {
            return false;
        }
        else
        {
            this.dropRecord(var1, var2, var3, var4);
            return true;
        }
    }

    /**
     * Insert the specified music disc in the jukebox at the given coordinates
     */
    public void insertRecord(World par1World, int par2, int par3, int par4, ItemStack par5ItemStack)
    {
        if (!par1World.isStatic)
        {
            TileEntityRecordPlayer var6 = (TileEntityRecordPlayer)par1World.getTileEntity(par2, par3, par4);

            if (var6 != null)
            {
                var6.setRecord(par5ItemStack.cloneItemStack());
                par1World.setData(par2, par3, par4, 1, 2);
            }
        }
    }

    public void dropRecord(World var1, int var2, int var3, int var4)
    {
        if (!var1.isStatic)
        {
            TileEntityRecordPlayer var5 = (TileEntityRecordPlayer)var1.getTileEntity(var2, var3, var4);

            if (var5 != null)
            {
                ItemStack var6 = var5.getRecord();

                if (var6 != null)
                {
                    var1.triggerEffect(1005, var2, var3, var4, 0);
                    var1.playRecord((String)null, var2, var3, var4);
                    var5.setRecord((ItemStack)null);
                    var1.setData(var2, var3, var4, 0, 2);
                    float var7 = 0.7F;
                    double var8 = (double)(var1.random.nextFloat() * var7) + (double)(1.0F - var7) * 0.5D;
                    double var10 = (double)(var1.random.nextFloat() * var7) + (double)(1.0F - var7) * 0.2D + 0.6D;
                    double var12 = (double)(var1.random.nextFloat() * var7) + (double)(1.0F - var7) * 0.5D;
                    ItemStack var14 = var6.cloneItemStack();
                    EntityItem var15 = new EntityItem(var1, (double)var2 + var8, (double)var3 + var10, (double)var4 + var12, var14);
                    var15.pickupDelay = 10;
                    var1.addEntity(var15);
                }
            }
        }
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        this.dropRecord(var1, var2, var3, var4);
        super.remove(var1, var2, var3, var4, var5, var6);
    }

    public void dropNaturally(World var1, int var2, int var3, int var4, int var5, float var6, int var7)
    {
        if (!var1.isStatic)
        {
            super.dropNaturally(var1, var2, var3, var4, var5, var6, 0);
        }
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityRecordPlayer();
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        ItemStack var6 = ((TileEntityRecordPlayer)par1World.getTileEntity(par2, par3, par4)).getRecord();
        return var6 == null ? 0 : var6.id + 1 - Item.RECORD_1.id;
    }
}
