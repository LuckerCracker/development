package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockVine extends Block
{
    public BlockVine(int par1)
    {
        super(par1, Material.REPLACEABLE_PLANT);
        this.setTickRandomly(true);
        this.a(CreativeModeTab.c);
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 20;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        float f = 0.0625F;
        int l = iblockaccess.getData(i, j, k);
        float f1 = 1.0F;
        float f2 = 1.0F;
        float f3 = 1.0F;
        float f4 = 0.0F;
        float f5 = 0.0F;
        float f6 = 0.0F;
        boolean flag = l > 0;

        if ((l & 2) != 0)
        {
            f4 = Math.max(f4, 0.0625F);
            f1 = 0.0F;
            f2 = 0.0F;
            f5 = 1.0F;
            f3 = 0.0F;
            f6 = 1.0F;
            flag = true;
        }

        if ((l & 8) != 0)
        {
            f1 = Math.min(f1, 0.9375F);
            f4 = 1.0F;
            f2 = 0.0F;
            f5 = 1.0F;
            f3 = 0.0F;
            f6 = 1.0F;
            flag = true;
        }

        if ((l & 4) != 0)
        {
            f6 = Math.max(f6, 0.0625F);
            f3 = 0.0F;
            f1 = 0.0F;
            f4 = 1.0F;
            f2 = 0.0F;
            f5 = 1.0F;
            flag = true;
        }

        if ((l & 1) != 0)
        {
            f3 = Math.min(f3, 0.9375F);
            f6 = 1.0F;
            f1 = 0.0F;
            f4 = 1.0F;
            f2 = 0.0F;
            f5 = 1.0F;
            flag = true;
        }

        if (!flag && this.canBePlacedOn(iblockaccess.getTypeId(i, j + 1, k)))
        {
            f2 = Math.min(f2, 0.9375F);
            f5 = 1.0F;
            f1 = 0.0F;
            f4 = 1.0F;
            f3 = 0.0F;
            f6 = 1.0F;
        }

        this.setBlockBounds(f1, f2, f3, f4, f5, f6);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return null;
    }

    public boolean canPlace(World world, int i, int j, int k, int l)
    {
        switch (l)
        {
            case 1:
                return this.canBePlacedOn(world.getTypeId(i, j + 1, k));

            case 2:
                return this.canBePlacedOn(world.getTypeId(i, j, k + 1));

            case 3:
                return this.canBePlacedOn(world.getTypeId(i, j, k - 1));

            case 4:
                return this.canBePlacedOn(world.getTypeId(i + 1, j, k));

            case 5:
                return this.canBePlacedOn(world.getTypeId(i - 1, j, k));

            default:
                return false;
        }
    }

    /**
     * returns true if a vine can be placed on that block (checks for render as normal block and if it is solid)
     */
    private boolean canBePlacedOn(int par1)
    {
        if (par1 == 0)
        {
            return false;
        }
        else
        {
            Block var2 = Block.byId[par1];
            return var2.renderAsNormalBlock() && var2.material.isSolid();
        }
    }

    /**
     * Returns if the vine can stay in the world. It also changes the metadata according to neighboring blocks.
     */
    private boolean canVineStay(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4);
        int var6 = var5;

        if (var5 > 0)
        {
            for (int var7 = 0; var7 <= 3; ++var7)
            {
                int var8 = 1 << var7;

                if ((var5 & var8) != 0 && !this.canBePlacedOn(par1World.getTypeId(par2 + Direction.offsetX[var7], par3, par4 + Direction.offsetZ[var7])) && (par1World.getTypeId(par2, par3 + 1, par4) != this.id || (par1World.getData(par2, par3 + 1, par4) & var8) == 0))
                {
                    var6 &= ~var8;
                }
            }
        }

        if (var6 == 0 && !this.canBePlacedOn(par1World.getTypeId(par2, par3 + 1, par4)))
        {
            return false;
        }
        else
        {
            if (var6 != var5)
            {
                par1World.setData(par2, par3, par4, var6, 2);
            }

            return true;
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (!world.isStatic && !this.canVineStay(world, i, j, k))
        {
            this.dropBlockAsItem(world, i, j, k, world.getData(i, j, k), 0);
            world.setAir(i, j, k);
        }
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (!par1World.isStatic && par1World.random.nextInt(4) == 0)
        {
            byte var6 = 4;
            int var7 = 5;
            boolean var8 = false;
            int var9;
            int var10;
            int var11;
            label135:

            for (var9 = par2 - var6; var9 <= par2 + var6; ++var9)
            {
                for (var10 = par4 - var6; var10 <= par4 + var6; ++var10)
                {
                    for (var11 = par3 - 1; var11 <= par3 + 1; ++var11)
                    {
                        if (par1World.getTypeId(var9, var11, var10) == this.id)
                        {
                            --var7;

                            if (var7 <= 0)
                            {
                                var8 = true;
                                break label135;
                            }
                        }
                    }
                }
            }

            var9 = par1World.getData(par2, par3, par4);
            var10 = par1World.random.nextInt(6);
            var11 = Direction.facingToDirection[var10];
            int var12;
            int var13;
            org.bukkit.block.Block var15;

            if (var10 == 1 && par3 < 255 && par1World.isEmpty(par2, par3 + 1, par4))
            {
                if (var8)
                {
                    return;
                }

                var12 = par1World.random.nextInt(16) & var9;

                if (var12 > 0)
                {
                    for (var13 = 0; var13 <= 3; ++var13)
                    {
                        if (!this.canBePlacedOn(par1World.getTypeId(par2 + Direction.offsetX[var13], par3 + 1, par4 + Direction.offsetZ[var13])))
                        {
                            var12 &= ~(1 << var13);
                        }
                    }

                    if (var12 > 0)
                    {
                        org.bukkit.block.Block var17 = par1World.getWorld().getBlockAt(par2, par3, par4);
                        var15 = par1World.getWorld().getBlockAt(par2, par3 + 1, par4);
                        CraftEventFactory.handleBlockSpreadEvent(var15, var17, this.id, var12);
                    }
                }
            }
            else
            {
                int var14;
                org.bukkit.block.Block var16;

                if (var10 >= 2 && var10 <= 5 && (var9 & 1 << var11) == 0)
                {
                    if (var8)
                    {
                        return;
                    }

                    var12 = par1World.getTypeId(par2 + Direction.offsetX[var11], par3, par4 + Direction.offsetZ[var11]);

                    if (var12 != 0 && Block.byId[var12] != null)
                    {
                        if (Block.byId[var12].material.isOpaque() && Block.byId[var12].renderAsNormalBlock())
                        {
                            par1World.setData(par2, par3, par4, var9 | 1 << var11, 2);
                        }
                    }
                    else
                    {
                        var13 = var11 + 1 & 3;
                        var14 = var11 + 3 & 3;
                        var15 = par1World.getWorld().getBlockAt(par2, par3, par4);
                        var16 = par1World.getWorld().getBlockAt(par2 + Direction.offsetX[var11], par3, par4 + Direction.offsetZ[var11]);

                        if ((var9 & 1 << var13) != 0 && this.canBePlacedOn(par1World.getTypeId(par2 + Direction.offsetX[var11] + Direction.offsetX[var13], par3, par4 + Direction.offsetZ[var11] + Direction.offsetZ[var13])))
                        {
                            CraftEventFactory.handleBlockSpreadEvent(var16, var15, this.id, 1 << var13);
                        }
                        else if ((var9 & 1 << var14) != 0 && this.canBePlacedOn(par1World.getTypeId(par2 + Direction.offsetX[var11] + Direction.offsetX[var14], par3, par4 + Direction.offsetZ[var11] + Direction.offsetZ[var14])))
                        {
                            CraftEventFactory.handleBlockSpreadEvent(var16, var15, this.id, 1 << var14);
                        }
                        else if ((var9 & 1 << var13) != 0 && par1World.isEmpty(par2 + Direction.offsetX[var11] + Direction.offsetX[var13], par3, par4 + Direction.offsetZ[var11] + Direction.offsetZ[var13]) && this.canBePlacedOn(par1World.getTypeId(par2 + Direction.offsetX[var13], par3, par4 + Direction.offsetZ[var13])))
                        {
                            var16 = par1World.getWorld().getBlockAt(par2 + Direction.offsetX[var11] + Direction.offsetX[var13], par3, par4 + Direction.offsetZ[var11] + Direction.offsetZ[var13]);
                            CraftEventFactory.handleBlockSpreadEvent(var16, var15, this.id, 1 << (var11 + 2 & 3));
                        }
                        else if ((var9 & 1 << var14) != 0 && par1World.isEmpty(par2 + Direction.offsetX[var11] + Direction.offsetX[var14], par3, par4 + Direction.offsetZ[var11] + Direction.offsetZ[var14]) && this.canBePlacedOn(par1World.getTypeId(par2 + Direction.offsetX[var14], par3, par4 + Direction.offsetZ[var14])))
                        {
                            var16 = par1World.getWorld().getBlockAt(par2 + Direction.offsetX[var11] + Direction.offsetX[var14], par3, par4 + Direction.offsetZ[var11] + Direction.offsetZ[var14]);
                            CraftEventFactory.handleBlockSpreadEvent(var16, var15, this.id, 1 << (var11 + 2 & 3));
                        }
                        else if (this.canBePlacedOn(par1World.getTypeId(par2 + Direction.offsetX[var11], par3 + 1, par4 + Direction.offsetZ[var11])))
                        {
                            CraftEventFactory.handleBlockSpreadEvent(var16, var15, this.id, 0);
                        }
                    }
                }
                else if (par3 > 1)
                {
                    var12 = par1World.getTypeId(par2, par3 - 1, par4);

                    if (var12 == 0)
                    {
                        var13 = par1World.random.nextInt(16) & var9;

                        if (var13 > 0)
                        {
                            var15 = par1World.getWorld().getBlockAt(par2, par3, par4);
                            var16 = par1World.getWorld().getBlockAt(par2, par3 - 1, par4);
                            CraftEventFactory.handleBlockSpreadEvent(var16, var15, this.id, var13);
                        }
                    }
                    else if (var12 == this.id)
                    {
                        var13 = par1World.random.nextInt(16) & var9;
                        var14 = par1World.getData(par2, par3 - 1, par4);

                        if (var14 != (var14 | var13))
                        {
                            par1World.setData(par2, par3 - 1, par4, var14 | var13, 2);
                        }
                    }
                }
            }
        }
    }

    public int getPlacedData(World world, int i, int j, int k, int l, float f, float f1, float f2, int i1)
    {
        byte b0 = 0;

        switch (l)
        {
            case 2:
                b0 = 1;
                break;

            case 3:
                b0 = 4;
                break;

            case 4:
                b0 = 8;
                break;

            case 5:
                b0 = 2;
        }

        return b0 != 0 ? b0 : i1;
    }

    public int getDropType(int i, Random random, int j)
    {
        return 0;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 0;
    }

    public void a(World world, EntityHuman entityhuman, int i, int j, int k, int l)
    {
        if (!world.isStatic && entityhuman.getCurrentEquippedItem() != null && entityhuman.getCurrentEquippedItem().id == Item.SHEARS.id)
        {
            entityhuman.addStat(StatisticList.C[this.id], 1);
            this.dropBlockAsItem_do(world, i, j, k, new ItemStack(Block.VINE, 1, 0));
        }
        else
        {
            super.a(world, entityhuman, i, j, k, l);
        }
    }
}
