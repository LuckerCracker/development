package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockFurnace extends BlockContainer
{
    /**
     * Is the random generator used by furnace to drop the inventory contents in random directions.
     */
    private final Random furnaceRand = new Random();

    /** True if this is an active furnace, false if idle */
    private final boolean isActive;

    /**
     * This flag is used to prevent the furnace inventory to be dropped upon block removal, is used internally when the
     * furnace block changes from idle to active and vice-versa.
     */
    private static boolean keepFurnaceInventory;

    protected BlockFurnace(int par1, boolean par2)
    {
        super(par1, Material.STONE);
        this.isActive = par2;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Block.FURNACE.id;
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        super.onPlace(var1, var2, var3, var4);
        this.setDefaultDirection(var1, var2, var3, var4);
    }

    /**
     * set a blocks direction
     */
    private void setDefaultDirection(World par1World, int par2, int par3, int par4)
    {
        if (!par1World.isStatic)
        {
            int var5 = par1World.getTypeId(par2, par3, par4 - 1);
            int var6 = par1World.getTypeId(par2, par3, par4 + 1);
            int var7 = par1World.getTypeId(par2 - 1, par3, par4);
            int var8 = par1World.getTypeId(par2 + 1, par3, par4);
            byte var9 = 3;

            if (Block.opaqueCubeLookup[var5] && !Block.opaqueCubeLookup[var6])
            {
                var9 = 3;
            }

            if (Block.opaqueCubeLookup[var6] && !Block.opaqueCubeLookup[var5])
            {
                var9 = 2;
            }

            if (Block.opaqueCubeLookup[var7] && !Block.opaqueCubeLookup[var8])
            {
                var9 = 5;
            }

            if (Block.opaqueCubeLookup[var8] && !Block.opaqueCubeLookup[var7])
            {
                var9 = 4;
            }

            par1World.setData(par2, par3, par4, var9, 2);
        }
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            TileEntityFurnace var10 = (TileEntityFurnace)var1.getTileEntity(var2, var3, var4);

            if (var10 != null)
            {
                var5.openFurnace(var10);
            }

            return true;
        }
    }

    /**
     * Update which block ID the furnace is using depending on whether or not it is burning
     */
    public static void updateFurnaceBlockState(boolean par0, World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4);
        TileEntity var6 = par1World.getTileEntity(par2, par3, par4);
        keepFurnaceInventory = true;

        if (par0)
        {
            par1World.setTypeIdUpdate(par2, par3, par4, Block.BURNING_FURNACE.id);
        }
        else
        {
            par1World.setTypeIdUpdate(par2, par3, par4, Block.FURNACE.id);
        }

        keepFurnaceInventory = false;
        par1World.setData(par2, par3, par4, var5, 2);

        if (var6 != null)
        {
            var6.validate();
            par1World.setTileEntity(par2, par3, par4, var6);
        }
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityFurnace();
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        int var7 = MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3;

        if (var7 == 0)
        {
            var1.setData(var2, var3, var4, 2, 2);
        }

        if (var7 == 1)
        {
            var1.setData(var2, var3, var4, 5, 2);
        }

        if (var7 == 2)
        {
            var1.setData(var2, var3, var4, 3, 2);
        }

        if (var7 == 3)
        {
            var1.setData(var2, var3, var4, 4, 2);
        }

        if (var6.hasName())
        {
            ((TileEntityFurnace)var1.getTileEntity(var2, var3, var4)).setGuiDisplayName(var6.getName());
        }
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        if (!keepFurnaceInventory)
        {
            TileEntityFurnace var7 = (TileEntityFurnace)var1.getTileEntity(var2, var3, var4);

            if (var7 != null)
            {
                for (int var8 = 0; var8 < var7.getSize(); ++var8)
                {
                    ItemStack var9 = var7.getItem(var8);

                    if (var9 != null)
                    {
                        float var10 = this.furnaceRand.nextFloat() * 0.8F + 0.1F;
                        float var11 = this.furnaceRand.nextFloat() * 0.8F + 0.1F;
                        float var12 = this.furnaceRand.nextFloat() * 0.8F + 0.1F;

                        while (var9.count > 0)
                        {
                            int var13 = this.furnaceRand.nextInt(21) + 10;

                            if (var13 > var9.count)
                            {
                                var13 = var9.count;
                            }

                            var9.count -= var13;
                            EntityItem var14 = new EntityItem(var1, (double)((float)var2 + var10), (double)((float)var3 + var11), (double)((float)var4 + var12), new ItemStack(var9.id, var13, var9.getData()));

                            if (var9.hasTag())
                            {
                                var14.getItemStack().setTag((NBTTagCompound)var9.getTag().clone());
                            }

                            float var15 = 0.05F;
                            var14.motX = (double)((float)this.furnaceRand.nextGaussian() * var15);
                            var14.motY = (double)((float)this.furnaceRand.nextGaussian() * var15 + 0.2F);
                            var14.motZ = (double)((float)this.furnaceRand.nextGaussian() * var15);
                            var1.addEntity(var14);
                        }
                    }
                }

                var1.func_96440_m(var2, var3, var4, var5);
            }
        }

        super.remove(var1, var2, var3, var4, var5, var6);
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        return Container.calcRedstoneFromInventory((IInventory)par1World.getTileEntity(par2, par3, par4));
    }
}
