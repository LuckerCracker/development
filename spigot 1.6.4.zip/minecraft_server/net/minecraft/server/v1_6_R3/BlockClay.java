package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockClay extends Block
{
    public BlockClay(int par1)
    {
        super(par1, Material.CLAY);
        this.a(CreativeModeTab.b);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Item.CLAY_BALL.id;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 4;
    }
}
