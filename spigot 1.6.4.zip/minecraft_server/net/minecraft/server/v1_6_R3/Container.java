package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftHumanEntity;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.Event;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryView;

public abstract class Container {
	/** the list of all items(stacks) for the corresponding slot */
	public List inventoryItemStacks = new ArrayList();

	/** the list of all slots in the inventory */
	public List inventorySlots = new ArrayList();
	public int windowId;
	private int field_94535_f = -1;
	public int field_94536_g;
	private final Set field_94537_h = new HashSet();
	protected List listeners = new ArrayList();
	private Set playerList = new HashSet();
	public boolean checkReachable = true;

	public abstract InventoryView getBukkitView();

	public void transferTo(Container other, CraftHumanEntity player) {
		InventoryView source = this.getBukkitView();
		InventoryView destination = other.getBukkitView();
		((CraftInventory) source.getTopInventory()).getInventory().onClose(player);
		((CraftInventory) source.getBottomInventory()).getInventory().onClose(player);
		((CraftInventory) destination.getTopInventory()).getInventory().onOpen(player);
		((CraftInventory) destination.getBottomInventory()).getInventory().onOpen(player);
	}

	/**
	 * Adds an item slot to this container
	 */
	protected Slot addSlotToContainer(Slot par1Slot) {
		par1Slot.slotNumber = this.inventorySlots.size();
		this.inventorySlots.add(par1Slot);
		this.inventoryItemStacks.add((Object) null);
		return par1Slot;
	}

	public void addSlotListener(ICrafting icrafting) {
		if (this.listeners.contains(icrafting)) {
			throw new IllegalArgumentException("Listener already listening");
		} else {
			this.listeners.add(icrafting);
			icrafting.updateCraftingInventory(this, this.getInventory());
			this.detectAndSendChanges();
		}
	}

	/**
	 * returns a list if itemStacks, for each slot.
	 */
	public List getInventory() {
		ArrayList var1 = new ArrayList();

		for (int var2 = 0; var2 < this.inventorySlots.size(); ++var2) {
			var1.add(((Slot) this.inventorySlots.get(var2)).getItem());
		}

		return var1;
	}

	/**
	 * Looks for changes made in the container, sends them to every listener.
	 */
	public void detectAndSendChanges() {
		for (int var1 = 0; var1 < this.inventorySlots.size(); ++var1) {
			ItemStack var2 = ((Slot) this.inventorySlots.get(var1)).getItem();
			ItemStack var3 = (ItemStack) this.inventoryItemStacks.get(var1);

			if (!ItemStack.matches(var3, var2)) {
				var3 = var2 == null ? null : var2.cloneItemStack();
				this.inventoryItemStacks.set(var1, var3);

				for (int var4 = 0; var4 < this.listeners.size(); ++var4) {
					((ICrafting) this.listeners.get(var4)).sendSlotContents(this, var1, var3);
				}
			}
		}
	}

	public boolean a(EntityHuman entityhuman, int i) {
		return false;
	}

	public Slot getSlotFromInventory(IInventory par1IInventory, int par2) {
		for (int var3 = 0; var3 < this.inventorySlots.size(); ++var3) {
			Slot var4 = (Slot) this.inventorySlots.get(var3);

			if (var4.isHere(par1IInventory, par2)) {
				return var4;
			}
		}

		return null;
	}

	public Slot getSlot(int i) {
		return (Slot) this.inventorySlots.get(i);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		Slot slot = (Slot) this.inventorySlots.get(i);
		return slot != null ? slot.getItem() : null;
	}

	public ItemStack clickItem(int i, int j, int k, EntityHuman entityhuman) {
		ItemStack itemstack = null;
		PlayerInventory playerinventory = entityhuman.inventory;
		ItemStack itemstack1;
		int l;

		if (k == 5) {
			int slot2 = this.field_94536_g;
			this.field_94536_g = func_94532_c(j);

			if ((slot2 != 1 || this.field_94536_g != 2) && slot2 != this.field_94536_g) {
				this.func_94533_d();
			} else if (playerinventory.getCarried() == null) {
				this.func_94533_d();
			} else if (this.field_94536_g == 0) {
				this.field_94535_f = func_94529_b(j);

				if (func_94528_d(this.field_94535_f)) {
					this.field_94536_g = 1;
					this.field_94537_h.clear();
				} else {
					this.func_94533_d();
				}
			} else if (this.field_94536_g == 1) {
				Slot k1 = (Slot) this.inventorySlots.get(i);

				if (k1 != null && func_94527_a(k1, playerinventory.getCarried(), true)
						&& k1.isAllowed(playerinventory.getCarried())
						&& playerinventory.getCarried().count > this.field_94537_h.size() && this.canDragIntoSlot(k1)) {
					this.field_94537_h.add(k1);
				}
			} else if (this.field_94536_g == 2) {
				if (!this.field_94537_h.isEmpty()) {
					itemstack1 = playerinventory.getCarried().cloneItemStack();
					l = playerinventory.getCarried().count;
					Iterator var21 = this.field_94537_h.iterator();
					HashMap itemstack3 = new HashMap();

					while (var21.hasNext()) {
						Slot l1 = (Slot) var21.next();

						if (l1 != null && func_94527_a(l1, playerinventory.getCarried(), true)
								&& l1.isAllowed(playerinventory.getCarried())
								&& playerinventory.getCarried().count >= this.field_94537_h.size()
								&& this.canDragIntoSlot(l1)) {
							ItemStack i2 = itemstack1.cloneItemStack();
							int slot3 = l1.getHasStack() ? l1.getItem().count : 0;
							func_94525_a(this.field_94537_h, this.field_94535_f, i2, slot3);

							if (i2.count > i2.getMaxStackSize()) {
								i2.count = i2.getMaxStackSize();
							}

							if (i2.count > l1.getSlotStackLimit()) {
								i2.count = l1.getSlotStackLimit();
							}

							l -= i2.count - slot3;
							itemstack3.put(Integer.valueOf(l1.slotNumber), i2);
						}
					}

					InventoryView var24 = this.getBukkitView();
					CraftItemStack var27 = CraftItemStack.asCraftMirror(itemstack1);
					var27.setAmount(l);
					HashMap var30 = new HashMap();
					Iterator j2 = itemstack3.entrySet().iterator();

					while (j2.hasNext()) {
						Entry itemstack5 = (Entry) j2.next();
						var30.put(itemstack5.getKey(), CraftItemStack.asBukkitCopy((ItemStack) itemstack5.getValue()));
					}

					ItemStack var32 = playerinventory.getCarried();
					playerinventory.setCarried(CraftItemStack.asNMSCopy(var27));
					InventoryDragEvent var34 = new InventoryDragEvent(var24,
							var27.getType() != org.bukkit.Material.AIR ? var27 : null,
							CraftItemStack.asBukkitCopy(var32), this.field_94535_f == 1, var30);
					entityhuman.world.getServer().getPluginManager().callEvent(var34);
					boolean needsUpdate = var34.getResult() != Event.Result.DEFAULT;

					if (var34.getResult() != Event.Result.DENY) {
						Iterator i$ = itemstack3.entrySet().iterator();

						while (i$.hasNext()) {
							Entry dslot = (Entry) i$.next();
							var24.setItem(((Integer) dslot.getKey()).intValue(),
									CraftItemStack.asBukkitCopy((ItemStack) dslot.getValue()));
						}

						if (playerinventory.getCarried() != null) {
							playerinventory.setCarried(CraftItemStack.asNMSCopy(var34.getCursor()));
							needsUpdate = true;
						}
					} else {
						playerinventory.setCarried(var32);
					}

					if (needsUpdate && entityhuman instanceof EntityPlayer) {
						((EntityPlayer) entityhuman).updateInventory(this);
					}
				}

				this.func_94533_d();
			} else {
				this.func_94533_d();
			}
		} else if (this.field_94536_g != 0) {
			this.func_94533_d();
		} else {
			Slot var20;
			int var22;
			ItemStack var23;

			if ((k == 0 || k == 1) && (j == 0 || j == 1)) {
				ItemStack var29;

				if (i == -999) {
					if (playerinventory.getCarried() != null && i == -999) {
						if (j == 0) {
							entityhuman.drop(playerinventory.getCarried());
							playerinventory.setCarried((ItemStack) null);
						}

						if (j == 1) {
							var29 = playerinventory.getCarried();

							if (var29.count > 0) {
								entityhuman.drop(var29.splitStack(1));
							}

							if (var29.count == 0) {
								playerinventory.setCarried((ItemStack) null);
							}
						}
					}
				} else if (k == 1) {
					if (i < 0) {
						return null;
					}

					var20 = (Slot) this.inventorySlots.get(i);

					if (var20 != null && var20.a(entityhuman)) {
						itemstack1 = this.b(entityhuman, i);

						if (itemstack1 != null) {
							l = itemstack1.id;
							itemstack = itemstack1.cloneItemStack();

							if (var20 != null && var20.getItem() != null && var20.getItem().id == l) {
								this.a(i, j, true, entityhuman);
							}
						}
					}
				} else {
					if (i < 0) {
						return null;
					}

					var20 = (Slot) this.inventorySlots.get(i);

					if (var20 != null) {
						itemstack1 = var20.getItem();
						var29 = playerinventory.getCarried();

						if (itemstack1 != null) {
							itemstack = itemstack1.cloneItemStack();
						}

						if (itemstack1 == null) {
							if (var29 != null && var20.isAllowed(var29)) {
								var22 = j == 0 ? var29.count : 1;

								if (var22 > var20.getSlotStackLimit()) {
									var22 = var20.getSlotStackLimit();
								}

								if (var29.count >= var22) {
									var20.set(var29.splitStack(var22));
								}

								if (var29.count == 0) {
									playerinventory.setCarried((ItemStack) null);
								}
							}
						} else if (var20.a(entityhuman)) {
							if (var29 == null) {
								var22 = j == 0 ? itemstack1.count : (itemstack1.count + 1) / 2;
								var23 = var20.decrStackSize(var22);
								playerinventory.setCarried(var23);

								if (itemstack1.count == 0) {
									var20.set((ItemStack) null);
								}

								var20.a(entityhuman, playerinventory.getCarried());
							} else if (var20.isAllowed(var29)) {
								if (itemstack1.id == var29.id && itemstack1.getData() == var29.getData()
										&& ItemStack.equals(itemstack1, var29)) {
									var22 = j == 0 ? var29.count : 1;

									if (var22 > var20.getSlotStackLimit() - itemstack1.count) {
										var22 = var20.getSlotStackLimit() - itemstack1.count;
									}

									if (var22 > var29.getMaxStackSize() - itemstack1.count) {
										var22 = var29.getMaxStackSize() - itemstack1.count;
									}

									var29.splitStack(var22);

									if (var29.count == 0) {
										playerinventory.setCarried((ItemStack) null);
									}

									itemstack1.count += var22;
								} else if (var29.count <= var20.getSlotStackLimit()) {
									var20.set(var29);
									playerinventory.setCarried(itemstack1);
								}
							} else if (itemstack1.id == var29.id && var29.getMaxStackSize() > 1
									&& (!itemstack1.usesData() || itemstack1.getData() == var29.getData())
									&& ItemStack.equals(itemstack1, var29)) {
								var22 = itemstack1.count;

								if (var22 > 0 && var22 + var29.count <= var29.getMaxStackSize()) {
									var29.count += var22;
									itemstack1 = var20.decrStackSize(var22);

									if (itemstack1.count == 0) {
										var20.set((ItemStack) null);
									}

									var20.a(entityhuman, playerinventory.getCarried());
								}
							}
						}

						var20.onSlotChanged();
					}
				}
			} else if (k == 2 && j >= 0 && j < 9) {
				var20 = (Slot) this.inventorySlots.get(i);

				if (var20.a(entityhuman)) {
					itemstack1 = playerinventory.getItem(j);
					boolean var26 = itemstack1 == null
							|| var20.inventory == playerinventory && var20.isAllowed(itemstack1);
					var22 = -1;

					if (!var26) {
						var22 = playerinventory.j();
						var26 |= var22 > -1;
					}

					if (var20.getHasStack() && var26) {
						var23 = var20.getItem();
						playerinventory.setItem(j, var23.cloneItemStack());

						if ((var20.inventory != playerinventory || !var20.isAllowed(itemstack1))
								&& itemstack1 != null) {
							if (var22 > -1) {
								playerinventory.pickup(itemstack1);
								var20.decrStackSize(var23.count);
								var20.set((ItemStack) null);
								var20.a(entityhuman, var23);
							}
						} else {
							var20.decrStackSize(var23.count);
							var20.set(itemstack1);
							var20.a(entityhuman, var23);
						}
					} else if (!var20.getHasStack() && itemstack1 != null && var20.isAllowed(itemstack1)) {
						playerinventory.setItem(j, (ItemStack) null);
						var20.set(itemstack1);
					}
				}
			} else if (k == 3 && entityhuman.abilities.canInstantlyBuild && playerinventory.getCarried() == null
					&& i >= 0) {
				var20 = (Slot) this.inventorySlots.get(i);

				if (var20 != null && var20.getHasStack()) {
					itemstack1 = var20.getItem().cloneItemStack();
					itemstack1.count = itemstack1.getMaxStackSize();
					playerinventory.setCarried(itemstack1);
				}
			} else if (k == 4 && playerinventory.getCarried() == null && i >= 0) {
				var20 = (Slot) this.inventorySlots.get(i);

				if (var20 != null && var20.getHasStack() && var20.a(entityhuman)) {
					itemstack1 = var20.decrStackSize(j == 0 ? 1 : var20.getItem().count);
					var20.a(entityhuman, itemstack1);
					entityhuman.drop(itemstack1);
				}
			} else if (k == 6 && i >= 0) {
				var20 = (Slot) this.inventorySlots.get(i);
				itemstack1 = playerinventory.getCarried();

				if (itemstack1 != null && (var20 == null || !var20.getHasStack() || !var20.a(entityhuman))) {
					l = j == 0 ? 0 : this.inventorySlots.size() - 1;
					var22 = j == 0 ? 1 : -1;

					for (int var25 = 0; var25 < 2; ++var25) {
						for (int var28 = l; var28 >= 0 && var28 < this.inventorySlots.size()
								&& itemstack1.count < itemstack1.getMaxStackSize(); var28 += var22) {
							Slot var31 = (Slot) this.inventorySlots.get(var28);

							if (var31.getHasStack() && func_94527_a(var31, itemstack1, true) && var31.a(entityhuman)
									&& this.func_94530_a(itemstack1, var31)
									&& (var25 != 0 || var31.getItem().count != var31.getItem().getMaxStackSize())) {
								int var33 = Math.min(itemstack1.getMaxStackSize() - itemstack1.count,
										var31.getItem().count);
								ItemStack var35 = var31.decrStackSize(var33);
								itemstack1.count += var33;

								if (var35.count <= 0) {
									var31.set((ItemStack) null);
								}

								var31.a(entityhuman, var35);
							}
						}
					}
				}

				this.detectAndSendChanges();
			}
		}

		return itemstack;
	}

	public boolean func_94530_a(ItemStack par1ItemStack, Slot par2Slot) {
		return true;
	}

	protected void a(int i, int j, boolean flag, EntityHuman entityhuman) {
		this.clickItem(i, j, 1, entityhuman);
	}

	public void b(EntityHuman entityhuman) {
		PlayerInventory playerinventory = entityhuman.inventory;

		if (playerinventory.getCarried() != null) {
			entityhuman.drop(playerinventory.getCarried());
			playerinventory.setCarried((ItemStack) null);
		}
	}

	/**
	 * Callback for when the crafting matrix is changed.
	 */
	public void onCraftMatrixChanged(IInventory par1IInventory) {
		this.detectAndSendChanges();
	}

	public void setItem(int i, ItemStack itemstack) {
		this.getSlot(i).set(itemstack);
	}

	public boolean c(EntityHuman entityhuman) {
		return !this.playerList.contains(entityhuman);
	}

	public void a(EntityHuman entityhuman, boolean flag) {
		if (flag) {
			this.playerList.remove(entityhuman);
		} else {
			this.playerList.add(entityhuman);
		}
	}

	public abstract boolean a(EntityHuman var1);

	/**
	 * merges provided ItemStack with the first avaliable one in the
	 * container/player inventory
	 */
	protected boolean mergeItemStack(ItemStack par1ItemStack, int par2, int par3, boolean par4) {
		boolean var5 = false;
		int var6 = par2;

		if (par4) {
			var6 = par3 - 1;
		}

		Slot var7;
		ItemStack var8;

		if (par1ItemStack.isStackable()) {
			while (par1ItemStack.count > 0 && (!par4 && var6 < par3 || par4 && var6 >= par2)) {
				var7 = (Slot) this.inventorySlots.get(var6);
				var8 = var7.getItem();

				if (var8 != null && var8.id == par1ItemStack.id
						&& (!par1ItemStack.usesData() || par1ItemStack.getData() == var8.getData())
						&& ItemStack.equals(par1ItemStack, var8)) {
					int var9 = var8.count + par1ItemStack.count;

					if (var9 <= par1ItemStack.getMaxStackSize()) {
						par1ItemStack.count = 0;
						var8.count = var9;
						var7.onSlotChanged();
						var5 = true;
					} else if (var8.count < par1ItemStack.getMaxStackSize()) {
						par1ItemStack.count -= par1ItemStack.getMaxStackSize() - var8.count;
						var8.count = par1ItemStack.getMaxStackSize();
						var7.onSlotChanged();
						var5 = true;
					}
				}

				if (par4) {
					--var6;
				} else {
					++var6;
				}
			}
		}

		if (par1ItemStack.count > 0) {
			if (par4) {
				var6 = par3 - 1;
			} else {
				var6 = par2;
			}

			while (!par4 && var6 < par3 || par4 && var6 >= par2) {
				var7 = (Slot) this.inventorySlots.get(var6);
				var8 = var7.getItem();

				if (var8 == null) {
					var7.set(par1ItemStack.cloneItemStack());
					var7.onSlotChanged();
					par1ItemStack.count = 0;
					var5 = true;
					break;
				}

				if (par4) {
					--var6;
				} else {
					++var6;
				}
			}
		}

		return var5;
	}

	public static int func_94529_b(int par0) {
		return par0 >> 2 & 3;
	}

	public static int func_94532_c(int par0) {
		return par0 & 3;
	}

	public static boolean func_94528_d(int par0) {
		return par0 == 0 || par0 == 1;
	}

	protected void func_94533_d() {
		this.field_94536_g = 0;
		this.field_94537_h.clear();
	}

	public static boolean func_94527_a(Slot par0Slot, ItemStack par1ItemStack, boolean par2) {
		boolean var3 = par0Slot == null || !par0Slot.getHasStack();

		if (par0Slot != null && par0Slot.getHasStack() && par1ItemStack != null
				&& par1ItemStack.doMaterialsMatch(par0Slot.getItem())
				&& ItemStack.equals(par0Slot.getItem(), par1ItemStack)) {
			int var4 = par2 ? 0 : par1ItemStack.count;
			var3 |= par0Slot.getItem().count + var4 <= par1ItemStack.getMaxStackSize();
		}

		return var3;
	}

	public static void func_94525_a(Set par0Set, int par1, ItemStack par2ItemStack, int par3) {
		switch (par1) {
		case 0:
			par2ItemStack.count = MathHelper.floor_float((float) par2ItemStack.count / (float) par0Set.size());
			break;

		case 1:
			par2ItemStack.count = 1;
		}

		par2ItemStack.count += par3;
	}

	/**
	 * Returns true if the player can "drag-spilt" items into this slot,.
	 * returns true by default. Called to check if the slot can be added to a
	 * list of Slots to split the held ItemStack across.
	 */
	public boolean canDragIntoSlot(Slot par1Slot) {
		return true;
	}

	public static int calcRedstoneFromInventory(IInventory par0IInventory) {
		if (par0IInventory == null) {
			return 0;
		} else {
			int var1 = 0;
			float var2 = 0.0F;

			for (int var3 = 0; var3 < par0IInventory.getSize(); ++var3) {
				ItemStack var4 = par0IInventory.getItem(var3);

				if (var4 != null) {
					var2 += (float) var4.count
							/ (float) Math.min(par0IInventory.getMaxStackSize(), var4.getMaxStackSize());
					++var1;
				}
			}

			var2 /= (float) par0IInventory.getSize();
			return MathHelper.floor_float(var2 * 14.0F) + (var1 > 0 ? 1 : 0);
		}
	}
}
