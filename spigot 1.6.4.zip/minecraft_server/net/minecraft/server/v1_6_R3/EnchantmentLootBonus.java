package net.minecraft.server.v1_6_R3;

public class EnchantmentLootBonus extends Enchantment
{
    protected EnchantmentLootBonus(int var1, int var2, EnchantmentSlotType var3)
    {
        super(var1, var2, var3);
        this.setName("lootBonus");

        if (var3 == EnchantmentSlotType.DIGGER)
        {
            this.setName("lootBonusDigger");
        }
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int par1)
    {
        return 15 + (par1 - 1) * 9;
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int par1)
    {
        return super.getMinEnchantability(par1) + 50;
    }

    public int getMaxLevel()
    {
        return 3;
    }

    /**
     * Determines if the enchantment passed can be applyied together with this enchantment.
     */
    public boolean canApplyTogether(Enchantment par1Enchantment)
    {
        return super.canApplyTogether(par1Enchantment) && par1Enchantment.id != SILK_TOUCH.id;
    }
}
