package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryMerchant;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public class ContainerMerchant extends Container {
	private IMerchant merchant;
	private InventoryMerchant merchantInventory;

	/** Instance of World. */
	private final World theWorld;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity == null) {
			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(),
					new CraftInventoryMerchant(this.getMerchantInventory()), this);
		}

		return this.bukkitEntity;
	}

	public ContainerMerchant(PlayerInventory playerinventory, IMerchant imerchant, World world) {
		this.merchant = imerchant;
		this.theWorld = world;
		this.merchantInventory = new InventoryMerchant(playerinventory.player, imerchant);
		this.addSlotToContainer(new Slot(this.merchantInventory, 0, 36, 53));
		this.addSlotToContainer(new Slot(this.merchantInventory, 1, 62, 53));
		this.addSlotToContainer(
				new SlotMerchantResult(playerinventory.player, imerchant, this.merchantInventory, 2, 120, 53));
		this.player = playerinventory;
		int i;

		for (i = 0; i < 3; ++i) {
			for (int j = 0; j < 9; ++j) {
				this.addSlotToContainer(new Slot(playerinventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
			}
		}

		for (i = 0; i < 9; ++i) {
			this.addSlotToContainer(new Slot(playerinventory, i, 8 + i * 18, 142));
		}
	}

	public InventoryMerchant getMerchantInventory() {
		return this.merchantInventory;
	}

	public void addSlotListener(ICrafting icrafting) {
		super.addSlotListener(icrafting);
	}

	/**
	 * Looks for changes made in the container, sends them to every listener.
	 */
	public void detectAndSendChanges() {
		super.detectAndSendChanges();
	}

	/**
	 * Callback for when the crafting matrix is changed.
	 */
	public void onCraftMatrixChanged(IInventory par1IInventory) {
		this.merchantInventory.resetRecipeAndSlots();
		super.onCraftMatrixChanged(par1IInventory);
	}

	public void setCurrentRecipeIndex(int par1) {
		this.merchantInventory.setCurrentRecipeIndex(par1);
	}

	public boolean a(EntityHuman entityhuman) {
		return this.merchant.m_() == entityhuman;
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i == 2) {
				if (!this.mergeItemStack(itemstack1, 3, 39, true)) {
					return null;
				}

				slot.onSlotChange(itemstack1, itemstack);
			} else if (i != 0 && i != 1) {
				if (i >= 3 && i < 30) {
					if (!this.mergeItemStack(itemstack1, 30, 39, false)) {
						return null;
					}
				} else if (i >= 30 && i < 39 && !this.mergeItemStack(itemstack1, 3, 30, false)) {
					return null;
				}
			} else if (!this.mergeItemStack(itemstack1, 3, 39, false)) {
				return null;
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}

	public void b(EntityHuman entityhuman) {
		super.b(entityhuman);
		this.merchant.a_((EntityHuman) null);
		super.b(entityhuman);

		if (!this.theWorld.isStatic) {
			ItemStack itemstack = this.merchantInventory.splitWithoutUpdate(0);

			if (itemstack != null) {
				entityhuman.drop(itemstack);
			}

			itemstack = this.merchantInventory.splitWithoutUpdate(1);

			if (itemstack != null) {
				entityhuman.drop(itemstack);
			}
		}
	}
}
