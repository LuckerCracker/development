package net.minecraft.server.v1_6_R3;

public class CommandKill extends CommandAbstract
{
    public String getCommandName()
    {
        return "kill";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 0;
    }

    public String c(ICommandListener var1)
    {
        return "commands.kill.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        EntityPlayer var3 = b(var1);
        var3.attackEntityFrom(DamageSource.OUT_OF_WORLD, Float.MAX_VALUE);
        var1.sendMessage(ChatMessage.e("commands.kill.success"));
    }
}
