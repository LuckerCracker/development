package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandDeop extends CommandAbstract
{
    public String getCommandName()
    {
        return "deop";
    }

    public int a()
    {
        return 3;
    }

    public String c(ICommandListener var1)
    {
        return "commands.deop.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length == 1 && var2[0].length() > 0)
        {
            MinecraftServer.getServer().getPlayerList().removeOp(var2[0]);
            a(var1, "commands.deop.success", new Object[] {var2[0]});
        }
        else
        {
            throw new ExceptionUsage("commands.deop.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, MinecraftServer.getServer().getPlayerList().getOPs()) : null;
    }
}
