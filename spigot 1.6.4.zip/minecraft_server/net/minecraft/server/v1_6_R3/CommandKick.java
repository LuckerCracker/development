package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandKick extends CommandAbstract
{
    public String getCommandName()
    {
        return "kick";
    }

    public int a()
    {
        return 3;
    }

    public String c(ICommandListener var1)
    {
        return "commands.kick.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length > 0 && var2[0].length() > 1)
        {
            EntityPlayer var3 = MinecraftServer.getServer().getPlayerList().getPlayer(var2[0]);
            String var4 = "Kicked by an operator.";
            boolean var5 = false;

            if (var3 == null)
            {
                throw new ExceptionPlayerNotFound();
            }
            else
            {
                if (var2.length >= 2)
                {
                    var4 = a(var1, var2, 1);
                    var5 = true;
                }

                var3.playerConnection.disconnect(var4);

                if (var5)
                {
                    a(var1, "commands.kick.success.reason", new Object[] {var3.getLocalizedName(), var4});
                }
                else
                {
                    a(var1, "commands.kick.success", new Object[] {var3.getLocalizedName()});
                }
            }
        }
        else
        {
            throw new ExceptionUsage("commands.kick.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length >= 1 ? a(var2, MinecraftServer.getServer().getPlayers()) : null;
    }
}
