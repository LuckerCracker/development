package net.minecraft.server.v1_6_R3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;

public class BanEntry
{
    public static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z");
    private final String username;
    private Date banStartDate = new Date();
    private String bannedBy = "(Unknown)";
    private Date banEndDate;
    private String reason = "Banned by an operator.";

    public BanEntry(String par1Str)
    {
        this.username = par1Str;
    }

    public String getName()
    {
        return this.username;
    }

    public Date getCreated()
    {
        return this.banStartDate;
    }

    public void setCreated(Date var1)
    {
        this.banStartDate = var1 != null ? var1 : new Date();
    }

    public String getSource()
    {
        return this.bannedBy;
    }

    public void setSource(String var1)
    {
        this.bannedBy = var1;
    }

    public Date getExpires()
    {
        return this.banEndDate;
    }

    public void setExpires(Date var1)
    {
        this.banEndDate = var1;
    }

    public boolean hasExpired()
    {
        return this.banEndDate == null ? false : this.banEndDate.before(new Date());
    }

    public String getReason()
    {
        return this.reason;
    }

    public void setReason(String var1)
    {
        this.reason = var1;
    }

    public String buildBanString()
    {
        StringBuilder var1 = new StringBuilder();
        var1.append(this.getName());
        var1.append("|");
        var1.append(dateFormat.format(this.getCreated()));
        var1.append("|");
        var1.append(this.getSource());
        var1.append("|");
        var1.append(this.getExpires() == null ? "Forever" : dateFormat.format(this.getExpires()));
        var1.append("|");
        var1.append(this.getReason());
        return var1.toString();
    }

    public static BanEntry parse(String par0Str)
    {
        if (par0Str.trim().length() < 2)
        {
            return null;
        }
        else
        {
            String[] var1 = par0Str.trim().split(Pattern.quote("|"), 5);
            BanEntry var2 = new BanEntry(var1[0].trim());
            byte var3 = 0;
            int var10000 = var1.length;
            int var7 = var3 + 1;

            if (var10000 <= var7)
            {
                return var2;
            }
            else
            {
                try
                {
                    var2.setCreated(dateFormat.parse(var1[var7].trim()));
                }
                catch (ParseException var6)
                {
                    MinecraftServer.getServer().getLogger().warning("Could not read creation date format for ban entry \'" + var2.getName() + "\' (was: \'" + var1[var7] + "\')", (Throwable)var6);
                }

                var10000 = var1.length;
                ++var7;

                if (var10000 <= var7)
                {
                    return var2;
                }
                else
                {
                    var2.setSource(var1[var7].trim());
                    var10000 = var1.length;
                    ++var7;

                    if (var10000 <= var7)
                    {
                        return var2;
                    }
                    else
                    {
                        try
                        {
                            String var4 = var1[var7].trim();

                            if (!var4.equalsIgnoreCase("Forever") && var4.length() > 0)
                            {
                                var2.setExpires(dateFormat.parse(var4));
                            }
                        }
                        catch (ParseException var5)
                        {
                            MinecraftServer.getServer().getLogger().warning("Could not read expiry date format for ban entry \'" + var2.getName() + "\' (was: \'" + var1[var7] + "\')", (Throwable)var5);
                        }

                        var10000 = var1.length;
                        ++var7;

                        if (var10000 <= var7)
                        {
                            return var2;
                        }
                        else
                        {
                            var2.setReason(var1[var7].trim());
                            return var2;
                        }
                    }
                }
            }
        }
    }
}
