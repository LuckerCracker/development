package net.minecraft.server.v1_6_R3;

import org.bukkit.event.block.BlockRedstoneEvent;

public class BlockBloodStone extends Block
{
    public BlockBloodStone(int i)
    {
        super(i, Material.STONE);
        this.a(CreativeModeTab.b);
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (Block.byId[l] != null && Block.byId[l].isPowerSource())
        {
            org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
            int power = block.getBlockPower();
            BlockRedstoneEvent event = new BlockRedstoneEvent(block, power, power);
            world.getServer().getPluginManager().callEvent(event);
        }
    }
}
