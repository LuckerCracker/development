package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandGive extends CommandAbstract
{
    public String getCommandName()
    {
        return "give";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.give.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length >= 2)
        {
            EntityPlayer var3 = d(var1, var2[0]);
            int var4 = a(var1, var2[1], 1);
            int var5 = 1;
            int var6 = 0;

            if (Item.byId[var4] == null)
            {
                throw new ExceptionInvalidNumber("commands.give.notFound", new Object[] {Integer.valueOf(var4)});
            }
            else
            {
                if (var2.length >= 3)
                {
                    var5 = a(var1, var2[2], 1, 64);
                }

                if (var2.length >= 4)
                {
                    var6 = a(var1, var2[3]);
                }

                ItemStack var7 = new ItemStack(var4, var5, var6);
                EntityItem var8 = var3.drop(var7);
                var8.pickupDelay = 0;
                a(var1, "commands.give.success", new Object[] {Item.byId[var4].getItemStackDisplayName(var7), Integer.valueOf(var4), Integer.valueOf(var5), var3.getLocalizedName()});
            }
        }
        else
        {
            throw new ExceptionUsage("commands.give.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, this.getPlayers()) : null;
    }

    protected String[] getPlayers()
    {
        return MinecraftServer.getServer().getPlayers();
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] par1ArrayOfStr, int par2)
    {
        return par2 == 0;
    }
}
