package net.minecraft.server.v1_6_R3;

public class EntityDamageSource extends DamageSource
{
    protected Entity damageSourceEntity;

    public EntityDamageSource(String par1Str, Entity par2Entity)
    {
        super(par1Str);
        this.damageSourceEntity = par2Entity;
    }

    public Entity getEntity()
    {
        return this.damageSourceEntity;
    }

    public ChatMessage getLocalizedDeathMessage(EntityLiving var1)
    {
        ItemStack var2 = this.damageSourceEntity instanceof EntityLiving ? ((EntityLiving)this.damageSourceEntity).getHeldItem() : null;
        String var3 = "death.attack." + this.translationIndex;
        String var4 = var3 + ".item";
        return var2 != null && var2.hasName() && LocaleI18n.b(var4) ? ChatMessage.b(var4, new Object[] {var1.getScoreboardDisplayName(), this.damageSourceEntity.getScoreboardDisplayName(), var2.getName()}): ChatMessage.b(var3, new Object[] {var1.getScoreboardDisplayName(), this.damageSourceEntity.getScoreboardDisplayName()});
    }

    /**
     * Return whether this damage source will have its damage amount scaled based on the current difficulty.
     */
    public boolean isDifficultyScaled()
    {
        return this.damageSourceEntity != null && this.damageSourceEntity instanceof EntityLiving && !(this.damageSourceEntity instanceof EntityHuman);
    }
}
