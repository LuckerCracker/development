package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntityBlaze extends EntityMonster
{
    /** Random offset used in floating behaviour */
    private float heightOffset = 0.5F;

    /** ticks until heightOffset is randomized */
    private int heightOffsetUpdateTime;
    private int field_70846_g;

    public EntityBlaze(World par1World)
    {
        super(par1World);
        this.fireProof = true;
        this.experienceValue = 10;
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.e).setValue(6.0D);
    }

    protected void entityInit()
    {
        super.entityInit();
        this.datawatcher.addObject(16, new Byte((byte)0));
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return "mob.blaze.breathe";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.blaze.hit";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.blaze.death";
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float par1)
    {
        return 1.0F;
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
        if (!this.world.isStatic)
        {
            if (this.isWet())
            {
                this.attackEntityFrom(DamageSource.DROWN, 1.0F);
            }

            --this.heightOffsetUpdateTime;

            if (this.heightOffsetUpdateTime <= 0)
            {
                this.heightOffsetUpdateTime = 100;
                this.heightOffset = 0.5F + (float)this.random.nextGaussian() * 3.0F;
            }

            if (this.getEntityToAttack() != null && this.getEntityToAttack().locY + (double)this.getEntityToAttack().getHeadHeight() > this.locY + (double)this.getHeadHeight() + (double)this.heightOffset)
            {
                this.motY += (0.30000001192092896D - this.motY) * 0.30000001192092896D;
            }
        }

        if (this.random.nextInt(24) == 0)
        {
            this.world.makeSound(this.locX + 0.5D, this.locY + 0.5D, this.locZ + 0.5D, "fire.fire", 1.0F + this.random.nextFloat(), this.random.nextFloat() * 0.7F + 0.3F);
        }

        if (!this.onGround && this.motY < 0.0D)
        {
            this.motY *= 0.6D;
        }

        for (int var1 = 0; var1 < 2; ++var1)
        {
            this.world.addParticle("largesmoke", this.locX + (this.random.nextDouble() - 0.5D) * (double)this.width, this.locY + this.random.nextDouble() * (double)this.length, this.locZ + (this.random.nextDouble() - 0.5D) * (double)this.width, 0.0D, 0.0D, 0.0D);
        }

        super.onLivingUpdate();
    }

    /**
     * Basic mob attack. Default to touch of death in EntityCreature. Overridden by each mob to define their attack.
     */
    protected void attackEntity(Entity par1Entity, float par2)
    {
        if (this.attackTicks <= 0 && par2 < 2.0F && par1Entity.boundingBox.maxY > this.boundingBox.minY && par1Entity.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTicks = 20;
            this.attackEntityAsMob(par1Entity);
        }
        else if (par2 < 30.0F)
        {
            double var3 = par1Entity.locX - this.locX;
            double var5 = par1Entity.boundingBox.minY + (double)(par1Entity.length / 2.0F) - (this.locY + (double)(this.length / 2.0F));
            double var7 = par1Entity.locZ - this.locZ;

            if (this.attackTicks == 0)
            {
                ++this.field_70846_g;

                if (this.field_70846_g == 1)
                {
                    this.attackTicks = 60;
                    this.func_70844_e(true);
                }
                else if (this.field_70846_g <= 4)
                {
                    this.attackTicks = 6;
                }
                else
                {
                    this.attackTicks = 100;
                    this.field_70846_g = 0;
                    this.func_70844_e(false);
                }

                if (this.field_70846_g > 1)
                {
                    float var9 = MathHelper.sqrt_float(par2) * 0.5F;
                    this.world.a((EntityHuman)null, 1009, (int)this.locX, (int)this.locY, (int)this.locZ, 0);

                    for (int var10 = 0; var10 < 1; ++var10)
                    {
                        EntitySmallFireball var11 = new EntitySmallFireball(this.world, this, var3 + this.random.nextGaussian() * (double)var9, var5, var7 + this.random.nextGaussian() * (double)var9);
                        var11.locY = this.locY + (double)(this.length / 2.0F) + 0.5D;
                        this.world.addEntity(var11);
                    }
                }
            }

            this.yaw = (float)(Math.atan2(var7, var3) * 180.0D / Math.PI) - 90.0F;
            this.hasAttacked = true;
        }
    }

    /**
     * Called when the mob is falling. Calculates and applies fall damage.
     */
    protected void fall(float par1) {}

    protected int getLootId()
    {
        return Item.BLAZE_ROD.id;
    }

    public boolean isBurning()
    {
        return this.func_70845_n();
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        if (flag)
        {
            ArrayList loot = new ArrayList();
            int j = this.random.nextInt(2 + i);

            if (j > 0)
            {
                loot.add(new org.bukkit.inventory.ItemStack(Item.BLAZE_ROD.id, j));
            }

            CraftEventFactory.callEntityDeathEvent(this, loot);
        }
    }

    public boolean func_70845_n()
    {
        return (this.datawatcher.getByte(16) & 1) != 0;
    }

    public void func_70844_e(boolean par1)
    {
        byte var2 = this.datawatcher.getByte(16);

        if (par1)
        {
            var2 = (byte)(var2 | 1);
        }
        else
        {
            var2 &= -2;
        }

        this.datawatcher.watch(16, Byte.valueOf(var2));
    }

    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
    protected boolean isValidLightLevel()
    {
        return true;
    }
}
