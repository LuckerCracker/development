package net.minecraft.server.v1_6_R3;

public class BlockDirt extends Block
{
    protected BlockDirt(int par1)
    {
        super(par1, Material.EARTH);
        this.a(CreativeModeTab.b);
    }
}
