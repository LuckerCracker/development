package net.minecraft.server.v1_6_R3;

public class BlockCobbleWall extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    public static final String[] displayOnCreativeTab = new String[] {"normal", "mossy"};

    public BlockCobbleWall(int var1, Block var2)
    {
        super(var1, var2.material);
        this.setHardness(var2.strength);
        this.setResistance(var2.durability / 3.0F);
        this.setStepSound(var2.stepSound);
        this.a(CreativeModeTab.b);
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 32;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public boolean getBlocksMovement(IBlockAccess var1, int var2, int var3, int var4)
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        boolean var5 = this.d(var1, var2, var3, var4 - 1);
        boolean var6 = this.d(var1, var2, var3, var4 + 1);
        boolean var7 = this.d(var1, var2 - 1, var3, var4);
        boolean var8 = this.d(var1, var2 + 1, var3, var4);
        float var9 = 0.25F;
        float var10 = 0.75F;
        float var11 = 0.25F;
        float var12 = 0.75F;
        float var13 = 1.0F;

        if (var5)
        {
            var11 = 0.0F;
        }

        if (var6)
        {
            var12 = 1.0F;
        }

        if (var7)
        {
            var9 = 0.0F;
        }

        if (var8)
        {
            var10 = 1.0F;
        }

        if (var5 && var6 && !var7 && !var8)
        {
            var13 = 0.8125F;
            var9 = 0.3125F;
            var10 = 0.6875F;
        }
        else if (!var5 && !var6 && var7 && var8)
        {
            var13 = 0.8125F;
            var11 = 0.3125F;
            var12 = 0.6875F;
        }

        this.setBlockBounds(var9, 0.0F, var11, var10, var13, var12);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World var1, int var2, int var3, int var4)
    {
        this.updateShape(var1, var2, var3, var4);
        this.maxY = 1.5D;
        return super.getCollisionBoundingBoxFromPool(var1, var2, var3, var4);
    }

    public boolean d(IBlockAccess var1, int var2, int var3, int var4)
    {
        int var5 = var1.getTypeId(var2, var3, var4);

        if (var5 != this.id && var5 != Block.FENCE_GATE.id)
        {
            Block var6 = Block.byId[var5];
            return var6 != null && var6.material.isOpaque() && var6.renderAsNormalBlock() ? var6.material != Material.PUMPKIN : false;
        }
        else
        {
            return true;
        }
    }

    public int getDropData(int var1)
    {
        return var1;
    }
}
