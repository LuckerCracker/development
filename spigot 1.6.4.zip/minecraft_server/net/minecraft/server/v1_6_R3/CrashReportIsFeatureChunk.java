package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportIsFeatureChunk implements Callable
{
    final int a;

    final int b;

    final StructureGenerator c;

    CrashReportIsFeatureChunk(StructureGenerator var1, int var2, int var3)
    {
        this.c = var1;
        this.a = var2;
        this.b = var3;
    }

    public String a()
    {
        return this.c.a(this.a, this.b) ? "True" : "False";
    }

    public Object call()
    {
        return this.a();
    }
}
