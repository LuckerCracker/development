package net.minecraft.server.v1_6_R3;

public class BlockSponge extends Block
{
    protected BlockSponge(int par1)
    {
        super(par1, Material.SPONGE);
        this.a(CreativeModeTab.b);
    }
}
