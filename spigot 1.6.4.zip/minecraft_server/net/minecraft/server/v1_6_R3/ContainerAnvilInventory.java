package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftHumanEntity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryHolder;

public class ContainerAnvilInventory extends InventorySubcontainer
{
    final ContainerAnvil a;
    public List<HumanEntity> transaction = new ArrayList();
    public Player player;
    private int maxStack = 64;

    public ItemStack[] getContents()
    {
        return this.items;
    }

    public void onOpen(CraftHumanEntity who)
    {
        this.transaction.add(who);
    }

    public void onClose(CraftHumanEntity who)
    {
        this.transaction.remove(who);
    }

    public List<HumanEntity> getViewers()
    {
        return this.transaction;
    }

    public InventoryHolder getOwner()
    {
        return this.player;
    }

    public void setMaxStackSize(int size)
    {
        this.maxStack = size;
    }

    ContainerAnvilInventory(ContainerAnvil containeranvil, String s, boolean flag, int i)
    {
        super(s, flag, i);
        this.a = containeranvil;
        this.setMaxStackSize(1);
    }

    public void update()
    {
        super.update();
        this.a.onCraftMatrixChanged(this);
    }

    /**
     * Returns true if automation is allowed to insert the given stack (ignoring stack size) into the given slot.
     */
    public boolean isItemValidForSlot(int i, ItemStack itemstack)
    {
        return true;
    }
}
