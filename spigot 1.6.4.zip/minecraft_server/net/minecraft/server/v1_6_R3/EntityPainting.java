package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;

public class EntityPainting extends EntityHanging
{
    public EnumArt art;

    public EntityPainting(World par1World)
    {
        super(par1World);
        this.art = EnumArt.values()[this.random.nextInt(EnumArt.values().length)];
    }

    public EntityPainting(World par1World, int par2, int par3, int par4, int par5)
    {
        super(par1World, par2, par3, par4, par5);
        ArrayList var6 = new ArrayList();
        EnumArt[] var7 = EnumArt.values();
        int var8 = var7.length;

        for (int var9 = 0; var9 < var8; ++var9)
        {
            EnumArt var10 = var7[var9];
            this.art = var10;
            this.setDirection(par5);

            if (this.survives())
            {
                var6.add(var10);
            }
        }

        if (!var6.isEmpty())
        {
            this.art = (EnumArt)var6.get(this.random.nextInt(var6.size()));
        }

        this.setDirection(par5);
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        par1NBTTagCompound.setString("Motive", this.art.title);
        super.writeEntityToNBT(par1NBTTagCompound);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        String var2 = par1NBTTagCompound.getString("Motive");
        EnumArt[] var3 = EnumArt.values();
        int var4 = var3.length;

        for (int var5 = 0; var5 < var4; ++var5)
        {
            EnumArt var6 = var3[var5];

            if (var6.title.equals(var2))
            {
                this.art = var6;
            }
        }

        if (this.art == null)
        {
            this.art = EnumArt.KEBAB;
        }

        super.readEntityFromNBT(par1NBTTagCompound);
    }

    public int getWidthPixels()
    {
        return this.art.sizeX;
    }

    public int getHeightPixels()
    {
        return this.art.sizeY;
    }

    /**
     * Called when this entity is broken. Entity parameter may be null.
     */
    public void onBroken(Entity par1Entity)
    {
        if (par1Entity instanceof EntityHuman)
        {
            EntityHuman var2 = (EntityHuman)par1Entity;

            if (var2.abilities.canInstantlyBuild)
            {
                return;
            }
        }

        this.entityDropItem(new ItemStack(Item.PAINTING), 0.0F);
    }
}
