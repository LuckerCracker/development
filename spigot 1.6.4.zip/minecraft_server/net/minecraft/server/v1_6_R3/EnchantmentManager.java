package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class EnchantmentManager
{
    private static final Random random = new Random();
    private static final EnchantmentModifierProtection b = new EnchantmentModifierProtection((EmptyClass)null);
    private static final EnchantmentModifierDamage c = new EnchantmentModifierDamage((EmptyClass)null);

    public static int getEnchantmentLevel(int var0, ItemStack var1)
    {
        if (var1 == null)
        {
            return 0;
        }
        else
        {
            NBTTagList var2 = var1.getEnchantments();

            if (var2 == null)
            {
                return 0;
            }
            else
            {
                for (int var3 = 0; var3 < var2.size(); ++var3)
                {
                    short var4 = ((NBTTagCompound)var2.get(var3)).getShort("id");
                    short var5 = ((NBTTagCompound)var2.get(var3)).getShort("lvl");

                    if (var4 == var0)
                    {
                        return var5;
                    }
                }

                return 0;
            }
        }
    }

    public static Map a(ItemStack var0)
    {
        LinkedHashMap var1 = new LinkedHashMap();
        NBTTagList var2 = var0.id == Item.ENCHANTED_BOOK.id ? Item.ENCHANTED_BOOK.func_92110_g(var0) : var0.getEnchantments();

        if (var2 != null)
        {
            for (int var3 = 0; var3 < var2.size(); ++var3)
            {
                short var4 = ((NBTTagCompound)var2.get(var3)).getShort("id");
                short var5 = ((NBTTagCompound)var2.get(var3)).getShort("lvl");
                var1.put(Integer.valueOf(var4), Integer.valueOf(var5));
            }
        }

        return var1;
    }

    public static void a(Map var0, ItemStack var1)
    {
        NBTTagList var2 = new NBTTagList();
        Iterator var3 = var0.keySet().iterator();

        while (var3.hasNext())
        {
            int var4 = ((Integer)var3.next()).intValue();
            NBTTagCompound var5 = new NBTTagCompound();
            var5.setShort("id", (short)var4);
            var5.setShort("lvl", (short)((Integer)var0.get(Integer.valueOf(var4))).intValue());
            var2.add(var5);

            if (var1.id == Item.ENCHANTED_BOOK.id)
            {
                Item.ENCHANTED_BOOK.a(var1, new EnchantmentInstance(var4, ((Integer)var0.get(Integer.valueOf(var4))).intValue()));
            }
        }

        if (var2.size() > 0)
        {
            if (var1.id != Item.ENCHANTED_BOOK.id)
            {
                var1.setTagInfo("ench", var2);
            }
        }
        else if (var1.hasTag())
        {
            var1.getTag().remove("ench");
        }
    }

    public static int getEnchantmentLevel(int var0, ItemStack[] var1)
    {
        if (var1 == null)
        {
            return 0;
        }
        else
        {
            int var2 = 0;
            ItemStack[] var3 = var1;
            int var4 = var1.length;

            for (int var5 = 0; var5 < var4; ++var5)
            {
                ItemStack var6 = var3[var5];
                int var7 = getEnchantmentLevel(var0, var6);

                if (var7 > var2)
                {
                    var2 = var7;
                }
            }

            return var2;
        }
    }

    private static void a(EnchantmentModifier var0, ItemStack var1)
    {
        if (var1 != null)
        {
            NBTTagList var2 = var1.getEnchantments();

            if (var2 != null)
            {
                for (int var3 = 0; var3 < var2.size(); ++var3)
                {
                    short var4 = ((NBTTagCompound)var2.get(var3)).getShort("id");
                    short var5 = ((NBTTagCompound)var2.get(var3)).getShort("lvl");

                    if (Enchantment.byId[var4] != null)
                    {
                        var0.calculateModifier(Enchantment.byId[var4], var5);
                    }
                }
            }
        }
    }

    private static void a(EnchantmentModifier var0, ItemStack[] var1)
    {
        ItemStack[] var2 = var1;
        int var3 = var1.length;

        for (int var4 = 0; var4 < var3; ++var4)
        {
            ItemStack var5 = var2[var4];
            a(var0, var5);
        }
    }

    public static int a(ItemStack[] var0, DamageSource var1)
    {
        b.a = 0;
        b.b = var1;
        a((EnchantmentModifier)b, var0);

        if (b.a > 25)
        {
            b.a = 25;
        }

        return (b.a + 1 >> 1) + random.nextInt((b.a >> 1) + 1);
    }

    public static float a(EntityLiving var0, EntityLiving var1)
    {
        c.damageModifier = 0.0F;
        c.source = var1;
        a((EnchantmentModifier)c, var0.getHeldItem());
        return c.damageModifier;
    }

    public static int getKnockbackEnchantmentLevel(EntityLiving var0, EntityLiving var1)
    {
        return getEnchantmentLevel(Enchantment.KNOCKBACK.id, var0.getHeldItem());
    }

    public static int getFireAspectEnchantmentLevel(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.FIRE_ASPECT.id, var0.getHeldItem());
    }

    public static int getOxygenEnchantmentLevel(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.OXYGEN.id, var0.getEquipment());
    }

    public static int getDigSpeedEnchantmentLevel(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.DIG_SPEED.id, var0.getHeldItem());
    }

    public static boolean hasSilkTouchEnchantment(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.SILK_TOUCH.id, var0.getHeldItem()) > 0;
    }

    public static int getBonusBlockLootEnchantmentLevel(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS.id, var0.getHeldItem());
    }

    public static int getBonusMonsterLootEnchantmentLevel(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.LOOT_BONUS_MOBS.id, var0.getHeldItem());
    }

    public static boolean hasWaterWorkerEnchantment(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.WATER_WORKER.id, var0.getEquipment()) > 0;
    }

    public static int getThornsEnchantmentLevel(EntityLiving var0)
    {
        return getEnchantmentLevel(Enchantment.THORNS.id, var0.getEquipment());
    }

    public static ItemStack a(Enchantment var0, EntityLiving var1)
    {
        ItemStack[] var2 = var1.getEquipment();
        int var3 = var2.length;

        for (int var4 = 0; var4 < var3; ++var4)
        {
            ItemStack var5 = var2[var4];

            if (var5 != null && getEnchantmentLevel(var0.id, var5) > 0)
            {
                return var5;
            }
        }

        return null;
    }

    public static int a(Random var0, int var1, int var2, ItemStack var3)
    {
        Item var4 = var3.getItem();
        int var5 = var4.getItemEnchantability();

        if (var5 <= 0)
        {
            return 0;
        }
        else
        {
            if (var2 > 15)
            {
                var2 = 15;
            }

            int var6 = var0.nextInt(8) + 1 + (var2 >> 1) + var0.nextInt(var2 + 1);
            return var1 == 0 ? Math.max(var6 / 3, 1) : (var1 == 1 ? var6 * 2 / 3 + 1 : Math.max(var6, var2 * 2));
        }
    }

    public static ItemStack a(Random var0, ItemStack var1, int var2)
    {
        List var3 = b(var0, var1, var2);
        boolean var4 = var1.id == Item.BOOK.id;

        if (var4)
        {
            var1.id = Item.ENCHANTED_BOOK.id;
        }

        if (var3 != null)
        {
            Iterator var5 = var3.iterator();

            while (var5.hasNext())
            {
                EnchantmentInstance var6 = (EnchantmentInstance)var5.next();

                if (var4)
                {
                    Item.ENCHANTED_BOOK.a(var1, var6);
                }
                else
                {
                    var1.addEnchantment(var6.enchantment, var6.level);
                }
            }
        }

        return var1;
    }

    public static List b(Random var0, ItemStack var1, int var2)
    {
        Item var3 = var1.getItem();
        int var4 = var3.getItemEnchantability();

        if (var4 <= 0)
        {
            return null;
        }
        else
        {
            var4 /= 2;
            var4 = 1 + var0.nextInt((var4 >> 1) + 1) + var0.nextInt((var4 >> 1) + 1);
            int var5 = var4 + var2;
            float var6 = (var0.nextFloat() + var0.nextFloat() - 1.0F) * 0.15F;
            int var7 = (int)((float)var5 * (1.0F + var6) + 0.5F);

            if (var7 < 1)
            {
                var7 = 1;
            }

            ArrayList var8 = null;
            Map var9 = b(var7, var1);

            if (var9 != null && !var9.isEmpty())
            {
                EnchantmentInstance var10 = (EnchantmentInstance)WeightedRandom.a(var0, var9.values());

                if (var10 != null)
                {
                    var8 = new ArrayList();
                    var8.add(var10);

                    for (int var11 = var7; var0.nextInt(50) <= var11; var11 >>= 1)
                    {
                        Iterator var12 = var9.keySet().iterator();

                        while (var12.hasNext())
                        {
                            Integer var13 = (Integer)var12.next();
                            boolean var14 = true;
                            Iterator var15 = var8.iterator();

                            while (true)
                            {
                                if (var15.hasNext())
                                {
                                    EnchantmentInstance var16 = (EnchantmentInstance)var15.next();

                                    if (var16.enchantment.canApplyTogether(Enchantment.byId[var13.intValue()]))
                                    {
                                        continue;
                                    }

                                    var14 = false;
                                }

                                if (!var14)
                                {
                                    var12.remove();
                                }

                                break;
                            }
                        }

                        if (!var9.isEmpty())
                        {
                            EnchantmentInstance var17 = (EnchantmentInstance)WeightedRandom.a(var0, var9.values());
                            var8.add(var17);
                        }
                    }
                }
            }

            return var8;
        }
    }

    public static Map b(int var0, ItemStack var1)
    {
        Item var2 = var1.getItem();
        HashMap var3 = null;
        boolean var4 = var1.id == Item.BOOK.id;
        Enchantment[] var5 = Enchantment.byId;
        int var6 = var5.length;

        for (int var7 = 0; var7 < var6; ++var7)
        {
            Enchantment var8 = var5[var7];

            if (var8 != null && (var8.slot.canEnchant(var2) || var4))
            {
                for (int var9 = var8.getStartLevel(); var9 <= var8.getMaxLevel(); ++var9)
                {
                    if (var0 >= var8.getMinEnchantability(var9) && var0 <= var8.getMaxEnchantability(var9))
                    {
                        if (var3 == null)
                        {
                            var3 = new HashMap();
                        }

                        var3.put(Integer.valueOf(var8.id), new EnchantmentInstance(var8, var9));
                    }
                }
            }
        }

        return var3;
    }
}
