package net.minecraft.server.v1_6_R3;

public class ChunkCoordIntPair
{
    public final int x;
    public final int z;

    public ChunkCoordIntPair(int par1, int par2)
    {
        this.x = par1;
        this.z = par2;
    }

    /**
     * converts a chunk coordinate pair to an integer (suitable for hashing)
     */
    public static long chunkXZ2Int(int par0, int par1)
    {
        return (long)par0 & 4294967295L | ((long)par1 & 4294967295L) << 32;
    }

    public int hashCode()
    {
        long var1 = chunkXZ2Int(this.x, this.z);
        int var3 = (int)var1;
        int var4 = (int)(var1 >> 32);
        return var3 ^ var4;
    }

    public boolean equals(Object par1Obj)
    {
        ChunkCoordIntPair var2 = (ChunkCoordIntPair)par1Obj;
        return var2.x == this.x && var2.z == this.z;
    }

    public int getCenterXPos()
    {
        return (this.x << 4) + 8;
    }

    public int getCenterZPosition()
    {
        return (this.z << 4) + 8;
    }

    public ChunkPosition getChunkPosition(int par1)
    {
        return new ChunkPosition(this.getCenterXPos(), par1, this.getCenterZPosition());
    }

    public String toString()
    {
        return "[" + this.x + ", " + this.z + "]";
    }
}
