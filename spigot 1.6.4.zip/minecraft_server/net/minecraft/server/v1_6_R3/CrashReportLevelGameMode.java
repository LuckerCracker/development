package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportLevelGameMode implements Callable
{
    final WorldData a;

    CrashReportLevelGameMode(WorldData var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return String.format("Game mode: %s (ID %d). Hardcore: %b. Cheats: %b", new Object[] {WorldData.o(this.a).b(), Integer.valueOf(WorldData.o(this.a).a()), Boolean.valueOf(WorldData.p(this.a)), Boolean.valueOf(WorldData.q(this.a))});
    }

    public Object call()
    {
        return this.a();
    }
}
