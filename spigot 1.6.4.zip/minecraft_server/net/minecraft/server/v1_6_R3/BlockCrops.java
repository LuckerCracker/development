package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockCrops extends BlockFlower
{
    protected BlockCrops(int par1)
    {
        super(par1);
        this.setTickRandomly(true);
        float var2 = 0.5F;
        this.setBlockBounds(0.5F - var2, 0.0F, 0.5F - var2, 0.5F + var2, 0.25F, 0.5F + var2);
        this.a((CreativeModeTab)null);
        this.setHardness(0.0F);
        this.setStepSound(soundGrassFootstep);
        this.disableStats();
    }

    /**
     * Gets passed in the blockID of the block below and supposed to return true if its allowed to grow on the type of
     * blockID passed in. Args: blockID
     */
    protected boolean canThisPlantGrowOnThisBlockID(int par1)
    {
        return par1 == Block.SOIL.id;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        super.updateTick(par1World, par2, par3, par4, par5Random);

        if (par1World.getLightLevel(par2, par3 + 1, par4) >= 9)
        {
            int var6 = par1World.getData(par2, par3, par4);

            if (var6 < 7)
            {
                float var7 = this.getGrowthRate(par1World, par2, par3, par4);

                if (par5Random.nextInt((int)(par1World.growthOdds / (float)par1World.spigotConfig.wheatModifier * (25.0F / var7)) + 1) == 0)
                {
                    ++var6;
                    CraftEventFactory.handleBlockGrowEvent(par1World, par2, par3, par4, this.id, var6);
                }
            }
        }
    }

    /**
     * Apply bonemeal to the crops.
     */
    public void fertilize(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4) + MathHelper.nextInt(par1World.random, 2, 5);

        if (var5 > 7)
        {
            var5 = 7;
        }

        par1World.setData(par2, par3, par4, var5, 2);
    }

    /**
     * Gets the growth rate for the crop. Setup to encourage rows by halving growth rate if there is diagonals, crops on
     * different sides that aren't opposing, and by adding growth for every crop next to this one (and for crop below
     * this one). Args: x, y, z
     */
    private float getGrowthRate(World par1World, int par2, int par3, int par4)
    {
        float var5 = 1.0F;
        int var6 = par1World.getTypeId(par2, par3, par4 - 1);
        int var7 = par1World.getTypeId(par2, par3, par4 + 1);
        int var8 = par1World.getTypeId(par2 - 1, par3, par4);
        int var9 = par1World.getTypeId(par2 + 1, par3, par4);
        int var10 = par1World.getTypeId(par2 - 1, par3, par4 - 1);
        int var11 = par1World.getTypeId(par2 + 1, par3, par4 - 1);
        int var12 = par1World.getTypeId(par2 + 1, par3, par4 + 1);
        int var13 = par1World.getTypeId(par2 - 1, par3, par4 + 1);
        boolean var14 = var8 == this.id || var9 == this.id;
        boolean var15 = var6 == this.id || var7 == this.id;
        boolean var16 = var10 == this.id || var11 == this.id || var12 == this.id || var13 == this.id;

        for (int var17 = par2 - 1; var17 <= par2 + 1; ++var17)
        {
            for (int var18 = par4 - 1; var18 <= par4 + 1; ++var18)
            {
                int var19 = par1World.getTypeId(var17, par3 - 1, var18);
                float var20 = 0.0F;

                if (var19 == Block.SOIL.id)
                {
                    var20 = 1.0F;

                    if (par1World.getData(var17, par3 - 1, var18) > 0)
                    {
                        var20 = 3.0F;
                    }
                }

                if (var17 != par2 || var18 != par4)
                {
                    var20 /= 4.0F;
                }

                var5 += var20;
            }
        }

        if (var16 || var14 && var15)
        {
            var5 /= 2.0F;
        }

        return var5;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 6;
    }

    /**
     * Generate a seed ItemStack for this crop.
     */
    protected int getSeedItem()
    {
        return Item.SEEDS.id;
    }

    /**
     * Generate a crop produce ItemStack for this crop.
     */
    protected int getCropItem()
    {
        return Item.WHEAT.id;
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        super.dropNaturally(world, i, j, k, l, f, 0);

        if (!world.isStatic && l >= 7)
        {
            int j1 = 3 + i1;

            for (int k1 = 0; k1 < j1; ++k1)
            {
                if (world.random.nextInt(15) <= l)
                {
                    this.dropBlockAsItem_do(world, i, j, k, new ItemStack(this.getSeedItem(), 1, 0));
                }
            }
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return i == 7 ? this.getCropItem() : this.getSeedItem();
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 1;
    }
}
