package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportIntCacheSize implements Callable
{
    final CrashReport a;

    CrashReportIntCacheSize(CrashReport var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return IntCache.func_85144_b();
    }

    public Object call()
    {
        return this.a();
    }
}
