package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandSay extends CommandAbstract
{
    public String getCommandName()
    {
        return "say";
    }

    public int a()
    {
        return 1;
    }

    public String c(ICommandListener var1)
    {
        return "commands.say.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length > 0 && var2[0].length() > 0)
        {
            String var3 = a(var1, var2, 0, true);
            MinecraftServer.getServer().getPlayerList().sendMessage(ChatMessage.b("chat.type.announcement", new Object[] {var1.getName(), var3}));
        }
        else
        {
            throw new ExceptionUsage("commands.say.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length >= 1 ? a(var2, MinecraftServer.getServer().getPlayers()) : null;
    }
}
