package net.minecraft.server.v1_6_R3;

public class BiomeRiver extends BiomeBase
{
    public BiomeRiver(int var1)
    {
        super(var1);
        this.spawnableCreatureList.clear();
    }
}
