package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportConnectionPacketID implements Callable
{
    final Packet a;

    final PlayerConnection b;

    CrashReportConnectionPacketID(PlayerConnection var1, Packet var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        return String.valueOf(this.a.getPacketId());
    }

    public Object call()
    {
        return this.a();
    }
}
