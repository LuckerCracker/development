package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.EntityCombustByEntityEvent;

public class EntitySmallFireball extends EntityFireball
{
    public EntitySmallFireball(World par1World)
    {
        super(par1World);
        this.setSize(0.3125F, 0.3125F);
    }

    public EntitySmallFireball(World world, EntityLiving entityliving, double d0, double d1, double d2)
    {
        super(world, entityliving, d0, d1, d2);
        this.setSize(0.3125F, 0.3125F);
    }

    public EntitySmallFireball(World par1World, double par2, double par4, double par6, double par8, double par10, double par12)
    {
        super(par1World, par2, par4, par6, par8, par10, par12);
        this.setSize(0.3125F, 0.3125F);
    }

    /**
     * Called when this EntityFireball hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition par1MovingObjectPosition)
    {
        if (!this.world.isStatic)
        {
            if (par1MovingObjectPosition.entity != null)
            {
                if (!par1MovingObjectPosition.entity.isFireproof() && par1MovingObjectPosition.entity.attackEntityFrom(DamageSource.fireball(this, this.shooter), 5.0F))
                {
                    EntityCombustByEntityEvent var2 = new EntityCombustByEntityEvent((Projectile)this.getBukkitEntity(), par1MovingObjectPosition.entity.getBukkitEntity(), 5);
                    par1MovingObjectPosition.entity.world.getServer().getPluginManager().callEvent(var2);

                    if (!var2.isCancelled())
                    {
                        par1MovingObjectPosition.entity.setOnFire(var2.getDuration());
                    }
                }
            }
            else
            {
                int var5 = par1MovingObjectPosition.blockX;
                int var3 = par1MovingObjectPosition.blockY;
                int var4 = par1MovingObjectPosition.blockZ;

                switch (par1MovingObjectPosition.face)
                {
                    case 0:
                        --var3;
                        break;

                    case 1:
                        ++var3;
                        break;

                    case 2:
                        --var4;
                        break;

                    case 3:
                        ++var4;
                        break;

                    case 4:
                        --var5;
                        break;

                    case 5:
                        ++var5;
                }

                if (this.world.isEmpty(var5, var3, var4) && !CraftEventFactory.callBlockIgniteEvent(this.world, var5, var3, var4, (Entity)this).isCancelled())
                {
                    this.world.setTypeIdUpdate(var5, var3, var4, Block.FIRE.id);
                }
            }

            this.die();
        }
    }

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
        return false;
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        return false;
    }
}
