package net.minecraft.server.v1_6_R3;

import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.block.CraftBlock;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;

public class BlockPiston extends Block {
	/**
	 * used as foreach item, if item.tab = current tab, display it on the screen
	 */
	private final boolean displayOnCreativeTab;

	public BlockPiston(int i, boolean flag) {
		super(i, Material.PISTON);
		this.displayOnCreativeTab = flag;
		this.setStepSound(soundStoneFootstep);
		this.setHardness(0.5F);
		this.a(CreativeModeTab.d);
	}

	/**
	 * The type of render function that is called for this block
	 */
	public int getRenderType() {
		return 16;
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube? This determines whether
	 * or not to render the shared face of two adjacent blocks and also whether
	 * the player can attach torches, redstone wire, etc to this block.
	 */
	public boolean isOpaqueCube() {
		return false;
	}

	public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1,
			float f2) {
		return false;
	}

	public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack) {
		int l = a(world, i, j, k, entityliving);
		world.setData(i, j, k, l, 2);

		if (!world.isStatic) {
			this.k(world, i, j, k);
		}
	}

	public void doPhysics(World world, int i, int j, int k, int l) {
		if (!world.isStatic) {
			this.k(world, i, j, k);
		}
	}

	public void onPlace(World world, int i, int j, int k) {
		if (!world.isStatic && world.getTileEntity(i, j, k) == null) {
			this.k(world, i, j, k);
		}
	}

	private void k(World world, int i, int j, int k) {
		int l = world.getData(i, j, k);
		int i1 = d(l);

		if (i1 != 7) {
			boolean flag = this.d(world, i, j, k, i1);

			if (flag && !e(l)) {
				int block1 = e(world, i, j, k, i1);

				if (block1 >= 0) {
					org.bukkit.block.Block event2 = world.getWorld().getBlockAt(i, j, k);
					BlockPistonExtendEvent event1 = new BlockPistonExtendEvent(event2, block1,
							CraftBlock.notchToBlockFace(i1));
					world.getServer().getPluginManager().callEvent(event1);

					if (event1.isCancelled()) {
						return;
					}

					world.playNote(i, j, k, this.id, 0, i1);
				}
			} else if (!flag && e(l)) {
				org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
				BlockPistonRetractEvent event = new BlockPistonRetractEvent(block, CraftBlock.notchToBlockFace(i1));
				world.getServer().getPluginManager().callEvent(event);

				if (event.isCancelled()) {
					return;
				}

				world.setData(i, j, k, i1, 2);
				world.playNote(i, j, k, this.id, 1, i1);
			}
		}
	}

	private boolean d(World world, int i, int j, int k, int l) {
		return l != 0 && world.isBlockFacePowered(i, j - 1, k, 0) ? true
				: (l != 1 && world.isBlockFacePowered(i, j + 1, k, 1) ? true
						: (l != 2 && world.isBlockFacePowered(i, j, k - 1, 2) ? true
								: (l != 3 && world.isBlockFacePowered(i, j, k + 1, 3) ? true
										: (l != 5 && world.isBlockFacePowered(i + 1, j, k, 5) ? true
												: (l != 4 && world.isBlockFacePowered(i - 1, j, k, 4) ? true
														: (world.isBlockFacePowered(i, j, k, 0) ? true
																: (world.isBlockFacePowered(i, j + 2, k, 1) ? true
																		: (world.isBlockFacePowered(i, j + 1, k - 1, 2)
																				? true
																				: (world.isBlockFacePowered(i, j + 1,
																						k + 1, 3)
																								? true
																								: (world.isBlockFacePowered(
																										i - 1, j + 1,
																										k, 4)
																												? true
																												: world.isBlockFacePowered(
																														i + 1,
																														j + 1,
																														k,
																														5)))))))))));
	}

	/**
	 * Called when the block receives a BlockEvent - see World.addBlockEvent. By
	 * default, passes it on to the tile entity at this location. Args: world,
	 * x, y, z, blockID, EventID, event parameter
	 */
	public boolean onBlockEventReceived(World world, int i, int j, int k, int l, int i1) {
		if (!world.isStatic) {
			boolean tileentity = this.d(world, i, j, k, i1);

			if (tileentity && l == 1) {
				world.setData(i, j, k, i1 | 8, 2);
				return false;
			}

			if (!tileentity && l == 0) {
				return false;
			}
		}

		if (l == 0) {
			if (!this.f(world, i, j, k, i1)) {
				return false;
			}

			world.setData(i, j, k, i1 | 8, 2);
			world.makeSound((double) i + 0.5D, (double) j + 0.5D, (double) k + 0.5D, "tile.piston.out", 0.5F,
					world.random.nextFloat() * 0.25F + 0.6F);
		} else if (l == 1) {
			TileEntity tileentity1 = world.getTileEntity(i + Facing.offsetsXForSide[i1], j + Facing.offsetsYForSide[i1],
					k + Facing.offsetsZForSide[i1]);

			if (tileentity1 instanceof TileEntityPiston) {
				((TileEntityPiston) tileentity1).clearPistonTileEntity();
			}

			world.setTypeIdAndData(i, j, k, Block.PISTON_MOVING.id, i1, 3);
			world.setTileEntity(i, j, k, BlockPistonMoving.getTileEntity(this.id, i1, i1, false, true));

			if (this.displayOnCreativeTab) {
				int j1 = i + Facing.offsetsXForSide[i1] * 2;
				int k1 = j + Facing.offsetsYForSide[i1] * 2;
				int l1 = k + Facing.offsetsZForSide[i1] * 2;
				int i2 = world.getTypeId(j1, k1, l1);
				int j2 = world.getData(j1, k1, l1);
				boolean flag1 = false;

				if (i2 == Block.PISTON_MOVING.id) {
					TileEntity tileentity11 = world.getTileEntity(j1, k1, l1);

					if (tileentity11 instanceof TileEntityPiston) {
						TileEntityPiston tileentitypiston = (TileEntityPiston) tileentity11;

						if (tileentitypiston.getPistonOrientation() == i1 && tileentitypiston.isExtending()) {
							tileentitypiston.clearPistonTileEntity();
							i2 = tileentitypiston.getStoredBlockID();
							j2 = tileentitypiston.getBlockMetadata();
							flag1 = true;
						}
					}
				}

				if (!flag1 && i2 > 0 && a(i2, world, j1, k1, l1, false) && (Block.byId[i2].getMobilityFlag() == 0
						|| i2 == Block.PISTON.id || i2 == Block.PISTON_STICKY.id)) {
					i += Facing.offsetsXForSide[i1];
					j += Facing.offsetsYForSide[i1];
					k += Facing.offsetsZForSide[i1];
					world.setTypeIdAndData(i, j, k, Block.PISTON_MOVING.id, j2, 3);
					world.setTileEntity(i, j, k, BlockPistonMoving.getTileEntity(i2, j2, i1, false, false));
					world.setAir(j1, k1, l1);
				} else if (!flag1) {
					world.setAir(i + Facing.offsetsXForSide[i1], j + Facing.offsetsYForSide[i1],
							k + Facing.offsetsZForSide[i1]);
				}
			} else {
				world.setAir(i + Facing.offsetsXForSide[i1], j + Facing.offsetsYForSide[i1],
						k + Facing.offsetsZForSide[i1]);
			}

			world.makeSound((double) i + 0.5D, (double) j + 0.5D, (double) k + 0.5D, "tile.piston.in", 0.5F,
					world.random.nextFloat() * 0.15F + 0.6F);
		}

		return true;
	}

	public void updateShape(IBlockAccess iblockaccess, int i, int j, int k) {
		int l = iblockaccess.getData(i, j, k);

		if (e(l)) {
			float f = 0.25F;

			switch (d(l)) {
			case 0:
				this.setBlockBounds(0.0F, 0.25F, 0.0F, 1.0F, 1.0F, 1.0F);
				break;

			case 1:
				this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
				break;

			case 2:
				this.setBlockBounds(0.0F, 0.0F, 0.25F, 1.0F, 1.0F, 1.0F);
				break;

			case 3:
				this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.75F);
				break;

			case 4:
				this.setBlockBounds(0.25F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
				break;

			case 5:
				this.setBlockBounds(0.0F, 0.0F, 0.0F, 0.75F, 1.0F, 1.0F);
			}
		} else {
			this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		}
	}

	/**
	 * Sets the block's bounds for rendering it as an item
	 */
	public void setBlockBoundsForItemRender() {
		this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
	}

	/**
	 * Adds all intersecting collision boxes to a list. (Be sure to only add
	 * boxes to the list if they intersect the mask.) Parameters: World, X, Y,
	 * Z, mask, list, colliding entity
	 */
	public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List list,
			Entity entity) {
		this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		super.addCollisionBoxesToList(world, i, j, k, axisalignedbb, list, entity);
	}

	/**
	 * Returns a bounding box from the pool of bounding boxes (this means this
	 * box can change after the pool has been cleared to be reused)
	 */
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k) {
		this.updateShape(world, i, j, k);
		return super.getCollisionBoundingBoxFromPool(world, i, j, k);
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False
	 * (examples: signs, buttons, stairs, etc)
	 */
	public boolean renderAsNormalBlock() {
		return false;
	}

	public static int d(int i) {
		return (i & 7) >= Facing.OPPOSITE_FACING.length ? 7 : i & 7;
	}

	public static boolean e(int i) {
		return (i & 8) != 0;
	}

	public static int a(World world, int i, int j, int k, EntityLiving entityliving) {
		if (MathHelper.abs((float) entityliving.locX - (float) i) < 2.0F
				&& MathHelper.abs((float) entityliving.locZ - (float) k) < 2.0F) {
			double d0 = entityliving.locY + 1.82D - (double) entityliving.height;

			if (d0 - (double) j > 2.0D) {
				return 1;
			}

			if ((double) j - d0 > 0.0D) {
				return 0;
			}
		}

		int l = MathHelper.floor((double) (entityliving.yaw * 4.0F / 360.0F) + 0.5D) & 3;
		return l == 0 ? 2 : (l == 1 ? 5 : (l == 2 ? 3 : (l == 3 ? 4 : 0)));
	}

	private static boolean a(int i, World world, int j, int k, int l, boolean flag) {
		if (i == Block.OBSIDIAN.id) {
			return false;
		} else {
			if (i != Block.PISTON.id && i != Block.PISTON_STICKY.id) {
				if (Block.byId[i].getBlockHardness(world, j, k, l) == -1.0F) {
					return false;
				}

				if (Block.byId[i].getMobilityFlag() == 2) {
					return false;
				}

				if (Block.byId[i].getMobilityFlag() == 1) {
					if (!flag) {
						return false;
					}

					return true;
				}
			} else if (e(world.getData(j, k, l))) {
				return false;
			}

			return !(Block.byId[i] instanceof IContainer);
		}
	}

	private static int e(World world, int i, int j, int k, int l) {
		int i1 = i + Facing.offsetsXForSide[l];
		int j1 = j + Facing.offsetsYForSide[l];
		int k1 = k + Facing.offsetsZForSide[l];
		int l1 = 0;

		while (true) {
			if (l1 < 13) {
				if (j1 <= 0 || j1 >= 255) {
					return -1;
				}

				int i2 = world.getTypeId(i1, j1, k1);

				if (i2 != 0) {
					if (!a(i2, world, i1, j1, k1, true)) {
						return -1;
					}

					if (Block.byId[i2].getMobilityFlag() != 1) {
						if (l1 == 12) {
							return -1;
						}

						i1 += Facing.offsetsXForSide[l];
						j1 += Facing.offsetsYForSide[l];
						k1 += Facing.offsetsZForSide[l];
						++l1;
						continue;
					}
				}
			}

			return l1;
		}
	}

	private boolean f(World world, int i, int j, int k, int l) {
		int i1 = i + Facing.offsetsXForSide[l];
		int j1 = j + Facing.offsetsYForSide[l];
		int k1 = k + Facing.offsetsZForSide[l];
		int l1 = 0;

		while (true) {
			int i2;

			if (l1 < 13) {
				if (j1 <= 0 || j1 >= 255) {
					return false;
				}

				i2 = world.getTypeId(i1, j1, k1);

				if (i2 != 0) {
					if (!a(i2, world, i1, j1, k1, true)) {
						return false;
					}

					if (Block.byId[i2].getMobilityFlag() != 1) {
						if (l1 == 12) {
							return false;
						}

						i1 += Facing.offsetsXForSide[l];
						j1 += Facing.offsetsYForSide[l];
						k1 += Facing.offsetsZForSide[l];
						++l1;
						continue;
					}

					Block.byId[i2].dropBlockAsItem(world, i1, j1, k1, world.getData(i1, j1, k1), 0);
					world.setAir(i1, j1, k1);
				}
			}

			l1 = i1;
			i2 = j1;
			int j2 = k1;
			int k2 = 0;
			int[] aint;
			int l2;
			int i3;
			int j3;

			for (aint = new int[13]; i1 != i || j1 != j || k1 != k; k1 = j3) {
				l2 = i1 - Facing.offsetsXForSide[l];
				i3 = j1 - Facing.offsetsYForSide[l];
				j3 = k1 - Facing.offsetsZForSide[l];
				int k3 = world.getTypeId(l2, i3, j3);
				int l3 = world.getData(l2, i3, j3);

				if (k3 == this.id && l2 == i && i3 == j && j3 == k) {
					world.setTypeIdAndData(i1, j1, k1, Block.PISTON_MOVING.id, l | (this.displayOnCreativeTab ? 8 : 0),
							4);
					world.setTileEntity(i1, j1, k1, BlockPistonMoving.getTileEntity(Block.PISTON_EXTENSION.id,
							l | (this.displayOnCreativeTab ? 8 : 0), l, true, false));
				} else {
					world.setTypeIdAndData(i1, j1, k1, Block.PISTON_MOVING.id, l3, 4);
					world.setTileEntity(i1, j1, k1, BlockPistonMoving.getTileEntity(k3, l3, l, true, false));
				}

				aint[k2++] = k3;
				i1 = l2;
				j1 = i3;
			}

			i1 = l1;
			j1 = i2;
			k1 = j2;

			for (k2 = 0; i1 != i || j1 != j || k1 != k; k1 = j3) {
				l2 = i1 - Facing.offsetsXForSide[l];
				i3 = j1 - Facing.offsetsYForSide[l];
				j3 = k1 - Facing.offsetsZForSide[l];
				world.applyPhysics(l2, i3, j3, aint[k2++]);
				i1 = l2;
				j1 = i3;
			}

			return true;
		}
	}
}
