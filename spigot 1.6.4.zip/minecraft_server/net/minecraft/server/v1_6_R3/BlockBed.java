package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.Random;

public class BlockBed extends BlockDirectional
{
    /** Maps the foot-of-bed block to the head-of-bed block. */
    public static final int[][] footBlockToHeadBlockMap = new int[][] {{0, 1}, { -1, 0}, {0, -1}, {1, 0}};

    public BlockBed(int par1)
    {
        super(par1, Material.CLOTH);
        this.setBounds();
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            int var10 = var1.getData(var2, var3, var4);

            if (!isBlockHeadOfBed(var10))
            {
                int var11 = getDirection(var10);
                var2 += footBlockToHeadBlockMap[var11][0];
                var4 += footBlockToHeadBlockMap[var11][1];

                if (var1.getTypeId(var2, var3, var4) != this.id)
                {
                    return true;
                }

                var10 = var1.getData(var2, var3, var4);
            }

            if (var1.worldProvider.canRespawnHere() && var1.getBiome(var2, var4) != BiomeBase.HELL)
            {
                if (isBedOccupied(var10))
                {
                    EntityHuman var22 = null;
                    Iterator var19 = var1.players.iterator();

                    while (var19.hasNext())
                    {
                        EntityHuman var20 = (EntityHuman)var19.next();

                        if (var20.isSleeping())
                        {
                            ChunkCoordinates var21 = var20.playerLocation;

                            if (var21.x == var2 && var21.y == var3 && var21.z == var4)
                            {
                                var22 = var20;
                            }
                        }
                    }

                    if (var22 != null)
                    {
                        var5.setCustomNameTag("tile.bed.occupied");
                        return true;
                    }

                    setBedOccupied(var1, var2, var3, var4, false);
                }

                EnumBedResult var23 = var5.sleepInBedAt(var2, var3, var4);

                if (var23 == EnumBedResult.OK)
                {
                    setBedOccupied(var1, var2, var3, var4, true);
                    return true;
                }
                else
                {
                    if (var23 == EnumBedResult.NOT_POSSIBLE_NOW)
                    {
                        var5.setCustomNameTag("tile.bed.noSleep");
                    }
                    else if (var23 == EnumBedResult.NOT_SAFE)
                    {
                        var5.setCustomNameTag("tile.bed.notSafe");
                    }

                    return true;
                }
            }
            else
            {
                double var12 = (double)var2 + 0.5D;
                double var14 = (double)var3 + 0.5D;
                double var16 = (double)var4 + 0.5D;
                var1.setAir(var2, var3, var4);
                int var18 = getDirection(var10);
                var2 += footBlockToHeadBlockMap[var18][0];
                var4 += footBlockToHeadBlockMap[var18][1];

                if (var1.getTypeId(var2, var3, var4) == this.id)
                {
                    var1.setAir(var2, var3, var4);
                    var12 = (var12 + (double)var2 + 0.5D) / 2.0D;
                    var14 = (var14 + (double)var3 + 0.5D) / 2.0D;
                    var16 = (var16 + (double)var4 + 0.5D) / 2.0D;
                }

                var1.createExplosion((Entity)null, (double)((float)var2 + 0.5F), (double)((float)var3 + 0.5F), (double)((float)var4 + 0.5F), 5.0F, true, true);
                return true;
            }
        }
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 14;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        this.setBounds();
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        int var6 = var1.getData(var2, var3, var4);
        int var7 = getDirection(var6);

        if (isBlockHeadOfBed(var6))
        {
            if (var1.getTypeId(var2 - footBlockToHeadBlockMap[var7][0], var3, var4 - footBlockToHeadBlockMap[var7][1]) != this.id)
            {
                var1.setAir(var2, var3, var4);
            }
        }
        else if (var1.getTypeId(var2 + footBlockToHeadBlockMap[var7][0], var3, var4 + footBlockToHeadBlockMap[var7][1]) != this.id)
        {
            var1.setAir(var2, var3, var4);

            if (!var1.isStatic)
            {
                this.dropBlockAsItem(var1, var2, var3, var4, var6, 0);
            }
        }
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return isBlockHeadOfBed(var1) ? 0 : Item.BED.id;
    }

    /**
     * Set the bounds of the bed block.
     */
    private void setBounds()
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5625F, 1.0F);
    }

    /**
     * Returns whether or not this bed block is the head of the bed.
     */
    public static boolean isBlockHeadOfBed(int par0)
    {
        return (par0 & 8) != 0;
    }

    /**
     * Return whether or not the bed is occupied.
     */
    public static boolean isBedOccupied(int par0)
    {
        return (par0 & 4) != 0;
    }

    /**
     * Sets whether or not the bed is occupied.
     */
    public static void setBedOccupied(World par0World, int par1, int par2, int par3, boolean par4)
    {
        int var5 = par0World.getData(par1, par2, par3);

        if (par4)
        {
            var5 |= 4;
        }
        else
        {
            var5 &= -5;
        }

        par0World.setData(par1, par2, par3, var5, 4);
    }

    /**
     * Gets the nearest empty chunk coordinates for the player to wake up from a bed into.
     */
    public static ChunkCoordinates getNearestEmptyChunkCoordinates(World par0World, int par1, int par2, int par3, int par4)
    {
        int var5 = par0World.getData(par1, par2, par3);
        int var6 = BlockDirectional.getDirection(var5);

        for (int var7 = 0; var7 <= 1; ++var7)
        {
            int var8 = par1 - footBlockToHeadBlockMap[var6][0] * var7 - 1;
            int var9 = par3 - footBlockToHeadBlockMap[var6][1] * var7 - 1;
            int var10 = var8 + 2;
            int var11 = var9 + 2;

            for (int var12 = var8; var12 <= var10; ++var12)
            {
                for (int var13 = var9; var13 <= var11; ++var13)
                {
                    if (par0World.doesBlockHaveSolidTopSurface(var12, par2 - 1, var13) && !par0World.getMaterial(var12, par2, var13).isOpaque() && !par0World.getMaterial(var12, par2 + 1, var13).isOpaque())
                    {
                        if (par4 <= 0)
                        {
                            return new ChunkCoordinates(var12, par2, var13);
                        }

                        --par4;
                    }
                }
            }
        }

        return null;
    }

    public void dropNaturally(World var1, int var2, int var3, int var4, int var5, float var6, int var7)
    {
        if (!isBlockHeadOfBed(var5))
        {
            super.dropNaturally(var1, var2, var3, var4, var5, var6, 0);
        }
    }

    /**
     * Returns the mobility information of the block, 0 = free, 1 = can't push but can move over, 2 = total immobility
     * and stop pistons
     */
    public int getMobilityFlag()
    {
        return 1;
    }

    public void a(World var1, int var2, int var3, int var4, int var5, EntityHuman var6)
    {
        if (var6.abilities.canInstantlyBuild && isBlockHeadOfBed(var5))
        {
            int var7 = getDirection(var5);
            var2 -= footBlockToHeadBlockMap[var7][0];
            var4 -= footBlockToHeadBlockMap[var7][1];

            if (var1.getTypeId(var2, var3, var4) == this.id)
            {
                var1.setAir(var2, var3, var4);
            }
        }
    }
}
