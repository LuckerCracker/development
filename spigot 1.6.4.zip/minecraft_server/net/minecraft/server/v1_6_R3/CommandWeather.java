package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class CommandWeather extends CommandAbstract
{
    public String getCommandName()
    {
        return "weather";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.weather.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length >= 1 && var2.length <= 2)
        {
            int var3 = (300 + (new Random()).nextInt(600)) * 20;

            if (var2.length >= 2)
            {
                var3 = a(var1, var2[1], 1, 1000000) * 20;
            }

            WorldServer var4 = MinecraftServer.getServer().worldServer[0];
            WorldData var5 = var4.getWorldData();
            var5.setWeatherDuration(var3);
            var5.setThunderDuration(var3);

            if ("clear".equalsIgnoreCase(var2[0]))
            {
                var5.setStorm(false);
                var5.setThundering(false);
                a(var1, "commands.weather.clear", new Object[0]);
            }
            else if ("rain".equalsIgnoreCase(var2[0]))
            {
                var5.setStorm(true);
                var5.setThundering(false);
                a(var1, "commands.weather.rain", new Object[0]);
            }
            else
            {
                if (!"thunder".equalsIgnoreCase(var2[0]))
                {
                    throw new ExceptionUsage("commands.weather.usage", new Object[0]);
                }

                var5.setStorm(true);
                var5.setThundering(true);
                a(var1, "commands.weather.thunder", new Object[0]);
            }
        }
        else
        {
            throw new ExceptionUsage("commands.weather.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, new String[] {"clear", "rain", "thunder"}): null;
    }
}
