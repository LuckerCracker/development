package net.minecraft.server.v1_6_R3;

import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;

public class EntityWitherSkull extends EntityFireball {
	public EntityWitherSkull(World par1World) {
		super(par1World);
		this.setSize(0.3125F, 0.3125F);
	}

	public EntityWitherSkull(World world, EntityLiving entityliving, double d0, double d1, double d2) {
		super(world, entityliving, d0, d1, d2);
		this.setSize(0.3125F, 0.3125F);
	}

	/**
	 * Return the motion factor for this projectile. The factor is multiplied by
	 * the original motion.
	 */
	protected float getMotionFactor() {
		return this.isInvulnerable() ? 0.73F : super.getMotionFactor();
	}

	public boolean isBurning() {
		return false;
	}

	/**
	 * Gets a block's resistance to this entity's explosion. Used to make rails
	 * immune to TNT minecarts' explosions and Wither skulls more destructive.
	 */
	public float getBlockExplosionResistance(Explosion par1Explosion, World par2World, int par3, int par4, int par5,
			Block par6Block) {
		float var7 = super.getBlockExplosionResistance(par1Explosion, par2World, par3, par4, par5, par6Block);

		if (this.isInvulnerable() && par6Block != Block.BEDROCK && par6Block != Block.ENDER_PORTAL
				&& par6Block != Block.ENDER_PORTAL_FRAME) {
			var7 = Math.min(0.8F, var7);
		}

		return var7;
	}

	/**
	 * Called when this EntityFireball hits a block or entity.
	 */
	protected void onImpact(MovingObjectPosition par1MovingObjectPosition) {
		if (!this.world.isStatic) {
			if (par1MovingObjectPosition.entity != null) {
				if (this.shooter != null) {
					if (par1MovingObjectPosition.entity.attackEntityFrom(DamageSource.mobAttack(this.shooter), 8.0F)
							&& !par1MovingObjectPosition.entity.isAlive()) {
						this.shooter.heal(5.0F, EntityRegainHealthEvent.RegainReason.WITHER);
					}
				} else {
					par1MovingObjectPosition.entity.attackEntityFrom(DamageSource.MAGIC, 5.0F);
				}

				if (par1MovingObjectPosition.entity instanceof EntityLiving) {
					byte var2 = 0;

					if (this.world.difficulty > 1) {
						if (this.world.difficulty == 2) {
							var2 = 10;
						} else if (this.world.difficulty == 3) {
							var2 = 40;
						}
					}

					if (var2 > 0) {
						((EntityLiving) par1MovingObjectPosition.entity)
								.addEffect(new MobEffect(MobEffectList.WITHER.id, 20 * var2, 1));
					}
				}
			}

			ExplosionPrimeEvent var3 = new ExplosionPrimeEvent(this.getBukkitEntity(), 1.0F, false);
			this.world.getServer().getPluginManager().callEvent(var3);

			if (!var3.isCancelled()) {
				this.world.createExplosion(this, this.locX, this.locY, this.locZ, var3.getRadius(), var3.getFire(),
						this.world.getGameRules().getBoolean("mobGriefing"));
			}

			this.die();
		}
	}

	/**
	 * Returns true if other Entities should be prevented from moving through
	 * this Entity.
	 */
	public boolean canBeCollidedWith() {
		return false;
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		return false;
	}

	protected void entityInit() {
		this.datawatcher.addObject(10, Byte.valueOf((byte) 0));
	}

	/**
	 * Return whether this skull comes from an invulnerable (aura) wither boss.
	 */
	public boolean isInvulnerable() {
		return this.datawatcher.getByte(10) == 1;
	}

	/**
	 * Set whether this skull comes from an invulnerable (aura) wither boss.
	 */
	public void setInvulnerable(boolean par1) {
		this.datawatcher.watch(10, Byte.valueOf((byte) (par1 ? 1 : 0)));
	}
}
