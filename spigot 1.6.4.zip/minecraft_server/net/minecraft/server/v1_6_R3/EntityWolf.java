package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntityWolf extends EntityTameableAnimal {
	private float field_70926_e;
	private float field_70924_f;

	/** true is the wolf is wet else false */
	private boolean isShaking;
	private boolean field_70928_h;

	/**
	 * This time increases while wolf is shaking and emitting water particles.
	 */
	private float timeWolfIsShaking;
	private float prevTimeWolfIsShaking;

	public EntityWolf(World par1World) {
		super(par1World);
		this.setSize(0.6F, 0.8F);
		this.getNavigation().a(true);
		this.goalSelector.a(1, new PathfinderGoalFloat(this));
		this.goalSelector.a(2, this.inLove);
		this.goalSelector.a(3, new PathfinderGoalLeapAtTarget(this, 0.4F));
		this.goalSelector.a(4, new PathfinderGoalMeleeAttack(this, 1.0D, true));
		this.goalSelector.a(5, new PathfinderGoalFollowOwner(this, 1.0D, 10.0F, 2.0F));
		this.goalSelector.a(6, new PathfinderGoalBreed(this, 1.0D));
		this.goalSelector.a(7, new PathfinderGoalRandomStroll(this, 1.0D));
		this.goalSelector.a(8, new PathfinderGoalBeg(this, 8.0F));
		this.goalSelector.a(9, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
		this.goalSelector.a(9, new PathfinderGoalRandomLookaround(this));
		this.targetSelector.a(1, new PathfinderGoalOwnerHurtByTarget(this));
		this.targetSelector.a(2, new PathfinderGoalOwnerHurtTarget(this));
		this.targetSelector.a(3, new PathfinderGoalHurtByTarget(this, true));
		this.targetSelector.a(4, new PathfinderGoalRandomTargetNonTamed(this, EntitySheep.class, 200, false));
		this.setTamed(false);
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.d).setValue(0.30000001192092896D);

		if (this.isTamed()) {
			this.getAttributeInstance(GenericAttributes.a).setValue(20.0D);
		} else {
			this.getAttributeInstance(GenericAttributes.a).setValue(8.0D);
		}
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	public boolean isAIEnabled() {
		return true;
	}

	public void setGoalTarget(EntityLiving entityliving) {
		super.setGoalTarget(entityliving);

		if (entityliving == null) {
			this.setAngry(false);
		} else if (!this.isTamed()) {
			this.setAngry(true);
		}
	}

	/**
	 * main AI tick function, replaces updateEntityActionState
	 */
	protected void updateAITick() {
		this.datawatcher.watch(18, Float.valueOf(this.getHealth()));
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(18, new Float(this.getHealth()));
		this.datawatcher.addObject(19, new Byte((byte) 0));
		this.datawatcher.addObject(20, new Byte((byte) BlockCloth.j_(1)));
	}

	/**
	 * Plays step sound at given x, y, z for the entity
	 */
	protected void playStepSound(int par1, int par2, int par3, int par4) {
		this.makeSound("mob.wolf.step", 0.15F, 1.0F);
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setBoolean("Angry", this.isAngry());
		par1NBTTagCompound.setByte("CollarColor", (byte) this.getCollarColor());
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		this.setAngry(par1NBTTagCompound.getBoolean("Angry"));

		if (par1NBTTagCompound.hasKey("CollarColor")) {
			this.setCollarColor(par1NBTTagCompound.getByte("CollarColor"));
		}
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return this.isAngry() ? "mob.wolf.growl"
				: (this.random.nextInt(3) == 0
						? (this.isTamed() && this.datawatcher.getFloat(18) < this.getMaxHealth() / 2.0F
								? "mob.wolf.whine" : "mob.wolf.panting")
						: "mob.wolf.bark");
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.wolf.hurt";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.wolf.death";
	}

	/**
	 * Returns the volume for the sounds this mob makes.
	 */
	protected float getSoundVolume() {
		return 0.4F;
	}

	protected int getLootId() {
		return -1;
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		super.onLivingUpdate();

		if (!this.world.isStatic && this.isShaking && !this.field_70928_h && !this.hasPath() && this.onGround) {
			this.field_70928_h = true;
			this.timeWolfIsShaking = 0.0F;
			this.prevTimeWolfIsShaking = 0.0F;
			this.world.broadcastEntityEffect(this, (byte) 8);
		}
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		super.onUpdate();
		this.field_70924_f = this.field_70926_e;

		if (this.func_70922_bv()) {
			this.field_70926_e += (1.0F - this.field_70926_e) * 0.4F;
		} else {
			this.field_70926_e += (0.0F - this.field_70926_e) * 0.4F;
		}

		if (this.func_70922_bv()) {
			this.numTicksToChaseTarget = 10;
		}

		if (this.isWet()) {
			this.isShaking = true;
			this.field_70928_h = false;
			this.timeWolfIsShaking = 0.0F;
			this.prevTimeWolfIsShaking = 0.0F;
		} else if ((this.isShaking || this.field_70928_h) && this.field_70928_h) {
			if (this.timeWolfIsShaking == 0.0F) {
				this.makeSound("mob.wolf.shake", this.getSoundVolume(),
						(this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
			}

			this.prevTimeWolfIsShaking = this.timeWolfIsShaking;
			this.timeWolfIsShaking += 0.05F;

			if (this.prevTimeWolfIsShaking >= 2.0F) {
				this.isShaking = false;
				this.field_70928_h = false;
				this.prevTimeWolfIsShaking = 0.0F;
				this.timeWolfIsShaking = 0.0F;
			}

			if (this.timeWolfIsShaking > 0.4F) {
				float var1 = (float) this.boundingBox.minY;
				int var2 = (int) (MathHelper.sin((this.timeWolfIsShaking - 0.4F) * (float) Math.PI) * 7.0F);

				for (int var3 = 0; var3 < var2; ++var3) {
					float var4 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width * 0.5F;
					float var5 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width * 0.5F;
					this.world.addParticle("splash", this.locX + (double) var4, (double) (var1 + 0.8F),
							this.locZ + (double) var5, this.motX, this.motY, this.motZ);
				}
			}
		}
	}

	public float getHeadHeight() {
		return this.length * 0.8F;
	}

	/**
	 * The speed it takes to move the entityliving's rotationPitch through the
	 * faceEntity method. This is only currently use in wolves.
	 */
	public int getVerticalFaceSpeed() {
		return this.isSitting() ? 20 : super.getVerticalFaceSpeed();
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else {
			Entity entity = damagesource.getEntity();
			this.inLove.setSitting(false);

			if (entity != null && !(entity instanceof EntityHuman) && !(entity instanceof EntityArrow)) {
				f = (f + 1.0F) / 2.0F;
			}

			return super.attackEntityFrom(damagesource, f);
		}
	}

	public boolean attackEntityAsMob(Entity par1Entity) {
		int var2 = this.isTamed() ? 4 : 2;
		return par1Entity.attackEntityFrom(DamageSource.mobAttack(this), (float) var2);
	}

	public void setTamed(boolean flag) {
		super.setTamed(flag);

		if (flag) {
			this.getAttributeInstance(GenericAttributes.a).setValue(20.0D);
		} else {
			this.getAttributeInstance(GenericAttributes.a).setValue(8.0D);
		}
	}

	public boolean a(EntityHuman entityhuman) {
		ItemStack itemstack = entityhuman.inventory.getItemInHand();

		if (this.isTamed()) {
			if (itemstack != null) {
				if (Item.byId[itemstack.id] instanceof ItemFood) {
					ItemFood i = (ItemFood) Item.byId[itemstack.id];

					if (i.isWolfsFavoriteMeat() && this.datawatcher.getFloat(18) < 20.0F) {
						if (!entityhuman.abilities.canInstantlyBuild) {
							--itemstack.count;
						}

						this.heal((float) i.getNutrition());

						if (itemstack.count <= 0) {
							entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack) null);
						}

						return true;
					}
				} else if (itemstack.id == Item.INK_SACK.id) {
					int var4 = BlockCloth.j_(itemstack.getData());

					if (var4 != this.getCollarColor()) {
						this.setCollarColor(var4);

						if (!entityhuman.abilities.canInstantlyBuild && --itemstack.count <= 0) {
							entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack) null);
						}

						return true;
					}
				}
			}

			if (entityhuman.getName().equalsIgnoreCase(this.getOwnerName()) && !this.world.isStatic
					&& !this.isBreedingItem(itemstack)) {
				this.inLove.setSitting(!this.isSitting());
				this.isJumping = false;
				this.setPathEntity((PathEntity) null);
				this.setTarget((Entity) null);
				this.setGoalTarget((EntityLiving) null);
			}
		} else if (itemstack != null && itemstack.id == Item.BONE.id && !this.isAngry()) {
			if (!entityhuman.abilities.canInstantlyBuild) {
				--itemstack.count;
			}

			if (itemstack.count <= 0) {
				entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack) null);
			}

			if (!this.world.isStatic) {
				if (this.random.nextInt(3) == 0
						&& !CraftEventFactory.callEntityTameEvent(this, entityhuman).isCancelled()) {
					this.setTamed(true);
					this.setPathEntity((PathEntity) null);
					this.setGoalTarget((EntityLiving) null);
					this.inLove.setSitting(true);
					this.setHealth(this.getMaxHealth());
					this.setOwnerName(entityhuman.getName());
					this.i(true);
					this.world.broadcastEntityEffect(this, (byte) 7);
				} else {
					this.i(false);
					this.world.broadcastEntityEffect(this, (byte) 6);
				}
			}

			return true;
		}

		return super.a(entityhuman);
	}

	/**
	 * Checks if the parameter is an item which this animal can be fed to breed
	 * it (wheat, carrots or seeds depending on the animal type)
	 */
	public boolean isBreedingItem(ItemStack par1ItemStack) {
		return par1ItemStack == null ? false
				: (!(Item.byId[par1ItemStack.id] instanceof ItemFood) ? false
						: ((ItemFood) Item.byId[par1ItemStack.id]).isWolfsFavoriteMeat());
	}

	/**
	 * Will return how many at most can spawn in a chunk at once.
	 */
	public int getMaxSpawnedInChunk() {
		return 8;
	}

	public boolean isAngry() {
		return (this.datawatcher.getByte(16) & 2) != 0;
	}

	public void setAngry(boolean flag) {
		byte b0 = this.datawatcher.getByte(16);

		if (flag) {
			this.datawatcher.watch(16, Byte.valueOf((byte) (b0 | 2)));
		} else {
			this.datawatcher.watch(16, Byte.valueOf((byte) (b0 & -3)));
		}
	}

	public int getCollarColor() {
		return this.datawatcher.getByte(20) & 15;
	}

	public void setCollarColor(int i) {
		this.datawatcher.watch(20, Byte.valueOf((byte) (i & 15)));
	}

	/**
	 * This function is used when two same-species animals in 'love mode' breed
	 * to generate the new baby animal.
	 */
	public EntityWolf spawnBabyAnimal(EntityAgeable par1EntityAgeable) {
		EntityWolf var2 = new EntityWolf(this.world);
		String var3 = this.getOwnerName();

		if (var3 != null && var3.trim().length() > 0) {
			var2.setOwnerName(var3);
			var2.setTamed(true);
		}

		return var2;
	}

	public void func_70918_i(boolean par1) {
		if (par1) {
			this.datawatcher.watch(19, Byte.valueOf((byte) 1));
		} else {
			this.datawatcher.watch(19, Byte.valueOf((byte) 0));
		}
	}

	public boolean mate(EntityAnimal entityanimal) {
		if (entityanimal == this) {
			return false;
		} else if (!this.isTamed()) {
			return false;
		} else if (!(entityanimal instanceof EntityWolf)) {
			return false;
		} else {
			EntityWolf entitywolf = (EntityWolf) entityanimal;
			return !entitywolf.isTamed() ? false
					: (entitywolf.isSitting() ? false : this.isInLove() && entitywolf.isInLove());
		}
	}

	public boolean func_70922_bv() {
		return this.datawatcher.getByte(19) == 1;
	}

	protected boolean isTypeNotPersistent() {
		return !this.isTamed();
	}

	public boolean a(EntityLiving entityliving, EntityLiving entityliving1) {
		if (!(entityliving instanceof EntityCreeper) && !(entityliving instanceof EntityGhast)) {
			if (entityliving instanceof EntityWolf) {
				EntityWolf entitywolf = (EntityWolf) entityliving;

				if (entitywolf.isTamed() && entitywolf.getOwner() == entityliving1) {
					return false;
				}
			}

			return entityliving instanceof EntityHuman && entityliving1 instanceof EntityHuman
					&& !((EntityHuman) entityliving1).canAttackPlayer((EntityHuman) entityliving) ? false
							: !(entityliving instanceof EntityHorse) || !((EntityHorse) entityliving).isTame();
		} else {
			return false;
		}
	}

	public EntityAgeable createChild(EntityAgeable entityageable) {
		return this.spawnBabyAnimal(entityageable);
	}
}
