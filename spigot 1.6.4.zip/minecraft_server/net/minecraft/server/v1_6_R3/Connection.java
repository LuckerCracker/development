package net.minecraft.server.v1_6_R3;

public abstract class Connection
{
    public abstract boolean a();

    public void a(Packet51MapChunk var1) {}

    public void onUnhandledPacket(Packet var1) {}

    public void a(String var1, Object[] var2) {}

    public void a(Packet255KickDisconnect var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet1Login var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet10Flying var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet52MultiBlockChange var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet14BlockDig var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet53BlockChange var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet20NamedEntitySpawn var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet30Entity var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet34EntityTeleport var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet15Place var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet16BlockItemSwitch var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet29DestroyEntity var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet22Collect var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet3Chat var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet23VehicleSpawn var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet18ArmAnimation var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet19EntityAction var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet2Handshake var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet253KeyRequest var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet252KeyResponse var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet24MobSpawn var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet4UpdateTime var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet6SpawnPosition var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet28EntityVelocity var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet40EntityMetadata var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet39AttachEntity var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet7UseEntity var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet38EntityStatus var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet8UpdateHealth var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet9Respawn var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet60Explosion var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet100OpenWindow var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void handleContainerClose(Packet101CloseWindow var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet102WindowClick var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet103SetSlot var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet104WindowItems var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet130UpdateSign var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet105CraftProgressBar var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet5EntityEquipment var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet106Transaction var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet25EntityPainting var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet54PlayNoteBlock var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet200Statistic var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet17EntityLocationAction var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet27PlayerInput var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet70Bed var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet71Weather var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet131ItemData var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet61WorldEvent var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet254GetInfo var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet41MobEffect var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet42RemoveMobEffect var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet201PlayerInfo var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet0KeepAlive var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet43SetExperience var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet107SetCreativeSlot var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet26AddExpOrb var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet108ButtonClick var1) {}

    public void a(Packet250CustomPayload var1) {}

    public void a(Packet35EntityHeadRotation var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet132TileEntityData var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet202Abilities var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet203TabComplete var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet204LocaleAndViewDistance var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet62NamedSoundEffect var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet55BlockBreakAnimation var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet205ClientCommand var1) {}

    public void a(Packet56MapChunkBulk var1)
    {
        this.onUnhandledPacket(var1);
    }

    public boolean b()
    {
        return false;
    }

    public void a(Packet206SetScoreboardObjective var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet207SetScoreboardScore var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet208SetScoreboardDisplayObjective var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet209SetScoreboardTeam var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet63WorldParticles var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet44UpdateAttributes var1)
    {
        this.onUnhandledPacket(var1);
    }

    public void a(Packet133OpenTileEntity var1) {}

    public boolean c()
    {
        return false;
    }
}
