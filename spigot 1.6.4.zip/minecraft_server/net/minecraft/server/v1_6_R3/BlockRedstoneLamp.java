package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockRedstoneLamp extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    private final boolean displayOnCreativeTab;

    public BlockRedstoneLamp(int i, boolean flag)
    {
        super(i, Material.BUILDABLE_GLASS);
        this.displayOnCreativeTab = flag;

        if (flag)
        {
            this.setLightValue(1.0F);
        }
    }

    public void onPlace(World world, int i, int j, int k)
    {
        if (!world.isStatic)
        {
            if (this.displayOnCreativeTab && !world.isBlockIndirectlyPowered(i, j, k))
            {
                world.scheduleBlockUpdate(i, j, k, this.id, 4);
            }
            else if (!this.displayOnCreativeTab && world.isBlockIndirectlyPowered(i, j, k))
            {
                if (CraftEventFactory.callRedstoneChange(world, i, j, k, 0, 15).getNewCurrent() != 15)
                {
                    return;
                }

                world.setTypeIdAndData(i, j, k, Block.REDSTONE_LAMP_ON.id, 0, 2);
            }
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (!world.isStatic)
        {
            if (this.displayOnCreativeTab && !world.isBlockIndirectlyPowered(i, j, k))
            {
                world.scheduleBlockUpdate(i, j, k, this.id, 4);
            }
            else if (!this.displayOnCreativeTab && world.isBlockIndirectlyPowered(i, j, k))
            {
                if (CraftEventFactory.callRedstoneChange(world, i, j, k, 0, 15).getNewCurrent() != 15)
                {
                    return;
                }

                world.setTypeIdAndData(i, j, k, Block.REDSTONE_LAMP_ON.id, 0, 2);
            }
        }
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        if (!world.isStatic && this.displayOnCreativeTab && !world.isBlockIndirectlyPowered(i, j, k))
        {
            if (CraftEventFactory.callRedstoneChange(world, i, j, k, 15, 0).getNewCurrent() != 0)
            {
                return;
            }

            world.setTypeIdAndData(i, j, k, Block.REDSTONE_LAMP_OFF.id, 0, 2);
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Block.REDSTONE_LAMP_OFF.id;
    }
}
