package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.util.Vector;

final class DispenseBehaviorMinecart extends DispenseBehaviorItem
{
    private final DispenseBehaviorItem b = new DispenseBehaviorItem();

    public ItemStack b(ISourceBlock isourceblock, ItemStack itemstack)
    {
        EnumFacing enumfacing = BlockDispenser.getFacing(isourceblock.h());
        World world = isourceblock.k();
        double d0 = isourceblock.getX() + (double)((float)enumfacing.getFrontOffsetX() * 1.125F);
        double d1 = isourceblock.getY() + (double)((float)enumfacing.getFrontOffsetY() * 1.125F);
        double d2 = isourceblock.getZ() + (double)((float)enumfacing.getFrontOffsetZ() * 1.125F);
        int i = isourceblock.getBlockX() + enumfacing.getFrontOffsetX();
        int j = isourceblock.getBlockY() + enumfacing.getFrontOffsetY();
        int k = isourceblock.getBlockZ() + enumfacing.getFrontOffsetZ();
        int l = world.getTypeId(i, j, k);
        double d3;

        if (BlockMinecartTrackAbstract.e_(l))
        {
            d3 = 0.0D;
        }
        else
        {
            if (l != 0 || !BlockMinecartTrackAbstract.e_(world.getTypeId(i, j - 1, k)))
            {
                return this.b.a(isourceblock, itemstack);
            }

            d3 = -1.0D;
        }

        ItemStack itemstack1 = itemstack.splitStack(1);
        org.bukkit.block.Block block = world.getWorld().getBlockAt(isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ());
        CraftItemStack craftItem = CraftItemStack.asCraftMirror(itemstack1);
        BlockDispenseEvent event = new BlockDispenseEvent(block, craftItem.clone(), new Vector(d0, d1 + d3, d2));

        if (!BlockDispenser.eventFired)
        {
            world.getServer().getPluginManager().callEvent(event);
        }

        if (event.isCancelled())
        {
            ++itemstack.count;
            return itemstack;
        }
        else
        {
            if (!event.getItem().equals(craftItem))
            {
                ++itemstack.count;
                ItemStack entityminecartabstract = CraftItemStack.asNMSCopy(event.getItem());
                IDispenseBehavior idispensebehavior = (IDispenseBehavior)BlockDispenser.dispenseBehaviorRegistry.getObject(entityminecartabstract.getItem());

                if (idispensebehavior != IDispenseBehavior.a && idispensebehavior != this)
                {
                    idispensebehavior.a(isourceblock, entityminecartabstract);
                    return itemstack;
                }
            }

            itemstack1 = CraftItemStack.asNMSCopy(event.getItem());
            EntityMinecartAbstract entityminecartabstract1 = EntityMinecartAbstract.a(world, event.getVelocity().getX(), event.getVelocity().getY(), event.getVelocity().getZ(), ((ItemMinecart)itemstack1.getItem()).minecartType);

            if (itemstack.hasName())
            {
                entityminecartabstract1.a(itemstack.getName());
            }

            world.addEntity(entityminecartabstract1);
            return itemstack;
        }
    }

    protected void a(ISourceBlock isourceblock)
    {
        isourceblock.k().triggerEffect(1000, isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ(), 0);
    }
}
