package net.minecraft.server.v1_6_R3;

final class CreativeModeTab12 extends CreativeModeTab
{
    CreativeModeTab12(int var1, String var2)
    {
        super(var1, var2);
    }
}
