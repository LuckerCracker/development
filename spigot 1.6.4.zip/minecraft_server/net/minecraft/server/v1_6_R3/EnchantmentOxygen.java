package net.minecraft.server.v1_6_R3;

public class EnchantmentOxygen extends Enchantment
{
    public EnchantmentOxygen(int par1, int par2)
    {
        super(par1, par2, EnchantmentSlotType.ARMOR_HEAD);
        this.setName("oxygen");
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int par1)
    {
        return 10 * par1;
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int par1)
    {
        return this.getMinEnchantability(par1) + 30;
    }

    public int getMaxLevel()
    {
        return 3;
    }
}
