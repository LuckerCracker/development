package net.minecraft.server.v1_6_R3;

final class DamageCounter implements Counter
{
}
