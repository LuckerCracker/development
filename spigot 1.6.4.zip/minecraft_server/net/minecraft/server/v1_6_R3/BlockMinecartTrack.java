package net.minecraft.server.v1_6_R3;

public class BlockMinecartTrack extends BlockMinecartTrackAbstract
{
    protected BlockMinecartTrack(int var1)
    {
        super(var1, false);
    }

    protected void a(World var1, int var2, int var3, int var4, int var5, int var6, int var7)
    {
        if (var7 > 0 && Block.byId[var7].isPowerSource() && (new MinecartTrackLogic(this, var1, var2, var3, var4)).a() == 3)
        {
            this.a(var1, var2, var3, var4, false);
        }
    }
}
