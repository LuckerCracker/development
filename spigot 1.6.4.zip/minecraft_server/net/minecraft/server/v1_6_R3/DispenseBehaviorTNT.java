package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.util.Vector;

final class DispenseBehaviorTNT extends DispenseBehaviorItem
{
    protected ItemStack b(ISourceBlock isourceblock, ItemStack itemstack)
    {
        EnumFacing enumfacing = BlockDispenser.getFacing(isourceblock.h());
        World world = isourceblock.k();
        int i = isourceblock.getBlockX() + enumfacing.getFrontOffsetX();
        int j = isourceblock.getBlockY() + enumfacing.getFrontOffsetY();
        int k = isourceblock.getBlockZ() + enumfacing.getFrontOffsetZ();
        ItemStack itemstack1 = itemstack.splitStack(1);
        org.bukkit.block.Block block = world.getWorld().getBlockAt(isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ());
        CraftItemStack craftItem = CraftItemStack.asCraftMirror(itemstack1);
        BlockDispenseEvent event = new BlockDispenseEvent(block, craftItem.clone(), new Vector((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D));

        if (!BlockDispenser.eventFired)
        {
            world.getServer().getPluginManager().callEvent(event);
        }

        if (event.isCancelled())
        {
            ++itemstack.count;
            return itemstack;
        }
        else
        {
            if (!event.getItem().equals(craftItem))
            {
                ++itemstack.count;
                ItemStack entitytntprimed = CraftItemStack.asNMSCopy(event.getItem());
                IDispenseBehavior idispensebehavior = (IDispenseBehavior)BlockDispenser.dispenseBehaviorRegistry.getObject(entitytntprimed.getItem());

                if (idispensebehavior != IDispenseBehavior.a && idispensebehavior != this)
                {
                    idispensebehavior.a(isourceblock, entitytntprimed);
                    return itemstack;
                }
            }

            EntityTNTPrimed entitytntprimed1 = new EntityTNTPrimed(world, event.getVelocity().getX(), event.getVelocity().getY(), event.getVelocity().getZ(), (EntityLiving)null);
            world.addEntity(entitytntprimed1);
            return itemstack;
        }
    }
}
