package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandSpawnpoint extends CommandAbstract
{
    public String getCommandName()
    {
        return "spawnpoint";
    }

    public int a()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.spawnpoint.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        EntityPlayer var3 = var2.length == 0 ? b(var1) : d(var1, var2[0]);

        if (var2.length == 4)
        {
            if (var3.world != null)
            {
                byte var4 = 1;
                int var5 = 30000000;
                int var9 = var4 + 1;
                int var6 = a(var1, var2[var4], -var5, var5);
                int var7 = a(var1, var2[var9++], 0, 256);
                int var8 = a(var1, var2[var9++], -var5, var5);
                var3.setRespawnPosition(new ChunkCoordinates(var6, var7, var8), true);
                a(var1, "commands.spawnpoint.success", new Object[] {var3.getLocalizedName(), Integer.valueOf(var6), Integer.valueOf(var7), Integer.valueOf(var8)});
            }
        }
        else
        {
            if (var2.length > 1)
            {
                throw new ExceptionUsage("commands.spawnpoint.usage", new Object[0]);
            }

            ChunkCoordinates var10 = var3.b();
            var3.setRespawnPosition(var10, true);
            a(var1, "commands.spawnpoint.success", new Object[] {var3.getLocalizedName(), Integer.valueOf(var10.x), Integer.valueOf(var10.y), Integer.valueOf(var10.z)});
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length != 1 && var2.length != 2 ? null : a(var2, MinecraftServer.getServer().getPlayers());
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return var2 == 0;
    }
}
