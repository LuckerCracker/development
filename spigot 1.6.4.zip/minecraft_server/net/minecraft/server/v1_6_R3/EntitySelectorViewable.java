package net.minecraft.server.v1_6_R3;

class EntitySelectorViewable implements IEntitySelector
{
    final PathfinderGoalAvoidPlayer c;

    EntitySelectorViewable(PathfinderGoalAvoidPlayer var1)
    {
        this.c = var1;
    }

    /**
     * Return whether the specified entity is applicable to this filter.
     */
    public boolean isEntityApplicable(Entity var1)
    {
        return var1.isAlive() && PathfinderGoalAvoidPlayer.a(this.c).getEntitySenses().canSee(var1);
    }
}
