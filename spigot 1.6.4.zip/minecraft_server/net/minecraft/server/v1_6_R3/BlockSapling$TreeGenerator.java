package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.BlockChangeDelegate;

public interface BlockSapling$TreeGenerator {
	boolean generate(World var1, Random var2, int var3, int var4, int var5);

	boolean generate(BlockChangeDelegate var1, Random var2, int var3, int var4, int var5);
}
