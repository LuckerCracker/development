package net.minecraft.server.v1_6_R3;

public class BiomeTheEndDecorator extends BiomeDecorator
{
    protected WorldGenerator L;

    public BiomeTheEndDecorator(BiomeBase var1)
    {
        super(var1);
        this.L = new WorldGenEnder(Block.WHITESTONE.id);
    }

    /**
     * The method that does the work of actually decorating chunks
     */
    protected void decorate()
    {
        this.generateOres();

        if (this.randomGenerator.nextInt(5) == 0)
        {
            int var1 = this.chunk_X + this.randomGenerator.nextInt(16) + 8;
            int var2 = this.chunk_Z + this.randomGenerator.nextInt(16) + 8;
            int var3 = this.currentWorld.getTopSolidOrLiquidBlock(var1, var2);
            this.L.generate(this.currentWorld, this.randomGenerator, var1, var3, var2);
        }

        if (this.chunk_X == 0 && this.chunk_Z == 0)
        {
            EntityEnderDragon var4 = new EntityEnderDragon(this.currentWorld);
            var4.setPositionRotation(0.0D, 128.0D, 0.0D, this.randomGenerator.nextFloat() * 360.0F, 0.0F);
            this.currentWorld.addEntity(var4);
        }
    }
}
