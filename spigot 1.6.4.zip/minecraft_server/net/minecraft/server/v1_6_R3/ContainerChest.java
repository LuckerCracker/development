package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryDoubleChest;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryPlayer;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;

public class ContainerChest extends Container {
	public IInventory container;
	private int numRows;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			Object inventory;

			if (this.container instanceof PlayerInventory) {
				inventory = new CraftInventoryPlayer((PlayerInventory) this.container);
			} else if (this.container instanceof InventoryLargeChest) {
				inventory = new CraftInventoryDoubleChest((InventoryLargeChest) this.container);
			} else {
				inventory = new CraftInventory(this.container);
			}

			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(), (Inventory) inventory,
					this);
			return this.bukkitEntity;
		}
	}

	public ContainerChest(IInventory par1IInventory, IInventory par2IInventory) {
		this.container = par2IInventory;
		this.numRows = par2IInventory.getSize() / 9;
		par2IInventory.startOpen();
		int var3 = (this.numRows - 4) * 18;
		this.player = (PlayerInventory) par1IInventory;
		int var4;
		int var5;

		for (var4 = 0; var4 < this.numRows; ++var4) {
			for (var5 = 0; var5 < 9; ++var5) {
				this.addSlotToContainer(new Slot(par2IInventory, var5 + var4 * 9, 8 + var5 * 18, 18 + var4 * 18));
			}
		}

		for (var4 = 0; var4 < 3; ++var4) {
			for (var5 = 0; var5 < 9; ++var5) {
				this.addSlotToContainer(
						new Slot(par1IInventory, var5 + var4 * 9 + 9, 8 + var5 * 18, 103 + var4 * 18 + var3));
			}
		}

		for (var4 = 0; var4 < 9; ++var4) {
			this.addSlotToContainer(new Slot(par1IInventory, var4, 8 + var4 * 18, 161 + var3));
		}
	}

	public boolean a(EntityHuman entityhuman) {
		return !this.checkReachable ? true : this.container.a(entityhuman);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i < this.numRows * 9) {
				if (!this.mergeItemStack(itemstack1, this.numRows * 9, this.inventorySlots.size(), true)) {
					return null;
				}
			} else if (!this.mergeItemStack(itemstack1, 0, this.numRows * 9, false)) {
				return null;
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}
		}

		return itemstack;
	}

	public void b(EntityHuman entityhuman) {
		super.b(entityhuman);
		this.container.closeChest();
	}

	/**
	 * Return this chest container's lower chest inventory.
	 */
	public IInventory getLowerChestInventory() {
		return this.container;
	}
}
