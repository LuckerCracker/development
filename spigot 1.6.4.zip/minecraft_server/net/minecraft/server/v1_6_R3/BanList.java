package net.minecraft.server.v1_6_R3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

public class BanList
{
    private final InsensitiveStringMap theBanList = new InsensitiveStringMap();
    private final File fileName;

    /** set to true if not singlePlayer */
    private boolean listActive = true;

    public BanList(File par1File)
    {
        this.fileName = par1File;
    }

    public boolean isEnabled()
    {
        return this.listActive;
    }

    public void setEnabled(boolean var1)
    {
        this.listActive = var1;
    }

    public Map getEntries()
    {
        this.removeExpired();
        return this.theBanList;
    }

    public boolean isBanned(String var1)
    {
        if (!this.isEnabled())
        {
            return false;
        }
        else
        {
            this.removeExpired();
            return this.theBanList.containsKey(var1);
        }
    }

    public void add(BanEntry var1)
    {
        this.theBanList.put(var1.getName(), var1);
        this.save();
    }

    public void remove(String var1)
    {
        this.theBanList.remove(var1);
        this.save();
    }

    public void removeExpired()
    {
        Iterator var1 = this.theBanList.values().iterator();

        while (var1.hasNext())
        {
            BanEntry var2 = (BanEntry)var1.next();

            if (var2.hasExpired())
            {
                var1.remove();
            }
        }
    }

    public void load()
    {
        if (this.fileName.isFile())
        {
            BufferedReader var1;

            try
            {
                var1 = new BufferedReader(new FileReader(this.fileName));
            }
            catch (FileNotFoundException var4)
            {
                throw new Error();
            }

            String var2;

            try
            {
                while ((var2 = var1.readLine()) != null)
                {
                    if (!var2.startsWith("#"))
                    {
                        BanEntry var3 = BanEntry.parse(var2);

                        if (var3 != null)
                        {
                            this.theBanList.put(var3.getName(), var3);
                        }
                    }
                }
            }
            catch (IOException var5)
            {
                MinecraftServer.getServer().getLogger().severe("Could not load ban list", var5);
            }
        }
    }

    public void save()
    {
        this.save(true);
    }

    public void save(boolean var1)
    {
        this.removeExpired();

        try
        {
            PrintWriter var2 = new PrintWriter(new FileWriter(this.fileName, false));

            if (var1)
            {
                var2.println("# Updated " + (new SimpleDateFormat()).format(new Date()) + " by Minecraft " + "1.6.4");
                var2.println("# victim name | ban date | banned by | banned until | reason");
                var2.println();
            }

            Iterator var3 = this.theBanList.values().iterator();

            while (var3.hasNext())
            {
                BanEntry var4 = (BanEntry)var3.next();
                var2.println(var4.buildBanString());
            }

            var2.close();
        }
        catch (IOException var5)
        {
            MinecraftServer.getServer().getLogger().severe("Could not save ban list", var5);
        }
    }
}
