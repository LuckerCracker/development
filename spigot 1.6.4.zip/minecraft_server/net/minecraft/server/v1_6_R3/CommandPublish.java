package net.minecraft.server.v1_6_R3;

public class CommandPublish extends CommandAbstract
{
    public String getCommandName()
    {
        return "publish";
    }

    public int a()
    {
        return 4;
    }

    public String c(ICommandListener var1)
    {
        return "commands.publish.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        String var3 = MinecraftServer.getServer().a(EnumGamemode.SURVIVAL, false);

        if (var3 != null)
        {
            a(var1, "commands.publish.started", new Object[] {var3});
        }
        else
        {
            a(var1, "commands.publish.failed", new Object[0]);
        }
    }
}
