package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.event.block.BlockRedstoneEvent;

public class BlockCommand extends BlockContainer
{
    public BlockCommand(int i)
    {
        super(i, Material.ORE);
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World world)
    {
        return new TileEntityCommand();
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (!world.isStatic)
        {
            boolean flag = world.isBlockIndirectlyPowered(i, j, k);
            int i1 = world.getData(i, j, k);
            boolean flag1 = (i1 & 1) != 0;
            org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
            int old = flag1 ? 15 : 0;
            int current = flag ? 15 : 0;
            BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, old, current);
            world.getServer().getPluginManager().callEvent(eventRedstone);

            if (eventRedstone.getNewCurrent() > 0 && eventRedstone.getOldCurrent() <= 0)
            {
                world.setData(i, j, k, i1 | 1, 4);
                world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
            }
            else if (eventRedstone.getNewCurrent() <= 0 && eventRedstone.getOldCurrent() > 0)
            {
                world.setData(i, j, k, i1 & -2, 4);
            }
        }
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        TileEntity tileentity = world.getTileEntity(i, j, k);

        if (tileentity != null && tileentity instanceof TileEntityCommand)
        {
            TileEntityCommand tileentitycommand = (TileEntityCommand)tileentity;
            tileentitycommand.a(tileentitycommand.a(world));
            world.func_96440_m(i, j, k, this.id);
        }
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World world)
    {
        return 1;
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        TileEntityCommand tileentitycommand = (TileEntityCommand)world.getTileEntity(i, j, k);

        if (tileentitycommand != null)
        {
            entityhuman.openEditSign((TileEntity)tileentitycommand);
        }

        return true;
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World world, int i, int j, int k, int l)
    {
        TileEntity tileentity = world.getTileEntity(i, j, k);
        return tileentity != null && tileentity instanceof TileEntityCommand ? ((TileEntityCommand)tileentity).f() : 0;
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack)
    {
        TileEntityCommand tileentitycommand = (TileEntityCommand)world.getTileEntity(i, j, k);

        if (itemstack.hasName())
        {
            tileentitycommand.b(itemstack.getName());
        }
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random random)
    {
        return 0;
    }
}
