package net.minecraft.server.v1_6_R3;

import java.io.File;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import org.bukkit.craftbukkit.libs.joptsimple.OptionSet;
import org.bukkit.craftbukkit.v1_6_R3.LoggerOutputStream;
import org.bukkit.craftbukkit.v1_6_R3.command.CraftRemoteConsoleCommandSender;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.plugin.PluginLoadOrder;
import org.spigotmc.SpigotConfig;
import org.spigotmc.SpigotConfig$Listener;
import org.spigotmc.netty.NettyServerConnection;

public class DedicatedServer extends MinecraftServer implements IMinecraftServer
{
    private final List pendingCommandList = Collections.synchronizedList(new ArrayList());
    private final IConsoleLogManager field_98131_l = new ConsoleLogManager("Minecraft-Server", (String)null, (String)null);
    private RemoteStatusListener theRConThreadQuery;
    private RemoteControlListener theRConThreadMain;
    public PropertyManager propertyManager;
    private boolean generateStructures;
    private EnumGamemode gameType;
    private ServerConnection networkThread;
    private boolean guiIsEnabled;

    public DedicatedServer(OptionSet options)
    {
        super(options);
    }

    protected boolean init() throws UnknownHostException
    {
        ThreadCommandReader threadcommandreader = new ThreadCommandReader(this);
        threadcommandreader.setDaemon(true);
        threadcommandreader.start();
        System.setOut(new PrintStream(new LoggerOutputStream(this.getLogger().getLogger(), Level.INFO), true));
        System.setErr(new PrintStream(new LoggerOutputStream(this.getLogger().getLogger(), Level.SEVERE), true));
        this.getLogger().info("Starting minecraft server version 1.6.4");

        if (Runtime.getRuntime().maxMemory() / 1024L / 1024L < 512L)
        {
            this.getLogger().warning("To start the server with more ram, launch it as \"java -Xmx1024M -Xms1024M -jar minecraft_server.jar\"");
        }

        this.getLogger().info("Loading properties");
        this.propertyManager = new PropertyManager(this.options, this.getLogger());

        if (this.K())
        {
            this.c("127.0.0.1");
        }
        else
        {
            this.setOnlineMode(this.propertyManager.getBoolean("online-mode", true));
            this.c(this.propertyManager.getString("server-ip", ""));
        }

        this.setSpawnAnimals(this.propertyManager.getBoolean("spawn-animals", true));
        this.setSpawnNPCs(this.propertyManager.getBoolean("spawn-npcs", true));
        this.setPvP(this.propertyManager.getBoolean("pvp", true));
        this.setAllowFlight(this.propertyManager.getBoolean("allow-flight", false));
        this.setTexturePack(this.propertyManager.getString("texture-pack", ""));
        this.setMotd(this.propertyManager.getString("motd", "A Minecraft Server"));
        this.setForceGamemode(this.propertyManager.getBoolean("force-gamemode", false));
        this.func_143006_e(this.propertyManager.getInt("player-idle-timeout", 0));

        if (this.propertyManager.getInt("difficulty", 1) < 0)
        {
            this.propertyManager.setProperty("difficulty", Integer.valueOf(0));
        }
        else if (this.propertyManager.getInt("difficulty", 1) > 3)
        {
            this.propertyManager.setProperty("difficulty", Integer.valueOf(3));
        }

        this.generateStructures = this.propertyManager.getBoolean("generate-structures", true);
        int i = this.propertyManager.getInt("gamemode", EnumGamemode.SURVIVAL.a());
        this.gameType = WorldSettings.a(i);
        this.getLogger().info("Default game type: " + this.gameType);
        InetAddress inetaddress = null;

        if (this.getServerIp().length() > 0)
        {
            inetaddress = InetAddress.getByName(this.getServerIp());
        }

        if (this.I() < 0)
        {
            this.setPort(this.propertyManager.getInt("server-port", 25565));
        }

        this.a(new DedicatedPlayerList(this));
        SpigotConfig.init();
        SpigotConfig.registerCommands();
        this.getLogger().info("Generating keypair");
        this.a(MinecraftEncryption.b());
        this.getLogger().info("Starting Minecraft server on " + (this.getServerIp().length() == 0 ? "*" : this.getServerIp()) + ":" + this.I());

        try
        {
            this.networkThread = (ServerConnection)(((SpigotConfig$Listener)SpigotConfig.listeners.get(0)).netty ? new NettyServerConnection(this, inetaddress, this.I()) : new DedicatedServerConnection(this, inetaddress, this.I()));
        }
        catch (Throwable var19)
        {
            this.getLogger().warning("**** FAILED TO BIND TO PORT!");
            this.getLogger().warning("The exception was: {0}", new Object[] {var19.toString()});
            this.getLogger().warning("Perhaps a server is already running on that port?");
            return false;
        }

        this.server.loadPlugins();
        this.server.enablePlugins(PluginLoadOrder.STARTUP);

        if (!this.getOnlineMode())
        {
            this.getLogger().warning("**** SERVER IS RUNNING IN OFFLINE/INSECURE MODE!");
            this.getLogger().warning("The server will make no attempt to authenticate usernames. Beware.");
            this.getLogger().warning("While this makes the game possible to play without internet access, it also opens up the ability for hackers to connect with any username they choose.");
            this.getLogger().warning("To change this, set \"online-mode\" to \"true\" in the server.properties file.");
        }

        this.convertable = new WorldLoaderServer(this.server.getWorldContainer());
        long j = System.nanoTime();

        if (this.L() == null)
        {
            this.k(this.propertyManager.getString("level-name", "world"));
        }

        String s = this.propertyManager.getString("level-seed", "");
        String s1 = this.propertyManager.getString("level-type", "DEFAULT");
        String s2 = this.propertyManager.getString("generator-settings", "");
        long k = (new Random()).nextLong();

        if (s.length() > 0)
        {
            try
            {
                long l = Long.parseLong(s);

                if (l != 0L)
                {
                    k = l;
                }
            }
            catch (NumberFormatException var18)
            {
                k = (long)s.hashCode();
            }
        }

        WorldType worldtype = WorldType.getType(s1);

        if (worldtype == null)
        {
            worldtype = WorldType.NORMAL;
        }

        this.d(this.propertyManager.getInt("max-build-height", 256));
        this.d((this.getMaxBuildHeight() + 8) / 16 * 16);
        this.d(MathHelper.clamp_int(this.getMaxBuildHeight(), 64, 256));
        this.propertyManager.setProperty("max-build-height", Integer.valueOf(this.getMaxBuildHeight()));
        this.getLogger().info("Preparing level \"" + this.L() + "\"");
        this.a(this.L(), this.L(), k, worldtype, s2);
        long i1 = System.nanoTime() - j;
        String s3 = String.format("%.3fs", new Object[] {Double.valueOf((double)i1 / 1.0E9D)});
        this.getLogger().info("Done (" + s3 + ")! For help, type \"help\" or \"?\"");

        if (this.propertyManager.getBoolean("enable-query", false))
        {
            this.getLogger().info("Starting GS4 status listener");
            this.theRConThreadQuery = new RemoteStatusListener(this);
            this.theRConThreadQuery.a();
        }

        if (this.propertyManager.getBoolean("enable-rcon", false))
        {
            this.getLogger().info("Starting remote control listener");
            this.theRConThreadMain = new RemoteControlListener(this);
            this.theRConThreadMain.a();
            this.remoteConsole = new CraftRemoteConsoleCommandSender();
        }

        if (this.server.getBukkitSpawnRadius() > -1)
        {
            this.getLogger().info("\'settings.spawn-radius\' in bukkit.yml has been moved to \'spawn-protection\' in server.properties. I will move your config for you.");
            this.propertyManager.properties.remove("spawn-protection");
            this.propertyManager.getInt("spawn-protection", this.server.getBukkitSpawnRadius());
            this.server.removeBukkitSpawnRadius();
            this.propertyManager.savePropertiesFile();
        }

        return true;
    }

    public PropertyManager getPropertyManager()
    {
        return this.propertyManager;
    }

    public boolean getGenerateStructures()
    {
        return this.generateStructures;
    }

    public EnumGamemode getGamemode()
    {
        return this.gameType;
    }

    public int getDifficulty()
    {
        return Math.max(0, Math.min(3, this.propertyManager.getInt("difficulty", 1)));
    }

    public boolean isHardcore()
    {
        return this.propertyManager.getBoolean("hardcore", false);
    }

    /**
     * Called on exit from the main run() loop.
     */
    protected void finalTick(CrashReport par1CrashReport)
    {
        while (this.isRunning())
        {
            this.executePendingCommands();

            try
            {
                Thread.sleep(10L);
            }
            catch (InterruptedException var3)
            {
                var3.printStackTrace();
            }
        }
    }

    /**
     * Adds the server info, including from theWorldServer, to the crash report.
     */
    public CrashReport addServerInfoToCrashReport(CrashReport par1CrashReport)
    {
        par1CrashReport = super.b(par1CrashReport);
        par1CrashReport.g().a("Is Modded", (Callable)(new CrashReportModded(this)));
        par1CrashReport.g().a("Type", (Callable)(new CrashReportType(this)));
        return par1CrashReport;
    }

    /**
     * Directly calls System.exit(0), instantly killing the program.
     */
    protected void systemExitNow()
    {
        System.exit(0);
    }

    public void updateTimeLightAndEntities()
    {
        super.t();
        this.executePendingCommands();
    }

    public boolean getAllowNether()
    {
        return this.propertyManager.getBoolean("allow-nether", true);
    }

    public boolean getSpawnMonsters()
    {
        return this.propertyManager.getBoolean("spawn-monsters", true);
    }

    public void a(MojangStatisticsGenerator mojangstatisticsgenerator)
    {
        mojangstatisticsgenerator.a("whitelist_enabled", Boolean.valueOf(this.getDedicatedPlayerList().getHasWhitelist()));
        mojangstatisticsgenerator.a("whitelist_count", Integer.valueOf(this.getDedicatedPlayerList().getWhitelisted().size()));
        super.a(mojangstatisticsgenerator);
    }

    public boolean getSnooperEnabled()
    {
        return this.propertyManager.getBoolean("snooper-enabled", true);
    }

    public void issueCommand(String s, ICommandListener icommandlistener)
    {
        this.pendingCommandList.add(new ServerCommand(s, icommandlistener));
    }

    public void executePendingCommands()
    {
        while (!this.pendingCommandList.isEmpty())
        {
            ServerCommand var1 = (ServerCommand)this.pendingCommandList.remove(0);
            ServerCommandEvent var2 = new ServerCommandEvent(this.console, var1.command);
            this.server.getPluginManager().callEvent(var2);
            var1 = new ServerCommand(var2.getCommand(), var1.source);
            this.server.dispatchServerCommand(this.console, var1);
        }
    }

    public boolean isDedicatedServer()
    {
        return true;
    }

    public DedicatedPlayerList getDedicatedPlayerList()
    {
        return (DedicatedPlayerList)super.getPlayerList();
    }

    public ServerConnection ag()
    {
        return this.networkThread;
    }

    /**
     * Gets an integer property. If it does not exist, set it to the specified value.
     */
    public int getIntProperty(String par1Str, int par2)
    {
        return this.propertyManager.getInt(par1Str, par2);
    }

    /**
     * Gets a string property. If it does not exist, set it to the specified value.
     */
    public String getStringProperty(String par1Str, String par2Str)
    {
        return this.propertyManager.getString(par1Str, par2Str);
    }

    /**
     * Gets a boolean property. If it does not exist, set it to the specified value.
     */
    public boolean getBooleanProperty(String par1Str, boolean par2)
    {
        return this.propertyManager.getBoolean(par1Str, par2);
    }

    /**
     * Saves an Object with the given property name.
     */
    public void setProperty(String par1Str, Object par2Obj)
    {
        this.propertyManager.setProperty(par1Str, par2Obj);
    }

    /**
     * Saves all of the server properties to the properties file.
     */
    public void saveProperties()
    {
        this.propertyManager.savePropertiesFile();
    }

    /**
     * Returns the filename where server properties are stored
     */
    public String getSettingsFilename()
    {
        File var1 = this.propertyManager.getPropertiesFile();
        return var1 != null ? var1.getAbsolutePath() : "No settings file";
    }

    public void func_120011_ar()
    {
        ServerGUI.a(this);
        this.guiIsEnabled = true;
    }

    public boolean getGuiEnabled()
    {
        return this.guiIsEnabled;
    }

    public String a(EnumGamemode enumgamemode, boolean flag)
    {
        return "";
    }

    public boolean getEnableCommandBlock()
    {
        return this.propertyManager.getBoolean("enable-command-block", false);
    }

    public int getSpawnProtection()
    {
        return this.propertyManager.getInt("spawn-protection", super.getSpawnProtection());
    }

    public boolean a(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if (world.worldProvider.dimension != 0)
        {
            return false;
        }
        else if (this.getDedicatedPlayerList().getOPs().isEmpty())
        {
            return false;
        }
        else if (this.getDedicatedPlayerList().isOp(entityhuman.getName()))
        {
            return false;
        }
        else if (this.getSpawnProtection() <= 0)
        {
            return false;
        }
        else
        {
            ChunkCoordinates chunkcoordinates = world.getSpawn();
            int l = MathHelper.abs_int(i - chunkcoordinates.x);
            int i1 = MathHelper.abs_int(k - chunkcoordinates.z);
            int j1 = Math.max(l, i1);
            return j1 <= this.getSpawnProtection();
        }
    }

    public IConsoleLogManager getLogger()
    {
        return this.field_98131_l;
    }

    public int func_110455_j()
    {
        return this.propertyManager.getInt("op-permission-level", 4);
    }

    public void func_143006_e(int par1)
    {
        super.e(par1);
        this.propertyManager.setProperty("player-idle-timeout", Integer.valueOf(par1));
        this.saveProperties();
    }

    public PlayerList getPlayerList()
    {
        return this.getDedicatedPlayerList();
    }
}
