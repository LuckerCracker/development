package net.minecraft.server.v1_6_R3;

public class ChunkCoordinatesPortal extends ChunkCoordinates
{
    public long d;

    final PortalTravelAgent e;

    public ChunkCoordinatesPortal(PortalTravelAgent var1, int var2, int var3, int var4, long var5)
    {
        super(var2, var3, var4);
        this.e = var1;
        this.d = var5;
    }
}
