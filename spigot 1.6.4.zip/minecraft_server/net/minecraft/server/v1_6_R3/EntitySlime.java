package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Slime;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.SlimeSplitEvent;

public class EntitySlime extends EntityInsentient implements IMonster
{
    public float squishAmount;
    public float squishFactor;
    public float prevSquishFactor;
    private int jumpDelay;
    private Entity lastTarget;

    public EntitySlime(World par1World)
    {
        super(par1World);
        int var2 = 1 << this.random.nextInt(3);
        this.height = 0.0F;
        this.jumpDelay = this.random.nextInt(20) + 10;
        this.setSize(var2);
    }

    protected void entityInit()
    {
        super.entityInit();
        this.datawatcher.addObject(16, new Byte((byte)1));
    }

    public void setSize(int i)
    {
        this.datawatcher.watch(16, new Byte((byte)i));
        this.setSize(0.6F * (float)i, 0.6F * (float)i);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.getAttributeInstance(GenericAttributes.a).setValue((double)(i * i));
        this.setHealth(this.getMaxHealth());
        this.experienceValue = i;
    }

    public int getSize()
    {
        return this.datawatcher.getByte(16);
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setInt("Size", this.getSize() - 1);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);
        this.setSize(par1NBTTagCompound.getInt("Size") + 1);
    }

    /**
     * Returns the name of a particle effect that may be randomly created by EntitySlime.onUpdate()
     */
    protected String getSlimeParticle()
    {
        return "slime";
    }

    /**
     * Returns the name of the sound played when the slime jumps.
     */
    protected String getJumpSound()
    {
        return "mob.slime." + (this.getSize() > 1 ? "big" : "small");
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        if (!this.world.isStatic && this.world.difficulty == 0 && this.getSize() > 0)
        {
            this.dead = true;
        }

        this.squishFactor += (this.squishAmount - this.squishFactor) * 0.5F;
        this.prevSquishFactor = this.squishFactor;
        boolean var1 = this.onGround;
        super.onUpdate();
        int var2;

        if (this.onGround && !var1)
        {
            var2 = this.getSize();

            for (int var3 = 0; var3 < var2 * 8; ++var3)
            {
                float var4 = this.random.nextFloat() * (float)Math.PI * 2.0F;
                float var5 = this.random.nextFloat() * 0.5F + 0.5F;
                float var6 = MathHelper.sin(var4) * (float)var2 * 0.5F * var5;
                float var7 = MathHelper.cos(var4) * (float)var2 * 0.5F * var5;
                this.world.addParticle(this.getSlimeParticle(), this.locX + (double)var6, this.boundingBox.minY, this.locZ + (double)var7, 0.0D, 0.0D, 0.0D);
            }

            if (this.makesSoundOnLand())
            {
                this.makeSound(this.getJumpSound(), this.getSoundVolume(), ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) / 0.8F);
            }

            this.squishAmount = -0.5F;
        }
        else if (!this.onGround && var1)
        {
            this.squishAmount = 1.0F;
        }

        this.alterSquishAmount();

        if (this.world.isStatic)
        {
            var2 = this.getSize();
            this.setSize(0.6F * (float)var2, 0.6F * (float)var2);
        }
    }

    protected void updateEntityActionState()
    {
        this.despawnEntity();
        Object var1 = this.world.findNearbyVulnerablePlayer(this, 16.0D);
        EntityTargetEvent var2 = null;

        if (var1 != null && !((Entity)var1).equals(this.lastTarget))
        {
            var2 = CraftEventFactory.callEntityTargetEvent(this, (Entity)var1, EntityTargetEvent.TargetReason.CLOSEST_PLAYER);
        }
        else if (this.lastTarget != null && var1 == null)
        {
            var2 = CraftEventFactory.callEntityTargetEvent(this, (Entity)var1, EntityTargetEvent.TargetReason.FORGOT_TARGET);
        }

        if (var2 != null && !var2.isCancelled())
        {
            var1 = var2.getTarget() == null ? null : ((CraftEntity)var2.getTarget()).getHandle();
        }

        this.lastTarget = (Entity)var1;

        if (var1 != null)
        {
            this.faceEntity((Entity)var1, 10.0F, 20.0F);
        }

        if (this.onGround && this.jumpDelay-- <= 0)
        {
            this.jumpDelay = this.getJumpDelay();

            if (var1 != null)
            {
                this.jumpDelay /= 3;
            }

            this.isJumping = true;

            if (this.makesSoundOnJump())
            {
                this.makeSound(this.getJumpSound(), this.getSoundVolume(), ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) * 0.8F);
            }

            this.moveStrafing = 1.0F - this.random.nextFloat() * 2.0F;
            this.moveForward = (float)(1 * this.getSize());
        }
        else
        {
            this.isJumping = false;

            if (this.onGround)
            {
                this.moveStrafing = this.moveForward = 0.0F;
            }
        }
    }

    protected void alterSquishAmount()
    {
        this.squishAmount *= 0.6F;
    }

    /**
     * Gets the amount of time the slime needs to wait between jumps.
     */
    protected int getJumpDelay()
    {
        return this.random.nextInt(20) + 10;
    }

    protected EntitySlime createInstance()
    {
        return new EntitySlime(this.world);
    }

    public void die()
    {
        int i = this.getSize();

        if (!this.world.isStatic && i > 1 && this.getHealth() <= 0.0F)
        {
            int j = 2 + this.random.nextInt(3);
            SlimeSplitEvent event = new SlimeSplitEvent((Slime)this.getBukkitEntity(), j);
            this.world.getServer().getPluginManager().callEvent(event);

            if (event.isCancelled() || event.getCount() <= 0)
            {
                super.die();
                return;
            }

            j = event.getCount();

            for (int k = 0; k < j; ++k)
            {
                float f = ((float)(k % 2) - 0.5F) * (float)i / 4.0F;
                float f1 = ((float)(k / 2) - 0.5F) * (float)i / 4.0F;
                EntitySlime entityslime = this.createInstance();
                entityslime.setSize(i / 2);
                entityslime.setPositionRotation(this.locX + (double)f, this.locY + 0.5D, this.locZ + (double)f1, this.random.nextFloat() * 360.0F, 0.0F);
                this.world.addEntity(entityslime, CreatureSpawnEvent.SpawnReason.SLIME_SPLIT);
            }
        }

        super.die();
    }

    public void b_(EntityHuman entityhuman)
    {
        if (this.canDamagePlayer())
        {
            int i = this.getSize();

            if (this.canEntityBeSeen(entityhuman) && this.getDistanceSqToEntity(entityhuman) < 0.6D * (double)i * 0.6D * (double)i && entityhuman.attackEntityFrom(DamageSource.mobAttack(this), (float)this.getAttackStrength()))
            {
                this.makeSound("mob.attack", 1.0F, (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
            }
        }
    }

    /**
     * Indicates weather the slime is able to damage the player (based upon the slime's size)
     */
    protected boolean canDamagePlayer()
    {
        return this.getSize() > 1;
    }

    /**
     * Gets the amount of damage dealt to the player when "attacked" by the slime.
     */
    protected int getAttackStrength()
    {
        return this.getSize();
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.slime." + (this.getSize() > 1 ? "big" : "small");
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.slime." + (this.getSize() > 1 ? "big" : "small");
    }

    protected int getLootId()
    {
        return this.getSize() == 1 ? Item.SLIME_BALL.id : 0;
    }

    public boolean canSpawn()
    {
        Chunk chunk = this.world.getChunkAtWorldCoords(MathHelper.floor(this.locX), MathHelper.floor(this.locZ));

        if (this.world.getWorldData().getType() == WorldType.FLAT && this.random.nextInt(4) != 1)
        {
            return false;
        }
        else
        {
            if (this.getSize() == 1 || this.world.difficulty > 0)
            {
                BiomeBase biomebase = this.world.getBiome(MathHelper.floor(this.locX), MathHelper.floor(this.locZ));

                if (biomebase == BiomeBase.SWAMPLAND && this.locY > 50.0D && this.locY < 70.0D && this.random.nextFloat() < 0.5F && this.random.nextFloat() < this.world.getCurrentMoonPhaseFactor() && this.world.getLightLevel(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ)) <= this.random.nextInt(8))
                {
                    return super.canSpawn();
                }

                if (this.random.nextInt(10) == 0 && chunk.getRandomWithSeed(987234911L).nextInt(10) == 0 && this.locY < 40.0D)
                {
                    return super.canSpawn();
                }
            }

            return false;
        }
    }

    /**
     * Returns the volume for the sounds this mob makes.
     */
    protected float getSoundVolume()
    {
        return 0.4F * (float)this.getSize();
    }

    /**
     * The speed it takes to move the entityliving's rotationPitch through the faceEntity method. This is only currently
     * use in wolves.
     */
    public int getVerticalFaceSpeed()
    {
        return 0;
    }

    /**
     * Returns true if the slime makes a sound when it jumps (based upon the slime's size)
     */
    protected boolean makesSoundOnJump()
    {
        return this.getSize() > 0;
    }

    /**
     * Returns true if the slime makes a sound when it lands after a jump (based upon the slime's size)
     */
    protected boolean makesSoundOnLand()
    {
        return this.getSize() > 2;
    }
}
