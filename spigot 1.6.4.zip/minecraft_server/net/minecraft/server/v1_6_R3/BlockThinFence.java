package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class BlockThinFence extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    private final String displayOnCreativeTab;

    /** The unlocalized name of this block. */
    private final boolean unlocalizedName;
    private final String c;

    protected BlockThinFence(int var1, String var2, String var3, Material var4, boolean var5)
    {
        super(var1, var4);
        this.displayOnCreativeTab = var3;
        this.unlocalizedName = var5;
        this.c = var2;
        this.a(CreativeModeTab.c);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return !this.unlocalizedName ? 0 : super.getDropType(var1, var2, var3);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 18;
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World var1, int var2, int var3, int var4, AxisAlignedBB var5, List var6, Entity var7)
    {
        boolean var8 = this.d(var1.getTypeId(var2, var3, var4 - 1));
        boolean var9 = this.d(var1.getTypeId(var2, var3, var4 + 1));
        boolean var10 = this.d(var1.getTypeId(var2 - 1, var3, var4));
        boolean var11 = this.d(var1.getTypeId(var2 + 1, var3, var4));

        if ((!var10 || !var11) && (var10 || var11 || var8 || var9))
        {
            if (var10 && !var11)
            {
                this.setBlockBounds(0.0F, 0.0F, 0.4375F, 0.5F, 1.0F, 0.5625F);
                super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
            }
            else if (!var10 && var11)
            {
                this.setBlockBounds(0.5F, 0.0F, 0.4375F, 1.0F, 1.0F, 0.5625F);
                super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
            }
        }
        else
        {
            this.setBlockBounds(0.0F, 0.0F, 0.4375F, 1.0F, 1.0F, 0.5625F);
            super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
        }

        if ((!var8 || !var9) && (var10 || var11 || var8 || var9))
        {
            if (var8 && !var9)
            {
                this.setBlockBounds(0.4375F, 0.0F, 0.0F, 0.5625F, 1.0F, 0.5F);
                super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
            }
            else if (!var8 && var9)
            {
                this.setBlockBounds(0.4375F, 0.0F, 0.5F, 0.5625F, 1.0F, 1.0F);
                super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
            }
        }
        else
        {
            this.setBlockBounds(0.4375F, 0.0F, 0.0F, 0.5625F, 1.0F, 1.0F);
            super.addCollisionBoxesToList(var1, var2, var3, var4, var5, var6, var7);
        }
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        float var5 = 0.4375F;
        float var6 = 0.5625F;
        float var7 = 0.4375F;
        float var8 = 0.5625F;
        boolean var9 = this.d(var1.getTypeId(var2, var3, var4 - 1));
        boolean var10 = this.d(var1.getTypeId(var2, var3, var4 + 1));
        boolean var11 = this.d(var1.getTypeId(var2 - 1, var3, var4));
        boolean var12 = this.d(var1.getTypeId(var2 + 1, var3, var4));

        if ((!var11 || !var12) && (var11 || var12 || var9 || var10))
        {
            if (var11 && !var12)
            {
                var5 = 0.0F;
            }
            else if (!var11 && var12)
            {
                var6 = 1.0F;
            }
        }
        else
        {
            var5 = 0.0F;
            var6 = 1.0F;
        }

        if ((!var9 || !var10) && (var11 || var12 || var9 || var10))
        {
            if (var9 && !var10)
            {
                var7 = 0.0F;
            }
            else if (!var9 && var10)
            {
                var8 = 1.0F;
            }
        }
        else
        {
            var7 = 0.0F;
            var8 = 1.0F;
        }

        this.setBlockBounds(var5, 0.0F, var7, var6, 1.0F, var8);
    }

    public final boolean d(int var1)
    {
        return Block.opaqueCubeLookup[var1] || var1 == this.id || var1 == Block.GLASS.id;
    }

    /**
     * Return true if a player with Silk Touch can harvest this block directly, and not its normal drops.
     */
    protected boolean canSilkHarvest()
    {
        return true;
    }

    /**
     * Returns an item stack containing a single instance of the current block type. 'i' is the block's subtype/damage
     * and is ignored for blocks which do not support subtypes. Blocks which cannot be harvested should return null.
     */
    protected ItemStack createStackedBlock(int var1)
    {
        return new ItemStack(this.id, 1, var1);
    }
}
