package net.minecraft.server.v1_6_R3;

final class EntitySelectorNotUndead implements IEntitySelector
{
    /**
     * Return whether the specified entity is applicable to this filter.
     */
    public boolean isEntityApplicable(Entity var1)
    {
        return var1 instanceof EntityLiving && ((EntityLiving)var1).getMonsterType() != EnumMonsterType.UNDEAD;
    }
}
