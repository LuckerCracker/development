package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.plugin.PluginManager;

public abstract class BlockPressurePlateAbstract extends Block {
	/**
	 * used as foreach item, if item.tab = current tab, display it on the screen
	 */
	private String displayOnCreativeTab;

	protected BlockPressurePlateAbstract(int i, String s, Material material) {
		super(i, material);
		this.displayOnCreativeTab = s;
		this.a(CreativeModeTab.d);
		this.setTickRandomly(true);
		this.c_(this.getMetaFromWeight(15));
	}

	public void updateShape(IBlockAccess iblockaccess, int i, int j, int k) {
		this.c_(iblockaccess.getData(i, j, k));
	}

	protected void c_(int i) {
		boolean flag = this.getPowerSupply(i) > 0;
		float f = 0.0625F;

		if (flag) {
			this.setBlockBounds(f, 0.0F, f, 1.0F - f, 0.03125F, 1.0F - f);
		} else {
			this.setBlockBounds(f, 0.0F, f, 1.0F - f, 0.0625F, 1.0F - f);
		}
	}

	/**
	 * How many world ticks before ticking
	 */
	public int tickRate(World world) {
		return 20;
	}

	/**
	 * Returns a bounding box from the pool of bounding boxes (this means this
	 * box can change after the pool has been cleared to be reused)
	 */
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k) {
		return null;
	}

	/**
	 * Is this block (a) opaque and (b) a full 1m cube? This determines whether
	 * or not to render the shared face of two adjacent blocks and also whether
	 * the player can attach torches, redstone wire, etc to this block.
	 */
	public boolean isOpaqueCube() {
		return false;
	}

	/**
	 * If this block doesn't render as an ordinary block it will return False
	 * (examples: signs, buttons, stairs, etc)
	 */
	public boolean renderAsNormalBlock() {
		return false;
	}

	public boolean getBlocksMovement(IBlockAccess iblockaccess, int i, int j, int k) {
		return true;
	}

	public boolean canPlace(World world, int i, int j, int k) {
		return world.doesBlockHaveSolidTopSurface(i, j - 1, k) || BlockFence.isIdAFence(world.getTypeId(i, j - 1, k));
	}

	public void doPhysics(World world, int i, int j, int k, int l) {
		boolean flag = false;

		if (!world.doesBlockHaveSolidTopSurface(i, j - 1, k) && !BlockFence.isIdAFence(world.getTypeId(i, j - 1, k))) {
			flag = true;
		}

		if (flag) {
			this.dropBlockAsItem(world, i, j, k, world.getData(i, j, k), 0);
			world.setAir(i, j, k);
		}
	}

	/**
	 * Ticks the block if it's been scheduled
	 */
	public void updateTick(World world, int i, int j, int k, Random random) {
		if (!world.isStatic) {
			int l = this.getPowerSupply(world.getData(i, j, k));

			if (l > 0) {
				this.b(world, i, j, k, l);
			}
		}
	}

	/**
	 * Triggered whenever an entity collides with this block (enters into the
	 * block). Args: world, x, y, z, entity
	 */
	public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity) {
		if (!world.isStatic) {
			int l = this.getPowerSupply(world.getData(i, j, k));

			if (l == 0) {
				this.b(world, i, j, k, l);
			}
		}
	}

	protected void b(World world, int i, int j, int k, int l) {
		int i1 = this.getPlateState(world, i, j, k);
		boolean flag = l > 0;
		boolean flag1 = i1 > 0;
		CraftWorld bworld = world.getWorld();
		PluginManager manager = world.getServer().getPluginManager();

		if (flag != flag1) {
			BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(bworld.getBlockAt(i, j, k), l, i1);
			manager.callEvent(eventRedstone);
			flag1 = eventRedstone.getNewCurrent() > 0;
			i1 = eventRedstone.getNewCurrent();
		}

		if (l != i1) {
			world.setData(i, j, k, this.getMetaFromWeight(i1), 2);
			this.b_(world, i, j, k);
			world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
		}

		if (!flag1 && flag) {
			world.makeSound((double) i + 0.5D, (double) j + 0.1D, (double) k + 0.5D, "random.click", 0.3F, 0.5F);
		} else if (flag1 && !flag) {
			world.makeSound((double) i + 0.5D, (double) j + 0.1D, (double) k + 0.5D, "random.click", 0.3F, 0.6F);
		}

		if (flag1) {
			world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
		}
	}

	protected AxisAlignedBB a(int i, int j, int k) {
		float f = 0.125F;
		return AxisAlignedBB.getAABBPool().getAABB((double) ((float) i + f), (double) j, (double) ((float) k + f),
				(double) ((float) (i + 1) - f), (double) j + 0.25D, (double) ((float) (k + 1) - f));
	}

	public void remove(World world, int i, int j, int k, int l, int i1) {
		if (this.getPowerSupply(i1) > 0) {
			this.b_(world, i, j, k);
		}

		super.remove(world, i, j, k, l, i1);
	}

	protected void b_(World world, int i, int j, int k) {
		world.applyPhysics(i, j, k, this.id);
		world.applyPhysics(i, j - 1, k, this.id);
	}

	/**
	 * Returns true if the block is emitting indirect/weak redstone power on the
	 * specified side. If isBlockNormalCube returns true, standard redstone
	 * propagation rules will apply instead and this will not be called. Args:
	 * World, X, Y, Z, side. Note that the side is reversed - eg it is 1 (up)
	 * when checking the bottom of the block.
	 */
	public int isProvidingWeakPower(IBlockAccess iblockaccess, int i, int j, int k, int l) {
		return this.getPowerSupply(iblockaccess.getData(i, j, k));
	}

	/**
	 * Returns true if the block is emitting direct/strong redstone power on the
	 * specified side. Args: World, X, Y, Z, side. Note that the side is
	 * reversed - eg it is 1 (up) when checking the bottom of the block.
	 */
	public int isProvidingStrongPower(IBlockAccess iblockaccess, int i, int j, int k, int l) {
		return l == 1 ? this.getPowerSupply(iblockaccess.getData(i, j, k)) : 0;
	}

	public boolean isPowerSource() {
		return true;
	}

	/**
	 * Sets the block's bounds for rendering it as an item
	 */
	public void setBlockBoundsForItemRender() {
		float f = 0.5F;
		float f1 = 0.125F;
		float f2 = 0.5F;
		this.setBlockBounds(0.5F - f, 0.5F - f1, 0.5F - f2, 0.5F + f, 0.5F + f1, 0.5F + f2);
	}

	/**
	 * Returns the mobility information of the block, 0 = free, 1 = can't push
	 * but can move over, 2 = total immobility and stop pistons
	 */
	public int getMobilityFlag() {
		return 1;
	}

	protected abstract int getPlateState(World var1, int var2, int var3, int var4);

	protected abstract int getPowerSupply(int var1);

	protected abstract int getMetaFromWeight(int var1);
}
