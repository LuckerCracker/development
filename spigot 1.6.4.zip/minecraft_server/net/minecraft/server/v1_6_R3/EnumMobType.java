package net.minecraft.server.v1_6_R3;

public enum EnumMobType {
	EVERYTHING("everything", 0), MOBS("mobs", 1), PLAYERS("players", 2);
	private EnumMobType(String var1, int var2) {
	}
}
