package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockIce extends BlockHalfTransparant
{
    public BlockIce(int par1)
    {
        super(par1, "ice", Material.ICE, false);
        this.frictionFactor = 0.98F;
        this.setTickRandomly(true);
        this.a(CreativeModeTab.b);
    }

    public void a(World world, EntityHuman entityhuman, int i, int j, int k, int l)
    {
        entityhuman.addStat(StatisticList.C[this.id], 1);
        entityhuman.addExhaustion(0.025F);

        if (this.canSilkHarvest() && EnchantmentManager.hasSilkTouchEnchantment(entityhuman))
        {
            ItemStack i11 = this.createStackedBlock(l);

            if (i11 != null)
            {
                this.dropBlockAsItem_do(world, i, j, k, i11);
            }
        }
        else
        {
            if (world.worldProvider.isHellWorld)
            {
                world.setAir(i, j, k);
                return;
            }

            int i1 = EnchantmentManager.getBonusBlockLootEnchantmentLevel(entityhuman);
            this.dropBlockAsItem(world, i, j, k, l, i1);
            Material material = world.getMaterial(i, j - 1, k);

            if (material.isSolid() || material.isLiquid())
            {
                world.setTypeIdUpdate(i, j, k, Block.WATER.id);
            }
        }
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 0;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (par1World.getSavedLightValue(EnumSkyBlock.BLOCK, par2, par3, par4) > 11 - Block.lightBlock[this.id])
        {
            if (CraftEventFactory.callBlockFadeEvent(par1World.getWorld().getBlockAt(par2, par3, par4), Block.STATIONARY_WATER.id).isCancelled())
            {
                return;
            }

            if (par1World.worldProvider.isHellWorld)
            {
                par1World.setAir(par2, par3, par4);
                return;
            }

            this.dropBlockAsItem(par1World, par2, par3, par4, par1World.getData(par2, par3, par4), 0);
            par1World.setTypeIdUpdate(par2, par3, par4, Block.STATIONARY_WATER.id);
        }
    }

    /**
     * Returns the mobility information of the block, 0 = free, 1 = can't push but can move over, 2 = total immobility
     * and stop pistons
     */
    public int getMobilityFlag()
    {
        return 0;
    }
}
