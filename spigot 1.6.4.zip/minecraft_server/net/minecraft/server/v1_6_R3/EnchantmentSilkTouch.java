package net.minecraft.server.v1_6_R3;

public class EnchantmentSilkTouch extends Enchantment
{
    protected EnchantmentSilkTouch(int var1, int var2)
    {
        super(var1, var2, EnchantmentSlotType.DIGGER);
        this.setName("untouching");
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int var1)
    {
        return 15;
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int var1)
    {
        return super.getMinEnchantability(var1) + 50;
    }

    public int getMaxLevel()
    {
        return 1;
    }

    /**
     * Determines if the enchantment passed can be applyied together with this enchantment.
     */
    public boolean canApplyTogether(Enchantment var1)
    {
        return super.canApplyTogether(var1) && var1.id != LOOT_BONUS_BLOCKS.id;
    }

    public boolean canEnchant(ItemStack var1)
    {
        return var1.getItem().id == Item.SHEARS.id ? true : super.canEnchant(var1);
    }
}
