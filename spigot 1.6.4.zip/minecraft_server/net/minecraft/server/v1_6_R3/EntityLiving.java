package net.minecraft.server.v1_6_R3;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_6_R3.TrigMath;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;

public abstract class EntityLiving extends Entity {
	/** The experience points the Entity gives. */
	private static final UUID experienceValue = UUID.fromString("662A6B8D-DA3E-4C1C-8813-96EA6097278D");
	private static final AttributeModifier tasks = (new AttributeModifier(experienceValue, "Sprinting speed boost",
			0.30000001192092896D, 2)).setSaved(false);
	private AttributeMapBase targetTasks;
	public CombatTracker combatTracker = new CombatTracker(this);
	public final HashMap effects = new HashMap();

	/** How long to keep a specific target entity */
	private final ItemStack[] numTicksToChaseTarget = new ItemStack[5];
	public boolean isSwingInProgress;
	public int swingProgressInt;
	public int arrowHitTimer;
	public float prevHealth;
	public int hurtTicks;
	public int maxHurtTicks;
	public float attackedAtYaw;
	public int deathTicks;
	public int attackTicks;
	public float prevSwingProgress;
	public float swingProgress;
	public float prevLimbSwingAmount;
	public float limbSwingAmount;
	public float limbSwing;
	public int maxNoDamageTicks = 20;
	public float prevCameraPitch;
	public float cameraPitch;
	public float field_70769_ao;
	public float field_70770_ap;
	public float renderYawOffset;
	public float prevRenderYawOffset;
	public float rotationYawHead;
	public float prevRotationYawHead;
	public float jumpMovementFactor = 0.02F;
	public EntityHuman killer;
	protected int lastDamageByPlayerTime;
	protected boolean dead_entityliving;
	protected int entityAge;
	protected float field_70768_au;
	protected float field_110154_aX;
	protected float field_70764_aw;
	protected float field_70763_ax;
	protected float field_70741_aB;
	protected int scoreValue;
	public float lastDamage;
	protected boolean isJumping;
	public float moveStrafing;
	public float moveForward;
	protected float randomYawVelocity;
	protected int newPosRotationIncrements;
	protected double newPosX;
	protected double newPosY;
	protected double newPosZ;
	protected double newRotationYaw;
	protected double newRotationPitch;
	public boolean updateEffects = true;
	public EntityLiving lastDamager;

	/** Entity jumping helper */
	private int jumpHelper;
	private EntityLiving bodyHelper;
	private int navigator;

	/** The active target the Task system uses for tracking */
	private float attackTarget;
	private int senses;

	/** Equipment (armor and held item) for this entity. */
	private float equipment;
	public int expToDrop;
	public int maxAirTicks = 300;

	public void inactiveTick() {
		super.inactiveTick();
		++this.entityAge;
	}

	public EntityLiving(World par1World) {
		super(par1World);
		this.applyEntityAttributes();
		this.datawatcher.watch(6, Float.valueOf((float) this.getAttributeInstance(GenericAttributes.a).getValue()));
		this.preventEntitySpawning = true;
		this.field_70770_ap = (float) (Math.random() + 1.0D) * 0.01F;
		this.setPosition(this.locX, this.locY, this.locZ);
		this.field_70769_ao = (float) Math.random() * 12398.0F;
		this.yaw = (float) (Math.random() * Math.PI * 2.0D);
		this.rotationYawHead = this.yaw;
		this.stepHeight = 0.5F;
	}

	protected void entityInit() {
		this.datawatcher.addObject(7, Integer.valueOf(0));
		this.datawatcher.addObject(8, Byte.valueOf((byte) 0));
		this.datawatcher.addObject(9, Byte.valueOf((byte) 0));
		this.datawatcher.addObject(6, Float.valueOf(1.0F));
	}

	protected void applyEntityAttributes() {
		this.getAttributeMap().b(GenericAttributes.a);
		this.getAttributeMap().b(GenericAttributes.c);
		this.getAttributeMap().b(GenericAttributes.d);

		if (!this.isAIEnabled()) {
			this.getAttributeInstance(GenericAttributes.d).setValue(0.10000000149011612D);
		}
	}

	/**
	 * Takes in the distance the entity has fallen this tick and whether its on
	 * the ground to update the fall distance and deal fall damage if landing on
	 * the ground. Args: distanceFallenThisTick, onGround
	 */
	protected void updateFallState(double d0, boolean flag) {
		if (!this.isInWater()) {
			this.handleWaterMovement();
		}

		if (flag && this.fallDistance > 0.0F) {
			int i = MathHelper.floor(this.locX);
			int j = MathHelper.floor(this.locY - 0.20000000298023224D - (double) this.height);
			int k = MathHelper.floor(this.locZ);
			int l = this.world.getTypeId(i, j, k);

			if (l == 0) {
				int i1 = this.world.blockGetRenderType(i, j - 1, k);

				if (i1 == 11 || i1 == 32 || i1 == 21) {
					l = this.world.getTypeId(i, j - 1, k);
				}
			}

			if (l > 0) {
				Block.byId[l].onFallenUpon(this.world, i, j, k, this, this.fallDistance);
			}
		}

		super.updateFallState(d0, flag);
	}

	public boolean canBreatheUnderwater() {
		return false;
	}

	/**
	 * Gets called every tick from main Entity class
	 */
	public void onEntityUpdate() {
		this.prevSwingProgress = this.swingProgress;
		super.onEntityUpdate();
		this.world.methodProfiler.a("livingEntityBaseTick");

		if (this.isAlive() && this.inBlock()) {
			this.attackEntityFrom(DamageSource.STUCK, 1.0F);
		}

		if (this.isFireproof() || this.world.isStatic) {
			this.extinguish();
		}

		boolean var1 = this instanceof EntityHuman && ((EntityHuman) this).abilities.isInvulnerable;

		if (this.isAlive() && this.isInsideOfMaterial(Material.WATER)) {
			if (!this.canBreatheUnderwater() && !this.hasEffect(MobEffectList.WATER_BREATHING.id) && !var1) {
				this.setAirTicks(this.decreaseAirSupply(this.getAirTicks()));

				if (this.getAirTicks() == -20) {
					this.setAirTicks(0);

					for (int var2 = 0; var2 < 8; ++var2) {
						float var3 = this.random.nextFloat() - this.random.nextFloat();
						float var4 = this.random.nextFloat() - this.random.nextFloat();
						float var5 = this.random.nextFloat() - this.random.nextFloat();
						this.world.addParticle("bubble", this.locX + (double) var3, this.locY + (double) var4,
								this.locZ + (double) var5, this.motX, this.motY, this.motZ);
					}

					this.attackEntityFrom(DamageSource.DROWN, 2.0F);
				}
			}

			this.extinguish();

			if (!this.world.isStatic && this.isRiding() && this.vehicle instanceof EntityLiving) {
				this.mount((Entity) null);
			}
		} else if (this.getAirTicks() != 300) {
			this.setAirTicks(this.maxAirTicks);
		}

		this.prevCameraPitch = this.cameraPitch;

		if (this.attackTicks > 0) {
			--this.attackTicks;
		}

		if (this.hurtTicks > 0) {
			--this.hurtTicks;
		}

		if (this.noDamageTicks > 0 && !(this instanceof EntityPlayer)) {
			--this.noDamageTicks;
		}

		if (this.getHealth() <= 0.0F) {
			this.onDeathUpdate();
		}

		if (this.lastDamageByPlayerTime > 0) {
			--this.lastDamageByPlayerTime;
		} else {
			this.killer = null;
		}

		if (this.bodyHelper != null && !this.bodyHelper.isAlive()) {
			this.bodyHelper = null;
		}

		if (this.lastDamager != null && !this.lastDamager.isAlive()) {
			this.setRevengeTarget((EntityLiving) null);
		}

		this.updatePotionEffects();
		this.field_70763_ax = this.field_70764_aw;
		this.prevRenderYawOffset = this.renderYawOffset;
		this.prevRotationYawHead = this.rotationYawHead;
		this.lastYaw = this.yaw;
		this.lastPitch = this.pitch;
		this.world.methodProfiler.b();
	}

	public int getExpReward() {
		int exp = this.getExpValue(this.killer);
		return !this.world.isStatic && (this.lastDamageByPlayerTime > 0 || this.alwaysGivesExp()) && !this.isBaby()
				? exp : 0;
	}

	public boolean isBaby() {
		return false;
	}

	protected void onDeathUpdate() {
		++this.deathTicks;

		if (this.deathTicks >= 20 && !this.dead) {
			int i = this.expToDrop;

			while (i > 0) {
				int j = EntityExperienceOrb.getOrbValue(i);
				i -= j;
				this.world.addEntity(new EntityExperienceOrb(this.world, this.locX, this.locY, this.locZ, j));
			}

			this.expToDrop = 0;
			this.die();

			for (i = 0; i < 20; ++i) {
				double d0 = this.random.nextGaussian() * 0.02D;
				double d1 = this.random.nextGaussian() * 0.02D;
				double d2 = this.random.nextGaussian() * 0.02D;
				this.world.addParticle("explode",
						this.locX + (double) (this.random.nextFloat() * this.width * 2.0F) - (double) this.width,
						this.locY + (double) (this.random.nextFloat() * this.length),
						this.locZ + (double) (this.random.nextFloat() * this.width * 2.0F) - (double) this.width, d0,
						d1, d2);
			}
		}
	}

	protected int decreaseAirSupply(int i) {
		int j = EnchantmentManager.getOxygenEnchantmentLevel(this);
		return j > 0 && this.random.nextInt(j + 1) > 0 ? i : i - 1;
	}

	protected int getExpValue(EntityHuman entityhuman) {
		return 0;
	}

	protected boolean alwaysGivesExp() {
		return false;
	}

	public Random getRNG() {
		return this.random;
	}

	public EntityLiving getLastDamager() {
		return this.lastDamager;
	}

	public int func_142015_aE() {
		return this.jumpHelper;
	}

	public void setRevengeTarget(EntityLiving entityliving) {
		this.lastDamager = entityliving;
		this.jumpHelper = this.ticksLived;
	}

	public EntityLiving getLastAttacker() {
		return this.bodyHelper;
	}

	public int getLastAttackerTime() {
		return this.navigator;
	}

	public void setLastAttacker(Entity entity) {
		if (entity instanceof EntityLiving) {
			this.bodyHelper = (EntityLiving) entity;
		} else {
			this.bodyHelper = null;
		}

		this.navigator = this.ticksLived;
	}

	public int getAge() {
		return this.entityAge;
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		par1NBTTagCompound.setFloat("HealF", this.getHealth());
		par1NBTTagCompound.setShort("Health", (short) ((int) Math.ceil((double) this.getHealth())));
		par1NBTTagCompound.setShort("HurtTime", (short) this.hurtTicks);
		par1NBTTagCompound.setShort("DeathTime", (short) this.deathTicks);
		par1NBTTagCompound.setShort("AttackTime", (short) this.attackTicks);
		par1NBTTagCompound.setFloat("AbsorptionAmount", this.getAbsorptionAmount());
		ItemStack[] var2 = this.getEquipment();
		int var3 = var2.length;
		int var4;
		ItemStack var5;

		for (var4 = 0; var4 < var3; ++var4) {
			var5 = var2[var4];

			if (var5 != null) {
				this.targetTasks.a(var5.getAttributeModifiers());
			}
		}

		par1NBTTagCompound.set("Attributes", GenericAttributes.a(this.getAttributeMap()));
		var2 = this.getEquipment();
		var3 = var2.length;

		for (var4 = 0; var4 < var3; ++var4) {
			var5 = var2[var4];

			if (var5 != null) {
				this.targetTasks.b(var5.getAttributeModifiers());
			}
		}

		if (!this.effects.isEmpty()) {
			NBTTagList var6 = new NBTTagList();
			Iterator var7 = this.effects.values().iterator();

			while (var7.hasNext()) {
				MobEffect var8 = (MobEffect) var7.next();
				var6.add(var8.a(new NBTTagCompound()));
			}

			par1NBTTagCompound.set("ActiveEffects", var6);
		}
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		this.setAbsorptionAmount(par1NBTTagCompound.getFloat("AbsorptionAmount"));

		if (par1NBTTagCompound.hasKey("Attributes") && this.world != null && !this.world.isStatic) {
			GenericAttributes.a(this.getAttributeMap(), par1NBTTagCompound.getList("Attributes"),
					this.world == null ? null : this.world.getLogger());
		}

		if (par1NBTTagCompound.hasKey("ActiveEffects")) {
			NBTTagList var2 = par1NBTTagCompound.getList("ActiveEffects");

			for (int var3 = 0; var3 < var2.size(); ++var3) {
				NBTTagCompound var4 = (NBTTagCompound) var2.get(var3);
				MobEffect var5 = MobEffect.b(var4);
				this.effects.put(Integer.valueOf(var5.getEffectId()), var5);
			}
		}

		NBTBase var6;

		if (par1NBTTagCompound.hasKey("Bukkit.MaxHealth")) {
			var6 = par1NBTTagCompound.get("Bukkit.MaxHealth");

			if (var6.getTypeId() == 5) {
				this.getAttributeInstance(GenericAttributes.a).setValue((double) ((NBTTagFloat) var6).data);
			} else if (var6.getTypeId() == 3) {
				this.getAttributeInstance(GenericAttributes.a).setValue((double) ((NBTTagInt) var6).data);
			}
		}

		if (par1NBTTagCompound.hasKey("HealF")) {
			this.setHealth(par1NBTTagCompound.getFloat("HealF"));
		} else {
			var6 = par1NBTTagCompound.get("Health");

			if (var6 == null) {
				this.setHealth(this.getMaxHealth());
			} else if (var6.getTypeId() == 5) {
				this.setHealth(((NBTTagFloat) var6).data);
			} else if (var6.getTypeId() == 2) {
				this.setHealth((float) ((NBTTagShort) var6).data);
			}
		}

		this.hurtTicks = par1NBTTagCompound.getShort("HurtTime");
		this.deathTicks = par1NBTTagCompound.getShort("DeathTime");
		this.attackTicks = par1NBTTagCompound.getShort("AttackTime");
	}

	protected void updatePotionEffects() {
		Iterator iterator = this.effects.keySet().iterator();

		while (iterator.hasNext()) {
			Integer i = (Integer) iterator.next();
			MobEffect flag = (MobEffect) this.effects.get(i);

			if (!flag.tick(this)) {
				if (!this.world.isStatic) {
					iterator.remove();
					this.onFinishedPotionEffect(flag);
				}
			} else if (flag.getDuration() % 600 == 0) {
				this.onChangedPotionEffect(flag, false);
			}
		}

		int i1;

		if (this.updateEffects) {
			if (!this.world.isStatic) {
				if (this.effects.isEmpty()) {
					this.datawatcher.watch(8, Byte.valueOf((byte) 0));
					this.datawatcher.watch(7, Integer.valueOf(0));
					this.setInvisible(false);
				} else {
					i1 = PotionBrewer.a(this.effects.values());
					this.datawatcher.watch(8, Byte.valueOf((byte) (PotionBrewer.b(this.effects.values()) ? 1 : 0)));
					this.datawatcher.watch(7, Integer.valueOf(i1));
					this.setInvisible(this.hasEffect(MobEffectList.INVISIBILITY.id));
				}
			}

			this.updateEffects = false;
		}

		i1 = this.datawatcher.getInt(7);
		boolean flag1 = this.datawatcher.getByte(8) > 0;

		if (i1 > 0) {
			if (!this.isInvisible()) {
				flag1 = this.random.nextBoolean();
			} else {
				flag1 = this.random.nextInt(15) == 0;
			}

			if (flag1) {
				flag1 &= this.random.nextInt(5) == 0;
			}

			if (flag1 && i1 > 0) {
				double d0 = (double) (i1 >> 16 & 255) / 255.0D;
				double d1 = (double) (i1 >> 8 & 255) / 255.0D;
				double d2 = (double) (i1 >> 0 & 255) / 255.0D;
				this.world.addParticle(flag1 ? "mobSpellAmbient" : "mobSpell",
						this.locX + (this.random.nextDouble() - 0.5D) * (double) this.width,
						this.locY + this.random.nextDouble() * (double) this.length - (double) this.height,
						this.locZ + (this.random.nextDouble() - 0.5D) * (double) this.width, d0, d1, d2);
			}
		}
	}

	public void clearActivePotions() {
		Iterator iterator = this.effects.keySet().iterator();

		while (iterator.hasNext()) {
			Integer integer = (Integer) iterator.next();
			MobEffect mobeffect = (MobEffect) this.effects.get(integer);

			if (!this.world.isStatic) {
				iterator.remove();
				this.onFinishedPotionEffect(mobeffect);
			}
		}
	}

	public Collection getEffects() {
		return this.effects.values();
	}

	public boolean hasEffect(int i) {
		return this.effects.size() != 0 && this.effects.containsKey(Integer.valueOf(i));
	}

	public boolean hasEffect(MobEffectList mobeffectlist) {
		return this.effects.size() != 0 && this.effects.containsKey(Integer.valueOf(mobeffectlist.id));
	}

	public MobEffect getEffect(MobEffectList mobeffectlist) {
		return (MobEffect) this.effects.get(Integer.valueOf(mobeffectlist.id));
	}

	public void addEffect(MobEffect mobeffect) {
		if (this.isPotionApplicable(mobeffect)) {
			if (this.effects.containsKey(Integer.valueOf(mobeffect.getEffectId()))) {
				((MobEffect) this.effects.get(Integer.valueOf(mobeffect.getEffectId()))).a(mobeffect);
				this.onChangedPotionEffect((MobEffect) this.effects.get(Integer.valueOf(mobeffect.getEffectId())),
						true);
			} else {
				this.effects.put(Integer.valueOf(mobeffect.getEffectId()), mobeffect);
				this.onNewPotionEffect(mobeffect);
			}
		}
	}

	public boolean isPotionApplicable(MobEffect mobeffect) {
		if (this.getMonsterType() == EnumMonsterType.UNDEAD) {
			int i = mobeffect.getEffectId();

			if (i == MobEffectList.REGENERATION.id || i == MobEffectList.POISON.id) {
				return false;
			}
		}

		return true;
	}

	public boolean isEntityUndead() {
		return this.getMonsterType() == EnumMonsterType.UNDEAD;
	}

	public void removePotionEffect(int i) {
		MobEffect mobeffect = (MobEffect) this.effects.remove(Integer.valueOf(i));

		if (mobeffect != null) {
			this.onFinishedPotionEffect(mobeffect);
		}
	}

	protected void onNewPotionEffect(MobEffect mobeffect) {
		this.updateEffects = true;

		if (!this.world.isStatic) {
			MobEffectList.byId[mobeffect.getEffectId()].b(this, this.getAttributeMap(), mobeffect.getAmplifier());
		}
	}

	protected void onChangedPotionEffect(MobEffect mobeffect, boolean flag) {
		this.updateEffects = true;

		if (flag && !this.world.isStatic) {
			MobEffectList.byId[mobeffect.getEffectId()].a(this, this.getAttributeMap(), mobeffect.getAmplifier());
			MobEffectList.byId[mobeffect.getEffectId()].b(this, this.getAttributeMap(), mobeffect.getAmplifier());
		}
	}

	protected void onFinishedPotionEffect(MobEffect mobeffect) {
		this.updateEffects = true;

		if (!this.world.isStatic) {
			MobEffectList.byId[mobeffect.getEffectId()].a(this, this.getAttributeMap(), mobeffect.getAmplifier());
		}
	}

	public void heal(float f) {
		this.heal(f, EntityRegainHealthEvent.RegainReason.CUSTOM);
	}

	public void heal(float f, EntityRegainHealthEvent.RegainReason regainReason) {
		float f1 = this.getHealth();

		if (f1 > 0.0F) {
			EntityRegainHealthEvent event = new EntityRegainHealthEvent(this.getBukkitEntity(), (double) f,
					regainReason);
			this.world.getServer().getPluginManager().callEvent(event);

			if (!event.isCancelled()) {
				this.setHealth((float) ((double) this.getHealth() + event.getAmount()));
			}
		}
	}

	public final float getHealth() {
		return this instanceof EntityPlayer ? (float) ((EntityPlayer) this).getBukkitEntity().getHealth()
				: this.datawatcher.getFloat(6);
	}

	public void setHealth(float f) {
		if (this instanceof EntityPlayer) {
			CraftPlayer player = ((EntityPlayer) this).getBukkitEntity();

			if (f < 0.0F) {
				player.setRealHealth(0.0D);
			} else if ((double) f > player.getMaxHealth()) {
				player.setRealHealth(player.getMaxHealth());
			} else {
				player.setRealHealth((double) f);
			}

			this.datawatcher.watch(6, Float.valueOf(player.getScaledHealth()));
		} else {
			this.datawatcher.watch(6, Float.valueOf(MathHelper.clamp_float(f, 0.0F, this.getMaxHealth())));
		}
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else if (this.world.isStatic) {
			return false;
		} else {
			this.entityAge = 0;

			if (this.getHealth() <= 0.0F) {
				return false;
			} else if (damagesource.isFireDamage() && this.hasEffect(MobEffectList.FIRE_RESISTANCE)) {
				return false;
			} else {
				if ((damagesource == DamageSource.ANVIL || damagesource == DamageSource.FALLING_BLOCK)
						&& this.getEquipment(4) != null) {
					this.getEquipment(4).damage((int) (f * 4.0F + this.random.nextFloat() * f * 2.0F), this);
					f *= 0.75F;
				}

				this.limbSwingAmount = 1.5F;
				boolean flag = true;
				EntityDamageEvent event = CraftEventFactory.handleEntityDamageEvent(this, damagesource, f);

				if (event != null) {
					if (event.isCancelled()) {
						return false;
					}

					f = (float) event.getDamage();
				}

				if ((float) this.noDamageTicks > (float) this.maxNoDamageTicks / 2.0F) {
					if (f <= this.lastDamage) {
						return false;
					}

					this.damageEntity(damagesource, f - this.lastDamage);
					this.lastDamage = f;
					flag = false;
				} else {
					this.lastDamage = f;
					this.prevHealth = this.getHealth();
					this.noDamageTicks = this.maxNoDamageTicks;
					this.damageEntity(damagesource, f);
					this.hurtTicks = this.maxHurtTicks = 10;
				}

				this.attackedAtYaw = 0.0F;
				Entity entity = damagesource.getEntity();

				if (entity != null) {
					if (entity instanceof EntityLiving) {
						this.setRevengeTarget((EntityLiving) entity);
					}

					if (entity instanceof EntityHuman) {
						this.lastDamageByPlayerTime = 100;
						this.killer = (EntityHuman) entity;
					} else if (entity instanceof EntityWolf) {
						EntityWolf entitywolf = (EntityWolf) entity;

						if (entitywolf.isTamed()) {
							this.lastDamageByPlayerTime = 100;
							this.killer = null;
						}
					}
				}

				if (flag) {
					this.world.broadcastEntityEffect(this, (byte) 2);

					if (damagesource != DamageSource.DROWN) {
						this.setBeenAttacked();
					}

					if (entity != null) {
						double d0 = entity.locX - this.locX;
						double d1;

						for (d1 = entity.locZ - this.locZ; d0 * d0
								+ d1 * d1 < 1.0E-4D; d1 = (Math.random() - Math.random()) * 0.01D) {
							d0 = (Math.random() - Math.random()) * 0.01D;
						}

						this.attackedAtYaw = (float) (Math.atan2(d1, d0) * 180.0D / Math.PI) - this.yaw;
						this.knockBack(entity, f, d0, d1);
					} else {
						this.attackedAtYaw = (float) ((int) (Math.random() * 2.0D) * 180);
					}
				}

				if (this.getHealth() <= 0.0F) {
					if (flag) {
						this.makeSound(this.getDeathSound(), this.getSoundVolume(), this.getSoundPitch());
					}

					this.die(damagesource);
				} else if (flag) {
					this.makeSound(this.getHurtSound(), this.getSoundVolume(), this.getSoundPitch());
				}

				return true;
			}
		}
	}

	public void renderBrokenItemStack(ItemStack itemstack) {
		this.makeSound("random.break", 0.8F, 0.8F + this.world.random.nextFloat() * 0.4F);

		for (int i = 0; i < 5; ++i) {
			Vec3D vec3d = this.world.getVec3DPool().create(((double) this.random.nextFloat() - 0.5D) * 0.1D,
					Math.random() * 0.1D + 0.1D, 0.0D);
			vec3d.a(-this.pitch * (float) Math.PI / 180.0F);
			vec3d.b(-this.yaw * (float) Math.PI / 180.0F);
			Vec3D vec3d1 = this.world.getVec3DPool().create(((double) this.random.nextFloat() - 0.5D) * 0.3D,
					(double) (-this.random.nextFloat()) * 0.6D - 0.3D, 0.6D);
			vec3d1.a(-this.pitch * (float) Math.PI / 180.0F);
			vec3d1.b(-this.yaw * (float) Math.PI / 180.0F);
			vec3d1 = vec3d1.add(this.locX, this.locY + (double) this.getHeadHeight(), this.locZ);
			this.world.addParticle("iconcrack_" + itemstack.getItem().id, vec3d1.c, vec3d1.d, vec3d1.e, vec3d.c,
					vec3d.d + 0.05D, vec3d.e);
		}
	}

	public void die(DamageSource damagesource) {
		Entity entity = damagesource.getEntity();
		EntityLiving entityliving = this.func_94060_bK();

		if (this.scoreValue >= 0 && entityliving != null) {
			entityliving.addToPlayerScore(this, this.scoreValue);
		}

		if (entity != null) {
			entity.onKillEntity(this);
		}

		this.dead_entityliving = true;

		if (!this.world.isStatic) {
			int i = 0;

			if (entity instanceof EntityHuman) {
				i = EnchantmentManager.getBonusMonsterLootEnchantmentLevel((EntityLiving) entity);
			}

			if (!this.isBaby() && this.world.getGameRules().getBoolean("doMobLoot")) {
				this.dropDeathLoot(this.lastDamageByPlayerTime > 0, i);
				this.dropEquipment(this.lastDamageByPlayerTime > 0, i);
			} else {
				CraftEventFactory.callEntityDeathEvent(this);
			}
		}

		this.world.broadcastEntityEffect(this, (byte) 3);
	}

	protected void dropEquipment(boolean flag, int i) {
	}

	public void knockBack(Entity entity, float f, double d0, double d1) {
		if (this.random.nextDouble() >= this.getAttributeInstance(GenericAttributes.c).getValue()) {
			this.isAirBorne = true;
			float f1 = MathHelper.sqrt(d0 * d0 + d1 * d1);
			float f2 = 0.4F;
			this.motX /= 2.0D;
			this.motY /= 2.0D;
			this.motZ /= 2.0D;
			this.motX -= d0 / (double) f1 * (double) f2;
			this.motY += (double) f2;
			this.motZ -= d1 / (double) f1 * (double) f2;

			if (this.motY > 0.4000000059604645D) {
				this.motY = 0.4000000059604645D;
			}
		}
	}

	protected String getHurtSound() {
		return "damage.hit";
	}

	protected String getDeathSound() {
		return "damage.hit";
	}

	protected ItemStack l(int i) {
		return null;
	}

	protected void dropDeathLoot(boolean flag, int i) {
	}

	public boolean isOnLadder() {
		int i = MathHelper.floor(this.locX);
		int j = MathHelper.floor(this.boundingBox.minY);
		int k = MathHelper.floor(this.locZ);
		int l = this.world.getTypeId(i, j, k);
		return l == Block.LADDER.id || l == Block.VINE.id;
	}

	public boolean isAlive() {
		return !this.dead && this.getHealth() > 0.0F;
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float f) {
		super.fall(f);
		MobEffect mobeffect = this.getEffect(MobEffectList.JUMP);
		float f1 = mobeffect != null ? (float) (mobeffect.getAmplifier() + 1) : 0.0F;
		float i = (float) MathHelper.ceiling_float_int(f - 3.0F - f1);

		if (i > 0.0F) {
			EntityDamageEvent j = CraftEventFactory.callEntityDamageEvent((Entity) null, this,
					EntityDamageEvent.DamageCause.FALL, (double) i);

			if (j.isCancelled()) {
				return;
			}

			i = (float) j.getDamage();

			if (i > 0.0F) {
				this.getBukkitEntity().setLastDamageCause(j);
			}
		}

		if (i > 0.0F) {
			if (i > 4.0F) {
				this.makeSound("damage.fallbig", 1.0F, 1.0F);
			} else {
				this.makeSound("damage.fallsmall", 1.0F, 1.0F);
			}

			this.attackEntityFrom(DamageSource.FALL, i);
			int j1 = this.world.getTypeId(MathHelper.floor(this.locX),
					MathHelper.floor(this.locY - 0.20000000298023224D - (double) this.height),
					MathHelper.floor(this.locZ));

			if (j1 > 0) {
				StepSound stepsound = Block.byId[j1].stepSound;
				this.makeSound(stepsound.getStepSound(), stepsound.getVolume1() * 0.5F, stepsound.getVolume2() * 0.75F);
			}
		}
	}

	public int getTotalArmorValue() {
		int i = 0;
		ItemStack[] aitemstack = this.getEquipment();
		int j = aitemstack.length;

		for (int k = 0; k < j; ++k) {
			ItemStack itemstack = aitemstack[k];

			if (itemstack != null && itemstack.getItem() instanceof ItemArmor) {
				int l = ((ItemArmor) itemstack.getItem()).damageReduceAmount;
				i += l;
			}
		}

		return i;
	}

	protected void damageArmor(float f) {
	}

	protected float applyArmorCalculations(DamageSource damagesource, float f) {
		if (!damagesource.ignoresArmor()) {
			int i = 25 - this.getTotalArmorValue();
			float f1 = f * (float) i;
			this.damageArmor(f);
			f = f1 / 25.0F;
		}

		return f;
	}

	protected float applyPotionDamageCalculations(DamageSource damagesource, float f) {
		int i;
		int j;
		float f1;

		if (this.hasEffect(MobEffectList.RESISTANCE) && damagesource != DamageSource.OUT_OF_WORLD) {
			i = (this.getEffect(MobEffectList.RESISTANCE).getAmplifier() + 1) * 5;
			j = 25 - i;
			f1 = f * (float) j;
			f = f1 / 25.0F;
		}

		if (f <= 0.0F) {
			return 0.0F;
		} else {
			i = EnchantmentManager.a(this.getEquipment(), damagesource);

			if (i > 20) {
				i = 20;
			}

			if (i > 0 && i <= 20) {
				j = 25 - i;
				f1 = f * (float) j;
				f = f1 / 25.0F;
			}

			return f;
		}
	}

	protected void damageEntity(DamageSource damagesource, float f) {
		if (!this.isInvulnerable()) {
			f = this.applyArmorCalculations(damagesource, f);
			f = this.applyPotionDamageCalculations(damagesource, f);
			float f1 = f;
			f = Math.max(f - this.getAbsorptionAmount(), 0.0F);
			this.setAbsorptionAmount(this.getAbsorptionAmount() - (f1 - f));

			if (f != 0.0F) {
				float f2 = this.getHealth();
				this.setHealth(f2 - f);
				this.func_110142_aN().func_94547_a(damagesource, f2, f);
				this.setAbsorptionAmount(this.getAbsorptionAmount() - f);
			}
		}
	}

	public CombatTracker func_110142_aN() {
		return this.combatTracker;
	}

	public EntityLiving func_94060_bK() {
		return (EntityLiving) (this.combatTracker.c() != null ? this.combatTracker.c()
				: (this.killer != null ? this.killer : (this.lastDamager != null ? this.lastDamager : null)));
	}

	public final float getMaxHealth() {
		return (float) this.getAttributeInstance(GenericAttributes.a).getValue();
	}

	public final int getArrowCountInEntity() {
		return this.datawatcher.getByte(9);
	}

	public final void setArrowCountInEntity(int i) {
		this.datawatcher.watch(9, Byte.valueOf((byte) i));
	}

	private int getArmSwingAnimationEnd() {
		return this.hasEffect(MobEffectList.FASTER_DIG)
				? 6 - (1 + this.getEffect(MobEffectList.FASTER_DIG).getAmplifier()) * 1
				: (this.hasEffect(MobEffectList.SLOWER_DIG)
						? 6 + (1 + this.getEffect(MobEffectList.SLOWER_DIG).getAmplifier()) * 2 : 6);
	}

	public void swingItem() {
		if (!this.isSwingInProgress || this.swingProgressInt >= this.getArmSwingAnimationEnd() / 2
				|| this.swingProgressInt < 0) {
			this.swingProgressInt = -1;
			this.isSwingInProgress = true;

			if (this.world instanceof WorldServer) {
				((WorldServer) this.world).getTracker().sendPacketToTrackedPlayers(this,
						new Packet18ArmAnimation(this, 1));
			}
		}
	}

	/**
	 * sets the dead flag. Used when you fall off the bottom of the world.
	 */
	protected void kill() {
		this.attackEntityFrom(DamageSource.OUT_OF_WORLD, 4.0F);
	}

	protected void updateArmSwingProgress() {
		int i = this.getArmSwingAnimationEnd();

		if (this.isSwingInProgress) {
			++this.swingProgressInt;

			if (this.swingProgressInt >= i) {
				this.swingProgressInt = 0;
				this.isSwingInProgress = false;
			}
		} else {
			this.swingProgressInt = 0;
		}

		this.swingProgress = (float) this.swingProgressInt / (float) i;
	}

	public AttributeInstance getAttributeInstance(IAttribute iattribute) {
		return this.getAttributeMap().a(iattribute);
	}

	public AttributeMapBase getAttributeMap() {
		if (this.targetTasks == null) {
			this.targetTasks = new AttributeMapServer();
		}

		return this.targetTasks;
	}

	public EnumMonsterType getMonsterType() {
		return EnumMonsterType.UNDEFINED;
	}

	/**
	 * Returns the item that this EntityLiving is holding, if any.
	 */
	public abstract ItemStack getHeldItem();

	public abstract ItemStack getEquipment(int var1);

	public abstract void setEquipment(int var1, ItemStack var2);

	public void setSprinting(boolean flag) {
		super.setSprinting(flag);
		AttributeInstance attributeinstance = this.getAttributeInstance(GenericAttributes.d);

		if (attributeinstance.getModifier(experienceValue) != null) {
			attributeinstance.removeModifier(tasks);
		}

		if (flag) {
			attributeinstance.applyModifier(tasks);
		}
	}

	public abstract ItemStack[] getEquipment();

	protected float getSoundVolume() {
		return 1.0F;
	}

	protected float getSoundPitch() {
		return this.isBaby() ? (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.5F
				: (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F;
	}

	protected boolean isMovementBlocked() {
		return this.getHealth() <= 0.0F;
	}

	public void enderTeleportTo(double d0, double d1, double d2) {
		this.setPositionRotation(d0, d1, d2, this.yaw, this.pitch);
	}

	public void dismountEntity(Entity entity) {
		double d0 = entity.locX;
		double d1 = entity.boundingBox.minY + (double) entity.length;
		double d2 = entity.locZ;

		for (double d3 = -1.5D; d3 < 2.0D; ++d3) {
			for (double d4 = -1.5D; d4 < 2.0D; ++d4) {
				if (d3 != 0.0D || d4 != 0.0D) {
					int i = (int) (this.locX + d3);
					int j = (int) (this.locZ + d4);
					AxisAlignedBB axisalignedbb = this.boundingBox.getOffsetBoundingBox(d3, 1.0D, d4);

					if (this.world.getCollidingBlockBounds(axisalignedbb).isEmpty()) {
						if (this.world.doesBlockHaveSolidTopSurface(i, (int) this.locY, j)) {
							this.enderTeleportTo(this.locX + d3, this.locY + 1.0D, this.locZ + d4);
							return;
						}

						if (this.world.doesBlockHaveSolidTopSurface(i, (int) this.locY - 1, j)
								|| this.world.getMaterial(i, (int) this.locY - 1, j) == Material.WATER) {
							d0 = this.locX + d3;
							d1 = this.locY + 1.0D;
							d2 = this.locZ + d4;
						}
					}
				}
			}
		}

		this.enderTeleportTo(d0, d1, d2);
	}

	protected void jump() {
		this.motY = 0.41999998688697815D;

		if (this.hasEffect(MobEffectList.JUMP)) {
			this.motY += (double) ((float) (this.getEffect(MobEffectList.JUMP).getAmplifier() + 1) * 0.1F);
		}

		if (this.isSprinting()) {
			float f = this.yaw * 0.017453292F;
			this.motX -= (double) (MathHelper.sin(f) * 0.2F);
			this.motZ += (double) (MathHelper.cos(f) * 0.2F);
		}

		this.isAirBorne = true;
	}

	public void moveEntityWithHeading(float f, float f1) {
		double d0;
		float f6;

		if (this.isInWater() && (!(this instanceof EntityHuman) || !((EntityHuman) this).abilities.isFlying)) {
			d0 = this.locY;
			this.moveFlying(f, f1, this.isAIEnabled() ? 0.04F : 0.02F);
			this.move(this.motX, this.motY, this.motZ);
			this.motX *= 0.800000011920929D;
			this.motY *= 0.800000011920929D;
			this.motZ *= 0.800000011920929D;
			this.motY -= 0.02D;

			if (this.positionChanged && this.isOffsetPositionInLiquid(this.motX,
					this.motY + 0.6000000238418579D - this.locY + d0, this.motZ)) {
				this.motY = 0.30000001192092896D;
			}
		} else if (this.handleLavaMovement()
				&& (!(this instanceof EntityHuman) || !((EntityHuman) this).abilities.isFlying)) {
			d0 = this.locY;
			this.moveFlying(f, f1, 0.02F);
			this.move(this.motX, this.motY, this.motZ);
			this.motX *= 0.5D;
			this.motY *= 0.5D;
			this.motZ *= 0.5D;
			this.motY -= 0.02D;

			if (this.positionChanged && this.isOffsetPositionInLiquid(this.motX,
					this.motY + 0.6000000238418579D - this.locY + d0, this.motZ)) {
				this.motY = 0.30000001192092896D;
			}
		} else {
			float f2 = 0.91F;

			if (this.onGround) {
				f2 = 0.54600006F;
				int f3 = this.world.getTypeId(MathHelper.floor(this.locX), MathHelper.floor(this.boundingBox.minY) - 1,
						MathHelper.floor(this.locZ));

				if (f3 > 0) {
					f2 = Block.byId[f3].frictionFactor * 0.91F;
				}
			}

			float f31 = 0.16277136F / (f2 * f2 * f2);

			if (this.onGround) {
				f6 = this.getAIMoveSpeed() * f31;
			} else {
				f6 = this.jumpMovementFactor;
			}

			this.moveFlying(f, f1, f6);
			f2 = 0.91F;

			if (this.onGround) {
				f2 = 0.54600006F;
				int f5 = this.world.getTypeId(MathHelper.floor(this.locX), MathHelper.floor(this.boundingBox.minY) - 1,
						MathHelper.floor(this.locZ));

				if (f5 > 0) {
					f2 = Block.byId[f5].frictionFactor * 0.91F;
				}
			}

			if (this.isOnLadder()) {
				float f51 = 0.15F;

				if (this.motX < (double) (-f51)) {
					this.motX = (double) (-f51);
				}

				if (this.motX > (double) f51) {
					this.motX = (double) f51;
				}

				if (this.motZ < (double) (-f51)) {
					this.motZ = (double) (-f51);
				}

				if (this.motZ > (double) f51) {
					this.motZ = (double) f51;
				}

				this.fallDistance = 0.0F;

				if (this.motY < -0.15D) {
					this.motY = -0.15D;
				}

				boolean flag = this.isSneaking() && this instanceof EntityHuman;

				if (flag && this.motY < 0.0D) {
					this.motY = 0.0D;
				}
			}

			this.move(this.motX, this.motY, this.motZ);

			if (this.positionChanged && this.isOnLadder()) {
				this.motY = 0.2D;
			}

			if (this.world.isStatic && (!this.world.isLoaded((int) this.locX, 0, (int) this.locZ)
					|| !this.world.getChunkAtWorldCoords((int) this.locX, (int) this.locZ).isChunkLoaded)) {
				if (this.locY > 0.0D) {
					this.motY = -0.1D;
				} else {
					this.motY = 0.0D;
				}
			} else {
				this.motY -= 0.08D;
			}

			this.motY *= 0.9800000190734863D;
			this.motX *= (double) f2;
			this.motZ *= (double) f2;
		}

		this.prevLimbSwingAmount = this.limbSwingAmount;
		d0 = this.locX - this.lastX;
		double d1 = this.locZ - this.lastZ;
		f6 = MathHelper.sqrt(d0 * d0 + d1 * d1) * 4.0F;

		if (f6 > 1.0F) {
			f6 = 1.0F;
		}

		this.limbSwingAmount += (f6 - this.limbSwingAmount) * 0.4F;
		this.limbSwing += this.limbSwingAmount;
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	protected boolean isAIEnabled() {
		return false;
	}

	public float getAIMoveSpeed() {
		return this.isAIEnabled() ? this.attackTarget : 0.1F;
	}

	/**
	 * set the movespeed used for the new AI system
	 */
	public void setAIMoveSpeed(float par1) {
		this.attackTarget = par1;
	}

	public boolean attackEntityAsMob(Entity entity) {
		this.setLastAttacker(entity);
		return false;
	}

	public boolean isSleeping() {
		return false;
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		super.onUpdate();

		if (!this.world.isStatic) {
			int var1 = this.getArrowCountInEntity();

			if (var1 > 0) {
				if (this.arrowHitTimer <= 0) {
					this.arrowHitTimer = 20 * (30 - var1);
				}

				--this.arrowHitTimer;

				if (this.arrowHitTimer <= 0) {
					this.setArrowCountInEntity(var1 - 1);
				}
			}

			for (int var2 = 0; var2 < 5; ++var2) {
				ItemStack var3 = this.numTicksToChaseTarget[var2];
				ItemStack var4 = this.getEquipment(var2);

				if (!ItemStack.matches(var4, var3)) {
					((WorldServer) this.world).getTracker().sendPacketToTrackedPlayers(this,
							new Packet5EntityEquipment(this.id, var2, var4));

					if (var3 != null) {
						this.targetTasks.a(var3.getAttributeModifiers());
					}

					if (var4 != null) {
						this.targetTasks.b(var4.getAttributeModifiers());
					}

					this.numTicksToChaseTarget[var2] = var4 == null ? null : var4.cloneItemStack();
				}
			}
		}

		this.onLivingUpdate();
		double var5 = this.locX - this.lastX;
		double var7 = this.locZ - this.lastZ;
		float var9 = (float) (var5 * var5 + var7 * var7);
		float var10 = this.renderYawOffset;
		float var11 = 0.0F;
		this.field_70768_au = this.field_110154_aX;
		float var12 = 0.0F;

		if (var9 > 0.0025000002F) {
			var12 = 1.0F;
			var11 = (float) Math.sqrt((double) var9) * 3.0F;
			var10 = (float) TrigMath.atan2(var7, var5) * 180.0F / (float) Math.PI - 90.0F;
		}

		if (this.swingProgress > 0.0F) {
			var10 = this.yaw;
		}

		if (!this.onGround) {
			var12 = 0.0F;
		}

		this.field_110154_aX += (var12 - this.field_110154_aX) * 0.3F;
		this.world.methodProfiler.a("headTurn");
		var11 = this.func_110146_f(var10, var11);
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("rangeChecks");

		while (this.yaw - this.lastYaw < -180.0F) {
			this.lastYaw -= 360.0F;
		}

		while (this.yaw - this.lastYaw >= 180.0F) {
			this.lastYaw += 360.0F;
		}

		while (this.renderYawOffset - this.prevRenderYawOffset < -180.0F) {
			this.prevRenderYawOffset -= 360.0F;
		}

		while (this.renderYawOffset - this.prevRenderYawOffset >= 180.0F) {
			this.prevRenderYawOffset += 360.0F;
		}

		while (this.pitch - this.lastPitch < -180.0F) {
			this.lastPitch -= 360.0F;
		}

		while (this.pitch - this.lastPitch >= 180.0F) {
			this.lastPitch += 360.0F;
		}

		while (this.rotationYawHead - this.prevRotationYawHead < -180.0F) {
			this.prevRotationYawHead -= 360.0F;
		}

		while (this.rotationYawHead - this.prevRotationYawHead >= 180.0F) {
			this.prevRotationYawHead += 360.0F;
		}

		this.world.methodProfiler.b();
		this.field_70764_aw += var11;
	}

	protected float func_110146_f(float par1, float par2) {
		float var3 = MathHelper.wrapAngleTo180_float(par1 - this.renderYawOffset);
		this.renderYawOffset += var3 * 0.3F;
		float var4 = MathHelper.wrapAngleTo180_float(this.yaw - this.renderYawOffset);
		boolean var5 = var4 < -90.0F || var4 >= 90.0F;

		if (var4 < -75.0F) {
			var4 = -75.0F;
		}

		if (var4 >= 75.0F) {
			var4 = 75.0F;
		}

		this.renderYawOffset = this.yaw - var4;

		if (var4 * var4 > 2500.0F) {
			this.renderYawOffset += var4 * 0.2F;
		}

		if (var5) {
			par2 *= -1.0F;
		}

		return par2;
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		if (this.senses > 0) {
			--this.senses;
		}

		if (this.newPosRotationIncrements > 0) {
			double var1 = this.locX + (this.newPosX - this.locX) / (double) this.newPosRotationIncrements;
			double var3 = this.locY + (this.newPosY - this.locY) / (double) this.newPosRotationIncrements;
			double var5 = this.locZ + (this.newPosZ - this.locZ) / (double) this.newPosRotationIncrements;
			double var7 = MathHelper.wrapAngleTo180_double(this.newRotationYaw - (double) this.yaw);
			this.yaw = (float) ((double) this.yaw + var7 / (double) this.newPosRotationIncrements);
			this.pitch = (float) ((double) this.pitch
					+ (this.newRotationPitch - (double) this.pitch) / (double) this.newPosRotationIncrements);
			--this.newPosRotationIncrements;
			this.setPosition(var1, var3, var5);
			this.setRotation(this.yaw, this.pitch);
		} else if (!this.isClientWorld()) {
			this.motX *= 0.98D;
			this.motY *= 0.98D;
			this.motZ *= 0.98D;
		}

		if (Math.abs(this.motX) < 0.005D) {
			this.motX = 0.0D;
		}

		if (Math.abs(this.motY) < 0.005D) {
			this.motY = 0.0D;
		}

		if (Math.abs(this.motZ) < 0.005D) {
			this.motZ = 0.0D;
		}

		this.world.methodProfiler.a("ai");

		if (this.isMovementBlocked()) {
			this.isJumping = false;
			this.moveStrafing = 0.0F;
			this.moveForward = 0.0F;
			this.randomYawVelocity = 0.0F;
		} else if (this.isClientWorld()) {
			if (this.isAIEnabled()) {
				this.world.methodProfiler.a("newAi");
				this.updateAITasks();
				this.world.methodProfiler.b();
			} else {
				this.world.methodProfiler.a("oldAi");
				this.updateEntityActionState();
				this.world.methodProfiler.b();
				this.rotationYawHead = this.yaw;
			}
		}

		this.world.methodProfiler.b();
		this.world.methodProfiler.a("jump");

		if (this.isJumping) {
			if (!this.isInWater() && !this.handleLavaMovement()) {
				if (this.onGround && this.senses == 0) {
					this.jump();
					this.senses = 10;
				}
			} else {
				this.motY += 0.03999999910593033D;
			}
		} else {
			this.senses = 0;
		}

		this.world.methodProfiler.b();
		this.world.methodProfiler.a("travel");
		this.moveStrafing *= 0.98F;
		this.moveForward *= 0.98F;
		this.randomYawVelocity *= 0.9F;
		this.moveEntityWithHeading(this.moveStrafing, this.moveForward);
		this.world.methodProfiler.b();
		this.world.methodProfiler.a("push");

		if (!this.world.isStatic) {
			this.collideWithNearbyEntities();
		}

		this.world.methodProfiler.b();
	}

	protected void updateAITasks() {
	}

	protected void collideWithNearbyEntities() {
		List list = this.world.getEntities(this,
				this.boundingBox.grow(0.20000000298023224D, 0.0D, 0.20000000298023224D));

		if (this.canBeCollidedWith() && list != null && !list.isEmpty()) {
			for (int i = 0; i < list.size(); ++i) {
				Entity entity = (Entity) list.get(i);

				if ((!(entity instanceof EntityLiving) || this instanceof EntityPlayer || this.ticksLived % 2 != 0)
						&& entity.canBePushed()) {
					this.collideWithEntity(entity);
				}
			}
		}
	}

	protected void collideWithEntity(Entity entity) {
		entity.collide(this);
	}

	/**
	 * Handles updating while being ridden by an entity
	 */
	public void updateRidden() {
		super.updateRidden();
		this.field_70768_au = this.field_110154_aX;
		this.field_110154_aX = 0.0F;
		this.fallDistance = 0.0F;
	}

	protected void updateAITick() {
	}

	protected void updateEntityActionState() {
		++this.entityAge;
	}

	public void setJumping(boolean flag) {
		this.isJumping = flag;
	}

	public void receive(Entity entity, int i) {
		if (!entity.dead && !this.world.isStatic) {
			EntityTracker entitytracker = ((WorldServer) this.world).getTracker();

			if (entity instanceof EntityItem) {
				entitytracker.sendPacketToTrackedPlayers(entity, new Packet22Collect(entity.id, this.id));
			}

			if (entity instanceof EntityArrow) {
				entitytracker.sendPacketToTrackedPlayers(entity, new Packet22Collect(entity.id, this.id));
			}

			if (entity instanceof EntityExperienceOrb) {
				entitytracker.sendPacketToTrackedPlayers(entity, new Packet22Collect(entity.id, this.id));
			}
		}
	}

	public boolean canEntityBeSeen(Entity entity) {
		return this.world.a(
				this.world.getVec3DPool().create(this.locX, this.locY + (double) this.getHeadHeight(), this.locZ),
				this.world.getVec3DPool().create(entity.locX, entity.locY + (double) entity.getHeadHeight(),
						entity.locZ)) == null;
	}

	public Vec3D getLookVec() {
		return this.getLook(1.0F);
	}

	public Vec3D getLook(float f) {
		float f1;
		float f2;
		float f3;
		float f4;

		if (f == 1.0F) {
			f1 = MathHelper.cos(-this.yaw * 0.017453292F - (float) Math.PI);
			f2 = MathHelper.sin(-this.yaw * 0.017453292F - (float) Math.PI);
			f3 = -MathHelper.cos(-this.pitch * 0.017453292F);
			f4 = MathHelper.sin(-this.pitch * 0.017453292F);
			return this.world.getVec3DPool().create((double) (f2 * f3), (double) f4, (double) (f1 * f3));
		} else {
			f1 = this.lastPitch + (this.pitch - this.lastPitch) * f;
			f2 = this.lastYaw + (this.yaw - this.lastYaw) * f;
			f3 = MathHelper.cos(-f2 * 0.017453292F - (float) Math.PI);
			f4 = MathHelper.sin(-f2 * 0.017453292F - (float) Math.PI);
			float f5 = -MathHelper.cos(-f1 * 0.017453292F);
			float f6 = MathHelper.sin(-f1 * 0.017453292F);
			return this.world.getVec3DPool().create((double) (f4 * f5), (double) f6, (double) (f3 * f5));
		}
	}

	public boolean isClientWorld() {
		return !this.world.isStatic;
	}

	/**
	 * Returns true if other Entities should be prevented from moving through
	 * this Entity.
	 */
	public boolean canBeCollidedWith() {
		return !this.dead;
	}

	/**
	 * Returns true if this entity should push and be pushed by other entities
	 * when colliding.
	 */
	public boolean canBePushed() {
		return !this.dead;
	}

	public float getHeadHeight() {
		return this.length * 0.85F;
	}

	/**
	 * Sets that this entity has been attacked.
	 */
	protected void setBeenAttacked() {
		this.velocityChanged = this.random.nextDouble() >= this.getAttributeInstance(GenericAttributes.c).getValue();
	}

	public float getHeadRotation() {
		return this.rotationYawHead;
	}

	public float getAbsorptionAmount() {
		return this.equipment;
	}

	public void setAbsorptionAmount(float f) {
		if (f < 0.0F) {
			f = 0.0F;
		}

		this.equipment = f;
	}

	public ScoreboardTeamBase getScoreboardTeam() {
		return null;
	}

	public boolean isOnSameTeam(EntityLiving entityliving) {
		return this.isOnTeam(entityliving.getScoreboardTeam());
	}

	public boolean isOnTeam(ScoreboardTeamBase scoreboardteambase) {
		return this.getScoreboardTeam() != null ? this.getScoreboardTeam().isAlly(scoreboardteambase) : false;
	}
}
