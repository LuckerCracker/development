package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class ChunkProviderGenerate implements IChunkProvider
{
    /** RNG. */
    private Random rand;

    /** A NoiseGeneratorOctaves used in generating terrain */
    private NoiseGeneratorOctaves noiseGen1;

    /** A NoiseGeneratorOctaves used in generating terrain */
    private NoiseGeneratorOctaves noiseGen2;

    /** A NoiseGeneratorOctaves used in generating terrain */
    private NoiseGeneratorOctaves noiseGen3;

    /** A NoiseGeneratorOctaves used in generating terrain */
    private NoiseGeneratorOctaves noiseGen4;

    /** A NoiseGeneratorOctaves used in generating terrain */
    public NoiseGeneratorOctaves noiseGen5;

    /** A NoiseGeneratorOctaves used in generating terrain */
    public NoiseGeneratorOctaves noiseGen6;
    public NoiseGeneratorOctaves mobSpawnerNoise;

    /** Reference to the World object. */
    private World worldObj;

    /** are map structures going to be generated (e.g. strongholds) */
    private final boolean mapFeaturesEnabled;

    /** Holds the overall noise array used in chunk generation */
    private double[] noiseArray;
    private double[] stoneNoise = new double[256];
    private WorldGenBase caveGenerator = new WorldGenCaves();

    /** Holds Stronghold Generator */
    private WorldGenStronghold strongholdGenerator = new WorldGenStronghold();

    /** Holds Village Generator */
    private WorldGenVillage villageGenerator = new WorldGenVillage();

    /** Holds Mineshaft Generator */
    private WorldGenMineshaft mineshaftGenerator = new WorldGenMineshaft();
    private WorldGenLargeFeature scatteredFeatureGenerator = new WorldGenLargeFeature();

    /** Holds ravine generator */
    private WorldGenBase ravineGenerator = new WorldGenCanyon();

    /** The biomes that are used to generate the chunk */
    private BiomeBase[] biomesForGeneration;

    /** A double array that hold terrain noise from noiseGen3 */
    double[] noise3;

    /** A double array that hold terrain noise */
    double[] noise1;

    /** A double array that hold terrain noise from noiseGen2 */
    double[] noise2;

    /** A double array that hold terrain noise from noiseGen5 */
    double[] noise5;

    /** A double array that holds terrain noise from noiseGen6 */
    double[] noise6;

    /**
     * Used to store the 5x5 parabolic field that is used during terrain generation.
     */
    float[] parabolicField;
    int[][] field_73219_j = new int[32][32];

    public ChunkProviderGenerate(World par1World, long par2, boolean par4)
    {
        this.worldObj = par1World;
        this.mapFeaturesEnabled = par4;
        this.rand = new Random(par2);
        this.noiseGen1 = new NoiseGeneratorOctaves(this.rand, 16);
        this.noiseGen2 = new NoiseGeneratorOctaves(this.rand, 16);
        this.noiseGen3 = new NoiseGeneratorOctaves(this.rand, 8);
        this.noiseGen4 = new NoiseGeneratorOctaves(this.rand, 4);
        this.noiseGen5 = new NoiseGeneratorOctaves(this.rand, 10);
        this.noiseGen6 = new NoiseGeneratorOctaves(this.rand, 16);
        this.mobSpawnerNoise = new NoiseGeneratorOctaves(this.rand, 8);
    }

    /**
     * Generates the shape of the terrain for the chunk though its all stone though the water is frozen if the
     * temperature is low enough
     */
    public void generateTerrain(int par1, int par2, byte[] par3ArrayOfByte)
    {
        byte var4 = 4;
        byte var5 = 16;
        byte var6 = 63;
        int var7 = var4 + 1;
        byte var8 = 17;
        int var9 = var4 + 1;
        this.biomesForGeneration = this.worldObj.getWorldChunkManager().getBiomes(this.biomesForGeneration, par1 * 4 - 2, par2 * 4 - 2, var7 + 5, var9 + 5);
        this.noiseArray = this.initializeNoiseField(this.noiseArray, par1 * var4, 0, par2 * var4, var7, var8, var9);

        for (int var10 = 0; var10 < var4; ++var10)
        {
            for (int var11 = 0; var11 < var4; ++var11)
            {
                for (int var12 = 0; var12 < var5; ++var12)
                {
                    double var13 = 0.125D;
                    double var15 = this.noiseArray[((var10 + 0) * var9 + var11 + 0) * var8 + var12 + 0];
                    double var17 = this.noiseArray[((var10 + 0) * var9 + var11 + 1) * var8 + var12 + 0];
                    double var19 = this.noiseArray[((var10 + 1) * var9 + var11 + 0) * var8 + var12 + 0];
                    double var21 = this.noiseArray[((var10 + 1) * var9 + var11 + 1) * var8 + var12 + 0];
                    double var23 = (this.noiseArray[((var10 + 0) * var9 + var11 + 0) * var8 + var12 + 1] - var15) * var13;
                    double var25 = (this.noiseArray[((var10 + 0) * var9 + var11 + 1) * var8 + var12 + 1] - var17) * var13;
                    double var27 = (this.noiseArray[((var10 + 1) * var9 + var11 + 0) * var8 + var12 + 1] - var19) * var13;
                    double var29 = (this.noiseArray[((var10 + 1) * var9 + var11 + 1) * var8 + var12 + 1] - var21) * var13;

                    for (int var31 = 0; var31 < 8; ++var31)
                    {
                        double var32 = 0.25D;
                        double var34 = var15;
                        double var36 = var17;
                        double var38 = (var19 - var15) * var32;
                        double var40 = (var21 - var17) * var32;

                        for (int var42 = 0; var42 < 4; ++var42)
                        {
                            int var43 = var42 + var10 * 4 << 11 | 0 + var11 * 4 << 7 | var12 * 8 + var31;
                            short var44 = 128;
                            var43 -= var44;
                            double var45 = 0.25D;
                            double var49 = (var36 - var34) * var45;
                            double var47 = var34 - var49;

                            for (int var51 = 0; var51 < 4; ++var51)
                            {
                                if ((var47 += var49) > 0.0D)
                                {
                                    par3ArrayOfByte[var43 += var44] = (byte)Block.STONE.id;
                                }
                                else if (var12 * 8 + var31 < var6)
                                {
                                    par3ArrayOfByte[var43 += var44] = (byte)Block.STATIONARY_WATER.id;
                                }
                                else
                                {
                                    par3ArrayOfByte[var43 += var44] = 0;
                                }
                            }

                            var34 += var38;
                            var36 += var40;
                        }

                        var15 += var23;
                        var17 += var25;
                        var19 += var27;
                        var21 += var29;
                    }
                }
            }
        }
    }

    /**
     * Replaces the stone that was placed in with blocks that match the biome
     */
    public void replaceBlocksForBiome(int var1, int var2, byte[] var3, BiomeBase[] var4)
    {
        byte var5 = 63;
        double var6 = 0.03125D;
        this.stoneNoise = this.noiseGen4.generateNoiseOctaves(this.stoneNoise, var1 * 16, var2 * 16, 0, 16, 16, 1, var6 * 2.0D, var6 * 2.0D, var6 * 2.0D);

        for (int var8 = 0; var8 < 16; ++var8)
        {
            for (int var9 = 0; var9 < 16; ++var9)
            {
                BiomeBase var10 = var4[var9 + var8 * 16];
                float var11 = var10.getFloatTemperature();
                int var12 = (int)(this.stoneNoise[var8 + var9 * 16] / 3.0D + 3.0D + this.rand.nextDouble() * 0.25D);
                int var13 = -1;
                byte var14 = var10.topBlock;
                byte var15 = var10.fillerBlock;

                for (int var16 = 127; var16 >= 0; --var16)
                {
                    int var17 = (var9 * 16 + var8) * 128 + var16;

                    if (var16 <= 0 + this.rand.nextInt(5))
                    {
                        var3[var17] = (byte)Block.BEDROCK.id;
                    }
                    else
                    {
                        byte var18 = var3[var17];

                        if (var18 == 0)
                        {
                            var13 = -1;
                        }
                        else if (var18 == Block.STONE.id)
                        {
                            if (var13 == -1)
                            {
                                if (var12 <= 0)
                                {
                                    var14 = 0;
                                    var15 = (byte)Block.STONE.id;
                                }
                                else if (var16 >= var5 - 4 && var16 <= var5 + 1)
                                {
                                    var14 = var10.topBlock;
                                    var15 = var10.fillerBlock;
                                }

                                if (var16 < var5 && var14 == 0)
                                {
                                    if (var11 < 0.15F)
                                    {
                                        var14 = (byte)Block.ICE.id;
                                    }
                                    else
                                    {
                                        var14 = (byte)Block.STATIONARY_WATER.id;
                                    }
                                }

                                var13 = var12;

                                if (var16 >= var5 - 1)
                                {
                                    var3[var17] = var14;
                                }
                                else
                                {
                                    var3[var17] = var15;
                                }
                            }
                            else if (var13 > 0)
                            {
                                --var13;
                                var3[var17] = var15;

                                if (var13 == 0 && var15 == Block.SAND.id)
                                {
                                    var13 = this.rand.nextInt(4);
                                    var15 = (byte)Block.SANDSTONE.id;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public Chunk getChunkAt(int var1, int var2)
    {
        return this.getOrCreateChunk(var1, var2);
    }

    public Chunk getOrCreateChunk(int var1, int var2)
    {
        this.rand.setSeed((long)var1 * 341873128712L + (long)var2 * 132897987541L);
        byte[] var3 = new byte[32768];
        this.generateTerrain(var1, var2, var3);
        this.biomesForGeneration = this.worldObj.getWorldChunkManager().getBiomeBlock(this.biomesForGeneration, var1 * 16, var2 * 16, 16, 16);
        this.replaceBlocksForBiome(var1, var2, var3, this.biomesForGeneration);
        this.caveGenerator.a(this, this.worldObj, var1, var2, var3);
        this.ravineGenerator.a(this, this.worldObj, var1, var2, var3);

        if (this.mapFeaturesEnabled)
        {
            this.mineshaftGenerator.a(this, this.worldObj, var1, var2, var3);
            this.villageGenerator.a(this, this.worldObj, var1, var2, var3);
            this.strongholdGenerator.a(this, this.worldObj, var1, var2, var3);
            this.scatteredFeatureGenerator.a(this, this.worldObj, var1, var2, var3);
        }

        Chunk var4 = new Chunk(this.worldObj, var3, var1, var2);
        byte[] var5 = var4.getBiomeArray();

        for (int var6 = 0; var6 < var5.length; ++var6)
        {
            var5[var6] = (byte)this.biomesForGeneration[var6].id;
        }

        var4.initLighting();
        return var4;
    }

    /**
     * generates a subset of the level's terrain data. Takes 7 arguments: the [empty] noise array, the position, and the
     * size.
     */
    private double[] initializeNoiseField(double[] par1ArrayOfDouble, int par2, int par3, int par4, int par5, int par6, int par7)
    {
        if (par1ArrayOfDouble == null)
        {
            par1ArrayOfDouble = new double[par5 * par6 * par7];
        }

        if (this.parabolicField == null)
        {
            this.parabolicField = new float[25];

            for (int var8 = -2; var8 <= 2; ++var8)
            {
                for (int var9 = -2; var9 <= 2; ++var9)
                {
                    float var10 = 10.0F / MathHelper.sqrt_float((float)(var8 * var8 + var9 * var9) + 0.2F);
                    this.parabolicField[var8 + 2 + (var9 + 2) * 5] = var10;
                }
            }
        }

        double var11 = 684.412D;
        double var13 = 684.412D;
        this.noise5 = this.noiseGen5.generateNoiseOctaves(this.noise5, par2, par4, par5, par7, 1.121D, 1.121D, 0.5D);
        this.noise6 = this.noiseGen6.generateNoiseOctaves(this.noise6, par2, par4, par5, par7, 200.0D, 200.0D, 0.5D);
        this.noise3 = this.noiseGen3.generateNoiseOctaves(this.noise3, par2, par3, par4, par5, par6, par7, var11 / 80.0D, var13 / 160.0D, var11 / 80.0D);
        this.noise1 = this.noiseGen1.generateNoiseOctaves(this.noise1, par2, par3, par4, par5, par6, par7, var11, var13, var11);
        this.noise2 = this.noiseGen2.generateNoiseOctaves(this.noise2, par2, par3, par4, par5, par6, par7, var11, var13, var11);
        boolean var49 = false;
        boolean var48 = false;
        int var15 = 0;
        int var16 = 0;

        for (int var17 = 0; var17 < par5; ++var17)
        {
            for (int var18 = 0; var18 < par7; ++var18)
            {
                float var19 = 0.0F;
                float var20 = 0.0F;
                float var21 = 0.0F;
                byte var22 = 2;
                BiomeBase var23 = this.biomesForGeneration[var17 + 2 + (var18 + 2) * (par5 + 5)];

                for (int var24 = -var22; var24 <= var22; ++var24)
                {
                    for (int var25 = -var22; var25 <= var22; ++var25)
                    {
                        BiomeBase var26 = this.biomesForGeneration[var17 + var24 + 2 + (var18 + var25 + 2) * (par5 + 5)];
                        float var27 = this.parabolicField[var24 + 2 + (var25 + 2) * 5] / (var26.minHeight + 2.0F);

                        if (var26.minHeight > var23.minHeight)
                        {
                            var27 /= 2.0F;
                        }

                        var19 += var26.maxHeight * var27;
                        var20 += var26.minHeight * var27;
                        var21 += var27;
                    }
                }

                var19 /= var21;
                var20 /= var21;
                var19 = var19 * 0.9F + 0.1F;
                var20 = (var20 * 4.0F - 1.0F) / 8.0F;
                double var28 = this.noise6[var16] / 8000.0D;

                if (var28 < 0.0D)
                {
                    var28 = -var28 * 0.3D;
                }

                var28 = var28 * 3.0D - 2.0D;

                if (var28 < 0.0D)
                {
                    var28 /= 2.0D;

                    if (var28 < -1.0D)
                    {
                        var28 = -1.0D;
                    }

                    var28 /= 1.4D;
                    var28 /= 2.0D;
                }
                else
                {
                    if (var28 > 1.0D)
                    {
                        var28 = 1.0D;
                    }

                    var28 /= 8.0D;
                }

                ++var16;

                for (int var50 = 0; var50 < par6; ++var50)
                {
                    double var30 = (double)var20;
                    double var32 = (double)var19;
                    var30 += var28 * 0.2D;
                    var30 = var30 * (double)par6 / 16.0D;
                    double var34 = (double)par6 / 2.0D + var30 * 4.0D;
                    double var36 = 0.0D;
                    double var38 = ((double)var50 - var34) * 12.0D * 128.0D / 128.0D / var32;

                    if (var38 < 0.0D)
                    {
                        var38 *= 4.0D;
                    }

                    double var40 = this.noise1[var15] / 512.0D;
                    double var42 = this.noise2[var15] / 512.0D;
                    double var44 = (this.noise3[var15] / 10.0D + 1.0D) / 2.0D;

                    if (var44 < 0.0D)
                    {
                        var36 = var40;
                    }
                    else if (var44 > 1.0D)
                    {
                        var36 = var42;
                    }
                    else
                    {
                        var36 = var40 + (var42 - var40) * var44;
                    }

                    var36 -= var38;

                    if (var50 > par6 - 4)
                    {
                        double var46 = (double)((float)(var50 - (par6 - 4)) / 3.0F);
                        var36 = var36 * (1.0D - var46) + -10.0D * var46;
                    }

                    par1ArrayOfDouble[var15] = var36;
                    ++var15;
                }
            }
        }

        return par1ArrayOfDouble;
    }

    public boolean isChunkLoaded(int var1, int var2)
    {
        return true;
    }

    public void getChunkAt(IChunkProvider var1, int var2, int var3)
    {
        BlockSand.instaFall = true;
        int var4 = var2 * 16;
        int var5 = var3 * 16;
        BiomeBase var6 = this.worldObj.getBiome(var4 + 16, var5 + 16);
        this.rand.setSeed(this.worldObj.getSeed());
        long var7 = this.rand.nextLong() / 2L * 2L + 1L;
        long var9 = this.rand.nextLong() / 2L * 2L + 1L;
        this.rand.setSeed((long)var2 * var7 + (long)var3 * var9 ^ this.worldObj.getSeed());
        boolean var11 = false;

        if (this.mapFeaturesEnabled)
        {
            this.mineshaftGenerator.a(this.worldObj, this.rand, var2, var3);
            var11 = this.villageGenerator.a(this.worldObj, this.rand, var2, var3);
            this.strongholdGenerator.a(this.worldObj, this.rand, var2, var3);
            this.scatteredFeatureGenerator.a(this.worldObj, this.rand, var2, var3);
        }

        int var12;
        int var13;
        int var14;

        if (var6 != BiomeBase.DESERT && var6 != BiomeBase.DESERT_HILLS && !var11 && this.rand.nextInt(4) == 0)
        {
            var12 = var4 + this.rand.nextInt(16) + 8;
            var13 = this.rand.nextInt(128);
            var14 = var5 + this.rand.nextInt(16) + 8;
            (new WorldGenLakes(Block.STATIONARY_WATER.id)).generate(this.worldObj, this.rand, var12, var13, var14);
        }

        if (!var11 && this.rand.nextInt(8) == 0)
        {
            var12 = var4 + this.rand.nextInt(16) + 8;
            var13 = this.rand.nextInt(this.rand.nextInt(120) + 8);
            var14 = var5 + this.rand.nextInt(16) + 8;

            if (var13 < 63 || this.rand.nextInt(10) == 0)
            {
                (new WorldGenLakes(Block.STATIONARY_LAVA.id)).generate(this.worldObj, this.rand, var12, var13, var14);
            }
        }

        for (var12 = 0; var12 < 8; ++var12)
        {
            var13 = var4 + this.rand.nextInt(16) + 8;
            var14 = this.rand.nextInt(128);
            int var15 = var5 + this.rand.nextInt(16) + 8;
            (new WorldGenDungeons()).generate(this.worldObj, this.rand, var13, var14, var15);
        }

        var6.decorate(this.worldObj, this.rand, var4, var5);
        SpawnerCreature.a(this.worldObj, var6, var4 + 8, var5 + 8, 16, 16, this.rand);
        var4 += 8;
        var5 += 8;

        for (var12 = 0; var12 < 16; ++var12)
        {
            for (var13 = 0; var13 < 16; ++var13)
            {
                var14 = this.worldObj.getPrecipitationHeight(var4 + var12, var5 + var13);

                if (this.worldObj.isBlockFreezable(var12 + var4, var14 - 1, var13 + var5))
                {
                    this.worldObj.setTypeIdAndData(var12 + var4, var14 - 1, var13 + var5, Block.ICE.id, 0, 2);
                }

                if (this.worldObj.canSnowAt(var12 + var4, var14, var13 + var5))
                {
                    this.worldObj.setTypeIdAndData(var12 + var4, var14, var13 + var5, Block.SNOW.id, 0, 2);
                }
            }
        }

        BlockSand.instaFall = false;
    }

    public boolean saveChunks(boolean var1, IProgressUpdate var2)
    {
        return true;
    }

    /**
     * Save extra data not associated with any Chunk.  Not saved during autosave, only during world unload.  Currently
     * unimplemented.
     */
    public void saveExtraData() {}

    public boolean unloadChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public String getName()
    {
        return "RandomLevelSource";
    }

    public List getMobsFor(EnumCreatureType var1, int var2, int var3, int var4)
    {
        BiomeBase var5 = this.worldObj.getBiome(var2, var4);
        return var5 == null ? null : (var1 == EnumCreatureType.MONSTER && this.scatteredFeatureGenerator.a(var2, var3, var4) ? this.scatteredFeatureGenerator.b() : var5.getMobs(var1));
    }

    public ChunkPosition findNearestMapFeature(World var1, String var2, int var3, int var4, int var5)
    {
        return "Stronghold".equals(var2) && this.strongholdGenerator != null ? this.strongholdGenerator.getNearestGeneratedFeature(var1, var3, var4, var5) : null;
    }

    public int getLoadedChunks()
    {
        return 0;
    }

    public void recreateStructures(int var1, int var2)
    {
        if (this.mapFeaturesEnabled)
        {
            this.mineshaftGenerator.a(this, this.worldObj, var1, var2, (byte[])null);
            this.villageGenerator.a(this, this.worldObj, var1, var2, (byte[])null);
            this.strongholdGenerator.a(this, this.worldObj, var1, var2, (byte[])null);
            this.scatteredFeatureGenerator.a(this, this.worldObj, var1, var2, (byte[])null);
        }
    }
}
