package net.minecraft.server.v1_6_R3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Iterator;

public class DedicatedPlayerList extends PlayerList {
	private File opsList;
	private File whiteList;

	public DedicatedPlayerList(DedicatedServer par1DedicatedServer) {
		super(par1DedicatedServer);
		this.opsList = par1DedicatedServer.d("ops.txt");
		this.whiteList = par1DedicatedServer.d("white-list.txt");
		this.c = par1DedicatedServer.getIntProperty("view-distance", 10);
		this.maxPlayers = par1DedicatedServer.getIntProperty("max-players", 20);
		this.setHasWhitelist(par1DedicatedServer.getBooleanProperty("white-list", false));

		if (!par1DedicatedServer.K()) {
			this.getNameBans().setEnabled(true);
			this.getIPBans().setEnabled(true);
		}

		this.getNameBans().load();
		this.getNameBans().save();
		this.getIPBans().load();
		this.getIPBans().save();
		this.loadOpsList();
		this.readWhiteList();
		this.saveOpsList();

		if (!this.whiteList.exists()) {
			this.saveWhiteList();
		}
	}

	public void setHasWhitelist(boolean var1) {
		super.setHasWhitelist(var1);
		this.getServer().setProperty("white-list", Boolean.valueOf(var1));
		this.getServer().saveProperties();
	}

	public void addOp(String var1) {
		super.addOp(var1);
		this.saveOpsList();
	}

	public void removeOp(String var1) {
		super.removeOp(var1);
		this.saveOpsList();
	}

	public void removeWhitelist(String var1) {
		super.removeWhitelist(var1);
		this.saveWhiteList();
	}

	public void addWhitelist(String var1) {
		super.addWhitelist(var1);
		this.saveWhiteList();
	}

	public void reloadWhitelist() {
		this.readWhiteList();
	}

	private void loadOpsList() {
		try {
			this.getOPs().clear();
			BufferedReader var1 = new BufferedReader(new FileReader(this.opsList));
			String var2 = "";

			while ((var2 = var1.readLine()) != null) {
				this.getOPs().add(var2.trim().toLowerCase());
			}

			var1.close();
		} catch (Exception var3) {
			this.getServer().getLogger().warning("Failed to load operators list: " + var3);
		}
	}

	private void saveOpsList() {
		try {
			PrintWriter var1 = new PrintWriter(new FileWriter(this.opsList, false));
			Iterator var2 = this.getOPs().iterator();

			while (var2.hasNext()) {
				String var3 = (String) var2.next();
				var1.println(var3);
			}

			var1.close();
		} catch (Exception var4) {
			this.getServer().getLogger().warning("Failed to save operators list: " + var4);
		}
	}

	private void readWhiteList() {
		try {
			this.getWhitelisted().clear();
			BufferedReader var1 = new BufferedReader(new FileReader(this.whiteList));
			String var2 = "";

			while ((var2 = var1.readLine()) != null) {
				this.getWhitelisted().add(var2.trim().toLowerCase());
			}

			var1.close();
		} catch (Exception var3) {
			this.getServer().getLogger().warning("Failed to load white-list: " + var3);
		}
	}

	private void saveWhiteList() {
		try {
			PrintWriter var1 = new PrintWriter(new FileWriter(this.whiteList, false));
			Iterator var2 = this.getWhitelisted().iterator();

			while (var2.hasNext()) {
				String var3 = (String) var2.next();
				var1.println(var3);
			}

			var1.close();
		} catch (Exception var4) {
			this.getServer().getLogger().warning("Failed to save white-list: " + var4);
		}
	}

	public boolean isWhitelisted(String var1) {
		var1 = var1.trim().toLowerCase();
		return !this.getHasWhitelist() || this.isOp(var1) || this.getWhitelisted().contains(var1);
	}

	public DedicatedServer getServer() {
		return (DedicatedServer) super.getServer();
	}
}
