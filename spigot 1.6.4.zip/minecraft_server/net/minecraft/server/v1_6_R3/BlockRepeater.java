package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockRepeater extends BlockDiodeAbstract
{
    /** The unlocalized name of this block. */
    public static final double[] unlocalizedName = new double[] { -0.0625D, 0.0625D, 0.1875D, 0.3125D};
    private static final int[] c = new int[] {1, 2, 3, 4};

    protected BlockRepeater(int var1, boolean var2)
    {
        super(var1, var2);
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        int var10 = var1.getData(var2, var3, var4);
        int var11 = (var10 & 12) >> 2;
        var11 = var11 + 1 << 2 & 12;
        var1.setData(var2, var3, var4, var11 | var10 & 3, 3);
        return true;
    }

    protected int k_(int var1)
    {
        return c[(var1 & 12) >> 2] * 2;
    }

    protected BlockDiodeAbstract i()
    {
        return Block.DIODE_ON;
    }

    protected BlockDiodeAbstract j()
    {
        return Block.DIODE_OFF;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Item.DIODE.id;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 15;
    }

    public boolean e(IBlockAccess var1, int var2, int var3, int var4, int var5)
    {
        return this.f(var1, var2, var3, var4, var5) > 0;
    }

    protected boolean e(int var1)
    {
        return f(var1);
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        super.remove(var1, var2, var3, var4, var5, var6);
        this.h_(var1, var2, var3, var4);
    }
}
