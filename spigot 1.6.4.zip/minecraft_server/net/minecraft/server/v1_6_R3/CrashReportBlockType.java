package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

final class CrashReportBlockType implements Callable
{
    final int a;

    CrashReportBlockType(int var1)
    {
        this.a = var1;
    }

    public String a()
    {
        try
        {
            return String.format("ID #%d (%s // %s)", new Object[] {Integer.valueOf(this.a), Block.byId[this.a].getUnlocalizedName(), Block.byId[this.a].getClass().getCanonicalName()});
        }
        catch (Throwable var2)
        {
            return "ID #" + this.a;
        }
    }

    public Object call()
    {
        return this.a();
    }
}
