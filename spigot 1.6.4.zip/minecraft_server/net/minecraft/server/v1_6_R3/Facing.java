package net.minecraft.server.v1_6_R3;

public class Facing
{
    public static final int[] OPPOSITE_FACING = new int[] {1, 0, 3, 2, 5, 4};

    /**
     * gives the offset required for this axis to get the block at that side.
     */
    public static final int[] offsetsXForSide = new int[] {0, 0, 0, 0, -1, 1};

    /**
     * gives the offset required for this axis to get the block at that side.
     */
    public static final int[] offsetsYForSide = new int[] { -1, 1, 0, 0, 0, 0};

    /**
     * gives the offset required for this axis to get the block at that side.
     */
    public static final int[] offsetsZForSide = new int[] {0, 0, -1, 1, 0, 0};
    public static final String[] facings = new String[] {"DOWN", "UP", "NORTH", "SOUTH", "WEST", "EAST"};
}
