package net.minecraft.server.v1_6_R3;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class CommandSpreadPlayers extends CommandAbstract
{
    public String getCommandName()
    {
        return "spreadplayers";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.spreadplayers.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length < 6)
        {
            throw new ExceptionUsage("commands.spreadplayers.usage", new Object[0]);
        }
        else
        {
            byte var3 = 0;
            int var16 = var3 + 1;
            double var4 = a(var1, Double.NaN, var2[var3]);
            double var6 = a(var1, Double.NaN, var2[var16++]);
            double var8 = a(var1, var2[var16++], 0.0D);
            double var10 = a(var1, var2[var16++], var8 + 1.0D);
            boolean var12 = c(var1, var2[var16++]);
            ArrayList var13 = Lists.newArrayList();

            while (true)
            {
                while (var16 < var2.length)
                {
                    String var14 = var2[var16++];

                    if (PlayerSelector.isPattern(var14))
                    {
                        EntityPlayer[] var17 = PlayerSelector.getPlayers(var1, var14);

                        if (var17 == null || var17.length == 0)
                        {
                            throw new ExceptionPlayerNotFound();
                        }

                        Collections.addAll(var13, var17);
                    }
                    else
                    {
                        EntityPlayer var15 = MinecraftServer.getServer().getPlayerList().getPlayer(var14);

                        if (var15 == null)
                        {
                            throw new ExceptionPlayerNotFound();
                        }

                        var13.add(var15);
                    }
                }

                if (var13.isEmpty())
                {
                    throw new ExceptionPlayerNotFound();
                }

                var1.sendMessage(ChatMessage.b("commands.spreadplayers.spreading." + (var12 ? "teams" : "players"), new Object[] {b(var13), Double.valueOf(var4), Double.valueOf(var6), Double.valueOf(var8), Double.valueOf(var10)}));
                this.a(var1, var13, new Location2D(var4, var6), var8, var10, ((EntityLiving)var13.get(0)).world, var12);
                return;
            }
        }
    }

    private void a(ICommandListener var1, List var2, Location2D var3, double var4, double var6, World var8, boolean var9)
    {
        Random var10 = new Random();
        double var11 = var3.a - var6;
        double var13 = var3.b - var6;
        double var15 = var3.a + var6;
        double var17 = var3.b + var6;
        Location2D[] var19 = this.a(var10, var9 ? this.func_110667_a(var2) : var2.size(), var11, var13, var15, var17);
        int var20 = this.a(var3, var4, var8, var10, var11, var13, var15, var17, var19, var9);
        double var21 = this.a(var2, var8, var19, var9);
        a(var1, "commands.spreadplayers.success." + (var9 ? "teams" : "players"), new Object[] {Integer.valueOf(var19.length), Double.valueOf(var3.a), Double.valueOf(var3.b)});

        if (var19.length > 1)
        {
            var1.sendMessage(ChatMessage.b("commands.spreadplayers.info." + (var9 ? "teams" : "players"), new Object[] {String.format("%.2f", new Object[]{Double.valueOf(var21)}), Integer.valueOf(var20)}));
        }
    }

    private int func_110667_a(List par1List)
    {
        HashSet var2 = Sets.newHashSet();
        Iterator var3 = par1List.iterator();

        while (var3.hasNext())
        {
            EntityLiving var4 = (EntityLiving)var3.next();

            if (var4 instanceof EntityHuman)
            {
                var2.add(((EntityHuman)var4).getScoreboardTeam());
            }
            else
            {
                var2.add((Object)null);
            }
        }

        return var2.size();
    }

    private int a(Location2D var1, double var2, World var4, Random var5, double var6, double var8, double var10, double var12, Location2D[] var14, boolean var15)
    {
        boolean var16 = true;
        double var17 = 3.4028234663852886E38D;
        int var19;

        for (var19 = 0; var19 < 10000 && var16; ++var19)
        {
            var16 = false;
            var17 = 3.4028234663852886E38D;
            int var22;
            Location2D var23;

            for (int var20 = 0; var20 < var14.length; ++var20)
            {
                Location2D var21 = var14[var20];
                var22 = 0;
                var23 = new Location2D();

                for (int var24 = 0; var24 < var14.length; ++var24)
                {
                    if (var20 != var24)
                    {
                        Location2D var25 = var14[var24];
                        double var26 = var21.a(var25);
                        var17 = Math.min(var26, var17);

                        if (var26 < var2)
                        {
                            ++var22;
                            var23.a += var25.a - var21.a;
                            var23.b += var25.b - var21.b;
                        }
                    }
                }

                if (var22 > 0)
                {
                    var23.a /= (double)var22;
                    var23.b /= (double)var22;
                    double var28 = (double)var23.b();

                    if (var28 > 0.0D)
                    {
                        var23.a();
                        var21.b(var23);
                    }
                    else
                    {
                        var21.a(var5, var6, var8, var10, var12);
                    }

                    var16 = true;
                }

                if (var21.a(var6, var8, var10, var12))
                {
                    var16 = true;
                }
            }

            if (!var16)
            {
                Location2D[] var30 = var14;
                int var31 = var14.length;

                for (var22 = 0; var22 < var31; ++var22)
                {
                    var23 = var30[var22];

                    if (!var23.b(var4))
                    {
                        var23.a(var5, var6, var8, var10, var12);
                        var16 = true;
                    }
                }
            }
        }

        if (var19 >= 10000)
        {
            throw new CommandException("commands.spreadplayers.failure." + (var15 ? "teams" : "players"), new Object[] {Integer.valueOf(var14.length), Double.valueOf(var1.a), Double.valueOf(var1.b), String.format("%.2f", new Object[]{Double.valueOf(var17)})});
        }
        else
        {
            return var19;
        }
    }

    private double a(List var1, World var2, Location2D[] var3, boolean var4)
    {
        double var5 = 0.0D;
        int var7 = 0;
        HashMap var8 = Maps.newHashMap();

        for (int var9 = 0; var9 < var1.size(); ++var9)
        {
            EntityLiving var10 = (EntityLiving)var1.get(var9);
            Location2D var12;

            if (var4)
            {
                ScoreboardTeamBase var11 = var10 instanceof EntityHuman ? ((EntityHuman)var10).getScoreboardTeam() : null;

                if (!var8.containsKey(var11))
                {
                    var8.put(var11, var3[var7++]);
                }

                var12 = (Location2D)var8.get(var11);
            }
            else
            {
                var12 = var3[var7++];
            }

            var10.enderTeleportTo((double)((float)MathHelper.floor(var12.a) + 0.5F), (double)var12.a(var2), (double)MathHelper.floor(var12.b) + 0.5D);
            double var13 = Double.MAX_VALUE;

            for (int var15 = 0; var15 < var3.length; ++var15)
            {
                if (var12 != var3[var15])
                {
                    double var16 = var12.a(var3[var15]);
                    var13 = Math.min(var16, var13);
                }
            }

            var5 += var13;
        }

        var5 /= (double)var1.size();
        return var5;
    }

    private Location2D[] a(Random var1, int var2, double var3, double var5, double var7, double var9)
    {
        Location2D[] var11 = new Location2D[var2];

        for (int var12 = 0; var12 < var11.length; ++var12)
        {
            Location2D var13 = new Location2D();
            var13.a(var1, var3, var5, var7, var9);
            var11[var12] = var13;
        }

        return var11;
    }
}
