package net.minecraft.server.v1_6_R3;

public class BiomeIcePlains extends BiomeBase
{
    public BiomeIcePlains(int var1)
    {
        super(var1);
    }
}
