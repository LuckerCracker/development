package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockDeadBush extends BlockFlower
{
    protected BlockDeadBush(int par1)
    {
        super(par1, Material.REPLACEABLE_PLANT);
        float var2 = 0.4F;
        this.setBlockBounds(0.5F - var2, 0.0F, 0.5F - var2, 0.5F + var2, 0.8F, 0.5F + var2);
    }

    /**
     * Gets passed in the blockID of the block below and supposed to return true if its allowed to grow on the type of
     * blockID passed in. Args: blockID
     */
    protected boolean canThisPlantGrowOnThisBlockID(int par1)
    {
        return par1 == Block.SAND.id;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return -1;
    }

    public void a(World var1, EntityHuman var2, int var3, int var4, int var5, int var6)
    {
        if (!var1.isStatic && var2.getCurrentEquippedItem() != null && var2.getCurrentEquippedItem().id == Item.SHEARS.id)
        {
            var2.addStat(StatisticList.C[this.id], 1);
            this.dropBlockAsItem_do(var1, var3, var4, var5, new ItemStack(Block.DEAD_BUSH, 1, var6));
        }
        else
        {
            super.a(var1, var2, var3, var4, var5, var6);
        }
    }
}
