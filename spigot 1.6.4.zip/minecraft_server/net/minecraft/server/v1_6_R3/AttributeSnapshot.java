package net.minecraft.server.v1_6_R3;

import java.util.Collection;

public class AttributeSnapshot
{
    private final String b;
    private final double c;
    private final Collection d;

    final Packet44UpdateAttributes a;

    public AttributeSnapshot(Packet44UpdateAttributes var1, String var2, double var3, Collection var5)
    {
        this.a = var1;
        this.b = var2;
        this.c = var3;
        this.d = var5;
    }

    public String a()
    {
        return this.b;
    }

    public double b()
    {
        return this.c;
    }

    public Collection c()
    {
        return this.d;
    }
}
