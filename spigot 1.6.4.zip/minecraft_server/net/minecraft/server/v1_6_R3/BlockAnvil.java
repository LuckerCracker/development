package net.minecraft.server.v1_6_R3;

public class BlockAnvil extends BlockSand
{
    /** List of types/statues the Anvil can be in. */
    public static final String[] statuses = new String[] {"intact", "slightlyDamaged", "veryDamaged"};
    private static final String[] anvilIconNames = new String[] {"anvil_top_damaged_0", "anvil_top_damaged_1", "anvil_top_damaged_2"};

    protected BlockAnvil(int par1)
    {
        super(par1, Material.HEAVY);
        this.setLightOpacity(0);
        this.a(CreativeModeTab.c);
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        int var7 = MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3;
        int var8 = var1.getData(var2, var3, var4) >> 2;
        ++var7;
        var7 %= 4;

        if (var7 == 0)
        {
            var1.setData(var2, var3, var4, 2 | var8 << 2, 2);
        }

        if (var7 == 1)
        {
            var1.setData(var2, var3, var4, 3 | var8 << 2, 2);
        }

        if (var7 == 2)
        {
            var1.setData(var2, var3, var4, 0 | var8 << 2, 2);
        }

        if (var7 == 3)
        {
            var1.setData(var2, var3, var4, 1 | var8 << 2, 2);
        }
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            var5.openAnvil(var2, var3, var4);
            return true;
        }
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 35;
    }

    public int getDropData(int var1)
    {
        return var1 >> 2;
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        int var5 = var1.getData(var2, var3, var4) & 3;

        if (var5 != 3 && var5 != 1)
        {
            this.setBlockBounds(0.125F, 0.0F, 0.0F, 0.875F, 1.0F, 1.0F);
        }
        else
        {
            this.setBlockBounds(0.0F, 0.0F, 0.125F, 1.0F, 1.0F, 0.875F);
        }
    }

    protected void a(EntityFallingBlock var1)
    {
        var1.a(true);
    }

    /**
     * Called when the falling block entity for this block hits the ground and turns back into a block
     */
    public void onFinishFalling(World par1World, int par2, int par3, int par4, int par5)
    {
        par1World.triggerEffect(1022, par2, par3, par4, 0);
    }
}
