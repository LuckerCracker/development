package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.Callable;
import org.spigotmc.TrackingRange;

public class EntityTracker {
	private final WorldServer world;

	/**
	 * List of tracked entities, used for iteration operations on tracked
	 * entities.
	 */
	private Set entries = new HashSet();
	public IntHashMap trackedEntities = new IntHashMap();
	private int maxTrackingDistanceThreshold;

	public EntityTracker(WorldServer par1WorldServer) {
		this.world = par1WorldServer;
		this.maxTrackingDistanceThreshold = par1WorldServer.getMinecraftServer().getPlayerList().a();
	}

	public void track(Entity entity) {
		if (entity instanceof EntityPlayer) {
			this.addEntity(entity, 512, 2);
			EntityPlayer entityplayer = (EntityPlayer) entity;
			Iterator iterator = this.entries.iterator();

			while (iterator.hasNext()) {
				EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry) iterator.next();

				if (entitytrackerentry.tracker != entityplayer) {
					entitytrackerentry.updatePlayer(entityplayer);
				}
			}
		} else if (entity instanceof EntityFishingHook) {
			this.addEntity(entity, 64, 5, true);
		} else if (entity instanceof EntityArrow) {
			this.addEntity(entity, 64, 20, false);
		} else if (entity instanceof EntitySmallFireball) {
			this.addEntity(entity, 64, 10, false);
		} else if (entity instanceof EntityFireball) {
			this.addEntity(entity, 64, 10, false);
		} else if (entity instanceof EntitySnowball) {
			this.addEntity(entity, 64, 10, true);
		} else if (entity instanceof EntityEnderPearl) {
			this.addEntity(entity, 64, 10, true);
		} else if (entity instanceof EntityEnderSignal) {
			this.addEntity(entity, 64, 4, true);
		} else if (entity instanceof EntityEgg) {
			this.addEntity(entity, 64, 10, true);
		} else if (entity instanceof EntityPotion) {
			this.addEntity(entity, 64, 10, true);
		} else if (entity instanceof EntityThrownExpBottle) {
			this.addEntity(entity, 64, 10, true);
		} else if (entity instanceof EntityFireworks) {
			this.addEntity(entity, 64, 10, true);
		} else if (entity instanceof EntityItem) {
			this.addEntity(entity, 64, 20, true);
		} else if (entity instanceof EntityMinecartAbstract) {
			this.addEntity(entity, 80, 3, true);
		} else if (entity instanceof EntityBoat) {
			this.addEntity(entity, 80, 3, true);
		} else if (entity instanceof EntitySquid) {
			this.addEntity(entity, 64, 3, true);
		} else if (entity instanceof EntityWither) {
			this.addEntity(entity, 80, 3, false);
		} else if (entity instanceof EntityBat) {
			this.addEntity(entity, 80, 3, false);
		} else if (entity instanceof IAnimal) {
			this.addEntity(entity, 80, 3, true);
		} else if (entity instanceof EntityEnderDragon) {
			this.addEntity(entity, 160, 3, true);
		} else if (entity instanceof EntityTNTPrimed) {
			this.addEntity(entity, 160, 10, true);
		} else if (entity instanceof EntityFallingBlock) {
			this.addEntity(entity, 160, 20, true);
		} else if (entity instanceof EntityHanging) {
			this.addEntity(entity, 160, Integer.MAX_VALUE, false);
		} else if (entity instanceof EntityExperienceOrb) {
			this.addEntity(entity, 160, 20, true);
		} else if (entity instanceof EntityEnderCrystal) {
			this.addEntity(entity, 256, Integer.MAX_VALUE, false);
		}
	}

	public void addEntity(Entity entity, int i, int j) {
		this.addEntity(entity, i, j, false);
	}

	public void addEntity(Entity entity, int i, int j, boolean flag) {
		if (Thread.currentThread() != MinecraftServer.getServer().primaryThread) {
			throw new IllegalStateException("Asynchronous entity track!");
		} else {
			i = TrackingRange.getEntityTrackingRange(entity, i);

			if (i > this.maxTrackingDistanceThreshold) {
				i = this.maxTrackingDistanceThreshold;
			}

			try {
				if (this.trackedEntities.containsItem(entity.id)) {
					throw new IllegalStateException("Entity is already tracked!");
				}

				EntityTrackerEntry throwable = new EntityTrackerEntry(entity, i, j, flag);
				this.entries.add(throwable);
				this.trackedEntities.addKey(entity.id, throwable);
				throwable.scanPlayers(this.world.players);
			} catch (Throwable var11) {
				CrashReport crashreport = CrashReport.makeCrashReport(var11, "Adding entity to track");
				CrashReportSystemDetails crashreportsystemdetails = crashreport.a("Entity To Track");
				crashreportsystemdetails.a("Tracking range", (Object) (i + " blocks"));
				crashreportsystemdetails.a("Update interval",
						(Callable) (new CrashReportEntityTrackerUpdateInterval(this, j)));
				entity.a(crashreportsystemdetails);
				CrashReportSystemDetails crashreportsystemdetails1 = crashreport.a("Entity That Is Already Tracked");
				((EntityTrackerEntry) this.trackedEntities.get(entity.id)).tracker.a(crashreportsystemdetails1);

				try {
					throw new ReportedException(crashreport);
				} catch (ReportedException var10) {
					System.err.println("\"Silently\" catching entity tracking error.");
					var10.printStackTrace();
				}
			}
		}
	}

	public void untrackEntity(Entity entity) {
		if (Thread.currentThread() != MinecraftServer.getServer().primaryThread) {
			throw new IllegalStateException("Asynchronous entity untrack!");
		} else {
			if (entity instanceof EntityPlayer) {
				EntityPlayer entitytrackerentry1 = (EntityPlayer) entity;
				Iterator iterator = this.entries.iterator();

				while (iterator.hasNext()) {
					EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry) iterator.next();
					entitytrackerentry.a(entitytrackerentry1);
				}
			}

			EntityTrackerEntry entitytrackerentry11 = (EntityTrackerEntry) this.trackedEntities.removeObject(entity.id);

			if (entitytrackerentry11 != null) {
				this.entries.remove(entitytrackerentry11);
				entitytrackerentry11.sendDestroyEntityPacketToTrackedPlayers();
			}
		}
	}

	public void updatePlayers() {
		ArrayList arraylist = new ArrayList();
		Iterator iterator = this.entries.iterator();

		while (iterator.hasNext()) {
			EntityTrackerEntry i = (EntityTrackerEntry) iterator.next();
			i.track(this.world.players);

			if (i.playerEntitiesUpdated && i.tracker instanceof EntityPlayer) {
				arraylist.add((EntityPlayer) i.tracker);
			}
		}

		for (int var7 = 0; var7 < arraylist.size(); ++var7) {
			EntityPlayer entityplayer = (EntityPlayer) arraylist.get(var7);
			Iterator iterator1 = this.entries.iterator();

			while (iterator1.hasNext()) {
				EntityTrackerEntry entitytrackerentry1 = (EntityTrackerEntry) iterator1.next();

				if (entitytrackerentry1.tracker != entityplayer) {
					entitytrackerentry1.updatePlayer(entityplayer);
				}
			}
		}
	}

	public void sendPacketToTrackedPlayers(Entity par1Entity, Packet par2Packet) {
		EntityTrackerEntry var3 = (EntityTrackerEntry) this.trackedEntities.get(par1Entity.id);

		if (var3 != null) {
			var3.broadcast(par2Packet);
		}
	}

	public void sendPacketToEntity(Entity entity, Packet packet) {
		EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry) this.trackedEntities.get(entity.id);

		if (entitytrackerentry != null) {
			entitytrackerentry.broadcastIncludingSelf(packet);
		}
	}

	public void untrackPlayer(EntityPlayer entityplayer) {
		Iterator iterator = this.entries.iterator();

		while (iterator.hasNext()) {
			EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry) iterator.next();
			entitytrackerentry.clear(entityplayer);
		}
	}

	public void a(EntityPlayer entityplayer, Chunk chunk) {
		Iterator iterator = this.entries.iterator();

		while (iterator.hasNext()) {
			EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry) iterator.next();

			if (entitytrackerentry.tracker != entityplayer && entitytrackerentry.tracker.chunkCoordX == chunk.x
					&& entitytrackerentry.tracker.chunkCoordZ == chunk.z) {
				entitytrackerentry.updatePlayer(entityplayer);
			}
		}
	}
}
