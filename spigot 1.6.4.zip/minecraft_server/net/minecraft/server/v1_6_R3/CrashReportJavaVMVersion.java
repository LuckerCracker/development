package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportJavaVMVersion implements Callable
{
    final CrashReport a;

    CrashReportJavaVMVersion(CrashReport var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return System.getProperty("java.vm.name") + " (" + System.getProperty("java.vm.info") + "), " + System.getProperty("java.vm.vendor");
    }

    public Object call()
    {
        return this.a();
    }
}
