package net.minecraft.server.v1_6_R3;

public class AttributeRanged extends AttributeBase {
	private final double field_111115_a;
	private final double defaultValue;
	private String shouldWatch;

	public AttributeRanged(String var1, double var2, double var4, double var6) {
		super(var1, var2);
		this.field_111115_a = var4;
		this.defaultValue = var6;

		if (var4 > var6) {
			throw new IllegalArgumentException("Minimum value cannot be bigger than maximum value!");
		} else if (var2 < var4) {
			throw new IllegalArgumentException("Default value cannot be lower than minimum value!");
		} else if (var2 > var6) {
			throw new IllegalArgumentException("Default value cannot be bigger than maximum value!");
		}
	}

	public AttributeRanged a(String var1) {
		this.shouldWatch = var1;
		return this;
	}

	public String f() {
		return this.shouldWatch;
	}

	public double a(double var1) {
		if (var1 < this.field_111115_a) {
			var1 = this.field_111115_a;
		}

		if (var1 > this.defaultValue) {
			var1 = this.defaultValue;
		}

		return var1;
	}
}
