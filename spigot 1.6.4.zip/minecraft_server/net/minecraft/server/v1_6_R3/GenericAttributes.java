package net.minecraft.server.v1_6_R3;

import java.util.Collection;
import java.util.Iterator;
import java.util.UUID;

public class GenericAttributes {
	public static final IAttribute a = (new AttributeRanged("generic.maxHealth", 20.0D, 0.0D, Double.MAX_VALUE))
			.a("Max Health").setShouldWatch(true);
	public static final IAttribute b = (new AttributeRanged("generic.followRange", 32.0D, 0.0D, 2048.0D))
			.a("Follow Range");
	public static final IAttribute c = (new AttributeRanged("generic.knockbackResistance", 0.0D, 0.0D, 1.0D))
			.a("Knockback Resistance");
	public static final IAttribute d = (new AttributeRanged("generic.movementSpeed", 0.699999988079071D, 0.0D,
			Double.MAX_VALUE)).a("Movement Speed").setShouldWatch(true);
	public static final IAttribute e = new AttributeRanged("generic.attackDamage", 2.0D, 0.0D, Double.MAX_VALUE);

	public static NBTTagList a(AttributeMapBase var0) {
		NBTTagList var1 = new NBTTagList();
		Iterator var2 = var0.a().iterator();

		while (var2.hasNext()) {
			AttributeInstance var3 = (AttributeInstance) var2.next();
			var1.add(a(var3));
		}

		return var1;
	}

	private static NBTTagCompound a(AttributeInstance var0) {
		NBTTagCompound var1 = new NBTTagCompound();
		IAttribute var2 = var0.a();
		var1.setString("Name", var2.getAttributeUnlocalizedName());
		var1.setDouble("Base", var0.getBaseValue());
		Collection var3 = var0.func_111122_c();

		if (var3 != null && !var3.isEmpty()) {
			NBTTagList var4 = new NBTTagList();
			Iterator var5 = var3.iterator();

			while (var5.hasNext()) {
				AttributeModifier var6 = (AttributeModifier) var5.next();

				if (var6.isSaved()) {
					var4.add(a(var6));
				}
			}

			var1.set("Modifiers", var4);
		}

		return var1;
	}

	private static NBTTagCompound a(AttributeModifier var0) {
		NBTTagCompound var1 = new NBTTagCompound();
		var1.setString("Name", var0.getName());
		var1.setDouble("Amount", var0.getAmount());
		var1.setInt("Operation", var0.getOperation());
		var1.setLong("UUIDMost", var0.getID().getMostSignificantBits());
		var1.setLong("UUIDLeast", var0.getID().getLeastSignificantBits());
		return var1;
	}

	public static void a(AttributeMapBase var0, NBTTagList var1, IConsoleLogManager var2) {
		for (int var3 = 0; var3 < var1.size(); ++var3) {
			NBTTagCompound var4 = (NBTTagCompound) var1.get(var3);
			AttributeInstance var5 = var0.a(var4.getString("Name"));

			if (var5 != null) {
				a(var5, var4);
			} else if (var2 != null) {
				var2.warning("Ignoring unknown attribute \'" + var4.getString("Name") + "\'");
			}
		}
	}

	private static void a(AttributeInstance var0, NBTTagCompound var1) {
		var0.setValue(var1.getDouble("Base"));

		if (var1.hasKey("Modifiers")) {
			NBTTagList var2 = var1.getList("Modifiers");

			for (int var3 = 0; var3 < var2.size(); ++var3) {
				AttributeModifier var4 = a((NBTTagCompound) var2.get(var3));
				AttributeModifier var5 = var0.getModifier(var4.getID());

				if (var5 != null) {
					var0.removeModifier(var5);
				}

				var0.applyModifier(var4);
			}
		}
	}

	public static AttributeModifier a(NBTTagCompound var0) {
		UUID var1 = new UUID(var0.getLong("UUIDMost"), var0.getLong("UUIDLeast"));
		return new AttributeModifier(var1, var0.getString("Name"), var0.getDouble("Amount"), var0.getInt("Operation"));
	}
}
