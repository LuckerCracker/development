package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public enum EnumChatFormat {
	BLACK('0'), DARK_BLUE('1'), DARK_GREEN('2'), DARK_AQUA('3'), DARK_RED('4'), DARK_PURPLE('5'), GOLD('6'), GRAY(
			'7'), DARK_GRAY('8'), BLUE('9'), GREEN('a'), AQUA('b'), RED('c'), LIGHT_PURPLE('d'), YELLOW('e'), WHITE(
					'f'), RANDOM("OBFUSCATED", 16, 'k', true), BOLD('l',
							true), STRIKETHROUGH('m', true), UNDERLINE('n', true), ITALIC('o', true), RESET('r');
	private static final Map w = new HashMap();
	private static final Map x = new HashMap();
	private static final Pattern y = Pattern.compile("(?i)" + String.valueOf('\u00a7') + "[0-9A-FK-OR]");
	private final char z;
	private final boolean A;
	private final String B;

	private EnumChatFormat(char var3) {
		this(var3, false);
	}

	private EnumChatFormat(String var1, int var2, char var3, boolean var4) {
		this.z = var3;
		this.A = var4;
		this.B = "\u00a7" + var3;
	}

	private EnumChatFormat(char var3, boolean var4) {
		this.z = var3;
		this.A = var4;
		this.B = "\u00a7" + var3;
	}

	public char a() {
		return this.z;
	}

	public boolean b() {
		return this.A;
	}

	public boolean c() {
		return !this.A && this != RESET;
	}

	public String d() {
		return this.name().toLowerCase();
	}

	public String toString() {
		return this.B;
	}

	public static EnumChatFormat b(String var0) {
		return var0 == null ? null : (EnumChatFormat) x.get(var0.toLowerCase());
	}

	public static Collection a(boolean var0, boolean var1) {
		ArrayList var2 = new ArrayList();
		EnumChatFormat[] var3 = values();
		int var4 = var3.length;

		for (int var5 = 0; var5 < var4; ++var5) {
			EnumChatFormat var6 = var3[var5];

			if ((!var6.c() || var0) && (!var6.b() || var1)) {
				var2.add(var6.d());
			}
		}

		return var2;
	}

	static {
		EnumChatFormat[] var0 = values();
		int var1 = var0.length;

		for (int var2 = 0; var2 < var1; ++var2) {
			EnumChatFormat var3 = var0[var2];
			w.put(Character.valueOf(var3.a()), var3);
			x.put(var3.d(), var3);
		}
	}
}
