package net.minecraft.server.v1_6_R3;

public class EnchantmentInfiniteArrows extends Enchantment
{
    public EnchantmentInfiniteArrows(int var1, int var2)
    {
        super(var1, var2, EnchantmentSlotType.BOW);
        this.setName("arrowInfinite");
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int var1)
    {
        return 20;
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int var1)
    {
        return 50;
    }

    public int getMaxLevel()
    {
        return 1;
    }
}
