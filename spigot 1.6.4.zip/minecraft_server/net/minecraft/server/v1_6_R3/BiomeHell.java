package net.minecraft.server.v1_6_R3;

public class BiomeHell extends BiomeBase
{
    public BiomeHell(int var1)
    {
        super(var1);
        this.spawnableMonsterList.clear();
        this.spawnableCreatureList.clear();
        this.spawnableWaterCreatureList.clear();
        this.spawnableCaveCreatureList.clear();
        this.spawnableMonsterList.add(new BiomeMeta(EntityGhast.class, 50, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntityPigZombie.class, 100, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntityMagmaCube.class, 1, 4, 4));
    }
}
