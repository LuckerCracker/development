package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockTNT extends Block
{
    public BlockTNT(int par1)
    {
        super(par1, Material.TNT);
        this.a(CreativeModeTab.d);
    }

    public void onPlace(World world, int i, int j, int k)
    {
        super.onPlace(world, i, j, k);

        if (world.isBlockIndirectlyPowered(i, j, k))
        {
            this.postBreak(world, i, j, k, 1);
            world.setAir(i, j, k);
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (world.isBlockIndirectlyPowered(i, j, k))
        {
            this.postBreak(world, i, j, k, 1);
            world.setAir(i, j, k);
        }
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 1;
    }

    public void wasExploded(World world, int i, int j, int k, Explosion explosion)
    {
        if (!world.isStatic)
        {
            EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, (double)((float)i + 0.5F), (double)((float)j + 0.5F), (double)((float)k + 0.5F), explosion.c());
            entitytntprimed.fuseTicks = world.random.nextInt(entitytntprimed.fuseTicks / 4) + entitytntprimed.fuseTicks / 8;
            world.addEntity(entitytntprimed);
        }
    }

    public void postBreak(World world, int i, int j, int k, int l)
    {
        this.a(world, i, j, k, l, (EntityLiving)null);
    }

    public void a(World world, int i, int j, int k, int l, EntityLiving entityliving)
    {
        if (!world.isStatic && (l & 1) == 1)
        {
            EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, (double)((float)i + 0.5F), (double)((float)j + 0.5F), (double)((float)k + 0.5F), entityliving);
            world.addEntity(entitytntprimed);
            world.makeSound(entitytntprimed, "random.fuse", 1.0F, 1.0F);
        }
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        if (entityhuman.getCurrentEquippedItem() != null && entityhuman.getCurrentEquippedItem().id == Item.FLINT_AND_STEEL.id)
        {
            this.a(world, i, j, k, 1, entityhuman);
            world.setAir(i, j, k);
            entityhuman.getCurrentEquippedItem().damage(1, entityhuman);
            return true;
        }
        else
        {
            return super.interact(world, i, j, k, entityhuman, l, f, f1, f2);
        }
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void onEntityCollidedWithBlock(World par1World, int par2, int par3, int par4, Entity par5Entity)
    {
        if (par5Entity instanceof EntityArrow && !par1World.isStatic)
        {
            EntityArrow var6 = (EntityArrow)par5Entity;

            if (var6.isBurning())
            {
                if (CraftEventFactory.callEntityChangeBlockEvent(var6, par2, par3, par4, 0, 0).isCancelled())
                {
                    return;
                }

                this.a(par1World, par2, par3, par4, 1, var6.shooter instanceof EntityLiving ? (EntityLiving)var6.shooter : null);
                par1World.setAir(par2, par3, par4);
            }
        }
    }

    /**
     * Return whether this block can drop from an explosion.
     */
    public boolean canDropFromExplosion(Explosion par1Explosion)
    {
        return false;
    }
}
