package net.minecraft.server.v1_6_R3;

public class EntitySnowball extends EntityProjectile
{
    public EntitySnowball(World par1World)
    {
        super(par1World);
    }

    public EntitySnowball(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntitySnowball(World par1World, double par2, double par4, double par6)
    {
        super(par1World, par2, par4, par6);
    }

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition par1MovingObjectPosition)
    {
        if (par1MovingObjectPosition.entity != null)
        {
            byte var2 = 0;

            if (par1MovingObjectPosition.entity instanceof EntityBlaze)
            {
                var2 = 3;
            }

            par1MovingObjectPosition.entity.attackEntityFrom(DamageSource.projectile(this, this.getShooter()), (float)var2);
        }

        for (int var3 = 0; var3 < 8; ++var3)
        {
            this.world.addParticle("snowballpoof", this.locX, this.locY, this.locZ, 0.0D, 0.0D, 0.0D);
        }

        if (!this.world.isStatic)
        {
            this.die();
        }
    }
}
