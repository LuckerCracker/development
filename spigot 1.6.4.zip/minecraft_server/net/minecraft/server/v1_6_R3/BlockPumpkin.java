package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.util.BlockStateListPopulator;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;

public class BlockPumpkin extends BlockDirectional {
	/** Boolean used to seperate different states of blocks */
	private boolean blockType;

	protected BlockPumpkin(int par1, boolean par2) {
		super(par1, Material.PUMPKIN);
		this.setTickRandomly(true);
		this.blockType = par2;
		this.a(CreativeModeTab.b);
	}

	public void onPlace(World world, int i, int j, int k) {
		super.onPlace(world, i, j, k);

		if (world.getTypeId(i, j - 1, k) == Block.SNOW_BLOCK.id
				&& world.getTypeId(i, j - 2, k) == Block.SNOW_BLOCK.id) {
			if (!world.isStatic) {
				BlockStateListPopulator var10 = new BlockStateListPopulator(world.getWorld());
				var10.setTypeId(i, j, k, 0);
				var10.setTypeId(i, j - 1, k, 0);
				var10.setTypeId(i, j - 2, k, 0);
				EntitySnowman var12 = new EntitySnowman(world);
				var12.setPositionRotation((double) i + 0.5D, (double) j - 1.95D, (double) k + 0.5D, 0.0F, 0.0F);

				if (world.addEntity(var12, CreatureSpawnEvent.SpawnReason.BUILD_SNOWMAN)) {
					var10.updateList();
				}
			}

			for (int var11 = 0; var11 < 120; ++var11) {
				world.addParticle("snowshovel", (double) i + world.random.nextDouble(),
						(double) (j - 2) + world.random.nextDouble() * 2.5D, (double) k + world.random.nextDouble(),
						0.0D, 0.0D, 0.0D);
			}
		} else if (world.getTypeId(i, j - 1, k) == Block.IRON_BLOCK.id
				&& world.getTypeId(i, j - 2, k) == Block.IRON_BLOCK.id) {
			boolean flag = world.getTypeId(i - 1, j - 1, k) == Block.IRON_BLOCK.id
					&& world.getTypeId(i + 1, j - 1, k) == Block.IRON_BLOCK.id;
			boolean flag1 = world.getTypeId(i, j - 1, k - 1) == Block.IRON_BLOCK.id
					&& world.getTypeId(i, j - 1, k + 1) == Block.IRON_BLOCK.id;

			if (flag || flag1) {
				BlockStateListPopulator blockList = new BlockStateListPopulator(world.getWorld());
				blockList.setTypeId(i, j, k, 0);
				blockList.setTypeId(i, j - 1, k, 0);
				blockList.setTypeId(i, j - 2, k, 0);

				if (flag) {
					blockList.setTypeId(i - 1, j - 1, k, 0);
					blockList.setTypeId(i + 1, j - 1, k, 0);
				} else {
					blockList.setTypeId(i, j - 1, k - 1, 0);
					blockList.setTypeId(i, j - 1, k + 1, 0);
				}

				EntityIronGolem entityirongolem = new EntityIronGolem(world);
				entityirongolem.setPlayerCreated(true);
				entityirongolem.setPositionRotation((double) i + 0.5D, (double) j - 1.95D, (double) k + 0.5D, 0.0F,
						0.0F);

				if (world.addEntity(entityirongolem, CreatureSpawnEvent.SpawnReason.BUILD_IRONGOLEM)) {
					for (int i1 = 0; i1 < 120; ++i1) {
						world.addParticle("snowballpoof", (double) i + world.random.nextDouble(),
								(double) (j - 2) + world.random.nextDouble() * 3.9D,
								(double) k + world.random.nextDouble(), 0.0D, 0.0D, 0.0D);
					}

					blockList.updateList();
				}
			}
		}
	}

	public boolean canPlace(World world, int i, int j, int k) {
		int l = world.getTypeId(i, j, k);
		return (l == 0 || Block.byId[l].material.isReplaceable()) && world.doesBlockHaveSolidTopSurface(i, j - 1, k);
	}

	public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack) {
		int l = MathHelper.floor((double) (entityliving.yaw * 4.0F / 360.0F) + 2.5D) & 3;
		world.setData(i, j, k, l, 2);
	}

	public void doPhysics(World world, int i, int j, int k, int l) {
		if (Block.byId[l] != null && Block.byId[l].isPowerSource()) {
			org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
			int power = block.getBlockPower();
			BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, power, power);
			world.getServer().getPluginManager().callEvent(eventRedstone);
		}
	}
}
