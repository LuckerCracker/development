package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.event.block.BlockFromToEvent;

public class BlockDragonEgg extends Block
{
    public BlockDragonEgg(int par1)
    {
        super(par1, Material.DRAGON_EGG);
        this.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 1.0F, 0.9375F);
    }

    public void onPlace(World world, int i, int j, int k)
    {
        world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        this.fallIfPossible(par1World, par2, par3, par4);
    }

    /**
     * Checks if the dragon egg can fall down, and if so, makes it fall.
     */
    private void fallIfPossible(World par1World, int par2, int par3, int par4)
    {
        if (BlockSand.canFall(par1World, par2, par3 - 1, par4) && par3 >= 0)
        {
            byte var5 = 32;

            if (!BlockSand.instaFall && par1World.checkChunksExist(par2 - var5, par3 - var5, par4 - var5, par2 + var5, par3 + var5, par4 + var5))
            {
                EntityFallingBlock var6 = new EntityFallingBlock(par1World, (double)((float)par2 + 0.5F), (double)((float)par3 + 0.5F), (double)((float)par4 + 0.5F), this.id, par1World.getData(par2, par3, par4));
                par1World.addEntity(var6);
            }
            else
            {
                par1World.setAir(par2, par3, par4);

                while (BlockSand.canFall(par1World, par2, par3 - 1, par4) && par3 > 0)
                {
                    --par3;
                }

                if (par3 > 0)
                {
                    par1World.setTypeIdAndData(par2, par3, par4, this.id, 0, 2);
                }
            }
        }
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        this.teleportNearby(world, i, j, k);
        return true;
    }

    public void attack(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        this.teleportNearby(world, i, j, k);
    }

    /**
     * Teleports the dragon egg somewhere else in a 31x19x31 area centered on the egg.
     */
    private void teleportNearby(World par1World, int par2, int par3, int par4)
    {
        if (par1World.getTypeId(par2, par3, par4) == this.id)
        {
            for (int var5 = 0; var5 < 1000; ++var5)
            {
                int var6 = par2 + par1World.random.nextInt(16) - par1World.random.nextInt(16);
                int var7 = par3 + par1World.random.nextInt(8) - par1World.random.nextInt(8);
                int var8 = par4 + par1World.random.nextInt(16) - par1World.random.nextInt(16);

                if (par1World.getTypeId(var6, var7, var8) == 0)
                {
                    org.bukkit.block.Block var9 = par1World.getWorld().getBlockAt(par2, par3, par4);
                    org.bukkit.block.Block var10 = par1World.getWorld().getBlockAt(var6, var7, var8);
                    BlockFromToEvent var11 = new BlockFromToEvent(var9, var10);
                    Bukkit.getPluginManager().callEvent(var11);

                    if (var11.isCancelled())
                    {
                        return;
                    }

                    var6 = var11.getToBlock().getX();
                    var7 = var11.getToBlock().getY();
                    var8 = var11.getToBlock().getZ();

                    if (!par1World.isStatic)
                    {
                        par1World.setTypeIdAndData(var6, var7, var8, this.id, par1World.getData(par2, par3, par4), 2);
                        par1World.setAir(par2, par3, par4);
                    }
                    else
                    {
                        short var12 = 128;

                        for (int var13 = 0; var13 < var12; ++var13)
                        {
                            double var14 = par1World.random.nextDouble();
                            float var16 = (par1World.random.nextFloat() - 0.5F) * 0.2F;
                            float var17 = (par1World.random.nextFloat() - 0.5F) * 0.2F;
                            float var18 = (par1World.random.nextFloat() - 0.5F) * 0.2F;
                            double var19 = (double)var6 + (double)(par2 - var6) * var14 + (par1World.random.nextDouble() - 0.5D) * 1.0D + 0.5D;
                            double var21 = (double)var7 + (double)(par3 - var7) * var14 + par1World.random.nextDouble() * 1.0D - 0.5D;
                            double var23 = (double)var8 + (double)(par4 - var8) * var14 + (par1World.random.nextDouble() - 0.5D) * 1.0D + 0.5D;
                            par1World.addParticle("portal", var19, var21, var23, (double)var16, (double)var17, (double)var18);
                        }
                    }

                    return;
                }
            }
        }
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World par1World)
    {
        return 5;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 27;
    }
}
