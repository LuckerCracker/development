package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockStem extends BlockFlower
{
    private final Block blockFruit;

    protected BlockStem(int par1, Block par2Block)
    {
        super(par1);
        this.blockFruit = par2Block;
        this.setTickRandomly(true);
        float var3 = 0.125F;
        this.setBlockBounds(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 0.25F, 0.5F + var3);
        this.a((CreativeModeTab)null);
    }

    /**
     * Gets passed in the blockID of the block below and supposed to return true if its allowed to grow on the type of
     * blockID passed in. Args: blockID
     */
    protected boolean canThisPlantGrowOnThisBlockID(int par1)
    {
        return par1 == Block.SOIL.id;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        super.updateTick(par1World, par2, par3, par4, par5Random);

        if (par1World.getLightLevel(par2, par3 + 1, par4) >= 9)
        {
            float var6 = this.getGrowthModifier(par1World, par2, par3, par4);

            if (par5Random.nextInt((int)(par1World.growthOdds / (float)(this.id == Block.PUMPKIN_STEM.id ? par1World.spigotConfig.pumpkinModifier : par1World.spigotConfig.melonModifier) * (25.0F / var6)) + 1) == 0)
            {
                int var7 = par1World.getData(par2, par3, par4);

                if (var7 < 7)
                {
                    ++var7;
                    CraftEventFactory.handleBlockGrowEvent(par1World, par2, par3, par4, this.id, var7);
                }
                else
                {
                    if (par1World.getTypeId(par2 - 1, par3, par4) == this.blockFruit.id)
                    {
                        return;
                    }

                    if (par1World.getTypeId(par2 + 1, par3, par4) == this.blockFruit.id)
                    {
                        return;
                    }

                    if (par1World.getTypeId(par2, par3, par4 - 1) == this.blockFruit.id)
                    {
                        return;
                    }

                    if (par1World.getTypeId(par2, par3, par4 + 1) == this.blockFruit.id)
                    {
                        return;
                    }

                    int var8 = par5Random.nextInt(4);
                    int var9 = par2;
                    int var10 = par4;

                    if (var8 == 0)
                    {
                        var9 = par2 - 1;
                    }

                    if (var8 == 1)
                    {
                        ++var9;
                    }

                    if (var8 == 2)
                    {
                        var10 = par4 - 1;
                    }

                    if (var8 == 3)
                    {
                        ++var10;
                    }

                    int var11 = par1World.getTypeId(var9, par3 - 1, var10);

                    if (par1World.getTypeId(var9, par3, var10) == 0 && (var11 == Block.SOIL.id || var11 == Block.DIRT.id || var11 == Block.GRASS.id))
                    {
                        CraftEventFactory.handleBlockGrowEvent(par1World, var9, par3, var10, this.blockFruit.id, 0);
                    }
                }
            }
        }
    }

    public void fertilizeStem(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4) + MathHelper.nextInt(par1World.random, 2, 5);

        if (var5 > 7)
        {
            var5 = 7;
        }

        par1World.setData(par2, par3, par4, var5, 2);
    }

    private float getGrowthModifier(World par1World, int par2, int par3, int par4)
    {
        float var5 = 1.0F;
        int var6 = par1World.getTypeId(par2, par3, par4 - 1);
        int var7 = par1World.getTypeId(par2, par3, par4 + 1);
        int var8 = par1World.getTypeId(par2 - 1, par3, par4);
        int var9 = par1World.getTypeId(par2 + 1, par3, par4);
        int var10 = par1World.getTypeId(par2 - 1, par3, par4 - 1);
        int var11 = par1World.getTypeId(par2 + 1, par3, par4 - 1);
        int var12 = par1World.getTypeId(par2 + 1, par3, par4 + 1);
        int var13 = par1World.getTypeId(par2 - 1, par3, par4 + 1);
        boolean var14 = var8 == this.id || var9 == this.id;
        boolean var15 = var6 == this.id || var7 == this.id;
        boolean var16 = var10 == this.id || var11 == this.id || var12 == this.id || var13 == this.id;

        for (int var17 = par2 - 1; var17 <= par2 + 1; ++var17)
        {
            for (int var18 = par4 - 1; var18 <= par4 + 1; ++var18)
            {
                int var19 = par1World.getTypeId(var17, par3 - 1, var18);
                float var20 = 0.0F;

                if (var19 == Block.SOIL.id)
                {
                    var20 = 1.0F;

                    if (par1World.getData(var17, par3 - 1, var18) > 0)
                    {
                        var20 = 3.0F;
                    }
                }

                if (var17 != par2 || var18 != par4)
                {
                    var20 /= 4.0F;
                }

                var5 += var20;
            }
        }

        if (var16 || var14 && var15)
        {
            var5 /= 2.0F;
        }

        return var5;
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        float var1 = 0.125F;
        this.setBlockBounds(0.5F - var1, 0.0F, 0.5F - var1, 0.5F + var1, 0.25F, 0.5F + var1);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        this.maxY = (double)((float)(iblockaccess.getData(i, j, k) * 2 + 2) / 16.0F);
        float f = 0.125F;
        this.setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, (float)this.maxY, 0.5F + f);
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 19;
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        super.dropNaturally(world, i, j, k, l, f, i1);

        if (!world.isStatic)
        {
            Item item = null;

            if (this.blockFruit == Block.PUMPKIN)
            {
                item = Item.PUMPKIN_SEEDS;
            }

            if (this.blockFruit == Block.MELON)
            {
                item = Item.MELON_SEEDS;
            }

            for (int j1 = 0; j1 < 3; ++j1)
            {
                if (world.random.nextInt(15) <= l)
                {
                    this.dropBlockAsItem_do(world, i, j, k, new ItemStack(item));
                }
            }
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return -1;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 1;
    }
}
