package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportStructureType implements Callable
{
    final StructureGenerator a;

    CrashReportStructureType(StructureGenerator var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return this.a.getClass().getCanonicalName();
    }

    public Object call()
    {
        return this.a();
    }
}
