package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.event.entity.SheepRegrowWoolEvent;
import org.bukkit.event.player.PlayerShearEntityEvent;

public class EntitySheep extends EntityAnimal
{
    private final InventoryCrafting field_90016_e = new InventoryCrafting(new ContainerSheepBreed(this), 2, 1);

    /**
     * Holds the RGB table of the sheep colors - in OpenGL glColor3f values - used to render the sheep colored fleece.
     */
    public static final float[][] fleeceColorTable = new float[][] {{1.0F, 1.0F, 1.0F}, {0.85F, 0.5F, 0.2F}, {0.7F, 0.3F, 0.85F}, {0.4F, 0.6F, 0.85F}, {0.9F, 0.9F, 0.2F}, {0.5F, 0.8F, 0.1F}, {0.95F, 0.5F, 0.65F}, {0.3F, 0.3F, 0.3F}, {0.6F, 0.6F, 0.6F}, {0.3F, 0.5F, 0.6F}, {0.5F, 0.25F, 0.7F}, {0.2F, 0.3F, 0.7F}, {0.4F, 0.3F, 0.2F}, {0.4F, 0.5F, 0.2F}, {0.6F, 0.2F, 0.2F}, {0.1F, 0.1F, 0.1F}};

    /**
     * Used to control movement as well as wool regrowth. Set to 40 on handleHealthUpdate and counts down with each
     * tick.
     */
    private int sheepTimer;

    /** The eat grass AI task for this mob. */
    private PathfinderGoalEatTile aiEatGrass = new PathfinderGoalEatTile(this);

    public EntitySheep(World par1World)
    {
        super(par1World);
        this.setSize(0.9F, 1.3F);
        this.getNavigation().a(true);
        this.goalSelector.a(0, new PathfinderGoalFloat(this));
        this.goalSelector.a(1, new PathfinderGoalPanic(this, 1.25D));
        this.goalSelector.a(2, new PathfinderGoalBreed(this, 1.0D));
        this.goalSelector.a(3, new PathfinderGoalTempt(this, 1.1D, Item.WHEAT.id, false));
        this.goalSelector.a(4, new PathfinderGoalFollowParent(this, 1.1D));
        this.goalSelector.a(5, this.aiEatGrass);
        this.goalSelector.a(6, new PathfinderGoalRandomStroll(this, 1.0D));
        this.goalSelector.a(7, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 6.0F));
        this.goalSelector.a(8, new PathfinderGoalRandomLookaround(this));
        this.field_90016_e.setItem(0, new ItemStack(Item.INK_SACK, 1, 0));
        this.field_90016_e.setItem(1, new ItemStack(Item.INK_SACK, 1, 0));
        this.field_90016_e.resultInventory = new InventoryCraftResult();
    }

    /**
     * Returns true if the newer Entity AI code should be run
     */
    protected boolean isAIEnabled()
    {
        return true;
    }

    protected void updateAITasks()
    {
        this.sheepTimer = this.aiEatGrass.f();
        super.updateAITasks();
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
        if (this.world.isStatic)
        {
            this.sheepTimer = Math.max(0, this.sheepTimer - 1);
        }

        super.onLivingUpdate();
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.a).setValue(8.0D);
        this.getAttributeInstance(GenericAttributes.d).setValue(0.23000000417232513D);
    }

    protected void entityInit()
    {
        super.entityInit();
        this.datawatcher.addObject(16, new Byte((byte)0));
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        ArrayList loot = new ArrayList();

        if (!this.isSheared())
        {
            loot.add(new org.bukkit.inventory.ItemStack(org.bukkit.Material.WOOL, 1, (short)0, Byte.valueOf((byte)this.getColor())));
        }

        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    protected int getLootId()
    {
        return Block.WOOL.id;
    }

    public boolean a(EntityHuman entityhuman)
    {
        ItemStack itemstack = entityhuman.inventory.getItemInHand();

        if (itemstack != null && itemstack.id == Item.SHEARS.id && !this.isSheared() && !this.isBaby())
        {
            if (!this.world.isStatic)
            {
                PlayerShearEntityEvent event = new PlayerShearEntityEvent((Player)entityhuman.getBukkitEntity(), this.getBukkitEntity());
                this.world.getServer().getPluginManager().callEvent(event);

                if (event.isCancelled())
                {
                    return false;
                }

                this.setSheared(true);
                int i = 1 + this.random.nextInt(3);

                for (int j = 0; j < i; ++j)
                {
                    EntityItem entityitem = this.entityDropItem(new ItemStack(Block.WOOL.id, 1, this.getColor()), 1.0F);
                    entityitem.motY += (double)(this.random.nextFloat() * 0.05F);
                    entityitem.motX += (double)((this.random.nextFloat() - this.random.nextFloat()) * 0.1F);
                    entityitem.motZ += (double)((this.random.nextFloat() - this.random.nextFloat()) * 0.1F);
                }
            }

            itemstack.damage(1, entityhuman);
            this.makeSound("mob.sheep.shear", 1.0F, 1.0F);
        }

        return super.a(entityhuman);
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setBoolean("Sheared", this.isSheared());
        par1NBTTagCompound.setByte("Color", (byte)this.getColor());
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);
        this.setSheared(par1NBTTagCompound.getBoolean("Sheared"));
        this.setColor(par1NBTTagCompound.getByte("Color"));
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return "mob.sheep.say";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.sheep.say";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.sheep.say";
    }

    /**
     * Plays step sound at given x, y, z for the entity
     */
    protected void playStepSound(int par1, int par2, int par3, int par4)
    {
        this.makeSound("mob.sheep.step", 0.15F, 1.0F);
    }

    public int getColor()
    {
        return this.datawatcher.getByte(16) & 15;
    }

    public void setColor(int i)
    {
        byte b0 = this.datawatcher.getByte(16);
        this.datawatcher.watch(16, Byte.valueOf((byte)(b0 & 240 | i & 15)));
    }

    public boolean isSheared()
    {
        return (this.datawatcher.getByte(16) & 16) != 0;
    }

    public void setSheared(boolean flag)
    {
        byte b0 = this.datawatcher.getByte(16);

        if (flag)
        {
            this.datawatcher.watch(16, Byte.valueOf((byte)(b0 | 16)));
        }
        else
        {
            this.datawatcher.watch(16, Byte.valueOf((byte)(b0 & -17)));
        }
    }

    /**
     * This method is called when a sheep spawns in the world to select the color of sheep fleece.
     */
    public static int getRandomFleeceColor(Random par0Random)
    {
        int var1 = par0Random.nextInt(100);
        return var1 < 5 ? 15 : (var1 < 10 ? 7 : (var1 < 15 ? 8 : (var1 < 18 ? 12 : (par0Random.nextInt(500) == 0 ? 6 : 0))));
    }

    public EntitySheep func_90015_b(EntityAgeable par1EntityAgeable)
    {
        EntitySheep var2 = (EntitySheep)par1EntityAgeable;
        EntitySheep var3 = new EntitySheep(this.world);
        int var4 = this.func_90014_a(this, var2);
        var3.setColor(15 - var4);
        return var3;
    }

    /**
     * This function applies the benefits of growing back wool and faster growing up to the acting entity. (This
     * function is used in the AIEatGrass)
     */
    public void eatGrassBonus()
    {
        SheepRegrowWoolEvent var1 = new SheepRegrowWoolEvent((Sheep)this.getBukkitEntity());
        this.world.getServer().getPluginManager().callEvent(var1);

        if (!var1.isCancelled())
        {
            this.setSheared(false);
        }

        if (this.isBaby())
        {
            this.addGrowth(60);
        }
    }

    public GroupDataEntity a(GroupDataEntity groupdataentity)
    {
        groupdataentity = super.a(groupdataentity);
        this.setColor(getRandomFleeceColor(this.world.random));
        return groupdataentity;
    }

    private int func_90014_a(EntityAnimal par1EntityAnimal, EntityAnimal par2EntityAnimal)
    {
        int var3 = this.func_90013_b(par1EntityAnimal);
        int var4 = this.func_90013_b(par2EntityAnimal);
        this.field_90016_e.getItem(0).setData(var3);
        this.field_90016_e.getItem(1).setData(var4);
        ItemStack var5 = CraftingManager.getInstance().craft(this.field_90016_e, ((EntitySheep)par1EntityAnimal).world);
        int var6;

        if (var5 != null && var5.getItem().id == Item.INK_SACK.id)
        {
            var6 = var5.getData();
        }
        else
        {
            var6 = this.world.random.nextBoolean() ? var3 : var4;
        }

        return var6;
    }

    private int func_90013_b(EntityAnimal par1EntityAnimal)
    {
        return 15 - ((EntitySheep)par1EntityAnimal).getColor();
    }

    public EntityAgeable createChild(EntityAgeable entityageable)
    {
        return this.func_90015_b(entityageable);
    }
}
