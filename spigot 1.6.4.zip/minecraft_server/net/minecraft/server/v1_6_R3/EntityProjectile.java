package net.minecraft.server.v1_6_R3;

import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public abstract class EntityProjectile extends Entity implements IProjectile
{
    private int blockX = -1;
    private int blockY = -1;
    private int blockZ = -1;
    private int inBlockId;
    protected boolean inGround;
    public int shake;
    public EntityLiving shooter;
    public String shooterName;
    private int entityUniqueID;
    private int j;

    public EntityProjectile(World world)
    {
        super(world);
        this.setSize(0.25F, 0.25F);
    }

    protected void entityInit() {}

    public EntityProjectile(World world, EntityLiving entityliving)
    {
        super(world);
        this.shooter = entityliving;
        this.setSize(0.25F, 0.25F);
        this.setPositionRotation(entityliving.locX, entityliving.locY + (double)entityliving.getHeadHeight(), entityliving.locZ, entityliving.yaw, entityliving.pitch);
        this.locX -= (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.locY -= 0.10000000149011612D;
        this.locZ -= (double)(MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.height = 0.0F;
        float f = 0.4F;
        this.motX = (double)(-MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * f);
        this.motZ = (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * f);
        this.motY = (double)(-MathHelper.sin((this.pitch + this.d()) / 180.0F * (float)Math.PI) * f);
        this.shoot(this.motX, this.motY, this.motZ, this.c(), 1.0F);
    }

    public EntityProjectile(World world, double d0, double d1, double d2)
    {
        super(world);
        this.entityUniqueID = 0;
        this.setSize(0.25F, 0.25F);
        this.setPosition(d0, d1, d2);
        this.height = 0.0F;
    }

    protected float c()
    {
        return 1.5F;
    }

    protected float d()
    {
        return 0.0F;
    }

    public void shoot(double d0, double d1, double d2, float f, float f1)
    {
        float f2 = MathHelper.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= (double)f2;
        d1 /= (double)f2;
        d2 /= (double)f2;
        d0 += this.random.nextGaussian() * 0.007499999832361937D * (double)f1;
        d1 += this.random.nextGaussian() * 0.007499999832361937D * (double)f1;
        d2 += this.random.nextGaussian() * 0.007499999832361937D * (double)f1;
        d0 *= (double)f;
        d1 *= (double)f;
        d2 *= (double)f;
        this.motX = d0;
        this.motY = d1;
        this.motZ = d2;
        float f3 = MathHelper.sqrt(d0 * d0 + d2 * d2);
        this.lastYaw = this.yaw = (float)(Math.atan2(d0, d2) * 180.0D / Math.PI);
        this.lastPitch = this.pitch = (float)(Math.atan2(d1, (double)f3) * 180.0D / Math.PI);
        this.entityUniqueID = 0;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        this.lastTickPosX = this.locX;
        this.lastTickPosY = this.locY;
        this.lastTickPosZ = this.locZ;
        super.onUpdate();

        if (this.shake > 0)
        {
            --this.shake;
        }

        if (this.inGround)
        {
            int vec3d = this.world.getTypeId(this.blockX, this.blockY, this.blockZ);

            if (vec3d == this.inBlockId)
            {
                ++this.entityUniqueID;

                if (this.entityUniqueID == 1200)
                {
                    this.die();
                }

                return;
            }

            this.inGround = false;
            this.motX *= (double)(this.random.nextFloat() * 0.2F);
            this.motY *= (double)(this.random.nextFloat() * 0.2F);
            this.motZ *= (double)(this.random.nextFloat() * 0.2F);
            this.entityUniqueID = 0;
            this.j = 0;
        }
        else
        {
            ++this.j;
        }

        Vec3D var18 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
        Vec3D vec3d1 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
        MovingObjectPosition movingobjectposition = this.world.a(var18, vec3d1);
        var18 = this.world.getVec3DPool().create(this.locX, this.locY, this.locZ);
        vec3d1 = this.world.getVec3DPool().create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);

        if (movingobjectposition != null)
        {
            vec3d1 = this.world.getVec3DPool().create(movingobjectposition.pos.c, movingobjectposition.pos.d, movingobjectposition.pos.e);
        }

        if (!this.world.isStatic)
        {
            Entity f1 = null;
            List f2 = this.world.getEntities(this, this.boundingBox.addCoord(this.motX, this.motY, this.motZ).grow(1.0D, 1.0D, 1.0D));
            double d0 = 0.0D;
            EntityLiving f4 = this.getShooter();

            for (int j = 0; j < f2.size(); ++j)
            {
                Entity entity1 = (Entity)f2.get(j);

                if (entity1.canBeCollidedWith() && (entity1 != f4 || this.j >= 5))
                {
                    float f = 0.3F;
                    AxisAlignedBB axisalignedbb = entity1.boundingBox.grow((double)f, (double)f, (double)f);
                    MovingObjectPosition movingobjectposition1 = axisalignedbb.a(var18, vec3d1);

                    if (movingobjectposition1 != null)
                    {
                        double d1 = var18.distanceSquared(movingobjectposition1.pos);

                        if (d1 < d0 || d0 == 0.0D)
                        {
                            f1 = entity1;
                            d0 = d1;
                        }
                    }
                }
            }

            if (f1 != null)
            {
                movingobjectposition = new MovingObjectPosition(f1);
            }
        }

        if (movingobjectposition != null)
        {
            if (movingobjectposition.type == EnumMovingObjectType.TILE && this.world.getTypeId(movingobjectposition.blockX, movingobjectposition.blockY, movingobjectposition.blockZ) == Block.PORTAL.id)
            {
                this.setInPortal();
            }
            else
            {
                this.onImpact(movingobjectposition);

                if (this.dead)
                {
                    CraftEventFactory.callProjectileHitEvent(this);
                }
            }
        }

        this.locX += this.motX;
        this.locY += this.motY;
        this.locZ += this.motZ;
        float var19 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
        this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);

        for (this.pitch = (float)(Math.atan2(this.motY, (double)var19) * 180.0D / Math.PI); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
        {
            ;
        }

        while (this.pitch - this.lastPitch >= 180.0F)
        {
            this.lastPitch += 360.0F;
        }

        while (this.yaw - this.lastYaw < -180.0F)
        {
            this.lastYaw -= 360.0F;
        }

        while (this.yaw - this.lastYaw >= 180.0F)
        {
            this.lastYaw += 360.0F;
        }

        this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
        this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
        float var20 = 0.99F;
        float f3 = this.e();

        if (this.isInWater())
        {
            for (int k = 0; k < 4; ++k)
            {
                float var21 = 0.25F;
                this.world.addParticle("bubble", this.locX - this.motX * (double)var21, this.locY - this.motY * (double)var21, this.locZ - this.motZ * (double)var21, this.motX, this.motY, this.motZ);
            }

            var20 = 0.8F;
        }

        this.motX *= (double)var20;
        this.motY *= (double)var20;
        this.motZ *= (double)var20;
        this.motY -= (double)f3;
        this.setPosition(this.locX, this.locY, this.locZ);
    }

    protected float e()
    {
        return 0.03F;
    }

    protected abstract void onImpact(MovingObjectPosition var1);

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("xTile", (short)this.blockX);
        nbttagcompound.setShort("yTile", (short)this.blockY);
        nbttagcompound.setShort("zTile", (short)this.blockZ);
        nbttagcompound.setByte("inTile", (byte)this.inBlockId);
        nbttagcompound.setByte("shake", (byte)this.shake);
        nbttagcompound.setByte("inGround", (byte)(this.inGround ? 1 : 0));

        if ((this.shooterName == null || this.shooterName.length() == 0) && this.shooter != null && this.shooter instanceof EntityHuman)
        {
            this.shooterName = this.shooter.getLocalizedName();
        }

        nbttagcompound.setString("ownerName", this.shooterName == null ? "" : this.shooterName);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound nbttagcompound)
    {
        this.blockX = nbttagcompound.getShort("xTile");
        this.blockY = nbttagcompound.getShort("yTile");
        this.blockZ = nbttagcompound.getShort("zTile");
        this.inBlockId = nbttagcompound.getByte("inTile") & 255;
        this.shake = nbttagcompound.getByte("shake") & 255;
        this.inGround = nbttagcompound.getByte("inGround") == 1;
        this.shooterName = nbttagcompound.getString("ownerName");

        if (this.shooterName != null && this.shooterName.length() == 0)
        {
            this.shooterName = null;
        }
    }

    public EntityLiving getShooter()
    {
        if (this.shooter == null && this.shooterName != null && this.shooterName.length() > 0)
        {
            this.shooter = this.world.a(this.shooterName);
        }

        return this.shooter;
    }
}
