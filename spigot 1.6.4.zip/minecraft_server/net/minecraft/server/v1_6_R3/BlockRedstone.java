package net.minecraft.server.v1_6_R3;

public class BlockRedstone extends BlockOreBlock
{
    public BlockRedstone(int var1)
    {
        super(var1);
        this.a(CreativeModeTab.d);
    }

    public boolean isPowerSource()
    {
        return true;
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess var1, int var2, int var3, int var4, int var5)
    {
        return 15;
    }
}
