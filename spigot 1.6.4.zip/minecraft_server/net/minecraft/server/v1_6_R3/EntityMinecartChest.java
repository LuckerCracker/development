package net.minecraft.server.v1_6_R3;

public class EntityMinecartChest extends EntityMinecartContainer {
	public EntityMinecartChest(World par1World) {
		super(par1World);
	}

	public EntityMinecartChest(World par1World, double par2, double par4, double par6) {
		super(par1World, par2, par4, par6);
	}

	public void killMinecart(DamageSource par1DamageSource) {
		super.killMinecart(par1DamageSource);
		this.dropItemWithOffset(Block.CHEST.id, 1, 0.0F);
	}

	public int getSize() {
		return 27;
	}

	public int getType() {
		return 1;
	}

	public Block getDefaultDisplayTile() {
		return Block.CHEST;
	}

	public int getDefaultDisplayTileOffset() {
		return 8;
	}

	@Override
	public boolean isInvNameLocalized() {
		return false;
	}
}
