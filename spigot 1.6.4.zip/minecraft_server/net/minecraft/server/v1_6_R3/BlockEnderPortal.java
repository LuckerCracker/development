package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.event.entity.EntityPortalEnterEvent;

public class BlockEnderPortal extends BlockContainer
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    public static boolean displayOnCreativeTab;

    protected BlockEnderPortal(int i, Material material)
    {
        super(i, material);
        this.setLightValue(1.0F);
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World world)
    {
        return new TileEntityEnderPortal();
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        float f = 0.0625F;
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F);
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World world, int i, int j, int k, AxisAlignedBB axisalignedbb, List list, Entity entity) {}

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random random)
    {
        return 0;
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
    {
        if (entity.vehicle == null && entity.passenger == null && !world.isStatic)
        {
            EntityPortalEnterEvent event = new EntityPortalEnterEvent(entity.getBukkitEntity(), new Location(world.getWorld(), (double)i, (double)j, (double)k));
            world.getServer().getPluginManager().callEvent(event);
            entity.travelToDimension(1);
        }
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return -1;
    }

    public void onPlace(World world, int i, int j, int k)
    {
        if (!displayOnCreativeTab && world.worldProvider.dimension != 0)
        {
            world.setAir(i, j, k);
        }
    }
}
