package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class BlockStairs extends Block
{
    private static final int[][] field_72159_a = new int[][] {{2, 6}, {3, 7}, {2, 3}, {6, 7}, {0, 4}, {1, 5}, {0, 1}, {4, 5}};

    /** The block that is used as model for the stair. */
    private final Block modelBlock;
    private final int modelBlockMetadata;
    private boolean field_72156_cr;
    private int field_72160_cs;

    protected BlockStairs(int par1, Block par2Block, int par3)
    {
        super(par1, par2Block.material);
        this.modelBlock = par2Block;
        this.modelBlockMetadata = par3;
        this.setHardness(par2Block.strength);
        this.setResistance(par2Block.durability / 3.0F);
        this.setStepSound(par2Block.stepSound);
        this.setLightOpacity(255);
        this.a(CreativeModeTab.b);
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        if (this.field_72156_cr)
        {
            this.setBlockBounds(0.5F * (float)(this.field_72160_cs % 2), 0.5F * (float)(this.field_72160_cs / 2 % 2), 0.5F * (float)(this.field_72160_cs / 4 % 2), 0.5F + 0.5F * (float)(this.field_72160_cs % 2), 0.5F + 0.5F * (float)(this.field_72160_cs / 2 % 2), 0.5F + 0.5F * (float)(this.field_72160_cs / 4 % 2));
        }
        else
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 10;
    }

    public void func_82541_d(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        int var5 = par1IBlockAccess.getData(par2, par3, par4);

        if ((var5 & 4) != 0)
        {
            this.setBlockBounds(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        else
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
        }
    }

    /**
     * Checks if supplied ID is one of a BlockStairs
     */
    public static boolean isBlockStairsID(int par0)
    {
        return par0 > 0 && Block.byId[par0] instanceof BlockStairs;
    }

    /**
     * returns true if the given block is a stairs block and is in the given direction of par5.  Parameters are
     * IBlockAccess, x, y, z, direction
     */
    private boolean isBlockStairsDirection(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        int var6 = par1IBlockAccess.getTypeId(par2, par3, par4);
        return isBlockStairsID(var6) && par1IBlockAccess.getData(par2, par3, par4) == par5;
    }

    public boolean func_82542_g(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        int var5 = par1IBlockAccess.getData(par2, par3, par4);
        int var6 = var5 & 3;
        float var7 = 0.5F;
        float var8 = 1.0F;

        if ((var5 & 4) != 0)
        {
            var7 = 0.0F;
            var8 = 0.5F;
        }

        float var9 = 0.0F;
        float var10 = 1.0F;
        float var11 = 0.0F;
        float var12 = 0.5F;
        boolean var13 = true;
        int var14;
        int var15;
        int var16;

        if (var6 == 0)
        {
            var9 = 0.5F;
            var12 = 1.0F;
            var14 = par1IBlockAccess.getTypeId(par2 + 1, par3, par4);
            var15 = par1IBlockAccess.getData(par2 + 1, par3, par4);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var16 = var15 & 3;

                if (var16 == 3 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 + 1, var5))
                {
                    var12 = 0.5F;
                    var13 = false;
                }
                else if (var16 == 2 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 - 1, var5))
                {
                    var11 = 0.5F;
                    var13 = false;
                }
            }
        }
        else if (var6 == 1)
        {
            var10 = 0.5F;
            var12 = 1.0F;
            var14 = par1IBlockAccess.getTypeId(par2 - 1, par3, par4);
            var15 = par1IBlockAccess.getData(par2 - 1, par3, par4);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var16 = var15 & 3;

                if (var16 == 3 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 + 1, var5))
                {
                    var12 = 0.5F;
                    var13 = false;
                }
                else if (var16 == 2 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 - 1, var5))
                {
                    var11 = 0.5F;
                    var13 = false;
                }
            }
        }
        else if (var6 == 2)
        {
            var11 = 0.5F;
            var12 = 1.0F;
            var14 = par1IBlockAccess.getTypeId(par2, par3, par4 + 1);
            var15 = par1IBlockAccess.getData(par2, par3, par4 + 1);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var16 = var15 & 3;

                if (var16 == 1 && !this.isBlockStairsDirection(par1IBlockAccess, par2 + 1, par3, par4, var5))
                {
                    var10 = 0.5F;
                    var13 = false;
                }
                else if (var16 == 0 && !this.isBlockStairsDirection(par1IBlockAccess, par2 - 1, par3, par4, var5))
                {
                    var9 = 0.5F;
                    var13 = false;
                }
            }
        }
        else if (var6 == 3)
        {
            var14 = par1IBlockAccess.getTypeId(par2, par3, par4 - 1);
            var15 = par1IBlockAccess.getData(par2, par3, par4 - 1);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var16 = var15 & 3;

                if (var16 == 1 && !this.isBlockStairsDirection(par1IBlockAccess, par2 + 1, par3, par4, var5))
                {
                    var10 = 0.5F;
                    var13 = false;
                }
                else if (var16 == 0 && !this.isBlockStairsDirection(par1IBlockAccess, par2 - 1, par3, par4, var5))
                {
                    var9 = 0.5F;
                    var13 = false;
                }
            }
        }

        this.setBlockBounds(var9, var7, var11, var10, var8, var12);
        return var13;
    }

    public boolean func_82544_h(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        int var5 = par1IBlockAccess.getData(par2, par3, par4);
        int var6 = var5 & 3;
        float var7 = 0.5F;
        float var8 = 1.0F;

        if ((var5 & 4) != 0)
        {
            var7 = 0.0F;
            var8 = 0.5F;
        }

        float var9 = 0.0F;
        float var10 = 0.5F;
        float var11 = 0.5F;
        float var12 = 1.0F;
        boolean var13 = false;
        int var14;
        int var15;
        int var16;

        if (var6 == 0)
        {
            var14 = par1IBlockAccess.getTypeId(par2 - 1, par3, par4);
            var15 = par1IBlockAccess.getData(par2 - 1, par3, par4);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var16 = var15 & 3;

                if (var16 == 3 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 - 1, var5))
                {
                    var11 = 0.0F;
                    var12 = 0.5F;
                    var13 = true;
                }
                else if (var16 == 2 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 + 1, var5))
                {
                    var11 = 0.5F;
                    var12 = 1.0F;
                    var13 = true;
                }
            }
        }
        else if (var6 == 1)
        {
            var14 = par1IBlockAccess.getTypeId(par2 + 1, par3, par4);
            var15 = par1IBlockAccess.getData(par2 + 1, par3, par4);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var9 = 0.5F;
                var10 = 1.0F;
                var16 = var15 & 3;

                if (var16 == 3 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 - 1, var5))
                {
                    var11 = 0.0F;
                    var12 = 0.5F;
                    var13 = true;
                }
                else if (var16 == 2 && !this.isBlockStairsDirection(par1IBlockAccess, par2, par3, par4 + 1, var5))
                {
                    var11 = 0.5F;
                    var12 = 1.0F;
                    var13 = true;
                }
            }
        }
        else if (var6 == 2)
        {
            var14 = par1IBlockAccess.getTypeId(par2, par3, par4 - 1);
            var15 = par1IBlockAccess.getData(par2, par3, par4 - 1);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var11 = 0.0F;
                var12 = 0.5F;
                var16 = var15 & 3;

                if (var16 == 1 && !this.isBlockStairsDirection(par1IBlockAccess, par2 - 1, par3, par4, var5))
                {
                    var13 = true;
                }
                else if (var16 == 0 && !this.isBlockStairsDirection(par1IBlockAccess, par2 + 1, par3, par4, var5))
                {
                    var9 = 0.5F;
                    var10 = 1.0F;
                    var13 = true;
                }
            }
        }
        else if (var6 == 3)
        {
            var14 = par1IBlockAccess.getTypeId(par2, par3, par4 + 1);
            var15 = par1IBlockAccess.getData(par2, par3, par4 + 1);

            if (isBlockStairsID(var14) && (var5 & 4) == (var15 & 4))
            {
                var16 = var15 & 3;

                if (var16 == 1 && !this.isBlockStairsDirection(par1IBlockAccess, par2 - 1, par3, par4, var5))
                {
                    var13 = true;
                }
                else if (var16 == 0 && !this.isBlockStairsDirection(par1IBlockAccess, par2 + 1, par3, par4, var5))
                {
                    var9 = 0.5F;
                    var10 = 1.0F;
                    var13 = true;
                }
            }
        }

        if (var13)
        {
            this.setBlockBounds(var9, var7, var11, var10, var8, var12);
        }

        return var13;
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World par1World, int par2, int par3, int par4, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity)
    {
        this.func_82541_d(par1World, par2, par3, par4);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        boolean var8 = this.func_82542_g(par1World, par2, par3, par4);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);

        if (var8 && this.func_82544_h(par1World, par2, par3, par4))
        {
            super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        }

        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    public void attack(World var1, int var2, int var3, int var4, EntityHuman var5)
    {
        this.modelBlock.attack(var1, var2, var3, var4, var5);
    }

    public void postBreak(World var1, int var2, int var3, int var4, int var5)
    {
        this.modelBlock.postBreak(var1, var2, var3, var4, var5);
    }

    /**
     * Returns how much this block can resist explosions from the passed in entity.
     */
    public float getExplosionResistance(Entity par1Entity)
    {
        return this.modelBlock.getExplosionResistance(par1Entity);
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World par1World)
    {
        return this.modelBlock.tickRate(par1World);
    }

    public void a(World var1, int var2, int var3, int var4, Entity var5, Vec3D var6)
    {
        this.modelBlock.a(var1, var2, var3, var4, var5, var6);
    }

    /**
     * Returns if this block is collidable (only used by Fire). Args: x, y, z
     */
    public boolean isCollidable()
    {
        return this.modelBlock.isCollidable();
    }

    /**
     * Returns whether this block is collideable based on the arguments passed in Args: blockMetaData, unknownFlag
     */
    public boolean canCollideCheck(int par1, boolean par2)
    {
        return this.modelBlock.canCollideCheck(par1, par2);
    }

    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        return this.modelBlock.canPlace(var1, var2, var3, var4);
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        this.doPhysics(var1, var2, var3, var4, 0);
        this.modelBlock.onPlace(var1, var2, var3, var4);
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        this.modelBlock.remove(var1, var2, var3, var4, var5, var6);
    }

    /**
     * Called whenever an entity is walking on top of this block. Args: world, x, y, z, entity
     */
    public void onEntityWalking(World par1World, int par2, int par3, int par4, Entity par5Entity)
    {
        this.modelBlock.onEntityWalking(par1World, par2, par3, par4, par5Entity);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        this.modelBlock.updateTick(par1World, par2, par3, par4, par5Random);
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        return this.modelBlock.interact(var1, var2, var3, var4, var5, 0, 0.0F, 0.0F, 0.0F);
    }

    public void wasExploded(World var1, int var2, int var3, int var4, Explosion var5)
    {
        this.modelBlock.wasExploded(var1, var2, var3, var4, var5);
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        int var7 = MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3;
        int var8 = var1.getData(var2, var3, var4) & 4;

        if (var7 == 0)
        {
            var1.setData(var2, var3, var4, 2 | var8, 2);
        }

        if (var7 == 1)
        {
            var1.setData(var2, var3, var4, 1 | var8, 2);
        }

        if (var7 == 2)
        {
            var1.setData(var2, var3, var4, 3 | var8, 2);
        }

        if (var7 == 3)
        {
            var1.setData(var2, var3, var4, 0 | var8, 2);
        }
    }

    public int getPlacedData(World var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, int var9)
    {
        return var5 != 0 && (var5 == 1 || (double)var7 <= 0.5D) ? var9 : var9 | 4;
    }

    public MovingObjectPosition a(World var1, int var2, int var3, int var4, Vec3D var5, Vec3D var6)
    {
        MovingObjectPosition[] var7 = new MovingObjectPosition[8];
        int var8 = var1.getData(var2, var3, var4);
        int var9 = var8 & 3;
        boolean var10 = (var8 & 4) == 4;
        int[] var11 = field_72159_a[var9 + (var10 ? 4 : 0)];
        this.field_72156_cr = true;
        int var14;
        int var15;
        int var16;

        for (int var12 = 0; var12 < 8; ++var12)
        {
            this.field_72160_cs = var12;
            int[] var13 = var11;
            var14 = var11.length;

            for (var15 = 0; var15 < var14; ++var15)
            {
                var16 = var13[var15];

                if (var16 == var12)
                {
                    ;
                }
            }

            var7[var12] = super.a(var1, var2, var3, var4, var5, var6);
        }

        int[] var23 = var11;
        int var25 = var11.length;

        for (var14 = 0; var14 < var25; ++var14)
        {
            var15 = var23[var14];
            var7[var15] = null;
        }

        MovingObjectPosition var24 = null;
        double var17 = 0.0D;
        MovingObjectPosition[] var26 = var7;
        var16 = var7.length;

        for (int var19 = 0; var19 < var16; ++var19)
        {
            MovingObjectPosition var20 = var26[var19];

            if (var20 != null)
            {
                double var21 = var20.pos.distanceSquared(var6);

                if (var21 > var17)
                {
                    var24 = var20;
                    var17 = var21;
                }
            }
        }

        return var24;
    }
}
