package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockSpreadEvent;

public class BlockMycel extends Block
{
    protected BlockMycel(int i)
    {
        super(i, Material.GRASS);
        this.setTickRandomly(true);
        this.a(CreativeModeTab.b);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        if (!world.isStatic)
        {
            if (world.getLightLevel(i, j + 1, k) < 4 && Block.lightBlock[world.getTypeId(i, j + 1, k)] > 2)
            {
                CraftWorld var15 = world.getWorld();
                BlockState var16 = var15.getBlockAt(i, j, k).getState();
                var16.setTypeId(Block.DIRT.id);
                BlockFadeEvent var17 = new BlockFadeEvent(var16.getBlock(), var16);
                world.getServer().getPluginManager().callEvent(var17);

                if (!var17.isCancelled())
                {
                    var16.update(true);
                }
            }
            else if (world.getLightLevel(i, j + 1, k) >= 9)
            {
                int numGrowth = Math.min(4, Math.max(20, (int)(400.0F / world.growthOdds)));

                for (int l = 0; l < numGrowth; ++l)
                {
                    int i1 = i + random.nextInt(3) - 1;
                    int j1 = j + random.nextInt(5) - 3;
                    int k1 = k + random.nextInt(3) - 1;
                    int l1 = world.getTypeId(i1, j1 + 1, k1);

                    if (world.getTypeId(i1, j1, k1) == Block.DIRT.id && world.getLightLevel(i1, j1 + 1, k1) >= 4 && Block.lightBlock[l1] <= 2)
                    {
                        CraftWorld bworld = world.getWorld();
                        BlockState blockState = bworld.getBlockAt(i1, j1, k1).getState();
                        blockState.setTypeId(this.id);
                        BlockSpreadEvent event = new BlockSpreadEvent(blockState.getBlock(), bworld.getBlockAt(i, j, k), blockState);
                        world.getServer().getPluginManager().callEvent(event);

                        if (!event.isCancelled())
                        {
                            blockState.update(true);
                        }
                    }
                }
            }
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Block.DIRT.getDropType(0, random, j);
    }
}
