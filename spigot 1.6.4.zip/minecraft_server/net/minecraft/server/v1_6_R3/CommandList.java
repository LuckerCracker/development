package net.minecraft.server.v1_6_R3;

public class CommandList extends CommandAbstract
{
    public String getCommandName()
    {
        return "list";
    }

    public int a()
    {
        return 0;
    }

    public String c(ICommandListener var1)
    {
        return "commands.players.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        var1.sendMessage(ChatMessage.b("commands.players.list", new Object[] {Integer.valueOf(MinecraftServer.getServer().A()), Integer.valueOf(MinecraftServer.getServer().B())}));
        var1.sendMessage(ChatMessage.d(MinecraftServer.getServer().getPlayerList().c()));
    }
}
