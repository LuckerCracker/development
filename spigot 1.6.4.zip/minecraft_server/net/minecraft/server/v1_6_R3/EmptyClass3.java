package net.minecraft.server.v1_6_R3;

class EmptyClass3
{
}
