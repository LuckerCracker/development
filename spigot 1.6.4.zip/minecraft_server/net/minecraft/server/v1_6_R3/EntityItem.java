package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerPickupItemEvent;

public class EntityItem extends Entity
{
    public int age;
    public int pickupDelay;

    /** The health of this EntityItem. (For example, damage for tools) */
    private int health;

    /** The EntityItem's random initial float height. */
    public float hoverStart;
    private int lastTick;

    public EntityItem(World par1World, double par2, double par4, double par6)
    {
        super(par1World);
        this.lastTick = MinecraftServer.currentTick;
        this.health = 5;
        this.hoverStart = (float)(Math.random() * Math.PI * 2.0D);
        this.setSize(0.25F, 0.25F);
        this.height = this.length / 2.0F;
        this.setPosition(par2, par4, par6);
        this.yaw = (float)(Math.random() * 360.0D);
        this.motX = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D));
        this.motY = 0.20000000298023224D;
        this.motZ = (double)((float)(Math.random() * 0.20000000298023224D - 0.10000000149011612D));
    }

    public EntityItem(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack)
    {
        this(par1World, par2, par4, par6);

        if (par8ItemStack != null && par8ItemStack.getItem() != null)
        {
            this.setItemStack(par8ItemStack);
        }
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    public EntityItem(World par1World)
    {
        super(par1World);
        this.lastTick = MinecraftServer.currentTick;
        this.health = 5;
        this.hoverStart = (float)(Math.random() * Math.PI * 2.0D);
        this.setSize(0.25F, 0.25F);
        this.height = this.length / 2.0F;
    }

    protected void entityInit()
    {
        this.getDataWatcher().addObjectByDataType(10, 5);
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();
        int var1 = MinecraftServer.currentTick - this.lastTick;
        this.pickupDelay -= var1;
        this.age += var1;
        this.lastTick = MinecraftServer.currentTick;
        this.lastX = this.locX;
        this.lastY = this.locY;
        this.lastZ = this.locZ;
        this.motY -= 0.03999999910593033D;
        this.noClip = this.pushOutOfBlocks(this.locX, (this.boundingBox.minY + this.boundingBox.maxY) / 2.0D, this.locZ);
        this.move(this.motX, this.motY, this.motZ);
        boolean var2 = (int)this.lastX != (int)this.locX || (int)this.lastY != (int)this.locY || (int)this.lastZ != (int)this.locZ;

        if (var2 || this.ticksLived % 25 == 0)
        {
            if (this.world.getMaterial(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ)) == Material.LAVA)
            {
                this.motY = 0.20000000298023224D;
                this.motX = (double)((this.random.nextFloat() - this.random.nextFloat()) * 0.2F);
                this.motZ = (double)((this.random.nextFloat() - this.random.nextFloat()) * 0.2F);
                this.makeSound("random.fizz", 0.4F, 2.0F + this.random.nextFloat() * 0.4F);
            }

            if (!this.world.isStatic)
            {
                this.searchForOtherItemsNearby();
            }
        }

        float var3 = 0.98F;

        if (this.onGround)
        {
            var3 = 0.58800006F;
            int var4 = this.world.getTypeId(MathHelper.floor(this.locX), MathHelper.floor(this.boundingBox.minY) - 1, MathHelper.floor(this.locZ));

            if (var4 > 0)
            {
                var3 = Block.byId[var4].frictionFactor * 0.98F;
            }
        }

        this.motX *= (double)var3;
        this.motY *= 0.9800000190734863D;
        this.motZ *= (double)var3;

        if (this.onGround)
        {
            this.motY *= -0.5D;
        }

        if (!this.world.isStatic && this.age >= this.world.spigotConfig.itemDespawnRate)
        {
            if (CraftEventFactory.callItemDespawnEvent(this).isCancelled())
            {
                this.age = 0;
                return;
            }

            this.die();
        }
    }

    /**
     * Looks for other itemstacks nearby and tries to stack them together
     */
    private void searchForOtherItemsNearby()
    {
        double var1 = this.world.spigotConfig.itemMerge;
        Iterator var3 = this.world.getEntitiesWithinAABB(EntityItem.class, this.boundingBox.grow(var1, var1, var1)).iterator();

        while (var3.hasNext())
        {
            EntityItem var4 = (EntityItem)var3.next();
            this.combineItems(var4);
        }
    }

    /**
     * Tries to merge this item with the item passed as the parameter. Returns true if successful. Either this item or
     * the other item will  be removed from the world.
     */
    public boolean combineItems(EntityItem par1EntityItem)
    {
        if (par1EntityItem == this)
        {
            return false;
        }
        else if (par1EntityItem.isAlive() && this.isAlive())
        {
            ItemStack var2 = this.getItemStack();
            ItemStack var3 = par1EntityItem.getItemStack();

            if (var3.getItem() != var2.getItem())
            {
                return false;
            }
            else if (var3.hasTag() ^ var2.hasTag())
            {
                return false;
            }
            else if (var3.hasTag() && !var3.getTag().equals(var2.getTag()))
            {
                return false;
            }
            else if (var3.getItem().getHasSubtypes() && var3.getData() != var2.getData())
            {
                return false;
            }
            else if (var3.count < var2.count)
            {
                return par1EntityItem.combineItems(this);
            }
            else if (var3.count + var2.count > var3.getMaxStackSize())
            {
                return false;
            }
            else
            {
                var2.count += var3.count;
                this.pickupDelay = Math.max(par1EntityItem.pickupDelay, this.pickupDelay);
                this.age = Math.min(par1EntityItem.age, this.age);
                this.setItemStack(var2);
                par1EntityItem.die();
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    /**
     * sets the age of the item so that it'll despawn one minute after it has been dropped (instead of five). Used when
     * items are dropped from players in creative mode
     */
    public void setAgeToCreativeDespawnTime()
    {
        this.age = 4800;
    }

    /**
     * Returns if this entity is in water and will end up adding the waters velocity to the entity
     */
    public boolean handleWaterMovement()
    {
        return this.world.handleMaterialAcceleration(this.boundingBox, Material.WATER, this);
    }

    protected void burn(int i)
    {
        this.attackEntityFrom(DamageSource.FIRE, (float)i);
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else if (this.getItemStack() != null && this.getItemStack().id == Item.NETHER_STAR.id && damagesource.isExplosion())
        {
            return false;
        }
        else
        {
            this.setBeenAttacked();
            this.health = (int)((float)this.health - f);

            if (this.health <= 0)
            {
                this.die();
            }

            return false;
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        par1NBTTagCompound.setShort("Health", (short)((byte)this.health));
        par1NBTTagCompound.setShort("Age", (short)this.age);

        if (this.getItemStack() != null)
        {
            par1NBTTagCompound.setCompound("Item", this.getItemStack().save(new NBTTagCompound()));
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        this.health = par1NBTTagCompound.getShort("Health") & 255;
        this.age = par1NBTTagCompound.getShort("Age");
        NBTTagCompound var2 = par1NBTTagCompound.getCompound("Item");

        if (var2 != null)
        {
            ItemStack var3 = ItemStack.createStack(var2);

            if (var3 != null)
            {
                this.setItemStack(var3);
            }
            else
            {
                this.die();
            }
        }
        else
        {
            this.die();
        }

        if (this.getItemStack() == null)
        {
            this.die();
        }
    }

    public void b_(EntityHuman entityhuman)
    {
        if (!this.world.isStatic)
        {
            ItemStack itemstack = this.getItemStack();
            int i = itemstack.count;
            int canHold = entityhuman.inventory.canHold(itemstack);
            int remaining = itemstack.count - canHold;

            if (this.pickupDelay <= 0 && canHold > 0)
            {
                itemstack.count = canHold;
                PlayerPickupItemEvent event = new PlayerPickupItemEvent((Player)entityhuman.getBukkitEntity(), (org.bukkit.entity.Item)this.getBukkitEntity(), remaining);
                this.world.getServer().getPluginManager().callEvent(event);
                itemstack.count = canHold + remaining;

                if (event.isCancelled())
                {
                    return;
                }

                this.pickupDelay = 0;
            }

            if (this.pickupDelay == 0 && entityhuman.inventory.pickup(itemstack))
            {
                if (itemstack.id == Block.LOG.id)
                {
                    entityhuman.triggerAchievement((Statistic)AchievementList.mineWood);
                }

                if (itemstack.id == Item.LEATHER.id)
                {
                    entityhuman.triggerAchievement((Statistic)AchievementList.killCow);
                }

                if (itemstack.id == Item.DIAMOND.id)
                {
                    entityhuman.triggerAchievement((Statistic)AchievementList.diamonds);
                }

                if (itemstack.id == Item.BLAZE_ROD.id)
                {
                    entityhuman.triggerAchievement((Statistic)AchievementList.blazeRod);
                }

                this.makeSound("random.pop", 0.2F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
                entityhuman.receive(this, i);

                if (itemstack.count <= 0)
                {
                    this.die();
                }
            }
        }
    }

    public String getLocalizedName()
    {
        return LocaleI18n.get("item." + this.getItemStack().getUnlocalizedName());
    }

    /**
     * If returns false, the item will not inflict any damage against entities.
     */
    public boolean canAttackWithItem()
    {
        return false;
    }

    /**
     * Teleports the entity to another dimension. Params: Dimension number to teleport to
     */
    public void travelToDimension(int par1)
    {
        super.travelToDimension(par1);

        if (!this.world.isStatic)
        {
            this.searchForOtherItemsNearby();
        }
    }

    public ItemStack getItemStack()
    {
        ItemStack itemstack = this.getDataWatcher().getItemStack(10);

        if (itemstack == null)
        {
            if (this.world != null)
            {
                this.world.getLogger().severe("Item entity " + this.id + " has no item?!");
            }

            return new ItemStack(Block.STONE);
        }
        else
        {
            return itemstack;
        }
    }

    public void setItemStack(ItemStack itemstack)
    {
        this.getDataWatcher().watch(10, itemstack);
        this.getDataWatcher().setObjectWatched(10);
    }
}
