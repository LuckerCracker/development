package net.minecraft.server.v1_6_R3;

public class BlockCarrots extends BlockCrops
{
    public BlockCarrots(int var1)
    {
        super(var1);
    }

    /**
     * Generate a seed ItemStack for this crop.
     */
    protected int getSeedItem()
    {
        return Item.CARROT.id;
    }

    /**
     * Generate a crop produce ItemStack for this crop.
     */
    protected int getCropItem()
    {
        return Item.CARROT.id;
    }
}
