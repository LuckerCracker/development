package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportPlayers implements Callable
{
    final World a;

    CrashReportPlayers(World var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return this.a.players.size() + " total; " + this.a.players.toString();
    }

    public Object call()
    {
        return this.a();
    }
}
