package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportEntityTrackerUpdateInterval implements Callable
{
    final int a;

    final EntityTracker b;

    CrashReportEntityTrackerUpdateInterval(EntityTracker var1, int var2)
    {
        this.b = var1;
        this.a = var2;
    }

    public String a()
    {
        String var1 = "Once per " + this.a + " ticks";

        if (this.a == Integer.MAX_VALUE)
        {
            var1 = "Maximum (" + var1 + ")";
        }

        return var1;
    }

    public Object call()
    {
        return this.a();
    }
}
