package net.minecraft.server.v1_6_R3;

public class CommandSaveOn extends CommandAbstract
{
    public String getCommandName()
    {
        return "save-on";
    }

    public int a()
    {
        return 4;
    }

    public String c(ICommandListener var1)
    {
        return "commands.save-on.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        MinecraftServer var3 = MinecraftServer.getServer();
        boolean var4 = false;

        for (int var5 = 0; var5 < var3.worldServer.length; ++var5)
        {
            if (var3.worldServer[var5] != null)
            {
                WorldServer var6 = var3.worldServer[var5];

                if (var6.savingDisabled)
                {
                    var6.savingDisabled = false;
                    var4 = true;
                }
            }
        }

        if (var4)
        {
            a(var1, "commands.save.enabled", new Object[0]);
        }
        else
        {
            throw new CommandException("commands.save-on.alreadyOn", new Object[0]);
        }
    }
}
