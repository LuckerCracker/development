package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockSand extends Block
{
    public static boolean instaFall;

    public BlockSand(int par1)
    {
        super(par1, Material.SAND);
        this.a(CreativeModeTab.b);
    }

    public BlockSand(int par1, Material par2Material)
    {
        super(par1, par2Material);
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        var1.scheduleBlockUpdate(var2, var3, var4, this.id, this.tickRate(var1));
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        var1.scheduleBlockUpdate(var2, var3, var4, this.id, this.tickRate(var1));
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (!par1World.isStatic)
        {
            this.tryToFall(par1World, par2, par3, par4);
        }
    }

    /**
     * If there is space to fall below will start this block falling
     */
    private void tryToFall(World par1World, int par2, int par3, int par4)
    {
        if (canFall(par1World, par2, par3 - 1, par4) && par3 >= 0)
        {
            byte var8 = 32;

            if (!instaFall && par1World.checkChunksExist(par2 - var8, par3 - var8, par4 - var8, par2 + var8, par3 + var8, par4 + var8))
            {
                if (!par1World.isStatic)
                {
                    EntityFallingBlock var9 = new EntityFallingBlock(par1World, (double)((float)par2 + 0.5F), (double)((float)par3 + 0.5F), (double)((float)par4 + 0.5F), this.id, par1World.getData(par2, par3, par4));
                    this.a(var9);
                    par1World.addEntity(var9);
                }
            }
            else
            {
                par1World.setAir(par2, par3, par4);

                while (canFall(par1World, par2, par3 - 1, par4) && par3 > 0)
                {
                    --par3;
                }

                if (par3 > 0)
                {
                    par1World.setTypeIdUpdate(par2, par3, par4, this.id);
                }
            }
        }
    }

    protected void a(EntityFallingBlock var1) {}

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World par1World)
    {
        return 2;
    }

    public static boolean canFall(World var0, int var1, int var2, int var3)
    {
        int var4 = var0.getTypeId(var1, var2, var3);

        if (var4 == 0)
        {
            return true;
        }
        else if (var4 == Block.FIRE.id)
        {
            return true;
        }
        else
        {
            Material var5 = Block.byId[var4].material;
            return var5 == Material.WATER ? true : var5 == Material.LAVA;
        }
    }

    /**
     * Called when the falling block entity for this block hits the ground and turns back into a block
     */
    public void onFinishFalling(World par1World, int par2, int par3, int par4, int par5) {}
}
