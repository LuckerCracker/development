package net.minecraft.server.v1_6_R3;

public enum EnumAnimation {
	NONE("none", 0), EAT("eat", 1), DRINK("drink", 2), BLOCK("block", 3), BOW("bow", 4);
	private EnumAnimation(String a, int b) {
		// TODO Auto-generated constructor stub
	}
}
