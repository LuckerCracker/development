package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityTeleportEvent;

public class EntityEnderman extends EntityMonster
{
    private static final UUID attackingSpeedBoostModifierUUID = UUID.fromString("020E0DFB-87AE-4653-9556-831010E291A0");
    private static final AttributeModifier attackingSpeedBoostModifier = (new AttributeModifier(attackingSpeedBoostModifierUUID, "Attacking speed boost", 6.199999809265137D, 0)).setSaved(false);
    private static boolean[] carriableBlocks = new boolean[256];

    /**
     * Counter to delay the teleportation of an enderman towards the currently attacked target
     */
    private int teleportDelay;

    /**
     * A player must stare at an enderman for 5 ticks before it becomes aggressive. This field counts those ticks.
     */
    private int stareTimer;
    private Entity lastEntityToAttack;
    private boolean isAggressive;

    public EntityEnderman(World par1World)
    {
        super(par1World);
        this.setSize(0.6F, 2.9F);
        this.stepHeight = 1.0F;
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.a).setValue(40.0D);
        this.getAttributeInstance(GenericAttributes.d).setValue(0.30000001192092896D);
        this.getAttributeInstance(GenericAttributes.e).setValue(7.0D);
    }

    protected void entityInit()
    {
        super.entityInit();
        this.datawatcher.addObject(16, new Byte((byte)0));
        this.datawatcher.addObject(17, new Byte((byte)0));
        this.datawatcher.addObject(18, new Byte((byte)0));
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setShort("carried", (short)this.getCarriedId());
        par1NBTTagCompound.setShort("carriedData", (short)this.getCarriedData());
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);
        this.setCarriedId(par1NBTTagCompound.getShort("carried"));
        this.setCarriedData(par1NBTTagCompound.getShort("carriedData"));
    }

    protected Entity findTarget()
    {
        EntityHuman entityhuman = this.world.findNearbyVulnerablePlayer(this, 64.0D);

        if (entityhuman != null)
        {
            if (this.f(entityhuman))
            {
                this.isAggressive = true;

                if (this.stareTimer == 0)
                {
                    this.world.makeSound(entityhuman, "mob.endermen.stare", 1.0F, 1.0F);
                }

                if (this.stareTimer++ == 5)
                {
                    this.stareTimer = 0;
                    this.setScreaming(true);
                    return entityhuman;
                }
            }
            else
            {
                this.stareTimer = 0;
            }
        }

        return null;
    }

    private boolean f(EntityHuman entityhuman)
    {
        ItemStack itemstack = entityhuman.inventory.armor[3];

        if (itemstack != null && itemstack.id == Block.PUMPKIN.id)
        {
            return false;
        }
        else
        {
            Vec3D vec3d = entityhuman.getLook(1.0F).a();
            Vec3D vec3d1 = this.world.getVec3DPool().create(this.locX - entityhuman.locX, this.boundingBox.minY + (double)(this.length / 2.0F) - (entityhuman.locY + (double)entityhuman.getHeadHeight()), this.locZ - entityhuman.locZ);
            double d0 = vec3d1.b();
            vec3d1 = vec3d1.a();
            double d1 = vec3d.b(vec3d1);
            return d1 > 1.0D - 0.025D / d0 ? entityhuman.canEntityBeSeen(this) : false;
        }
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
        if (this.isWet())
        {
            this.attackEntityFrom(DamageSource.DROWN, 1.0F);
        }

        if (this.lastEntityToAttack != this.target)
        {
            AttributeInstance var1 = this.getAttributeInstance(GenericAttributes.d);
            var1.removeModifier(attackingSpeedBoostModifier);

            if (this.target != null)
            {
                var1.applyModifier(attackingSpeedBoostModifier);
            }
        }

        this.lastEntityToAttack = this.target;
        int var6;

        if (!this.world.isStatic && this.world.getGameRules().getBoolean("mobGriefing"))
        {
            int var2;
            int var3;
            int var4;

            if (this.getCarriedId() == 0)
            {
                if (this.random.nextInt(20) == 0)
                {
                    var6 = MathHelper.floor(this.locX - 2.0D + this.random.nextDouble() * 4.0D);
                    var2 = MathHelper.floor(this.locY + this.random.nextDouble() * 3.0D);
                    var3 = MathHelper.floor(this.locZ - 2.0D + this.random.nextDouble() * 4.0D);
                    var4 = this.world.getTypeId(var6, var2, var3);

                    if (carriableBlocks[var4] && !CraftEventFactory.callEntityChangeBlockEvent((Entity)this, this.world.getWorld().getBlockAt(var6, var2, var3), org.bukkit.Material.AIR).isCancelled())
                    {
                        this.setCarriedId(this.world.getTypeId(var6, var2, var3));
                        this.setCarriedData(this.world.getData(var6, var2, var3));
                        this.world.setTypeIdUpdate(var6, var2, var3, 0);
                    }
                }
            }
            else if (this.random.nextInt(2000) == 0)
            {
                var6 = MathHelper.floor(this.locX - 1.0D + this.random.nextDouble() * 2.0D);
                var2 = MathHelper.floor(this.locY + this.random.nextDouble() * 2.0D);
                var3 = MathHelper.floor(this.locZ - 1.0D + this.random.nextDouble() * 2.0D);
                var4 = this.world.getTypeId(var6, var2, var3);
                int var5 = this.world.getTypeId(var6, var2 - 1, var3);

                if (var4 == 0 && var5 > 0 && Block.byId[var5].renderAsNormalBlock() && !CraftEventFactory.callEntityChangeBlockEvent(this, var6, var2, var3, this.getCarriedId(), this.getCarriedData()).isCancelled())
                {
                    this.world.setTypeIdAndData(var6, var2, var3, this.getCarriedId(), this.getCarriedData(), 3);
                    this.setCarriedId(0);
                }
            }
        }

        for (var6 = 0; var6 < 2; ++var6)
        {
            this.world.addParticle("portal", this.locX + (this.random.nextDouble() - 0.5D) * (double)this.width, this.locY + this.random.nextDouble() * (double)this.length - 0.25D, this.locZ + (this.random.nextDouble() - 0.5D) * (double)this.width, (this.random.nextDouble() - 0.5D) * 2.0D, -this.random.nextDouble(), (this.random.nextDouble() - 0.5D) * 2.0D);
        }

        if (this.world.isDaytime() && !this.world.isStatic)
        {
            float var7 = this.getBrightness(1.0F);

            if (var7 > 0.5F && this.world.canBlockSeeTheSky(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ)) && this.random.nextFloat() * 30.0F < (var7 - 0.4F) * 2.0F)
            {
                this.target = null;
                this.setScreaming(false);
                this.isAggressive = false;
                this.teleportRandomly();
            }
        }

        if (this.isWet() || this.isBurning())
        {
            this.target = null;
            this.setScreaming(false);
            this.isAggressive = false;
            this.teleportRandomly();
        }

        if (this.isScreaming() && !this.isAggressive && this.random.nextInt(100) == 0)
        {
            this.setScreaming(false);
        }

        this.isJumping = false;

        if (this.target != null)
        {
            this.faceEntity(this.target, 100.0F, 100.0F);
        }

        if (!this.world.isStatic && this.isAlive())
        {
            if (this.target != null)
            {
                if (this.target instanceof EntityHuman && this.f((EntityHuman)this.target))
                {
                    if (this.target.getDistanceSqToEntity(this) < 16.0D)
                    {
                        this.teleportRandomly();
                    }

                    this.teleportDelay = 0;
                }
                else if (this.target.getDistanceSqToEntity(this) > 256.0D && this.teleportDelay++ >= 30 && this.teleportToEntity(this.target))
                {
                    this.teleportDelay = 0;
                }
            }
            else
            {
                this.setScreaming(false);
                this.teleportDelay = 0;
            }
        }

        super.onLivingUpdate();
    }

    /**
     * Teleport the enderman to a random nearby position
     */
    protected boolean teleportRandomly()
    {
        double var1 = this.locX + (this.random.nextDouble() - 0.5D) * 64.0D;
        double var3 = this.locY + (double)(this.random.nextInt(64) - 32);
        double var5 = this.locZ + (this.random.nextDouble() - 0.5D) * 64.0D;
        return this.teleportTo(var1, var3, var5);
    }

    /**
     * Teleport the enderman to another entity
     */
    protected boolean teleportToEntity(Entity par1Entity)
    {
        Vec3D var2 = this.world.getVec3DPool().create(this.locX - par1Entity.locX, this.boundingBox.minY + (double)(this.length / 2.0F) - par1Entity.locY + (double)par1Entity.getHeadHeight(), this.locZ - par1Entity.locZ);
        var2 = var2.a();
        double var3 = 16.0D;
        double var5 = this.locX + (this.random.nextDouble() - 0.5D) * 8.0D - var2.c * var3;
        double var7 = this.locY + (double)(this.random.nextInt(16) - 8) - var2.d * var3;
        double var9 = this.locZ + (this.random.nextDouble() - 0.5D) * 8.0D - var2.e * var3;
        return this.teleportTo(var5, var7, var9);
    }

    /**
     * Teleport the enderman
     */
    protected boolean teleportTo(double par1, double par3, double par5)
    {
        double var7 = this.locX;
        double var9 = this.locY;
        double var11 = this.locZ;
        this.locX = par1;
        this.locY = par3;
        this.locZ = par5;
        boolean var13 = false;
        int var14 = MathHelper.floor(this.locX);
        int var15 = MathHelper.floor(this.locY);
        int var16 = MathHelper.floor(this.locZ);
        int var18;

        if (this.world.isLoaded(var14, var15, var16))
        {
            boolean var17 = false;

            while (!var17 && var15 > 0)
            {
                var18 = this.world.getTypeId(var14, var15 - 1, var16);

                if (var18 != 0 && Block.byId[var18].material.isSolid())
                {
                    var17 = true;
                }
                else
                {
                    --this.locY;
                    --var15;
                }
            }

            if (var17)
            {
                EntityTeleportEvent var19 = new EntityTeleportEvent(this.getBukkitEntity(), new Location(this.world.getWorld(), var7, var9, var11), new Location(this.world.getWorld(), this.locX, this.locY, this.locZ));
                this.world.getServer().getPluginManager().callEvent(var19);

                if (var19.isCancelled())
                {
                    return false;
                }

                Location var20 = var19.getTo();
                this.setPosition(var20.getX(), var20.getY(), var20.getZ());

                if (this.world.getCubes(this, this.boundingBox).isEmpty() && !this.world.containsLiquid(this.boundingBox))
                {
                    var13 = true;
                }
            }
        }

        if (!var13)
        {
            this.setPosition(var7, var9, var11);
            return false;
        }
        else
        {
            short var32 = 128;

            for (var18 = 0; var18 < var32; ++var18)
            {
                double var21 = (double)var18 / ((double)var32 - 1.0D);
                float var23 = (this.random.nextFloat() - 0.5F) * 0.2F;
                float var24 = (this.random.nextFloat() - 0.5F) * 0.2F;
                float var25 = (this.random.nextFloat() - 0.5F) * 0.2F;
                double var26 = var7 + (this.locX - var7) * var21 + (this.random.nextDouble() - 0.5D) * (double)this.width * 2.0D;
                double var28 = var9 + (this.locY - var9) * var21 + this.random.nextDouble() * (double)this.length;
                double var30 = var11 + (this.locZ - var11) * var21 + (this.random.nextDouble() - 0.5D) * (double)this.width * 2.0D;
                this.world.addParticle("portal", var26, var28, var30, (double)var23, (double)var24, (double)var25);
            }

            this.world.makeSound(var7, var9, var11, "mob.endermen.portal", 1.0F, 1.0F);
            this.makeSound("mob.endermen.portal", 1.0F, 1.0F);
            return true;
        }
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return this.isScreaming() ? "mob.endermen.scream" : "mob.endermen.idle";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.endermen.hit";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.endermen.death";
    }

    protected int getLootId()
    {
        return Item.ENDER_PEARL.id;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        int j = this.getLootId();

        if (j > 0)
        {
            ArrayList loot = new ArrayList();
            int count = this.random.nextInt(2 + i);

            if (j > 0 && count > 0)
            {
                loot.add(new org.bukkit.inventory.ItemStack(j, count));
            }

            CraftEventFactory.callEntityDeathEvent(this, loot);
        }
    }

    public void setCarriedId(int i)
    {
        this.datawatcher.watch(16, Byte.valueOf((byte)(i & 255)));
    }

    public int getCarriedId()
    {
        return this.datawatcher.getByte(16);
    }

    public void setCarriedData(int i)
    {
        this.datawatcher.watch(17, Byte.valueOf((byte)(i & 255)));
    }

    public int getCarriedData()
    {
        return this.datawatcher.getByte(17);
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else
        {
            this.setScreaming(true);

            if (damagesource instanceof EntityDamageSource && damagesource.getEntity() instanceof EntityHuman)
            {
                this.isAggressive = true;
            }

            if (damagesource instanceof EntityDamageSourceIndirect)
            {
                this.isAggressive = false;

                for (int i = 0; i < 64; ++i)
                {
                    if (this.teleportRandomly())
                    {
                        return true;
                    }
                }

                return false;
            }
            else
            {
                return super.attackEntityFrom(damagesource, f);
            }
        }
    }

    public boolean isScreaming()
    {
        return this.datawatcher.getByte(18) > 0;
    }

    public void setScreaming(boolean par1)
    {
        this.datawatcher.watch(18, Byte.valueOf((byte)(par1 ? 1 : 0)));
    }

    static
    {
        carriableBlocks[Block.GRASS.id] = true;
        carriableBlocks[Block.DIRT.id] = true;
        carriableBlocks[Block.SAND.id] = true;
        carriableBlocks[Block.GRAVEL.id] = true;
        carriableBlocks[Block.YELLOW_FLOWER.id] = true;
        carriableBlocks[Block.RED_ROSE.id] = true;
        carriableBlocks[Block.BROWN_MUSHROOM.id] = true;
        carriableBlocks[Block.RED_MUSHROOM.id] = true;
        carriableBlocks[Block.TNT.id] = true;
        carriableBlocks[Block.CACTUS.id] = true;
        carriableBlocks[Block.CLAY.id] = true;
        carriableBlocks[Block.PUMPKIN.id] = true;
        carriableBlocks[Block.MELON.id] = true;
        carriableBlocks[Block.MYCEL.id] = true;
    }
}
