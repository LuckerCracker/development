package net.minecraft.server.v1_6_R3;

final class DispenseBehaviorSnowBall extends DispenseBehaviorProjectile
{
    protected IProjectile a(World var1, IPosition var2)
    {
        return new EntitySnowball(var1, var2.getX(), var2.getY(), var2.getZ());
    }
}
