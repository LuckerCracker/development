package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class EnchantmentThorns extends Enchantment
{
    public EnchantmentThorns(int par1, int par2)
    {
        super(par1, par2, EnchantmentSlotType.ARMOR_TORSO);
        this.setName("thorns");
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int par1)
    {
        return 10 + 20 * (par1 - 1);
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int par1)
    {
        return super.getMinEnchantability(par1) + 50;
    }

    public int getMaxLevel()
    {
        return 3;
    }

    public boolean canEnchant(ItemStack var1)
    {
        return var1.getItem() instanceof ItemArmor ? true : super.canEnchant(var1);
    }

    public static boolean func_92094_a(int par0, Random par1Random)
    {
        return par0 <= 0 ? false : par1Random.nextFloat() < 0.15F * (float)par0;
    }

    public static int func_92095_b(int par0, Random par1Random)
    {
        return par0 > 10 ? par0 - 10 : 1 + par1Random.nextInt(4);
    }

    public static void a(Entity var0, EntityLiving var1, Random var2)
    {
        int var3 = EnchantmentManager.getThornsEnchantmentLevel(var1);
        ItemStack var4 = EnchantmentManager.a(Enchantment.THORNS, var1);

        if (func_92094_a(var3, var2))
        {
            var0.attackEntityFrom(DamageSource.causeThornsDamage(var1), (float)func_92095_b(var3, var2));
            var0.makeSound("damage.thorns", 0.5F, 1.0F);

            if (var4 != null)
            {
                var4.damage(3, var1);
            }
        }
        else if (var4 != null)
        {
            var4.damage(1, var1);
        }
    }
}
