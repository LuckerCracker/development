package net.minecraft.server.v1_6_R3;

public class CounterStatistic extends Statistic
{
    public CounterStatistic(int var1, String var2, Counter var3)
    {
        super(var1, var2, var3);
    }

    public CounterStatistic(int var1, String var2)
    {
        super(var1, var2);
    }

    public Statistic g()
    {
        super.g();
        StatisticList.c.add(this);
        return this;
    }
}
