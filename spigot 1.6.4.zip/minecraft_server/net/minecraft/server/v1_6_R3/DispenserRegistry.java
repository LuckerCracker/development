package net.minecraft.server.v1_6_R3;

public class DispenserRegistry
{
    public static void a()
    {
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.ARROW, new DispenseBehaviorArrow());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.EGG, new DispenseBehaviorEgg());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.SNOW_BALL, new DispenseBehaviorSnowBall());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.EXP_BOTTLE, new DispenseBehaviorExpBottle());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.POTION, new DispenseBehaviorPotion());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.MONSTER_EGG, new DispenseBehaviorMonsterEgg());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.FIREWORKS, new DispenseBehaviorFireworks());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.FIREBALL, new DispenseBehaviorFireball());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.BOAT, new DispenseBehaviorBoat());
        DispenseBehaviorFilledBucket var0 = new DispenseBehaviorFilledBucket();
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.LAVA_BUCKET, var0);
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.WATER_BUCKET, var0);
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.BUCKET, new DispenseBehaviorEmptyBucket());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.FLINT_AND_STEEL, new DispenseBehaviorFlintAndSteel());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.INK_SACK, new DispenseBehaviorBonemeal());
        BlockDispenser.dispenseBehaviorRegistry.putObject(Item.byId[Block.TNT.id], new DispenseBehaviorTNT());
    }
}
