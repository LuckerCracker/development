package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.PortalType;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.util.BlockStateListPopulator;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.entity.EntityCreatePortalEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;

public class EntityEnderDragon extends EntityInsentient implements IComplex, IMonster {
	public double lookHelper;
	public double moveHelper;

	/** Entity jumping helper */
	public double jumpHelper;
	public double[][] bodyHelper = new double[64][3];
	public int navigator = -1;
	public EntityComplexPart[] children;
	public EntityComplexPart senses;

	/** Equipment (armor and held item) for this entity. */
	public EntityComplexPart equipment;

	/** Whether this entity can pick up items from the ground. */
	public EntityComplexPart canPickUpLoot;

	/** Whether this entity should NOT despawn. */
	public EntityComplexPart persistenceRequired;

	/** This entity's current target. */
	public EntityComplexPart currentTarget;
	public EntityComplexPart isLeashed;
	public EntityComplexPart leashedToEntity;
	public float field_110170_bx;
	public float by;
	public boolean bz;
	public boolean bA;
	private Entity bD;
	public int bB;
	public EntityEnderCrystal bC;
	private Explosion explosionSource = new Explosion((World) null, this, Double.NaN, Double.NaN, Double.NaN,
			Float.NaN);

	public EntityEnderDragon(World world) {
		super(world);
		this.children = new EntityComplexPart[] { this.senses = new EntityComplexPart(this, "head", 6.0F, 6.0F),
				this.equipment = new EntityComplexPart(this, "body", 8.0F, 8.0F),
				this.canPickUpLoot = new EntityComplexPart(this, "tail", 4.0F, 4.0F),
				this.persistenceRequired = new EntityComplexPart(this, "tail", 4.0F, 4.0F),
				this.currentTarget = new EntityComplexPart(this, "tail", 4.0F, 4.0F),
				this.isLeashed = new EntityComplexPart(this, "wing", 4.0F, 4.0F),
				this.leashedToEntity = new EntityComplexPart(this, "wing", 4.0F, 4.0F) };
		this.setHealth(this.getMaxHealth());
		this.setSize(16.0F, 8.0F);
		this.noClip = true;
		this.fireProof = true;
		this.moveHelper = 100.0D;
		this.ignoreFrustumCheck = true;
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.a).setValue(200.0D);
	}

	protected void entityInit() {
		super.entityInit();
	}

	public double[] b(int i, float f) {
		if (this.getHealth() <= 0.0F) {
			f = 0.0F;
		}

		f = 1.0F - f;
		int j = this.navigator - i * 1 & 63;
		int k = this.navigator - i * 1 - 1 & 63;
		double[] adouble = new double[3];
		double d0 = this.bodyHelper[j][0];
		double d1 = MathHelper.wrapAngleTo180_double(this.bodyHelper[k][0] - d0);
		adouble[0] = d0 + d1 * (double) f;
		d0 = this.bodyHelper[j][1];
		d1 = this.bodyHelper[k][1] - d0;
		adouble[1] = d0 + d1 * (double) f;
		adouble[2] = this.bodyHelper[j][2] + (this.bodyHelper[k][2] - this.bodyHelper[j][2]) * (double) f;
		return adouble;
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		float f;
		float f1;

		if (this.world.isStatic) {
			f = MathHelper.cos(this.by * (float) Math.PI * 2.0F);
			f1 = MathHelper.cos(this.field_110170_bx * (float) Math.PI * 2.0F);

			if (f1 <= -0.3F && f >= -0.3F) {
				this.world.playSound(this.locX, this.locY, this.locZ, "mob.enderdragon.wings", 5.0F,
						0.8F + this.random.nextFloat() * 0.3F, false);
			}
		}

		this.field_110170_bx = this.by;
		float f2;

		if (this.getHealth() <= 0.0F) {
			f = (this.random.nextFloat() - 0.5F) * 8.0F;
			f1 = (this.random.nextFloat() - 0.5F) * 4.0F;
			f2 = (this.random.nextFloat() - 0.5F) * 8.0F;
			this.world.addParticle("largeexplode", this.locX + (double) f, this.locY + 2.0D + (double) f1,
					this.locZ + (double) f2, 0.0D, 0.0D, 0.0D);
		} else {
			this.recreateLeash();
			f = 0.2F / (MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ) * 10.0F + 1.0F);
			f *= (float) Math.pow(2.0D, this.motY);

			if (this.bA) {
				this.by += f * 0.5F;
			} else {
				this.by += f;
			}

			this.yaw = MathHelper.wrapAngleTo180_float(this.yaw);

			if (this.navigator < 0) {
				for (int d05 = 0; d05 < this.bodyHelper.length; ++d05) {
					this.bodyHelper[d05][0] = (double) this.yaw;
					this.bodyHelper[d05][1] = this.locY;
				}
			}

			if (++this.navigator == this.bodyHelper.length) {
				this.navigator = 0;
			}

			this.bodyHelper[this.navigator][0] = (double) this.yaw;
			this.bodyHelper[this.navigator][1] = this.locY;
			double d0;
			double d1;
			double d2;
			double d3;
			float f3;
			float f13;
			float f14;
			float f15;
			float f17;

			if (this.world.isStatic) {
				if (this.newPosRotationIncrements > 0) {
					d0 = this.locX + (this.newPosX - this.locX) / (double) this.newPosRotationIncrements;
					d1 = this.locY + (this.newPosY - this.locY) / (double) this.newPosRotationIncrements;
					d2 = this.locZ + (this.newPosZ - this.locZ) / (double) this.newPosRotationIncrements;
					d3 = MathHelper.wrapAngleTo180_double(this.newRotationYaw - (double) this.yaw);
					this.yaw = (float) ((double) this.yaw + d3 / (double) this.newPosRotationIncrements);
					this.pitch = (float) ((double) this.pitch + (this.newRotationPitch - (double) this.pitch) / (double) this.newPosRotationIncrements);
					--this.newPosRotationIncrements;
					this.setPosition(d0, d1, d2);
					this.setRotation(this.yaw, this.pitch);
				}
			} else {
				d0 = this.lookHelper - this.locX;
				d1 = this.moveHelper - this.locY;
				d2 = this.jumpHelper - this.locZ;
				d3 = d0 * d0 + d1 * d1 + d2 * d2;
				double d8;
				double d9;

				if (this.bD != null) {
					this.lookHelper = this.bD.locX;
					this.jumpHelper = this.bD.locZ;
					d8 = this.lookHelper - this.locX;
					d9 = this.jumpHelper - this.locZ;
					double d6 = Math.sqrt(d8 * d8 + d9 * d9);
					double d7 = 0.4000000059604645D + d6 / 80.0D - 1.0D;

					if (d7 > 10.0D) {
						d7 = 10.0D;
					}

					this.moveHelper = this.bD.boundingBox.minY + d7;
				} else {
					this.lookHelper += this.random.nextGaussian() * 2.0D;
					this.jumpHelper += this.random.nextGaussian() * 2.0D;
				}

				if (this.bz || d3 < 100.0D || d3 > 22500.0D || this.positionChanged || this.isCollidedVertically) {
					this.bK();
				}

				d1 /= (double) MathHelper.sqrt(d0 * d0 + d2 * d2);
				f3 = 0.6F;

				if (d1 < (double) (-f3)) {
					d1 = (double) (-f3);
				}

				if (d1 > (double) f3) {
					d1 = (double) f3;
				}

				this.motY += d1 * 0.10000000149011612D;
				this.yaw = MathHelper.wrapAngleTo180_float(this.yaw);
				d8 = 180.0D - Math.atan2(d0, d2) * 180.0D / Math.PI;
				d9 = MathHelper.wrapAngleTo180_double(d8 - (double) this.yaw);

				if (d9 > 50.0D) {
					d9 = 50.0D;
				}

				if (d9 < -50.0D) {
					d9 = -50.0D;
				}

				Vec3D adouble = this.world.getVec3DPool()
						.create(this.lookHelper - this.locX, this.moveHelper - this.locY, this.jumpHelper - this.locZ)
						.a();
				Vec3D adouble1 = this.world.getVec3DPool()
						.create((double) MathHelper.sin(this.yaw * (float) Math.PI / 180.0F), this.motY,
								(double) (-MathHelper.cos(this.yaw * (float) Math.PI / 180.0F)))
						.a();
				f13 = (float) (adouble1.b(adouble) + 0.5D) / 1.5F;

				if (f13 < 0.0F) {
					f13 = 0.0F;
				}

				this.randomYawVelocity *= 0.8F;
				float j = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ) * 1.0F + 1.0F;
				double d10 = Math.sqrt(this.motX * this.motX + this.motZ * this.motZ) * 1.0D + 1.0D;

				if (d10 > 40.0D) {
					d10 = 40.0D;
				}

				this.randomYawVelocity = (float) ((double) this.randomYawVelocity + d9 * (0.699999988079071D / d10 / (double) j));
				this.yaw += this.randomYawVelocity * 0.1F;
				f14 = (float) (2.0D / (d10 + 1.0D));
				f15 = 0.06F;
				this.moveFlying(0.0F, -1.0F, f15 * (f13 * f14 + (1.0F - f14)));

				if (this.bA) {
					this.move(this.motX * 0.800000011920929D, this.motY * 0.800000011920929D,
							this.motZ * 0.800000011920929D);
				} else {
					this.move(this.motX, this.motY, this.motZ);
				}

				Vec3D f16 = this.world.getVec3DPool().create(this.motX, this.motY, this.motZ).a();
				f17 = (float) (f16.b(adouble1) + 1.0D) / 2.0F;
				f17 = 0.8F + 0.15F * f17;
				this.motX *= (double) f17;
				this.motZ *= (double) f17;
				this.motY *= 0.9100000262260437D;
			}

			this.renderYawOffset = this.yaw;
			this.senses.width = this.senses.length = 3.0F;
			this.canPickUpLoot.width = this.canPickUpLoot.length = 2.0F;
			this.persistenceRequired.width = this.persistenceRequired.length = 2.0F;
			this.currentTarget.width = this.currentTarget.length = 2.0F;
			this.equipment.length = 3.0F;
			this.equipment.width = 5.0F;
			this.isLeashed.length = 2.0F;
			this.isLeashed.width = 4.0F;
			this.leashedToEntity.length = 3.0F;
			this.leashedToEntity.width = 4.0F;
			f1 = (float) (this.b(5, 1.0F)[1] - this.b(10, 1.0F)[1]) * 10.0F / 180.0F * (float) Math.PI;
			f2 = MathHelper.cos(f1);
			float f9 = -MathHelper.sin(f1);
			float f10 = this.yaw * (float) Math.PI / 180.0F;
			float f11 = MathHelper.sin(f10);
			float f12 = MathHelper.cos(f10);
			this.equipment.onUpdate();
			this.equipment.setPositionRotation(this.locX + (double) (f11 * 0.5F), this.locY,
					this.locZ - (double) (f12 * 0.5F), 0.0F, 0.0F);
			this.isLeashed.onUpdate();
			this.isLeashed.setPositionRotation(this.locX + (double) (f12 * 4.5F), this.locY + 2.0D,
					this.locZ + (double) (f11 * 4.5F), 0.0F, 0.0F);
			this.leashedToEntity.onUpdate();
			this.leashedToEntity.setPositionRotation(this.locX - (double) (f12 * 4.5F), this.locY + 2.0D,
					this.locZ - (double) (f11 * 4.5F), 0.0F, 0.0F);

			if (!this.world.isStatic && this.hurtTicks == 0) {
				this.a(this.world.getEntities(this,
						this.isLeashed.boundingBox.grow(4.0D, 2.0D, 4.0D).offset(0.0D, -2.0D, 0.0D)));
				this.a(this.world.getEntities(this,
						this.leashedToEntity.boundingBox.grow(4.0D, 2.0D, 4.0D).offset(0.0D, -2.0D, 0.0D)));
				this.b(this.world.getEntities(this, this.senses.boundingBox.grow(1.0D, 1.0D, 1.0D)));
			}

			double[] var39 = this.b(5, 1.0F);
			double[] var40 = this.b(0, 1.0F);
			f3 = MathHelper.sin(this.yaw * (float) Math.PI / 180.0F - this.randomYawVelocity * 0.01F);
			f13 = MathHelper.cos(this.yaw * (float) Math.PI / 180.0F - this.randomYawVelocity * 0.01F);
			this.senses.onUpdate();
			this.senses.setPositionRotation(this.locX + (double) (f3 * 5.5F * f2),
					this.locY + (var40[1] - var39[1]) * 1.0D + (double) (f9 * 5.5F),
					this.locZ - (double) (f13 * 5.5F * f2), 0.0F, 0.0F);

			for (int var41 = 0; var41 < 3; ++var41) {
				EntityComplexPart entitycomplexpart = null;

				if (var41 == 0) {
					entitycomplexpart = this.canPickUpLoot;
				}

				if (var41 == 1) {
					entitycomplexpart = this.persistenceRequired;
				}

				if (var41 == 2) {
					entitycomplexpart = this.currentTarget;
				}

				double[] adouble2 = this.b(12 + var41 * 2, 1.0F);
				f14 = this.yaw * (float) Math.PI / 180.0F
						+ this.b(adouble2[0] - var39[0]) * (float) Math.PI / 180.0F * 1.0F;
				f15 = MathHelper.sin(f14);
				float var42 = MathHelper.cos(f14);
				f17 = 1.5F;
				float f18 = (float) (var41 + 1) * 2.0F;
				entitycomplexpart.onUpdate();
				entitycomplexpart.setPositionRotation(this.locX - (double) ((f11 * f17 + f15 * f18) * f2),
						this.locY + (adouble2[1] - var39[1]) * 1.0D - (double) ((f18 + f17) * f9) + 1.5D,
						this.locZ + (double) ((f12 * f17 + var42 * f18) * f2), 0.0F, 0.0F);
			}

			if (!this.world.isStatic) {
				this.bA = this.a(this.senses.boundingBox) | this.a(this.equipment.boundingBox);
			}
		}
	}

	private void recreateLeash() {
		if (this.bC != null) {
			if (this.bC.dead) {
				if (!this.world.isStatic) {
					this.a(this.senses, DamageSource.explosion((Explosion) null), 10.0F);
				}

				this.bC = null;
			} else if (this.ticksLived % 10 == 0 && this.getHealth() < this.getMaxHealth()) {
				EntityRegainHealthEvent f = new EntityRegainHealthEvent(this.getBukkitEntity(), 1.0D,
						EntityRegainHealthEvent.RegainReason.ENDER_CRYSTAL);
				this.world.getServer().getPluginManager().callEvent(f);

				if (!f.isCancelled()) {
					this.setHealth((float) ((double) this.getHealth() + f.getAmount()));
				}
			}
		}

		if (this.random.nextInt(10) == 0) {
			float f1 = 32.0F;
			List list = this.world.getEntitiesWithinAABB(EntityEnderCrystal.class,
					this.boundingBox.grow((double) f1, (double) f1, (double) f1));
			EntityEnderCrystal entityendercrystal = null;
			double d0 = Double.MAX_VALUE;
			Iterator iterator = list.iterator();

			while (iterator.hasNext()) {
				EntityEnderCrystal entityendercrystal1 = (EntityEnderCrystal) iterator.next();
				double d1 = entityendercrystal1.getDistanceSqToEntity(this);

				if (d1 < d0) {
					d0 = d1;
					entityendercrystal = entityendercrystal1;
				}
			}

			this.bC = entityendercrystal;
		}
	}

	private void a(List list) {
		double d0 = (this.equipment.boundingBox.minX + this.equipment.boundingBox.maxX) / 2.0D;
		double d1 = (this.equipment.boundingBox.minZ + this.equipment.boundingBox.maxZ) / 2.0D;
		Iterator iterator = list.iterator();

		while (iterator.hasNext()) {
			Entity entity = (Entity) iterator.next();

			if (entity instanceof EntityLiving) {
				double d2 = entity.locX - d0;
				double d3 = entity.locZ - d1;
				double d4 = d2 * d2 + d3 * d3;
				entity.addVelocity(d2 / d4 * 4.0D, 0.20000000298023224D, d3 / d4 * 4.0D);
			}
		}
	}

	private void b(List list) {
		for (int i = 0; i < list.size(); ++i) {
			Entity entity = (Entity) list.get(i);

			if (entity instanceof EntityLiving) {
				entity.attackEntityFrom(DamageSource.mobAttack(this), 10.0F);
			}
		}
	}

	private void bK() {
		this.bz = false;

		if (this.random.nextInt(2) == 0 && !this.world.players.isEmpty()) {
			this.bD = (Entity) this.world.players.get(this.random.nextInt(this.world.players.size()));
		} else {
			boolean flag = false;

			do {
				this.lookHelper = 0.0D;
				this.moveHelper = (double) (70.0F + this.random.nextFloat() * 50.0F);
				this.jumpHelper = 0.0D;
				this.lookHelper += (double) (this.random.nextFloat() * 120.0F - 60.0F);
				this.jumpHelper += (double) (this.random.nextFloat() * 120.0F - 60.0F);
				double d0 = this.locX - this.lookHelper;
				double d1 = this.locY - this.moveHelper;
				double d2 = this.locZ - this.jumpHelper;
				flag = d0 * d0 + d1 * d1 + d2 * d2 > 100.0D;
			} while (!flag);

			this.bD = null;
		}
	}

	private float b(double d0) {
		return (float) MathHelper.wrapAngleTo180_double(d0);
	}

	private boolean a(AxisAlignedBB axisalignedbb) {
		int i = MathHelper.floor(axisalignedbb.minX);
		int j = MathHelper.floor(axisalignedbb.minY);
		int k = MathHelper.floor(axisalignedbb.minZ);
		int l = MathHelper.floor(axisalignedbb.maxX);
		int i1 = MathHelper.floor(axisalignedbb.maxY);
		int j1 = MathHelper.floor(axisalignedbb.maxZ);
		boolean flag = false;
		boolean flag1 = false;
		ArrayList destroyedBlocks = new ArrayList();
		CraftWorld craftWorld = this.world.getWorld();

		for (int bukkitEntity = i; bukkitEntity <= l; ++bukkitEntity) {
			for (int event = j; event <= i1; ++event) {
				for (int i$ = k; i$ <= j1; ++i$) {
					int block = this.world.getTypeId(bukkitEntity, event, i$);

					if (block != 0) {
						if (block != Block.OBSIDIAN.id && block != Block.WHITESTONE.id && block != Block.BEDROCK.id
								&& this.world.getGameRules().getBoolean("mobGriefing")) {
							flag1 = true;
							destroyedBlocks.add(craftWorld.getBlockAt(bukkitEntity, event, i$));
						} else {
							flag = true;
						}
					}
				}
			}
		}

		if (flag1) {
			CraftEntity var26 = this.getBukkitEntity();
			EntityExplodeEvent var27 = new EntityExplodeEvent(var26, var26.getLocation(), destroyedBlocks, 0.0F);
			Bukkit.getPluginManager().callEvent(var27);

			if (var27.isCancelled()) {
				return flag;
			}

			Iterator var28;
			org.bukkit.block.Block var29;

			if (var27.getYield() == 0.0F) {
				var28 = var27.blockList().iterator();

				while (var28.hasNext()) {
					var29 = (org.bukkit.block.Block) var28.next();
					this.world.setAir(var29.getX(), var29.getY(), var29.getZ());
				}
			} else {
				var28 = var27.blockList().iterator();

				while (var28.hasNext()) {
					var29 = (org.bukkit.block.Block) var28.next();
					int blockId = var29.getTypeId();

					if (blockId != 0) {
						int blockX = var29.getX();
						int blockY = var29.getY();
						int blockZ = var29.getZ();

						if (Block.byId[blockId].canDropFromExplosion(this.explosionSource)) {
							Block.byId[blockId].dropNaturally(this.world, blockX, blockY, blockZ, var29.getData(),
									var27.getYield(), 0);
						}

						Block.byId[blockId].wasExploded(this.world, blockX, blockY, blockZ, this.explosionSource);
						this.world.setAir(blockX, blockY, blockZ);
					}
				}
			}

			double d0 = axisalignedbb.minX
					+ (axisalignedbb.maxX - axisalignedbb.minX) * (double) this.random.nextFloat();
			double d1 = axisalignedbb.minY
					+ (axisalignedbb.maxY - axisalignedbb.minY) * (double) this.random.nextFloat();
			double d2 = axisalignedbb.minZ
					+ (axisalignedbb.maxZ - axisalignedbb.minZ) * (double) this.random.nextFloat();
			this.world.addParticle("largeexplode", d0, d1, d2, 0.0D, 0.0D, 0.0D);
		}

		return flag;
	}

	public boolean a(EntityComplexPart entitycomplexpart, DamageSource damagesource, float f) {
		if (entitycomplexpart != this.senses) {
			f = f / 4.0F + 1.0F;
		}

		float f1 = this.yaw * (float) Math.PI / 180.0F;
		float f2 = MathHelper.sin(f1);
		float f3 = MathHelper.cos(f1);
		this.lookHelper = this.locX + (double) (f2 * 5.0F) + (double) ((this.random.nextFloat() - 0.5F) * 2.0F);
		this.moveHelper = this.locY + (double) (this.random.nextFloat() * 3.0F) + 1.0D;
		this.jumpHelper = this.locZ - (double) (f3 * 5.0F) + (double) ((this.random.nextFloat() - 0.5F) * 2.0F);
		this.bD = null;

		if (damagesource.getEntity() instanceof EntityHuman || damagesource.isExplosion()) {
			this.dealDamage(damagesource, f);
		}

		return true;
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		return false;
	}

	public boolean dealDamage(DamageSource damagesource, float f) {
		return super.attackEntityFrom(damagesource, f);
	}

	protected void onDeathUpdate() {
		++this.bB;

		if (this.bB >= 180 && this.bB <= 200) {
			float i = (this.random.nextFloat() - 0.5F) * 8.0F;
			float j = (this.random.nextFloat() - 0.5F) * 4.0F;
			float f2 = (this.random.nextFloat() - 0.5F) * 8.0F;
			this.world.addParticle("hugeexplosion", this.locX + (double) i, this.locY + 2.0D + (double) j,
					this.locZ + (double) f2, 0.0D, 0.0D, 0.0D);
		}

		int var4;
		int var5;

		if (!this.world.isStatic) {
			if (this.bB > 150 && this.bB % 5 == 0) {
				var4 = this.expToDrop / 12;

				while (var4 > 0) {
					var5 = EntityExperienceOrb.getOrbValue(var4);
					var4 -= var5;
					this.world.addEntity(new EntityExperienceOrb(this.world, this.locX, this.locY, this.locZ, var5));
				}
			}

			if (this.bB == 1) {
				this.world.func_82739_e(1018, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
			}
		}

		this.move(0.0D, 0.10000000149011612D, 0.0D);
		this.renderYawOffset = this.yaw += 20.0F;

		if (this.bB == 200 && !this.world.isStatic) {
			var4 = this.expToDrop - 10 * (this.expToDrop / 12);

			while (var4 > 0) {
				var5 = EntityExperienceOrb.getOrbValue(var4);
				var4 -= var5;
				this.world.addEntity(new EntityExperienceOrb(this.world, this.locX, this.locY, this.locZ, var5));
			}

			this.c(MathHelper.floor(this.locX), MathHelper.floor(this.locZ));
			this.die();
		}
	}

	private void c(int i, int j) {
		byte b0 = 64;
		BlockEnderPortal.displayOnCreativeTab = true;
		byte b1 = 4;
		BlockStateListPopulator world = new BlockStateListPopulator(this.world.getWorld());

		for (int event = b0 - 1; event <= b0 + 32; ++event) {
			for (int i$ = i - b1; i$ <= i + b1; ++i$) {
				for (int state = j - b1; state <= j + b1; ++state) {
					double d0 = (double) (i$ - i);
					double d1 = (double) (state - j);
					double d2 = d0 * d0 + d1 * d1;

					if (d2 <= ((double) b1 - 0.5D) * ((double) b1 - 0.5D)) {
						if (event < b0) {
							if (d2 <= ((double) (b1 - 1) - 0.5D) * ((double) (b1 - 1) - 0.5D)) {
								world.setTypeId(i$, event, state, Block.BEDROCK.id);
							}
						} else if (event > b0) {
							world.setTypeId(i$, event, state, 0);
						} else if (d2 > ((double) (b1 - 1) - 0.5D) * ((double) (b1 - 1) - 0.5D)) {
							world.setTypeId(i$, event, state, Block.BEDROCK.id);
						} else {
							world.setTypeId(i$, event, state, Block.ENDER_PORTAL.id);
						}
					}
				}
			}
		}

		world.setTypeId(i, b0 + 0, j, Block.BEDROCK.id);
		world.setTypeId(i, b0 + 1, j, Block.BEDROCK.id);
		world.setTypeId(i, b0 + 2, j, Block.BEDROCK.id);
		world.setTypeId(i - 1, b0 + 2, j, Block.TORCH.id);
		world.setTypeId(i + 1, b0 + 2, j, Block.TORCH.id);
		world.setTypeId(i, b0 + 2, j - 1, Block.TORCH.id);
		world.setTypeId(i, b0 + 2, j + 1, Block.TORCH.id);
		world.setTypeId(i, b0 + 3, j, Block.BEDROCK.id);
		world.setTypeId(i, b0 + 4, j, Block.DRAGON_EGG.id);
		EntityCreatePortalEvent var18 = new EntityCreatePortalEvent((LivingEntity) this.getBukkitEntity(),
				Collections.unmodifiableList(world.getList()), PortalType.ENDER);
		this.world.getServer().getPluginManager().callEvent(var18);
		Iterator var19;
		BlockState var20;

		if (!var18.isCancelled()) {
			var19 = var18.getBlocks().iterator();

			while (var19.hasNext()) {
				var20 = (BlockState) var19.next();
				var20.update(true);
			}
		} else {
			var19 = var18.getBlocks().iterator();

			while (var19.hasNext()) {
				var20 = (BlockState) var19.next();
				Packet53BlockChange packet = new Packet53BlockChange(var20.getX(), var20.getY(), var20.getZ(),
						this.world);
				Iterator it = this.world.players.iterator();

				while (it.hasNext()) {
					EntityHuman entity = (EntityHuman) it.next();

					if (entity instanceof EntityPlayer) {
						((EntityPlayer) entity).playerConnection.sendPacket(packet);
					}
				}
			}
		}

		BlockEnderPortal.displayOnCreativeTab = false;
	}

	/**
	 * Makes the entity despawn if requirements are reached
	 */
	protected void despawnEntity() {
	}

	/**
	 * Return the Entity parts making up this Entity (currently only for
	 * dragons)
	 */
	public Entity[] getParts() {
		return this.children;
	}

	/**
	 * Returns true if other Entities should be prevented from moving through
	 * this Entity.
	 */
	public boolean canBeCollidedWith() {
		return false;
	}

	public World b() {
		return this.world;
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return "mob.enderdragon.growl";
	}

	protected String getHurtSound() {
		return "mob.enderdragon.hit";
	}

	protected float getSoundVolume() {
		return 5.0F;
	}

	public int getExpReward() {
		return 12000;
	}
}
