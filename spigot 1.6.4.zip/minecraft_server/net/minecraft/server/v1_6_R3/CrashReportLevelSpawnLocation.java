package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportLevelSpawnLocation implements Callable
{
    final WorldData a;

    CrashReportLevelSpawnLocation(WorldData var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return CrashReportSystemDetails.a(WorldData.d(this.a), WorldData.e(this.a), WorldData.f(this.a));
    }

    public Object call()
    {
        return this.a();
    }
}
