package net.minecraft.server.v1_6_R3;

public class BiomeTheEnd extends BiomeBase
{
    public BiomeTheEnd(int var1)
    {
        super(var1);
        this.spawnableMonsterList.clear();
        this.spawnableCreatureList.clear();
        this.spawnableWaterCreatureList.clear();
        this.spawnableCaveCreatureList.clear();
        this.spawnableMonsterList.add(new BiomeMeta(EntityEnderman.class, 10, 4, 4));
        this.topBlock = (byte)Block.DIRT.id;
        this.fillerBlock = (byte)Block.DIRT.id;
        this.theBiomeDecorator = new BiomeTheEndDecorator(this);
    }
}
