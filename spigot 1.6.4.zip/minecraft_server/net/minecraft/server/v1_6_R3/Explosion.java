package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;

public class Explosion {
	/** whether or not the explosion sets fire to blocks around it */
	public boolean isFlaming;

	/** whether or not this explosion spawns smoke particles */
	public boolean isSmoking = true;
	private int field_77289_h = 16;
	private Random explosionRNG = new Random();
	private World world;
	public double posX;
	public double posY;
	public double posZ;
	public Entity source;
	public float size;
	public List blocks = new ArrayList();
	private Map field_77288_k = new HashMap();
	public boolean wasCanceled = false;

	public Explosion(World par1World, Entity par2Entity, double par3, double par5, double par7, float par9) {
		this.world = par1World;
		this.source = par2Entity;
		this.size = (float) Math.max((double) par9, 0.0D);
		this.posX = par3;
		this.posY = par5;
		this.posZ = par7;
	}

	/**
	 * Does the first part of the explosion (destroy blocks)
	 */
	public void doExplosionA() {
		if (this.size >= 0.1F) {
			float var1 = this.size;
			HashSet var2 = new HashSet();
			int var3;
			int var4;
			int var5;
			double var15;
			double var17;
			double var19;

			for (var3 = 0; var3 < this.field_77289_h; ++var3) {
				for (var4 = 0; var4 < this.field_77289_h; ++var4) {
					for (var5 = 0; var5 < this.field_77289_h; ++var5) {
						if (var3 == 0 || var3 == this.field_77289_h - 1 || var4 == 0 || var4 == this.field_77289_h - 1
								|| var5 == 0 || var5 == this.field_77289_h - 1) {
							double var6 = (double) ((float) var3 / ((float) this.field_77289_h - 1.0F) * 2.0F - 1.0F);
							double var8 = (double) ((float) var4 / ((float) this.field_77289_h - 1.0F) * 2.0F - 1.0F);
							double var10 = (double) ((float) var5 / ((float) this.field_77289_h - 1.0F) * 2.0F - 1.0F);
							double var12 = Math.sqrt(var6 * var6 + var8 * var8 + var10 * var10);
							var6 /= var12;
							var8 /= var12;
							var10 /= var12;
							float var14 = this.size * (0.7F + this.world.random.nextFloat() * 0.6F);
							var15 = this.posX;
							var17 = this.posY;
							var19 = this.posZ;

							for (float var21 = 0.3F; var14 > 0.0F; var14 -= var21 * 0.75F) {
								int var22 = MathHelper.floor(var15);
								int var23 = MathHelper.floor(var17);
								int var24 = MathHelper.floor(var19);
								int var25 = this.world.getTypeId(var22, var23, var24);

								if (var25 > 0) {
									Block var26 = Block.byId[var25];
									float var27 = this.source != null ? this.source.getBlockExplosionResistance(this,
											this.world, var22, var23, var24, var26)
											: var26.getExplosionResistance(this.source);
									var14 -= (var27 + 0.3F) * var21;
								}

								if (var14 > 0.0F && (this.source == null || this.source.shouldExplodeBlock(this,
										this.world, var22, var23, var24, var25, var14)) && var23 < 256 && var23 >= 0) {
									var2.add(new ChunkPosition(var22, var23, var24));
								}

								var15 += var6 * (double) var21;
								var17 += var8 * (double) var21;
								var19 += var10 * (double) var21;
							}
						}
					}
				}
			}

			this.blocks.addAll(var2);
			this.size *= 2.0F;
			var3 = MathHelper.floor(this.posX - (double) this.size - 1.0D);
			var4 = MathHelper.floor(this.posX + (double) this.size + 1.0D);
			var5 = MathHelper.floor(this.posY - (double) this.size - 1.0D);
			int var28 = MathHelper.floor(this.posY + (double) this.size + 1.0D);
			int var29 = MathHelper.floor(this.posZ - (double) this.size - 1.0D);
			int var30 = MathHelper.floor(this.posZ + (double) this.size + 1.0D);
			List var31 = this.world.getEntities(this.source, AxisAlignedBB.getAABBPool().getAABB((double) var3,
					(double) var5, (double) var29, (double) var4, (double) var28, (double) var30));
			Vec3D var32 = this.world.getVec3DPool().create(this.posX, this.posY, this.posZ);

			for (int var33 = 0; var33 < var31.size(); ++var33) {
				Entity var34 = (Entity) var31.get(var33);
				double var35 = var34.getDistance(this.posX, this.posY, this.posZ) / (double) this.size;

				if (var35 <= 1.0D) {
					var15 = var34.locX - this.posX;
					var17 = var34.locY + (double) var34.getHeadHeight() - this.posY;
					var19 = var34.locZ - this.posZ;
					double var37 = (double) MathHelper.sqrt(var15 * var15 + var17 * var17 + var19 * var19);

					if (var37 != 0.0D) {
						var15 /= var37;
						var17 /= var37;
						var19 /= var37;
						double var39 = (double) this.world.a(var32, var34.boundingBox);
						double var41 = (1.0D - var35) * var39;
						CraftEntity var50 = var34 == null ? null : var34.getBukkitEntity();
						float var43 = (float) ((int) ((var41 * var41 + var41) / 2.0D * 8.0D * (double) this.size
								+ 1.0D));

						if (var50 != null) {
							if (this.source == null) {
								EntityDamageByBlockEvent var44 = new EntityDamageByBlockEvent(
										(org.bukkit.block.Block) null, var50,
										EntityDamageEvent.DamageCause.BLOCK_EXPLOSION, (double) var43);
								Bukkit.getPluginManager().callEvent(var44);

								if (!var44.isCancelled()) {
									var50.setLastDamageCause(var44);
									var34.attackEntityFrom(DamageSource.explosion(this), (float) var44.getDamage());
									double var45 = EnchantmentProtection.func_92092_a(var34, var41);
									var34.motX += var15 * var45;
									var34.motY += var17 * var45;
									var34.motZ += var19 * var45;

									if (var34 instanceof EntityHuman) {
										this.field_77288_k.put((EntityHuman) var34, this.world.getVec3DPool()
												.create(var15 * var41, var17 * var41, var19 * var41));
									}
								}
							} else {
								CraftEntity var49 = this.source.getBukkitEntity();
								EntityDamageEvent.DamageCause var47;

								if (var49 instanceof TNTPrimed) {
									var47 = EntityDamageEvent.DamageCause.BLOCK_EXPLOSION;
								} else {
									var47 = EntityDamageEvent.DamageCause.ENTITY_EXPLOSION;
								}

								EntityDamageByEntityEvent var48 = new EntityDamageByEntityEvent(var49, var50, var47,
										(double) var43);
								Bukkit.getPluginManager().callEvent(var48);

								if (!var48.isCancelled()) {
									var34.getBukkitEntity().setLastDamageCause(var48);
									var34.attackEntityFrom(DamageSource.explosion(this), (float) var48.getDamage());
									var34.motX += var15 * var41;
									var34.motY += var17 * var41;
									var34.motZ += var19 * var41;

									if (var34 instanceof EntityHuman) {
										this.field_77288_k.put((EntityHuman) var34, this.world.getVec3DPool()
												.create(var15 * var41, var17 * var41, var19 * var41));
									}
								}
							}
						}
					}
				}
			}

			this.size = var1;
		}
	}

	/**
	 * Does the second part of the explosion (sound, particles, drop spawn)
	 */
	public void doExplosionB(boolean par1) {
		this.world.makeSound(this.posX, this.posY, this.posZ, "random.explode", 4.0F,
				(1.0F + (this.world.random.nextFloat() - this.world.random.nextFloat()) * 0.2F) * 0.7F);

		if (this.size >= 2.0F && this.isSmoking) {
			this.world.addParticle("hugeexplosion", this.posX, this.posY, this.posZ, 1.0D, 0.0D, 0.0D);
		} else {
			this.world.addParticle("largeexplode", this.posX, this.posY, this.posZ, 1.0D, 0.0D, 0.0D);
		}

		Iterator var10;
		ChunkPosition var11;
		int var12;
		int var13;
		int var14;
		int var15;

		if (this.isSmoking) {
			CraftWorld var2 = this.world.getWorld();
			CraftEntity var3 = this.source == null ? null : this.source.getBukkitEntity();
			Location var4 = new Location(var2, this.posX, this.posY, this.posZ);
			ArrayList var5 = new ArrayList();
			org.bukkit.block.Block var8;

			for (int var6 = this.blocks.size() - 1; var6 >= 0; --var6) {
				ChunkPosition var7 = (ChunkPosition) this.blocks.get(var6);
				var8 = var2.getBlockAt(var7.x, var7.y, var7.z);

				if (var8.getType() != org.bukkit.Material.AIR) {
					var5.add(var8);
				}
			}

			EntityExplodeEvent var33 = new EntityExplodeEvent(var3, var4, var5, 0.3F);
			this.world.getServer().getPluginManager().callEvent(var33);
			this.blocks.clear();
			Iterator var34 = var33.blockList().iterator();

			while (var34.hasNext()) {
				var8 = (org.bukkit.block.Block) var34.next();
				ChunkPosition var9 = new ChunkPosition(var8.getX(), var8.getY(), var8.getZ());
				this.blocks.add(var9);
			}

			if (var33.isCancelled()) {
				this.wasCanceled = true;
				return;
			}

			var10 = this.blocks.iterator();

			while (var10.hasNext()) {
				var11 = (ChunkPosition) var10.next();
				var12 = var11.x;
				var13 = var11.y;
				var14 = var11.z;
				var15 = this.world.getTypeId(var12, var13, var14);
				this.world.spigotConfig.antiXrayInstance.updateNearbyBlocks(this.world, var12, var13, var14);

				if (par1) {
					double var16 = (double) ((float) var12 + this.world.random.nextFloat());
					double var18 = (double) ((float) var13 + this.world.random.nextFloat());
					double var20 = (double) ((float) var14 + this.world.random.nextFloat());
					double var22 = var16 - this.posX;
					double var24 = var18 - this.posY;
					double var26 = var20 - this.posZ;
					double var28 = (double) MathHelper.sqrt(var22 * var22 + var24 * var24 + var26 * var26);
					var22 /= var28;
					var24 /= var28;
					var26 /= var28;
					double var30 = 0.5D / (var28 / (double) this.size + 0.1D);
					var30 *= (double) (this.world.random.nextFloat() * this.world.random.nextFloat() + 0.3F);
					var22 *= var30;
					var24 *= var30;
					var26 *= var30;
					this.world.addParticle("explode", (var16 + this.posX * 1.0D) / 2.0D,
							(var18 + this.posY * 1.0D) / 2.0D, (var20 + this.posZ * 1.0D) / 2.0D, var22, var24, var26);
					this.world.addParticle("smoke", var16, var18, var20, var22, var24, var26);
				}

				if (var15 > 0) {
					Block var35 = Block.byId[var15];

					if (var35.canDropFromExplosion(this)) {
						var35.dropNaturally(this.world, var12, var13, var14, this.world.getData(var12, var13, var14),
								var33.getYield(), 0);
					}

					this.world.setTypeIdAndData(var12, var13, var14, 0, 0, 3);
					var35.wasExploded(this.world, var12, var13, var14, this);
				}
			}
		}

		if (this.isFlaming) {
			var10 = this.blocks.iterator();

			while (var10.hasNext()) {
				var11 = (ChunkPosition) var10.next();
				var12 = var11.x;
				var13 = var11.y;
				var14 = var11.z;
				var15 = this.world.getTypeId(var12, var13, var14);
				int var32 = this.world.getTypeId(var12, var13 - 1, var14);

				if (var15 == 0 && Block.opaqueCubeLookup[var32] && this.explosionRNG.nextInt(3) == 0
						&& !CraftEventFactory.callBlockIgniteEvent(this.world, var12, var13, var14, this)
								.isCancelled()) {
					this.world.setTypeIdUpdate(var12, var13, var14, Block.FIRE.id);
				}
			}
		}
	}

	public Map func_77277_b() {
		return this.field_77288_k;
	}

	public EntityLiving c() {
		return this.source == null ? null
				: (this.source instanceof EntityTNTPrimed ? ((EntityTNTPrimed) this.source).getSource()
						: (this.source instanceof EntityLiving ? (EntityLiving) this.source : null));
	}
}
