package net.minecraft.server.v1_6_R3;

public enum EnumSkyBlock {
	SKY("Sky", 0, 15), BLOCK("Block", 1, 0);
	public final int defaultLightValue;

	private EnumSkyBlock(String var1, int var2, int var3) {
		this.defaultLightValue = var3;
	}

	private EnumSkyBlock(int par3) {
		this.defaultLightValue = par3;
	}
}
