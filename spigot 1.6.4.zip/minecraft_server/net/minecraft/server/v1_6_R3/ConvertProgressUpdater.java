package net.minecraft.server.v1_6_R3;

public class ConvertProgressUpdater implements IProgressUpdate
{
    private long b;

    final MinecraftServer a;

    public ConvertProgressUpdater(MinecraftServer var1)
    {
        this.a = var1;
        this.b = MinecraftServer.aq();
    }

    /**
     * Shows the 'Saving level' string.
     */
    public void displaySavingString(String var1) {}

    /**
     * Updates the progress bar on the loading screen to the specified amount. Args: loadProgress
     */
    public void setLoadingProgress(int var1)
    {
        if (MinecraftServer.aq() - this.b >= 1000L)
        {
            this.b = MinecraftServer.aq();
            this.a.getLogger().info("Converting... " + var1 + "%");
        }
    }

    /**
     * Displays a string on the loading screen supposed to indicate what is being done currently.
     */
    public void displayLoadingString(String var1) {}
}
