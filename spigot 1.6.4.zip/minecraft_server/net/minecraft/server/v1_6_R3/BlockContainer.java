package net.minecraft.server.v1_6_R3;

public abstract class BlockContainer extends Block implements IContainer
{
    protected BlockContainer(int par1, Material par2Material)
    {
        super(par1, par2Material);
        this.isTileEntity = true;
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        super.onPlace(var1, var2, var3, var4);
    }

    public void remove(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        super.remove(var1, var2, var3, var4, var5, var6);
        var1.removeBlockTileEntity(var2, var3, var4);
    }

    /**
     * Called when the block receives a BlockEvent - see World.addBlockEvent. By default, passes it on to the tile
     * entity at this location. Args: world, x, y, z, blockID, EventID, event parameter
     */
    public boolean onBlockEventReceived(World par1World, int par2, int par3, int par4, int par5, int par6)
    {
        super.onBlockEventReceived(par1World, par2, par3, par4, par5, par6);
        TileEntity var7 = par1World.getTileEntity(par2, par3, par4);
        return var7 != null ? var7.receiveClientEvent(par5, par6) : false;
    }
}
