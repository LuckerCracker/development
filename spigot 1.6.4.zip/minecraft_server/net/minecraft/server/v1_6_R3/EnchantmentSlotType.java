package net.minecraft.server.v1_6_R3;

public enum EnchantmentSlotType {
	ALL("all", 0), ARMOR("armor", 1), ARMOR_FEET("armor_feet", 2), ARMOR_LEGS("armor_legs", 3), ARMOR_TORSO(
			"armor_torso", 4), ARMOR_HEAD("armor_head", 5), WEAPON("weapon", 6), DIGGER("digger", 7), BOW("bow", 8);
	private EnchantmentSlotType(String var1, int var2) {
	}

	public boolean canEnchant(Item var1) {
		if (this == ALL) {
			return true;
		} else if (var1 instanceof ItemArmor) {
			if (this == ARMOR) {
				return true;
			} else {
				ItemArmor var2 = (ItemArmor) var1;
				return var2.armorType == 0 ? this == ARMOR_HEAD
						: (var2.armorType == 2 ? this == ARMOR_LEGS
								: (var2.armorType == 1 ? this == ARMOR_TORSO
										: (var2.armorType == 3 ? this == ARMOR_FEET : false)));
			}
		} else {
			return var1 instanceof ItemSword ? this == WEAPON
					: (var1 instanceof ItemTool ? this == DIGGER : (var1 instanceof ItemBow ? this == BOW : false));
		}
	}
}
