package net.minecraft.server.v1_6_R3;

import com.google.common.collect.Maps;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class AttributeModifiable implements AttributeInstance {
	private final AttributeMapBase a;
	private final IAttribute b;
	private final Map c = Maps.newHashMap();
	private final Map d = Maps.newHashMap();
	private final Map e = Maps.newHashMap();
	private double f;
	private boolean g = true;
	private double h;

	public AttributeModifiable(AttributeMapBase var1, IAttribute var2) {
		this.a = var1;
		this.b = var2;
		this.f = var2.getDefaultValue();

		for (int var3 = 0; var3 < 3; ++var3) {
			this.c.put(Integer.valueOf(var3), new HashSet());
		}
	}

	public IAttribute a() {
		return this.b;
	}

	public double getBaseValue() {
		return this.f;
	}

	public void setValue(double var1) {
		if (var1 != this.getBaseValue()) {
			this.f = var1;
			this.f();
		}
	}

	public Collection a(int var1) {
		return (Collection) this.c.get(Integer.valueOf(var1));
	}

	public Collection func_111122_c() {
		HashSet var1 = new HashSet();

		for (int var2 = 0; var2 < 3; ++var2) {
			var1.addAll(this.a(var2));
		}

		return var1;
	}

	/**
	 * Returns attribute modifier, if any, by the given UUID
	 */
	public AttributeModifier getModifier(UUID var1) {
		return (AttributeModifier) this.e.get(var1);
	}

	public void applyModifier(AttributeModifier var1) {
		if (this.getModifier(var1.getID()) != null) {
			throw new IllegalArgumentException("Modifier is already applied on this attribute!");
		} else {
			Object var2 = (Set) this.d.get(var1.getName());

			if (var2 == null) {
				var2 = new HashSet();
				this.d.put(var1.getName(), var2);
			}

			((Set) this.c.get(Integer.valueOf(var1.getOperation()))).add(var1);
			((Set) var2).add(var1);
			this.e.put(var1.getID(), var1);
			this.f();
		}
	}

	private void f() {
		this.g = true;
		this.a.a(this);
	}

	public void removeModifier(AttributeModifier var1) {
		for (int var2 = 0; var2 < 3; ++var2) {
			Set var3 = (Set) this.c.get(Integer.valueOf(var2));
			var3.remove(var1);
		}

		Set var4 = (Set) this.d.get(var1.getName());

		if (var4 != null) {
			var4.remove(var1);

			if (var4.isEmpty()) {
				this.d.remove(var1.getName());
			}
		}

		this.e.remove(var1.getID());
		this.f();
	}

	public double getValue() {
		if (this.g) {
			this.h = this.g();
			this.g = false;
		}

		return this.h;
	}

	private double g() {
		double var1 = this.getBaseValue();
		AttributeModifier var4;

		for (Iterator var3 = this.a(0).iterator(); var3.hasNext(); var1 += var4.getAmount()) {
			var4 = (AttributeModifier) var3.next();
		}

		double var5 = var1;
		Iterator var7;
		AttributeModifier var8;

		for (var7 = this.a(1).iterator(); var7.hasNext(); var5 += var1 * var8.getAmount()) {
			var8 = (AttributeModifier) var7.next();
		}

		for (var7 = this.a(2).iterator(); var7.hasNext(); var5 *= 1.0D + var8.getAmount()) {
			var8 = (AttributeModifier) var7.next();
		}

		return this.b.a(var5);
	}
}
