package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;

public class AchievementList
{
    /** Is the smallest column used to display a achievement on the GUI. */
    public static int minDisplayColumn;

    /** Is the smallest row used to display a achievement on the GUI. */
    public static int minDisplayRow;

    /** Is the biggest column used to display a achievement on the GUI. */
    public static int maxDisplayColumn;

    /** Is the biggest row used to display a achievement on the GUI. */
    public static int maxDisplayRow;

    /** The list holding all achievements */
    public static List achievementList = new ArrayList();

    /** Is the 'open inventory' achievement. */
    public static Achievement openInventory = (new Achievement(0, "openInventory", 0, 0, Item.BOOK, (Achievement)null)).setIndependent().registerAchievement();

    /** Is the 'getting wood' achievement. */
    public static Achievement mineWood = (new Achievement(1, "mineWood", 2, 1, Block.LOG, openInventory)).registerAchievement();

    /** Is the 'benchmarking' achievement. */
    public static Achievement buildWorkBench = (new Achievement(2, "buildWorkBench", 4, -1, Block.WORKBENCH, mineWood)).registerAchievement();

    /** Is the 'time to mine' achievement. */
    public static Achievement buildPickaxe = (new Achievement(3, "buildPickaxe", 4, 2, Item.WOOD_PICKAXE, buildWorkBench)).registerAchievement();

    /** Is the 'hot topic' achievement. */
    public static Achievement buildFurnace = (new Achievement(4, "buildFurnace", 3, 4, Block.FURNACE, buildPickaxe)).registerAchievement();

    /** Is the 'acquire hardware' achievement. */
    public static Achievement acquireIron = (new Achievement(5, "acquireIron", 1, 4, Item.IRON_INGOT, buildFurnace)).registerAchievement();

    /** Is the 'time to farm' achievement. */
    public static Achievement buildHoe = (new Achievement(6, "buildHoe", 2, -3, Item.WOOD_HOE, buildWorkBench)).registerAchievement();

    /** Is the 'bake bread' achievement. */
    public static Achievement makeBread = (new Achievement(7, "makeBread", -1, -3, Item.BREAD, buildHoe)).registerAchievement();

    /** Is the 'the lie' achievement. */
    public static Achievement bakeCake = (new Achievement(8, "bakeCake", 0, -5, Item.CAKE, buildHoe)).registerAchievement();

    /** Is the 'getting a upgrade' achievement. */
    public static Achievement buildBetterPickaxe = (new Achievement(9, "buildBetterPickaxe", 6, 2, Item.STONE_PICKAXE, buildPickaxe)).registerAchievement();

    /** Is the 'delicious fish' achievement. */
    public static Achievement cookFish = (new Achievement(10, "cookFish", 2, 6, Item.COOKED_FISH, buildFurnace)).registerAchievement();

    /** Is the 'on a rail' achievement */
    public static Achievement onARail = (new Achievement(11, "onARail", 2, 3, Block.RAILS, acquireIron)).setSpecial().registerAchievement();

    /** Is the 'time to strike' achievement. */
    public static Achievement buildSword = (new Achievement(12, "buildSword", 6, -1, Item.WOOD_SWORD, buildWorkBench)).registerAchievement();

    /** Is the 'monster hunter' achievement. */
    public static Achievement killEnemy = (new Achievement(13, "killEnemy", 8, -1, Item.BONE, buildSword)).registerAchievement();

    /** is the 'cow tipper' achievement. */
    public static Achievement killCow = (new Achievement(14, "killCow", 7, -3, Item.LEATHER, buildSword)).registerAchievement();

    /** Is the 'when pig fly' achievement. */
    public static Achievement flyPig = (new Achievement(15, "flyPig", 8, -4, Item.SADDLE, killCow)).setSpecial().registerAchievement();

    /** The achievement for killing a Skeleton from 50 meters aways. */
    public static Achievement snipeSkeleton = (new Achievement(16, "snipeSkeleton", 7, 0, Item.BOW, killEnemy)).setSpecial().registerAchievement();

    /** Is the 'DIAMONDS!' achievement */
    public static Achievement diamonds = (new Achievement(17, "diamonds", -1, 5, Item.DIAMOND, acquireIron)).registerAchievement();

    /** Is the 'We Need to Go Deeper' achievement */
    public static Achievement portal = (new Achievement(18, "portal", -1, 7, Block.OBSIDIAN, diamonds)).registerAchievement();

    /** Is the 'Return to Sender' achievement */
    public static Achievement ghast = (new Achievement(19, "ghast", -4, 8, Item.GHAST_TEAR, portal)).setSpecial().registerAchievement();

    /** Is the 'Into Fire' achievement */
    public static Achievement blazeRod = (new Achievement(20, "blazeRod", 0, 9, Item.BLAZE_ROD, portal)).registerAchievement();

    /** Is the 'Local Brewery' achievement */
    public static Achievement potion = (new Achievement(21, "potion", 2, 8, Item.POTION, blazeRod)).registerAchievement();

    /** Is the 'The End?' achievement */
    public static Achievement theEnd = (new Achievement(22, "theEnd", 3, 10, Item.EYE_OF_ENDER, blazeRod)).setSpecial().registerAchievement();

    /** Is the 'The End.' achievement */
    public static Achievement theEnd2 = (new Achievement(23, "theEnd2", 4, 13, Block.DRAGON_EGG, theEnd)).setSpecial().registerAchievement();

    /** Is the 'Enchanter' achievement */
    public static Achievement enchantments = (new Achievement(24, "enchantments", -4, 4, Block.ENCHANTMENT_TABLE, diamonds)).registerAchievement();
    public static Achievement overkill = (new Achievement(25, "overkill", -4, 1, Item.DIAMOND_SWORD, enchantments)).setSpecial().registerAchievement();

    /** Is the 'Librarian' achievement */
    public static Achievement bookcase = (new Achievement(26, "bookcase", -3, 6, Block.BOOKSHELF, enchantments)).registerAchievement();

    /**
     * A stub functions called to make the static initializer for this class run.
     */
    public static void init() {}
}
