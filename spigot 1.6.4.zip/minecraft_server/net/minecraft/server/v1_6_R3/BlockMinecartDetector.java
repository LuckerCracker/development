package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;
import org.bukkit.event.block.BlockRedstoneEvent;

public class BlockMinecartDetector extends BlockMinecartTrackAbstract
{
    public BlockMinecartDetector(int i)
    {
        super(i, true);
        this.setTickRandomly(true);
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World world)
    {
        return 20;
    }

    public boolean isPowerSource()
    {
        return true;
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
    {
        if (!world.isStatic)
        {
            int l = world.getData(i, j, k);

            if ((l & 8) == 0)
            {
                this.d(world, i, j, k, l);
            }
        }
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        if (!world.isStatic)
        {
            int l = world.getData(i, j, k);

            if ((l & 8) != 0)
            {
                this.d(world, i, j, k, l);
            }
        }
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return (iblockaccess.getData(i, j, k) & 8) != 0 ? 15 : 0;
    }

    /**
     * Returns true if the block is emitting direct/strong redstone power on the specified side. Args: World, X, Y, Z,
     * side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingStrongPower(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return (iblockaccess.getData(i, j, k) & 8) == 0 ? 0 : (l == 1 ? 15 : 0);
    }

    private void d(World world, int i, int j, int k, int l)
    {
        boolean flag = (l & 8) != 0;
        boolean flag1 = false;
        float f = 0.125F;
        List list = world.getEntitiesWithinAABB(EntityMinecartAbstract.class, AxisAlignedBB.getAABBPool().getAABB((double)((float)i + f), (double)j, (double)((float)k + f), (double)((float)(i + 1) - f), (double)((float)(j + 1) - f), (double)((float)(k + 1) - f)));

        if (!list.isEmpty())
        {
            flag1 = true;
        }

        if (flag != flag1)
        {
            org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
            BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, flag ? 15 : 0, flag1 ? 15 : 0);
            world.getServer().getPluginManager().callEvent(eventRedstone);
            flag1 = eventRedstone.getNewCurrent() > 0;
        }

        if (flag1 && !flag)
        {
            world.setData(i, j, k, l | 8, 3);
            world.applyPhysics(i, j, k, this.id);
            world.applyPhysics(i, j - 1, k, this.id);
            world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
        }

        if (!flag1 && flag)
        {
            world.setData(i, j, k, l & 7, 3);
            world.applyPhysics(i, j, k, this.id);
            world.applyPhysics(i, j - 1, k, this.id);
            world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
        }

        if (flag1)
        {
            world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
        }

        world.func_96440_m(i, j, k, this.id);
    }

    public void onPlace(World world, int i, int j, int k)
    {
        super.onPlace(world, i, j, k);
        this.d(world, i, j, k, world.getData(i, j, k));
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World world, int i, int j, int k, int l)
    {
        if ((world.getData(i, j, k) & 8) > 0)
        {
            float f = 0.125F;
            List list = world.selectEntitiesWithinAABB(EntityMinecartAbstract.class, AxisAlignedBB.getAABBPool().getAABB((double)((float)i + f), (double)j, (double)((float)k + f), (double)((float)(i + 1) - f), (double)((float)(j + 1) - f), (double)((float)(k + 1) - f)), IEntitySelector.selectInventories);

            if (list.size() > 0)
            {
                return Container.calcRedstoneFromInventory((IInventory)list.get(0));
            }
        }

        return 0;
    }
}
