package net.minecraft.server.v1_6_R3;

public class EntityMinecartTNT extends EntityMinecartAbstract
{
    private int fuse = -1;

    public EntityMinecartTNT(World par1World)
    {
        super(par1World);
    }

    public EntityMinecartTNT(World par1World, double par2, double par4, double par6)
    {
        super(par1World, par2, par4, par6);
    }

    public int getType()
    {
        return 3;
    }

    public Block getDefaultDisplayTile()
    {
        return Block.TNT;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (this.fuse > 0)
        {
            --this.fuse;
            this.world.addParticle("smoke", this.locX, this.locY + 0.5D, this.locZ, 0.0D, 0.0D, 0.0D);
        }
        else if (this.fuse == 0)
        {
            this.explodeCart(this.motX * this.motX + this.motZ * this.motZ);
        }

        if (this.positionChanged)
        {
            double var1 = this.motX * this.motX + this.motZ * this.motZ;

            if (var1 >= 0.009999999776482582D)
            {
                this.explodeCart(var1);
            }
        }
    }

    public void killMinecart(DamageSource par1DamageSource)
    {
        super.a(par1DamageSource);
        double var2 = this.motX * this.motX + this.motZ * this.motZ;

        if (!par1DamageSource.isExplosion())
        {
            this.entityDropItem(new ItemStack(Block.TNT, 1), 0.0F);
        }

        if (par1DamageSource.isFireDamage() || par1DamageSource.isExplosion() || var2 >= 0.009999999776482582D)
        {
            this.explodeCart(var2);
        }
    }

    /**
     * Makes the minecart explode.
     */
    protected void explodeCart(double par1)
    {
        if (!this.world.isStatic)
        {
            double var3 = Math.sqrt(par1);

            if (var3 > 5.0D)
            {
                var3 = 5.0D;
            }

            this.world.explode(this, this.locX, this.locY, this.locZ, (float)(4.0D + this.random.nextDouble() * 1.5D * var3), true);
            this.die();
        }
    }

    /**
     * Called when the mob is falling. Calculates and applies fall damage.
     */
    protected void fall(float par1)
    {
        if (par1 >= 3.0F)
        {
            float var2 = par1 / 10.0F;
            this.explodeCart((double)(var2 * var2));
        }

        super.fall(par1);
    }

    /**
     * Called every tick the minecart is on an activator rail. Args: x, y, z, is the rail receiving power
     */
    public void onActivatorRailPass(int par1, int par2, int par3, boolean par4)
    {
        if (par4 && this.fuse < 0)
        {
            this.ignite();
        }
    }

    /**
     * Ignites this TNT cart.
     */
    public void ignite()
    {
        this.fuse = 80;

        if (!this.world.isStatic)
        {
            this.world.broadcastEntityEffect(this, (byte)10);
            this.world.makeSound(this, "random.fuse", 1.0F, 1.0F);
        }
    }

    /**
     * Returns true if the TNT minecart is ignited.
     */
    public boolean isIgnited()
    {
        return this.fuse > -1;
    }

    /**
     * Gets a block's resistance to this entity's explosion. Used to make rails immune to TNT minecarts' explosions and
     * Wither skulls more destructive.
     */
    public float getBlockExplosionResistance(Explosion par1Explosion, World par2World, int par3, int par4, int par5, Block par6Block)
    {
        return this.isIgnited() && (BlockMinecartTrackAbstract.e_(par6Block.id) || BlockMinecartTrackAbstract.d_(par2World, par3, par4 + 1, par5)) ? 0.0F : super.getBlockExplosionResistance(par1Explosion, par2World, par3, par4, par5, par6Block);
    }

    public boolean shouldExplodeBlock(Explosion par1Explosion, World par2World, int par3, int par4, int par5, int par6, float par7)
    {
        return this.isIgnited() && (BlockMinecartTrackAbstract.e_(par6) || BlockMinecartTrackAbstract.d_(par2World, par3, par4 + 1, par5)) ? false : super.shouldExplodeBlock(par1Explosion, par2World, par3, par4, par5, par6, par7);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);

        if (par1NBTTagCompound.hasKey("TNTFuse"))
        {
            this.fuse = par1NBTTagCompound.getInt("TNTFuse");
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setInt("TNTFuse", this.fuse);
    }
}
