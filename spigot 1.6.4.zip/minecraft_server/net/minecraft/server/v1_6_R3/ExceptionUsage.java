package net.minecraft.server.v1_6_R3;

public class ExceptionUsage extends ExceptionInvalidSyntax
{
    public ExceptionUsage(String var1, Object ... var2)
    {
        super(var1, var2);
    }
}
