package net.minecraft.server.v1_6_R3;

import java.util.Collection;
import java.util.UUID;

public interface AttributeInstance
{
    IAttribute a();

    double getBaseValue();

    void setValue(double var1);

    Collection func_111122_c();

    /**
     * Returns attribute modifier, if any, by the given UUID
     */
    AttributeModifier getModifier(UUID var1);

    void applyModifier(AttributeModifier var1);

    void removeModifier(AttributeModifier var1);

    double getValue();
}
