package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandBanList extends CommandAbstract
{
    public String getCommandName()
    {
        return "banlist";
    }

    public int a()
    {
        return 3;
    }

    public boolean a(ICommandListener var1)
    {
        return (MinecraftServer.getServer().getPlayerList().getIPBans().isEnabled() || MinecraftServer.getServer().getPlayerList().getNameBans().isEnabled()) && super.a(var1);
    }

    public String c(ICommandListener var1)
    {
        return "commands.banlist.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length >= 1 && var2[0].equalsIgnoreCase("ips"))
        {
            var1.sendMessage(ChatMessage.b("commands.banlist.ips", new Object[] {Integer.valueOf(MinecraftServer.getServer().getPlayerList().getIPBans().getEntries().size())}));
            var1.sendMessage(ChatMessage.d(a(MinecraftServer.getServer().getPlayerList().getIPBans().getEntries().keySet().toArray())));
        }
        else
        {
            var1.sendMessage(ChatMessage.b("commands.banlist.players", new Object[] {Integer.valueOf(MinecraftServer.getServer().getPlayerList().getNameBans().getEntries().size())}));
            var1.sendMessage(ChatMessage.d(a(MinecraftServer.getServer().getPlayerList().getNameBans().getEntries().keySet().toArray())));
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, new String[] {"players", "ips"}): null;
    }
}
