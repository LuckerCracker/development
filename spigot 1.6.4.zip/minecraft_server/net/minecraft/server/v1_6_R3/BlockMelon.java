package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockMelon extends Block
{
    protected BlockMelon(int par1)
    {
        super(par1, Material.PUMPKIN);
        this.a(CreativeModeTab.b);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Item.MELON.id;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 3 + par1Random.nextInt(5);
    }

    public int getDropCount(int var1, Random var2)
    {
        int var3 = this.quantityDropped(var2) + var2.nextInt(1 + var1);

        if (var3 > 9)
        {
            var3 = 9;
        }

        return var3;
    }
}
