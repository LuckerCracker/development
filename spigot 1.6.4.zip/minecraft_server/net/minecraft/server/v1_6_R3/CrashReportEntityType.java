package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportEntityType implements Callable
{
    final Entity a;

    CrashReportEntityType(Entity var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return EntityTypes.b(this.a) + " (" + this.a.getClass().getCanonicalName() + ")";
    }

    public Object call()
    {
        return this.a();
    }
}
