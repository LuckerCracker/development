package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CommandWhitelist extends CommandAbstract
{
    public String getCommandName()
    {
        return "whitelist";
    }

    public int a()
    {
        return 3;
    }

    public String c(ICommandListener var1)
    {
        return "commands.whitelist.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length >= 1)
        {
            if (var2[0].equals("on"))
            {
                MinecraftServer.getServer().getPlayerList().setHasWhitelist(true);
                a(var1, "commands.whitelist.enabled", new Object[0]);
                return;
            }

            if (var2[0].equals("off"))
            {
                MinecraftServer.getServer().getPlayerList().setHasWhitelist(false);
                a(var1, "commands.whitelist.disabled", new Object[0]);
                return;
            }

            if (var2[0].equals("list"))
            {
                var1.sendMessage(ChatMessage.b("commands.whitelist.list", new Object[] {Integer.valueOf(MinecraftServer.getServer().getPlayerList().getWhitelisted().size()), Integer.valueOf(MinecraftServer.getServer().getPlayerList().getSeenPlayers().length)}));
                Set var3 = MinecraftServer.getServer().getPlayerList().getWhitelisted();
                var1.sendMessage(ChatMessage.d(a(var3.toArray(new String[var3.size()]))));
                return;
            }

            if (var2[0].equals("add"))
            {
                if (var2.length < 2)
                {
                    throw new ExceptionUsage("commands.whitelist.add.usage", new Object[0]);
                }

                MinecraftServer.getServer().getPlayerList().addWhitelist(var2[1]);
                a(var1, "commands.whitelist.add.success", new Object[] {var2[1]});
                return;
            }

            if (var2[0].equals("remove"))
            {
                if (var2.length < 2)
                {
                    throw new ExceptionUsage("commands.whitelist.remove.usage", new Object[0]);
                }

                MinecraftServer.getServer().getPlayerList().removeWhitelist(var2[1]);
                a(var1, "commands.whitelist.remove.success", new Object[] {var2[1]});
                return;
            }

            if (var2[0].equals("reload"))
            {
                MinecraftServer.getServer().getPlayerList().reloadWhitelist();
                a(var1, "commands.whitelist.reloaded", new Object[0]);
                return;
            }
        }

        throw new ExceptionUsage("commands.whitelist.usage", new Object[0]);
    }

    public List a(ICommandListener var1, String[] var2)
    {
        if (var2.length == 1)
        {
            return a(var2, new String[] {"on", "off", "list", "add", "remove", "reload"});
        }
        else
        {
            if (var2.length == 2)
            {
                if (var2[0].equals("add"))
                {
                    String[] var3 = MinecraftServer.getServer().getPlayerList().getSeenPlayers();
                    ArrayList var4 = new ArrayList();
                    String var5 = var2[var2.length - 1];
                    String[] var6 = var3;
                    int var7 = var3.length;

                    for (int var8 = 0; var8 < var7; ++var8)
                    {
                        String var9 = var6[var8];

                        if (a(var5, var9) && !MinecraftServer.getServer().getPlayerList().getWhitelisted().contains(var9))
                        {
                            var4.add(var9);
                        }
                    }

                    return var4;
                }

                if (var2[0].equals("remove"))
                {
                    return a(var2, MinecraftServer.getServer().getPlayerList().getWhitelisted());
                }
            }

            return null;
        }
    }
}
