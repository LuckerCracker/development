package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.block.EntityBlockFormEvent;

public class EntitySnowman extends EntityGolem implements IRangedEntity
{
    public EntitySnowman(World par1World)
    {
        super(par1World);
        this.setSize(0.4F, 1.8F);
        this.getNavigation().a(true);
        this.goalSelector.a(1, new PathfinderGoalArrowAttack(this, 1.25D, 20, 10.0F));
        this.goalSelector.a(2, new PathfinderGoalRandomStroll(this, 1.0D));
        this.goalSelector.a(3, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 6.0F));
        this.goalSelector.a(4, new PathfinderGoalRandomLookaround(this));
        this.targetSelector.a(1, new PathfinderGoalNearestAttackableTarget(this, EntityInsentient.class, 0, true, false, IMonster.a));
    }

    /**
     * Returns true if the newer Entity AI code should be run
     */
    public boolean isAIEnabled()
    {
        return true;
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.a).setValue(4.0D);
        this.getAttributeInstance(GenericAttributes.d).setValue(0.20000000298023224D);
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
        super.onLivingUpdate();

        if (this.isWet())
        {
            this.attackEntityFrom(DamageSource.DROWN, 1.0F);
        }

        int var1 = MathHelper.floor(this.locX);
        int var2 = MathHelper.floor(this.locZ);

        if (this.world.getBiome(var1, var2).getFloatTemperature() > 1.0F)
        {
            this.attackEntityFrom(CraftEventFactory.MELTING, 1.0F);
        }

        for (var1 = 0; var1 < 4; ++var1)
        {
            var2 = MathHelper.floor(this.locX + (double)((float)(var1 % 2 * 2 - 1) * 0.25F));
            int var3 = MathHelper.floor(this.locY);
            int var4 = MathHelper.floor(this.locZ + (double)((float)(var1 / 2 % 2 * 2 - 1) * 0.25F));

            if (this.world.getTypeId(var2, var3, var4) == 0 && this.world.getBiome(var2, var4).getFloatTemperature() < 0.8F && Block.SNOW.canPlace(this.world, var2, var3, var4))
            {
                BlockState var5 = this.world.getWorld().getBlockAt(var2, var3, var4).getState();
                var5.setTypeId(Block.SNOW.id);
                EntityBlockFormEvent var6 = new EntityBlockFormEvent(this.getBukkitEntity(), var5.getBlock(), var5);
                this.world.getServer().getPluginManager().callEvent(var6);

                if (!var6.isCancelled())
                {
                    var5.update(true);
                }
            }
        }
    }

    protected int getLootId()
    {
        return Item.SNOW_BALL.id;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        ArrayList loot = new ArrayList();
        int j = this.random.nextInt(16);

        if (j > 0)
        {
            loot.add(new org.bukkit.inventory.ItemStack(Item.SNOW_BALL.id, j));
        }

        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    public void a(EntityLiving entityliving, float f)
    {
        EntitySnowball entitysnowball = new EntitySnowball(this.world, this);
        double d0 = entityliving.locX - this.locX;
        double d1 = entityliving.locY + (double)entityliving.getHeadHeight() - 1.100000023841858D - entitysnowball.locY;
        double d2 = entityliving.locZ - this.locZ;
        float f1 = MathHelper.sqrt(d0 * d0 + d2 * d2) * 0.2F;
        entitysnowball.shoot(d0, d1 + (double)f1, d2, 1.6F, 12.0F);
        this.makeSound("random.bow", 1.0F, 1.0F / (this.getRNG().nextFloat() * 0.4F + 0.8F));
        this.world.addEntity(entitysnowball);
    }
}
