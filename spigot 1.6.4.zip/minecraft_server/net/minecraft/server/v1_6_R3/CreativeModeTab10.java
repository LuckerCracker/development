package net.minecraft.server.v1_6_R3;

final class CreativeModeTab10 extends CreativeModeTab
{
    CreativeModeTab10(int var1, String var2)
    {
        super(var1, var2);
    }
}
