package net.minecraft.server.v1_6_R3;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.craftbukkit.v1_6_R3.util.ShortConsoleLogFormatter;
import org.bukkit.craftbukkit.v1_6_R3.util.TerminalConsoleHandler;

public class ConsoleLogManager implements IConsoleLogManager
{
    private final Logger a;
    private final String b;
    private final String c;
    private final String d;
    public static Logger global = Logger.getLogger("");

    public ConsoleLogManager(String s, String s1, String s2)
    {
        this.a = Logger.getLogger(s);
        this.c = s;
        this.d = s1;
        this.b = s2;
        this.b();
    }

    private void b()
    {
        this.a.setUseParentHandlers(false);
        Handler[] ahandler = this.a.getHandlers();
        int i = ahandler.length;

        for (int consolelogformatter = 0; consolelogformatter < i; ++consolelogformatter)
        {
            Handler server = ahandler[consolelogformatter];
            this.a.removeHandler(server);
        }

        ConsoleLogFormatter var18 = new ConsoleLogFormatter(this, (EmptyClass3)null);
        MinecraftServer var19 = MinecraftServer.getServer();
        TerminalConsoleHandler consolehandler = new TerminalConsoleHandler(var19.reader);
        consolehandler.setFormatter(var18);
        this.a.addHandler(consolehandler);
        Handler[] exception = global.getHandlers();
        int tmpDir = exception.length;

        for (int homeDir = 0; homeDir < tmpDir; ++homeDir)
        {
            Handler parent = exception[homeDir];
            global.removeHandler(parent);
        }

        consolehandler.setFormatter(new ShortConsoleLogFormatter(var19));
        global.addHandler(consolehandler);

        try
        {
            String var20 = (String)var19.options.valueOf("log-pattern");
            String var21 = System.getProperty("java.io.tmpdir");
            String var22 = System.getProperty("user.home");

            if (var21 == null)
            {
                var21 = var22;
            }

            File var23 = (new File(var20)).getParentFile();
            StringBuilder fixedPattern = new StringBuilder();
            String parentPath = "";

            if (var23 != null)
            {
                parentPath = var23.getPath();
            }

            int j = 0;

            while (j < parentPath.length())
            {
                char limit = parentPath.charAt(j);
                char count = 0;

                if (j + 1 < parentPath.length())
                {
                    count = Character.toLowerCase(var20.charAt(j + 1));
                }

                if (limit == 37)
                {
                    if (count == 104)
                    {
                        j += 2;
                        fixedPattern.append(var22);
                        continue;
                    }

                    if (count == 116)
                    {
                        j += 2;
                        fixedPattern.append(var21);
                        continue;
                    }

                    if (count == 37)
                    {
                        j += 2;
                        fixedPattern.append("%%");
                        continue;
                    }

                    if (count != 0)
                    {
                        throw new IOException("log-pattern can only use %t and %h for directories, got %" + count);
                    }
                }

                fixedPattern.append(limit);
                ++j;
            }

            var23 = new File(fixedPattern.toString());

            if (var23 != null)
            {
                var23.mkdirs();
            }

            int var24 = ((Integer)var19.options.valueOf("log-limit")).intValue();
            int var25 = ((Integer)var19.options.valueOf("log-count")).intValue();
            boolean append = ((Boolean)var19.options.valueOf("log-append")).booleanValue();
            FileHandler filehandler = new FileHandler(var20, var24, var25, append);
            filehandler.setFormatter(var18);
            this.a.addHandler(filehandler);
            global.addHandler(filehandler);
        }
        catch (Exception var17)
        {
            this.a.log(Level.WARNING, "Failed to log " + this.c + " to " + this.b, var17);
        }
    }

    public Logger getLogger()
    {
        return this.a;
    }

    public void info(String s)
    {
        this.a.log(Level.INFO, s);
    }

    public void warning(String s)
    {
        this.a.log(Level.WARNING, s);
    }

    public void warning(String s, Object ... aobject)
    {
        this.a.log(Level.WARNING, s, aobject);
    }

    public void warning(String s, Throwable throwable)
    {
        this.a.log(Level.WARNING, s, throwable);
    }

    public void severe(String s)
    {
        this.a.log(Level.SEVERE, s);
    }

    public void severe(String s, Throwable throwable)
    {
        this.a.log(Level.SEVERE, s, throwable);
    }

    static String a(ConsoleLogManager consolelogmanager)
    {
        return consolelogmanager.d;
    }
}
