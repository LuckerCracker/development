package net.minecraft.server.v1_6_R3;

public class BiomeMushrooms extends BiomeBase
{
    public BiomeMushrooms(int var1)
    {
        super(var1);
        this.theBiomeDecorator.treesPerChunk = -100;
        this.theBiomeDecorator.flowersPerChunk = -100;
        this.theBiomeDecorator.grassPerChunk = -100;
        this.theBiomeDecorator.mushroomsPerChunk = 1;
        this.theBiomeDecorator.bigMushroomsPerChunk = 1;
        this.topBlock = (byte)Block.MYCEL.id;
        this.spawnableMonsterList.clear();
        this.spawnableCreatureList.clear();
        this.spawnableWaterCreatureList.clear();
        this.spawnableCreatureList.add(new BiomeMeta(EntityMushroomCow.class, 8, 4, 8));
    }
}
