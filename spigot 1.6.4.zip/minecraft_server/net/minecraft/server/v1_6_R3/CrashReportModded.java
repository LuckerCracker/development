package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportModded implements Callable
{
    final DedicatedServer a;

    CrashReportModded(DedicatedServer var1)
    {
        this.a = var1;
    }

    public String a()
    {
        String var1 = this.a.getServerModName();
        return !var1.equals("vanilla") ? "Definitely; Server brand changed to \'" + var1 + "\'" : "Unknown (can\'t tell)";
    }

    public Object call()
    {
        return this.a();
    }
}
