package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockCocoa extends BlockDirectional
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    public static final String[] displayOnCreativeTab = new String[] {"cocoa_0", "cocoa_1", "cocoa_2"};

    public BlockCocoa(int par1)
    {
        super(par1, Material.PLANT);
        this.setTickRandomly(true);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (!this.canBlockStay(par1World, par2, par3, par4))
        {
            this.dropBlockAsItem(par1World, par2, par3, par4, par1World.getData(par2, par3, par4), 0);
            par1World.setTypeIdAndData(par2, par3, par4, 0, 0, 2);
        }
        else if (par1World.random.nextInt(5) == 0)
        {
            int var6 = par1World.getData(par2, par3, par4);
            int var7 = func_72219_c(var6);

            if (var7 < 2)
            {
                ++var7;
                CraftEventFactory.handleBlockGrowEvent(par1World, par2, par3, par4, this.id, var7 << 2 | getDirection(var6));
            }
        }
    }

    /**
     * Can this block stay at this position.  Similar to canPlaceBlockAt except gets checked often with plants.
     */
    public boolean canBlockStay(World par1World, int par2, int par3, int par4)
    {
        int var5 = getDirection(par1World.getData(par2, par3, par4));
        par2 += Direction.offsetX[var5];
        par4 += Direction.offsetZ[var5];
        int var6 = par1World.getTypeId(par2, par3, par4);
        return var6 == Block.LOG.id && BlockLog.limitToValidMetadata(par1World.getData(par2, par3, par4)) == 3;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 28;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        this.updateShape(par1World, par2, par3, par4);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = iblockaccess.getData(i, j, k);
        int i1 = getDirection(l);
        int j1 = func_72219_c(l);
        int k1 = 4 + j1 * 2;
        int l1 = 5 + j1 * 2;
        float f = (float)k1 / 2.0F;

        switch (i1)
        {
            case 0:
                this.setBlockBounds((8.0F - f) / 16.0F, (12.0F - (float)l1) / 16.0F, (15.0F - (float)k1) / 16.0F, (8.0F + f) / 16.0F, 0.75F, 0.9375F);
                break;

            case 1:
                this.setBlockBounds(0.0625F, (12.0F - (float)l1) / 16.0F, (8.0F - f) / 16.0F, (1.0F + (float)k1) / 16.0F, 0.75F, (8.0F + f) / 16.0F);
                break;

            case 2:
                this.setBlockBounds((8.0F - f) / 16.0F, (12.0F - (float)l1) / 16.0F, 0.0625F, (8.0F + f) / 16.0F, 0.75F, (1.0F + (float)k1) / 16.0F);
                break;

            case 3:
                this.setBlockBounds((15.0F - (float)k1) / 16.0F, (12.0F - (float)l1) / 16.0F, (8.0F - f) / 16.0F, 0.9375F, 0.75F, (8.0F + f) / 16.0F);
        }
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack)
    {
        int l = ((MathHelper.floor((double)(entityliving.yaw * 4.0F / 360.0F) + 0.5D) & 3) + 0) % 4;
        world.setData(i, j, k, l, 2);
    }

    public int getPlacedData(World world, int i, int j, int k, int l, float f, float f1, float f2, int i1)
    {
        if (l == 1 || l == 0)
        {
            l = 2;
        }

        return Direction.rotateOpposite[Direction.facingToDirection[l]];
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (!this.canBlockStay(world, i, j, k))
        {
            this.dropBlockAsItem(world, i, j, k, world.getData(i, j, k), 0);
            world.setTypeIdAndData(i, j, k, 0, 0, 2);
        }
    }

    public static int func_72219_c(int par0)
    {
        return (par0 & 12) >> 2;
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        int j1 = func_72219_c(l);
        byte b0 = 1;

        if (j1 >= 2)
        {
            b0 = 3;
        }

        for (int k1 = 0; k1 < b0; ++k1)
        {
            this.dropBlockAsItem_do(world, i, j, k, new ItemStack(Item.INK_SACK, 1, 3));
        }
    }

    public int getDropData(World world, int i, int j, int k)
    {
        return 3;
    }
}
