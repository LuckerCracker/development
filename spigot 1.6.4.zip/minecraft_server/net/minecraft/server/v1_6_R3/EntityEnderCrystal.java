package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntityEnderCrystal extends Entity
{
    /** Used to create the rotation animation when rendering the crystal. */
    public int innerRotation;
    public int health;

    public EntityEnderCrystal(World par1World)
    {
        super(par1World);
        this.preventEntitySpawning = true;
        this.setSize(2.0F, 2.0F);
        this.height = this.length / 2.0F;
        this.health = 5;
        this.innerRotation = this.random.nextInt(100000);
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    protected void entityInit()
    {
        this.datawatcher.addObject(8, Integer.valueOf(this.health));
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        this.lastX = this.locX;
        this.lastY = this.locY;
        this.lastZ = this.locZ;
        ++this.innerRotation;
        this.datawatcher.watch(8, Integer.valueOf(this.health));
        int var1 = MathHelper.floor(this.locX);
        int var2 = MathHelper.floor(this.locY);
        int var3 = MathHelper.floor(this.locZ);

        if (this.world.getTypeId(var1, var2, var3) != Block.FIRE.id && !CraftEventFactory.callBlockIgniteEvent(this.world, var1, var2, var3, (Entity)this).isCancelled())
        {
            this.world.setTypeIdUpdate(var1, var2, var3, Block.FIRE.id);
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {}

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {}

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
        return true;
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else
        {
            if (!this.dead && !this.world.isStatic)
            {
                if (CraftEventFactory.handleNonLivingEntityDamageEvent(this, damagesource, f))
                {
                    return false;
                }

                this.health = 0;

                if (this.health <= 0)
                {
                    this.die();

                    if (!this.world.isStatic)
                    {
                        this.world.explode(this, this.locX, this.locY, this.locZ, 6.0F, true);
                    }
                }
            }

            return true;
        }
    }
}
