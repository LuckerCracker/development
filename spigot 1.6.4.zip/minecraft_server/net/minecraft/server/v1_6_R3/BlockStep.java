package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockStep extends BlockStepAbstract
{
    /** The list of the types of step blocks. */
    public static final String[] blockStepTypes = new String[] {"stone", "sand", "wood", "cobble", "brick", "smoothStoneBrick", "netherBrick", "quartz"};

    public BlockStep(int par1, boolean par2)
    {
        super(par1, par2, Material.STONE);
        this.a(CreativeModeTab.b);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Block.STEP.id;
    }

    /**
     * Returns an item stack containing a single instance of the current block type. 'i' is the block's subtype/damage
     * and is ignored for blocks which do not support subtypes. Blocks which cannot be harvested should return null.
     */
    protected ItemStack createStackedBlock(int par1)
    {
        return new ItemStack(Block.STEP.id, 2, par1 & 7);
    }

    /**
     * Returns the slab block name with step type.
     */
    public String getFullSlabName(int par1)
    {
        if (par1 < 0 || par1 >= blockStepTypes.length)
        {
            par1 = 0;
        }

        return super.getUnlocalizedName() + "." + blockStepTypes[par1];
    }
}
