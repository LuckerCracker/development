package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockEnderChest extends BlockContainer
{
    protected BlockEnderChest(int par1)
    {
        super(par1, Material.STONE);
        this.a(CreativeModeTab.c);
        this.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 22;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Block.OBSIDIAN.id;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 8;
    }

    /**
     * Return true if a player with Silk Touch can harvest this block directly, and not its normal drops.
     */
    protected boolean canSilkHarvest()
    {
        return true;
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        byte var7 = 0;
        int var8 = MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3;

        if (var8 == 0)
        {
            var7 = 2;
        }

        if (var8 == 1)
        {
            var7 = 5;
        }

        if (var8 == 2)
        {
            var7 = 3;
        }

        if (var8 == 3)
        {
            var7 = 4;
        }

        var1.setData(var2, var3, var4, var7, 2);
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        InventoryEnderChest var10 = var5.getEnderChest();
        TileEntityEnderChest var11 = (TileEntityEnderChest)var1.getTileEntity(var2, var3, var4);

        if (var10 != null && var11 != null)
        {
            if (var1.isBlockNormalCube(var2, var3 + 1, var4))
            {
                return true;
            }
            else if (var1.isStatic)
            {
                return true;
            }
            else
            {
                var10.setAssociatedChest(var11);
                var5.openContainer(var10);
                return true;
            }
        }
        else
        {
            return true;
        }
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityEnderChest();
    }
}
