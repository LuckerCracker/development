package net.minecraft.server.v1_6_R3;

public class BlockSmoothBrick extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    public static final String[] displayOnCreativeTab = new String[] {"default", "mossy", "cracked", "chiseled"};

    /** The unlocalized name of this block. */
    public static final String[] unlocalizedName = new String[] {null, "mossy", "cracked", "carved"};

    public BlockSmoothBrick(int var1)
    {
        super(var1, Material.STONE);
        this.a(CreativeModeTab.b);
    }

    public int getDropData(int var1)
    {
        return var1;
    }
}
