package net.minecraft.server.v1_6_R3;

import gnu.trove.map.hash.TObjectIntHashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_6_R3.CraftChunk;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftHumanEntity;
import org.bukkit.craftbukkit.v1_6_R3.util.UnsafeList;

public class Chunk
{
    /**
     * Determines if the chunk is lit or not at a light value greater than 0.
     */
    public static boolean isLit;
    private ChunkSection[] sections;

    /**
     * Contains a 16x16 mapping on the X/Z plane of the biome ID to which each colum belongs.
     */
    private byte[] blockBiomeArray;

    /**
     * A map, similar to heightMap, that tracks how far down precipitation can fall.
     */
    public int[] precipitationHeightMap;

    /** Which columns need their skylightMaps updated. */
    public boolean[] updateSkylightColumns;

    /** Whether or not this Chunk is currently loaded into the World */
    public boolean isChunkLoaded;
    public World world;
    public int[] heightMap;
    public final int x;
    public final int z;
    private boolean isGapLightingUpdated;
    public Map tileEntities;
    public List[] entitySlices;
    public boolean done;

    /**
     * Set to true if the chunk has been modified and needs to be updated internally.
     */
    public boolean isModified;

    /**
     * Whether this Chunk has any Entities and thus requires saving on every tick
     */
    public boolean hasEntities;

    /** The time according to World.worldTime when this chunk was last saved */
    public long lastSaveTime;
    public boolean seenByPlayer;

    /** Lowest value in the heightmap. */
    public int heightMapMinimum;

    /** the cumulative number of ticks players have been in this chunk */
    public long inhabitedTime;

    /**
     * Contains the current round-robin relight check index, and is implied as the relight check location as well.
     */
    private int queuedLightChecks;
    protected TObjectIntHashMap<Class> entityCount;
    public org.bukkit.Chunk bukkitChunk;
    public boolean mustSave;

    public Chunk(World par1World, int par2, int par3)
    {
        this.entityCount = new TObjectIntHashMap();
        this.sections = new ChunkSection[16];
        this.blockBiomeArray = new byte[256];
        this.precipitationHeightMap = new int[256];
        this.updateSkylightColumns = new boolean[256];
        this.tileEntities = new HashMap();
        this.queuedLightChecks = 4096;
        this.entitySlices = new List[16];
        this.world = par1World;
        this.x = par2;
        this.z = par3;
        this.heightMap = new int[256];

        for (int var4 = 0; var4 < this.entitySlices.length; ++var4)
        {
            this.entitySlices[var4] = new UnsafeList();
        }

        Arrays.fill(this.precipitationHeightMap, -999);
        Arrays.fill(this.blockBiomeArray, (byte) - 1);

        if (!(this instanceof EmptyChunk))
        {
            this.bukkitChunk = new CraftChunk(this);
        }
    }

    public Chunk(World par1World, byte[] par2ArrayOfByte, int par3, int par4)
    {
        this(par1World, par3, par4);
        int var5 = par2ArrayOfByte.length / 256;

        for (int var6 = 0; var6 < 16; ++var6)
        {
            for (int var7 = 0; var7 < 16; ++var7)
            {
                for (int var8 = 0; var8 < var5; ++var8)
                {
                    byte var9 = par2ArrayOfByte[var6 << 11 | var7 << 7 | var8];

                    if (var9 != 0)
                    {
                        int var10 = var8 >> 4;

                        if (this.sections[var10] == null)
                        {
                            this.sections[var10] = new ChunkSection(var10 << 4, !par1World.worldProvider.hasNoSky);
                        }

                        this.sections[var10].setTypeId(var6, var8 & 15, var7, var9);
                    }
                }
            }
        }
    }

    /**
     * Checks whether the chunk is at the X/Z location specified
     */
    public boolean isAtLocation(int par1, int par2)
    {
        return par1 == this.x && par2 == this.z;
    }

    /**
     * Returns the value in the height map at this x, z coordinate in the chunk
     */
    public int getHeightValue(int par1, int par2)
    {
        return this.heightMap[par2 << 4 | par1];
    }

    /**
     * Returns the topmost ExtendedBlockStorage instance for this Chunk that actually contains a block.
     */
    public int getTopFilledSegment()
    {
        for (int var1 = this.sections.length - 1; var1 >= 0; --var1)
        {
            if (this.sections[var1] != null)
            {
                return this.sections[var1].getYPosition();
            }
        }

        return 0;
    }

    public ChunkSection[] i()
    {
        return this.sections;
    }

    public void initLighting()
    {
        int i = this.getTopFilledSegment();
        this.heightMapMinimum = Integer.MAX_VALUE;
        int j;
        int k;

        for (j = 0; j < 16; ++j)
        {
            k = 0;

            while (k < 16)
            {
                this.precipitationHeightMap[j + (k << 4)] = -999;
                int l = i + 16 - 1;

                while (true)
                {
                    if (l > 0)
                    {
                        if (this.getBlockLightOpacity(j, l - 1, k) == 0)
                        {
                            --l;
                            continue;
                        }

                        this.heightMap[k << 4 | j] = l;

                        if (l < this.heightMapMinimum)
                        {
                            this.heightMapMinimum = l;
                        }
                    }

                    if (!this.world.worldProvider.hasNoSky)
                    {
                        l = 15;
                        int i1 = i + 16 - 1;

                        do
                        {
                            l -= this.getBlockLightOpacity(j, i1, k);

                            if (l > 0)
                            {
                                ChunkSection chunksection = this.sections[i1 >> 4];

                                if (chunksection != null)
                                {
                                    chunksection.setSkyLight(j, i1 & 15, k, l);
                                    this.world.markBlockForRenderUpdate((this.x << 4) + j, i1, (this.z << 4) + k);
                                }
                            }

                            --i1;
                        }
                        while (i1 > 0 && l > 0);
                    }

                    ++k;
                    break;
                }
            }
        }

        this.isModified = true;

        for (j = 0; j < 16; ++j)
        {
            for (k = 0; k < 16; ++k)
            {
                this.propagateSkylightOcclusion(j, k);
            }
        }
    }

    /**
     * Propagates a given sky-visible block's light value downward and upward to neighboring blocks as necessary.
     */
    private void propagateSkylightOcclusion(int par1, int par2)
    {
        this.updateSkylightColumns[par1 + par2 * 16] = true;
        this.isGapLightingUpdated = true;
    }

    /**
     * Runs delayed skylight updates.
     */
    private void updateSkylight_do()
    {
        this.world.methodProfiler.a("recheckGaps");

        if (this.world.areChunksLoaded(this.x * 16 + 8, 0, this.z * 16 + 8, 16))
        {
            for (int var1 = 0; var1 < 16; ++var1)
            {
                for (int var2 = 0; var2 < 16; ++var2)
                {
                    if (this.updateSkylightColumns[var1 + var2 * 16])
                    {
                        this.updateSkylightColumns[var1 + var2 * 16] = false;
                        int var3 = this.getHeightValue(var1, var2);
                        int var4 = this.x * 16 + var1;
                        int var5 = this.z * 16 + var2;
                        int var6 = this.world.getChunkHeightMapMinimum(var4 - 1, var5);
                        int var7 = this.world.getChunkHeightMapMinimum(var4 + 1, var5);
                        int var8 = this.world.getChunkHeightMapMinimum(var4, var5 - 1);
                        int var9 = this.world.getChunkHeightMapMinimum(var4, var5 + 1);

                        if (var7 < var6)
                        {
                            var6 = var7;
                        }

                        if (var8 < var6)
                        {
                            var6 = var8;
                        }

                        if (var9 < var6)
                        {
                            var6 = var9;
                        }

                        this.checkSkylightNeighborHeight(var4, var5, var6);
                        this.checkSkylightNeighborHeight(var4 - 1, var5, var3);
                        this.checkSkylightNeighborHeight(var4 + 1, var5, var3);
                        this.checkSkylightNeighborHeight(var4, var5 - 1, var3);
                        this.checkSkylightNeighborHeight(var4, var5 + 1, var3);
                    }
                }
            }

            this.isGapLightingUpdated = false;
        }

        this.world.methodProfiler.b();
    }

    /**
     * Checks the height of a block next to a sky-visible block and schedules a lighting update as necessary.
     */
    private void checkSkylightNeighborHeight(int par1, int par2, int par3)
    {
        int var4 = this.world.getHighestBlockYAt(par1, par2);

        if (var4 > par3)
        {
            this.updateSkylightNeighborHeight(par1, par2, par3, var4 + 1);
        }
        else if (var4 < par3)
        {
            this.updateSkylightNeighborHeight(par1, par2, var4, par3 + 1);
        }
    }

    private void updateSkylightNeighborHeight(int par1, int par2, int par3, int par4)
    {
        if (par4 > par3 && this.world.areChunksLoaded(par1, 0, par2, 16))
        {
            for (int var5 = par3; var5 < par4; ++var5)
            {
                this.world.updateLightByType(EnumSkyBlock.SKY, par1, var5, par2);
            }

            this.isModified = true;
        }
    }

    /**
     * Initiates the recalculation of both the block-light and sky-light for a given block inside a chunk.
     */
    private void relightBlock(int par1, int par2, int par3)
    {
        int var4 = this.heightMap[par3 << 4 | par1] & 255;
        int var5 = var4;

        if (par2 > var4)
        {
            var5 = par2;
        }

        while (var5 > 0 && this.getBlockLightOpacity(par1, var5 - 1, par3) == 0)
        {
            --var5;
        }

        if (var5 != var4)
        {
            this.world.markBlocksDirtyVertical(par1 + this.x * 16, par3 + this.z * 16, var5, var4);
            this.heightMap[par3 << 4 | par1] = var5;
            int var6 = this.x * 16 + par1;
            int var7 = this.z * 16 + par3;
            int var8;
            int var10;

            if (!this.world.worldProvider.hasNoSky)
            {
                ChunkSection var9;

                if (var5 < var4)
                {
                    for (var8 = var5; var8 < var4; ++var8)
                    {
                        var9 = this.sections[var8 >> 4];

                        if (var9 != null)
                        {
                            var9.setSkyLight(par1, var8 & 15, par3, 15);
                            this.world.markBlockForRenderUpdate((this.x << 4) + par1, var8, (this.z << 4) + par3);
                        }
                    }
                }
                else
                {
                    for (var8 = var4; var8 < var5; ++var8)
                    {
                        var9 = this.sections[var8 >> 4];

                        if (var9 != null)
                        {
                            var9.setSkyLight(par1, var8 & 15, par3, 0);
                            this.world.markBlockForRenderUpdate((this.x << 4) + par1, var8, (this.z << 4) + par3);
                        }
                    }
                }

                var8 = 15;

                while (var5 > 0 && var8 > 0)
                {
                    --var5;
                    var10 = this.getBlockLightOpacity(par1, var5, par3);

                    if (var10 == 0)
                    {
                        var10 = 1;
                    }

                    var8 -= var10;

                    if (var8 < 0)
                    {
                        var8 = 0;
                    }

                    ChunkSection var11 = this.sections[var5 >> 4];

                    if (var11 != null)
                    {
                        var11.setSkyLight(par1, var5 & 15, par3, var8);
                    }
                }
            }

            var8 = this.heightMap[par3 << 4 | par1];
            var10 = var4;
            int var12 = var8;

            if (var8 < var4)
            {
                var10 = var8;
                var12 = var4;
            }

            if (var8 < this.heightMapMinimum)
            {
                this.heightMapMinimum = var8;
            }

            if (!this.world.worldProvider.hasNoSky)
            {
                this.updateSkylightNeighborHeight(var6 - 1, var7, var10, var12);
                this.updateSkylightNeighborHeight(var6 + 1, var7, var10, var12);
                this.updateSkylightNeighborHeight(var6, var7 - 1, var10, var12);
                this.updateSkylightNeighborHeight(var6, var7 + 1, var10, var12);
                this.updateSkylightNeighborHeight(var6, var7, var10, var12);
            }

            this.isModified = true;
        }
    }

    public int getBlockLightOpacity(int par1, int par2, int par3)
    {
        return Block.lightBlock[this.getTypeId(par1, par2, par3)];
    }

    public int getTypeId(int i, int j, int k)
    {
        if (j >> 4 >= this.sections.length)
        {
            return 0;
        }
        else
        {
            ChunkSection chunksection = this.sections[j >> 4];
            return chunksection != null ? chunksection.getTypeId(i, j & 15, k) : 0;
        }
    }

    public int getData(int i, int j, int k)
    {
        if (j >> 4 >= this.sections.length)
        {
            return 0;
        }
        else
        {
            ChunkSection chunksection = this.sections[j >> 4];
            return chunksection != null ? chunksection.getData(i, j & 15, k) : 0;
        }
    }

    /**
     * Sets a blockID of a position within a chunk with metadata. Args: x, y, z, blockID, metadata. Return true if the
     * id or meta was changed.
     */
    public boolean setBlockIDWithMetadata(int par1, int par2, int par3, int par4, int par5)
    {
        int var6 = par3 << 4 | par1;

        if (par2 >= this.precipitationHeightMap[var6] - 1)
        {
            this.precipitationHeightMap[var6] = -999;
        }

        int var7 = this.heightMap[var6];
        int var8 = this.getTypeId(par1, par2, par3);
        int var9 = this.getData(par1, par2, par3);

        if (var8 == par4 && var9 == par5)
        {
            return false;
        }
        else
        {
            ChunkSection var10 = this.sections[par2 >> 4];
            boolean var11 = false;

            if (var10 == null)
            {
                if (par4 == 0)
                {
                    return false;
                }

                var10 = this.sections[par2 >> 4] = new ChunkSection(par2 >> 4 << 4, !this.world.worldProvider.hasNoSky);
                var11 = par2 >= var7;
            }

            int var12 = this.x * 16 + par1;
            int var13 = this.z * 16 + par3;

            if (var8 != 0 && !this.world.isStatic)
            {
                Block.byId[var8].onBlockPreDestroy(this.world, var12, par2, var13, var9);
            }

            var10.setTypeId(par1, par2 & 15, par3, par4);

            if (var8 != 0)
            {
                if (!this.world.isStatic)
                {
                    Block.byId[var8].remove(this.world, var12, par2, var13, var8, var9);
                }
                else if (Block.byId[var8] instanceof IContainer && var8 != par4)
                {
                    this.world.removeBlockTileEntity(var12, par2, var13);
                }
            }

            if (var10.getTypeId(par1, par2 & 15, par3) != par4)
            {
                return false;
            }
            else
            {
                var10.setData(par1, par2 & 15, par3, par5);

                if (var11)
                {
                    this.initLighting();
                }
                else
                {
                    if (Block.lightBlock[par4 & 4095] > 0)
                    {
                        if (par2 >= var7)
                        {
                            this.relightBlock(par1, par2 + 1, par3);
                        }
                    }
                    else if (par2 == var7 - 1)
                    {
                        this.relightBlock(par1, par2, par3);
                    }

                    this.propagateSkylightOcclusion(par1, par3);
                }

                TileEntity var14;

                if (par4 != 0)
                {
                    if (!this.world.isStatic && (!this.world.callingPlaceEvent || Block.byId[par4] instanceof BlockContainer))
                    {
                        Block.byId[par4].onPlace(this.world, var12, par2, var13);
                    }

                    if (Block.byId[par4] instanceof IContainer)
                    {
                        if (this.getTypeId(par1, par2, par3) != par4)
                        {
                            return false;
                        }

                        var14 = this.getChunkBlockTileEntity(par1, par2, par3);

                        if (var14 == null)
                        {
                            var14 = ((IContainer)Block.byId[par4]).createNewTileEntity(this.world);
                            this.world.setTileEntity(var12, par2, var13, var14);
                        }

                        if (var14 != null)
                        {
                            var14.updateContainingBlockInfo();
                        }
                    }
                }
                else if (var8 > 0 && Block.byId[var8] instanceof IContainer)
                {
                    var14 = this.getChunkBlockTileEntity(par1, par2, par3);

                    if (var14 != null)
                    {
                        var14.updateContainingBlockInfo();
                    }
                }

                this.isModified = true;
                return true;
            }
        }
    }

    /**
     * Set the metadata of a block in the chunk
     */
    public boolean setBlockMetadata(int par1, int par2, int par3, int par4)
    {
        ChunkSection var5 = this.sections[par2 >> 4];

        if (var5 == null)
        {
            return false;
        }
        else
        {
            int var6 = var5.getData(par1, par2 & 15, par3);

            if (var6 == par4)
            {
                return false;
            }
            else
            {
                this.isModified = true;
                var5.setData(par1, par2 & 15, par3, par4);
                int var7 = var5.getTypeId(par1, par2 & 15, par3);

                if (var7 > 0 && Block.byId[var7] instanceof IContainer)
                {
                    TileEntity var8 = this.getChunkBlockTileEntity(par1, par2, par3);

                    if (var8 != null)
                    {
                        var8.updateContainingBlockInfo();
                        var8.blockMetadata = par4;
                    }
                }

                return true;
            }
        }
    }

    public int getBrightness(EnumSkyBlock enumskyblock, int i, int j, int k)
    {
        ChunkSection chunksection = this.sections[j >> 4];
        return chunksection == null ? (this.canBlockSeeTheSky(i, j, k) ? enumskyblock.defaultLightValue : 0) : (enumskyblock == EnumSkyBlock.SKY ? (this.world.worldProvider.hasNoSky ? 0 : chunksection.getSkyLight(i, j & 15, k)) : (enumskyblock == EnumSkyBlock.BLOCK ? chunksection.getEmittedLight(i, j & 15, k) : enumskyblock.defaultLightValue));
    }

    /**
     * Sets the light value at the coordinate. If enumskyblock is set to sky it sets it in the skylightmap and if its a
     * block then into the blocklightmap. Args enumSkyBlock, x, y, z, lightValue
     */
    public void setLightValue(EnumSkyBlock par1EnumSkyBlock, int par2, int par3, int par4, int par5)
    {
        ChunkSection var6 = this.sections[par3 >> 4];

        if (var6 == null)
        {
            var6 = this.sections[par3 >> 4] = new ChunkSection(par3 >> 4 << 4, !this.world.worldProvider.hasNoSky);
            this.initLighting();
        }

        this.isModified = true;

        if (par1EnumSkyBlock == EnumSkyBlock.SKY)
        {
            if (!this.world.worldProvider.hasNoSky)
            {
                var6.setSkyLight(par2, par3 & 15, par4, par5);
            }
        }
        else if (par1EnumSkyBlock == EnumSkyBlock.BLOCK)
        {
            var6.setEmittedLight(par2, par3 & 15, par4, par5);
        }
    }

    /**
     * Gets the amount of light on a block taking into account sunlight
     */
    public int getBlockLightValue(int par1, int par2, int par3, int par4)
    {
        ChunkSection var5 = this.sections[par2 >> 4];

        if (var5 != null)
        {
            int var6 = this.world.worldProvider.hasNoSky ? 0 : var5.getSkyLight(par1, par2 & 15, par3);

            if (var6 > 0)
            {
                isLit = true;
            }

            var6 -= par4;
            int var7 = var5.getEmittedLight(par1, par2 & 15, par3);

            if (var7 > var6)
            {
                var6 = var7;
            }

            return var6;
        }
        else
        {
            return !this.world.worldProvider.hasNoSky && par4 < EnumSkyBlock.SKY.defaultLightValue ? EnumSkyBlock.SKY.defaultLightValue - par4 : 0;
        }
    }

    /**
     * Adds an entity to the chunk. Args: entity
     */
    public void addEntity(Entity par1Entity)
    {
        this.hasEntities = true;
        int var2 = MathHelper.floor(par1Entity.locX / 16.0D);
        int var3 = MathHelper.floor(par1Entity.locZ / 16.0D);

        if (var2 != this.x || var3 != this.z)
        {
            Bukkit.getLogger().warning("Wrong location for " + par1Entity + " in world \'" + this.world.getWorld().getName() + "\'!");
            Bukkit.getLogger().warning("Entity is at " + par1Entity.locX + "," + par1Entity.locZ + " (chunk " + var2 + "," + var3 + ") but was stored in chunk " + this.x + "," + this.z);
        }

        int var4 = MathHelper.floor(par1Entity.locY / 16.0D);

        if (var4 < 0)
        {
            var4 = 0;
        }

        if (var4 >= this.entitySlices.length)
        {
            var4 = this.entitySlices.length - 1;
        }

        par1Entity.addedToChunk = true;
        par1Entity.chunkCoordX = this.x;
        par1Entity.chunkCoordY = var4;
        par1Entity.chunkCoordZ = this.z;
        this.entitySlices[var4].add(par1Entity);

        if (par1Entity instanceof EntityInsentient)
        {
            EntityInsentient var5 = (EntityInsentient)par1Entity;

            if (var5.isTypeNotPersistent() && var5.isPersistent())
            {
                return;
            }
        }

        EnumCreatureType[] var9 = EnumCreatureType.values();
        int var6 = var9.length;

        for (int var7 = 0; var7 < var6; ++var7)
        {
            EnumCreatureType var8 = var9[var7];

            if (var8.getCreatureClass().isAssignableFrom(par1Entity.getClass()))
            {
                this.entityCount.adjustOrPutValue(var8.getCreatureClass(), 1, 1);
            }
        }
    }

    /**
     * removes entity using its y chunk coordinate as its index
     */
    public void removeEntity(Entity par1Entity)
    {
        this.removeEntityAtIndex(par1Entity, par1Entity.chunkCoordY);
    }

    /**
     * Removes entity at the specified index from the entity array.
     */
    public void removeEntityAtIndex(Entity par1Entity, int par2)
    {
        if (par2 < 0)
        {
            par2 = 0;
        }

        if (par2 >= this.entitySlices.length)
        {
            par2 = this.entitySlices.length - 1;
        }

        this.entitySlices[par2].remove(par1Entity);

        if (par1Entity instanceof EntityInsentient)
        {
            EntityInsentient var3 = (EntityInsentient)par1Entity;

            if (var3.isTypeNotPersistent() && var3.isPersistent())
            {
                return;
            }
        }

        EnumCreatureType[] var7 = EnumCreatureType.values();
        int var4 = var7.length;

        for (int var5 = 0; var5 < var4; ++var5)
        {
            EnumCreatureType var6 = var7[var5];

            if (var6.getCreatureClass().isAssignableFrom(par1Entity.getClass()))
            {
                this.entityCount.adjustValue(var6.getCreatureClass(), -1);
            }
        }
    }

    /**
     * Returns whether is not a block above this one blocking sight to the sky (done via checking against the heightmap)
     */
    public boolean canBlockSeeTheSky(int par1, int par2, int par3)
    {
        return par2 >= this.heightMap[par3 << 4 | par1];
    }

    /**
     * Gets the TileEntity for a given block in this chunk
     */
    public TileEntity getChunkBlockTileEntity(int par1, int par2, int par3)
    {
        ChunkPosition var4 = new ChunkPosition(par1, par2, par3);
        TileEntity var5 = (TileEntity)this.tileEntities.get(var4);

        if (var5 == null)
        {
            int var6 = this.getTypeId(par1, par2, par3);

            if (var6 <= 0 || !Block.byId[var6].hasTileEntity())
            {
                return null;
            }

            if (var5 == null)
            {
                var5 = ((IContainer)Block.byId[var6]).createNewTileEntity(this.world);
                this.world.setTileEntity(this.x * 16 + par1, par2, this.z * 16 + par3, var5);
            }

            var5 = (TileEntity)this.tileEntities.get(var4);
        }

        if (var5 != null && var5.isInvalid())
        {
            this.tileEntities.remove(var4);
            return null;
        }
        else
        {
            return var5;
        }
    }

    /**
     * Adds a TileEntity to a chunk
     */
    public void addTileEntity(TileEntity par1TileEntity)
    {
        int var2 = par1TileEntity.x - this.x * 16;
        int var3 = par1TileEntity.y;
        int var4 = par1TileEntity.z - this.z * 16;
        this.setChunkBlockTileEntity(var2, var3, var4, par1TileEntity);

        if (this.isChunkLoaded)
        {
            this.world.tileEntityList.add(par1TileEntity);
        }
    }

    /**
     * Sets the TileEntity for a given block in this chunk
     */
    public void setChunkBlockTileEntity(int par1, int par2, int par3, TileEntity par4TileEntity)
    {
        ChunkPosition var5 = new ChunkPosition(par1, par2, par3);
        par4TileEntity.setWorldObj(this.world);
        par4TileEntity.x = this.x * 16 + par1;
        par4TileEntity.y = par2;
        par4TileEntity.z = this.z * 16 + par3;

        if (this.getTypeId(par1, par2, par3) != 0 && Block.byId[this.getTypeId(par1, par2, par3)] instanceof IContainer)
        {
            if (this.tileEntities.containsKey(var5))
            {
                ((TileEntity)this.tileEntities.get(var5)).invalidate();
            }

            par4TileEntity.validate();
            this.tileEntities.put(var5, par4TileEntity);
        }
        else
        {
            System.out.println("Attempted to place a tile entity (" + par4TileEntity + ") at " + par4TileEntity.x + "," + par4TileEntity.y + "," + par4TileEntity.z + " (" + org.bukkit.Material.getMaterial(this.getTypeId(par1, par2, par3)) + ") where there was no entity tile!");
            System.out.println("Chunk coordinates: " + this.x * 16 + "," + this.z * 16);
            (new Exception()).printStackTrace();
        }
    }

    /**
     * Removes the TileEntity for a given block in this chunk
     */
    public void removeChunkBlockTileEntity(int par1, int par2, int par3)
    {
        ChunkPosition var4 = new ChunkPosition(par1, par2, par3);

        if (this.isChunkLoaded)
        {
            TileEntity var5 = (TileEntity)this.tileEntities.remove(var4);

            if (var5 != null)
            {
                var5.invalidate();
            }
        }
    }

    public void addEntities()
    {
        this.isChunkLoaded = true;
        this.world.addTileEntity(this.tileEntities.values());

        for (int i = 0; i < this.entitySlices.length; ++i)
        {
            Iterator iterator = this.entitySlices[i].iterator();

            while (iterator.hasNext())
            {
                Entity entity = (Entity)iterator.next();
                entity.onChunkLoad();
            }

            this.world.addLoadedEntities(this.entitySlices[i]);
        }
    }

    public void removeEntities()
    {
        this.isChunkLoaded = false;
        TileEntity i;
        Iterator iter;

        for (Iterator iterator = this.tileEntities.values().iterator(); iterator.hasNext(); this.world.markTileEntityForDespawn(i))
        {
            i = (TileEntity)iterator.next();

            if (i instanceof IInventory)
            {
                iter = (new ArrayList(((IInventory)i).getViewers())).iterator();

                while (iter.hasNext())
                {
                    CraftHumanEntity entity = (CraftHumanEntity)iter.next();
                    entity.getHandle().closeInventory();
                }
            }
        }

        for (int var7 = 0; var7 < this.entitySlices.length; ++var7)
        {
            iter = this.entitySlices[var7].iterator();

            while (iter.hasNext())
            {
                Entity var8 = (Entity)iter.next();

                if (var8 instanceof IInventory)
                {
                    Iterator i$ = (new ArrayList(((IInventory)var8).getViewers())).iterator();

                    while (i$.hasNext())
                    {
                        CraftHumanEntity h = (CraftHumanEntity)i$.next();
                        h.getHandle().closeInventory();
                    }
                }

                if (var8 instanceof EntityPlayer)
                {
                    iter.remove();
                }
            }

            this.world.unloadEntities(this.entitySlices[var7]);
        }
    }

    /**
     * Sets the isModified flag for this Chunk
     */
    public void setChunkModified()
    {
        this.isModified = true;
    }

    /**
     * Fills the given list of all entities that intersect within the given bounding box that aren't the passed entity
     * Args: entity, aabb, listToFill
     */
    public void getEntitiesWithinAABBForEntity(Entity par1Entity, AxisAlignedBB par2AxisAlignedBB, List par3List, IEntitySelector par4IEntitySelector)
    {
        int var5 = MathHelper.floor((par2AxisAlignedBB.minY - 2.0D) / 16.0D);
        int var6 = MathHelper.floor((par2AxisAlignedBB.maxY + 2.0D) / 16.0D);

        if (var5 < 0)
        {
            var5 = 0;
            var6 = Math.max(var5, var6);
        }

        if (var6 >= this.entitySlices.length)
        {
            var6 = this.entitySlices.length - 1;
            var5 = Math.min(var5, var6);
        }

        for (int var7 = var5; var7 <= var6; ++var7)
        {
            List var8 = this.entitySlices[var7];

            for (int var9 = 0; var9 < var8.size(); ++var9)
            {
                Entity var10 = (Entity)var8.get(var9);

                if (var10 != par1Entity && var10.boundingBox.intersectsWith(par2AxisAlignedBB) && (par4IEntitySelector == null || par4IEntitySelector.isEntityApplicable(var10)))
                {
                    par3List.add(var10);
                    Entity[] var11 = var10.getParts();

                    if (var11 != null)
                    {
                        for (int var12 = 0; var12 < var11.length; ++var12)
                        {
                            var10 = var11[var12];

                            if (var10 != par1Entity && var10.boundingBox.intersectsWith(par2AxisAlignedBB) && (par4IEntitySelector == null || par4IEntitySelector.isEntityApplicable(var10)))
                            {
                                par3List.add(var10);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Gets all entities that can be assigned to the specified class. Args: entityClass, aabb, listToFill
     */
    public void getEntitiesOfTypeWithinAAAB(Class par1Class, AxisAlignedBB par2AxisAlignedBB, List par3List, IEntitySelector par4IEntitySelector)
    {
        int var5 = MathHelper.floor((par2AxisAlignedBB.minY - 2.0D) / 16.0D);
        int var6 = MathHelper.floor((par2AxisAlignedBB.maxY + 2.0D) / 16.0D);

        if (var5 < 0)
        {
            var5 = 0;
        }
        else if (var5 >= this.entitySlices.length)
        {
            var5 = this.entitySlices.length - 1;
        }

        if (var6 >= this.entitySlices.length)
        {
            var6 = this.entitySlices.length - 1;
        }
        else if (var6 < 0)
        {
            var6 = 0;
        }

        for (int var7 = var5; var7 <= var6; ++var7)
        {
            List var8 = this.entitySlices[var7];

            for (int var9 = 0; var9 < var8.size(); ++var9)
            {
                Entity var10 = (Entity)var8.get(var9);

                if (par1Class.isAssignableFrom(var10.getClass()) && var10.boundingBox.intersectsWith(par2AxisAlignedBB) && (par4IEntitySelector == null || par4IEntitySelector.isEntityApplicable(var10)))
                {
                    par3List.add(var10);
                }
            }
        }
    }

    /**
     * Returns true if this Chunk needs to be saved
     */
    public boolean needsSaving(boolean par1)
    {
        if (par1)
        {
            if (this.hasEntities && this.world.getTime() != this.lastSaveTime || this.isModified)
            {
                return true;
            }
        }
        else if (this.hasEntities && this.world.getTime() >= this.lastSaveTime + 600L)
        {
            return true;
        }

        return this.isModified;
    }

    public Random getRandomWithSeed(long par1)
    {
        return new Random(this.world.getSeed() + (long)(this.x * this.x * 4987142) + (long)(this.x * 5947611) + (long)(this.z * this.z) * 4392871L + (long)(this.z * 389711) ^ par1);
    }

    public boolean isEmpty()
    {
        return false;
    }

    public void populateChunk(IChunkProvider par1IChunkProvider, IChunkProvider par2IChunkProvider, int par3, int par4)
    {
        if (!this.done && par1IChunkProvider.isChunkLoaded(par3 + 1, par4 + 1) && par1IChunkProvider.isChunkLoaded(par3, par4 + 1) && par1IChunkProvider.isChunkLoaded(par3 + 1, par4))
        {
            par1IChunkProvider.getChunkAt(par2IChunkProvider, par3, par4);
        }

        if (par1IChunkProvider.isChunkLoaded(par3 - 1, par4) && !par1IChunkProvider.getOrCreateChunk(par3 - 1, par4).done && par1IChunkProvider.isChunkLoaded(par3 - 1, par4 + 1) && par1IChunkProvider.isChunkLoaded(par3, par4 + 1) && par1IChunkProvider.isChunkLoaded(par3 - 1, par4 + 1))
        {
            par1IChunkProvider.getChunkAt(par2IChunkProvider, par3 - 1, par4);
        }

        if (par1IChunkProvider.isChunkLoaded(par3, par4 - 1) && !par1IChunkProvider.getOrCreateChunk(par3, par4 - 1).done && par1IChunkProvider.isChunkLoaded(par3 + 1, par4 - 1) && par1IChunkProvider.isChunkLoaded(par3 + 1, par4 - 1) && par1IChunkProvider.isChunkLoaded(par3 + 1, par4))
        {
            par1IChunkProvider.getChunkAt(par2IChunkProvider, par3, par4 - 1);
        }

        if (par1IChunkProvider.isChunkLoaded(par3 - 1, par4 - 1) && !par1IChunkProvider.getOrCreateChunk(par3 - 1, par4 - 1).done && par1IChunkProvider.isChunkLoaded(par3, par4 - 1) && par1IChunkProvider.isChunkLoaded(par3 - 1, par4))
        {
            par1IChunkProvider.getChunkAt(par2IChunkProvider, par3 - 1, par4 - 1);
        }
    }

    /**
     * Gets the height to which rain/snow will fall. Calculates it if not already stored.
     */
    public int getPrecipitationHeight(int par1, int par2)
    {
        int var3 = par1 | par2 << 4;
        int var4 = this.precipitationHeightMap[var3];

        if (var4 == -999)
        {
            int var5 = this.getTopFilledSegment() + 15;
            var4 = -1;

            while (var5 > 0 && var4 == -1)
            {
                int var6 = this.getTypeId(par1, var5, par2);
                Material var7 = var6 == 0 ? Material.AIR : Block.byId[var6].material;

                if (!var7.isSolid() && !var7.isLiquid())
                {
                    --var5;
                }
                else
                {
                    var4 = var5 + 1;
                }
            }

            this.precipitationHeightMap[var3] = var4;
        }

        return var4;
    }

    /**
     * Checks whether skylight needs updated; if it does, calls updateSkylight_do
     */
    public void updateSkylight()
    {
        if (this.isGapLightingUpdated && !this.world.worldProvider.hasNoSky)
        {
            this.updateSkylight_do();
        }
    }

    /**
     * Gets a ChunkCoordIntPair representing the Chunk's position.
     */
    public ChunkCoordIntPair getChunkCoordIntPair()
    {
        return new ChunkCoordIntPair(this.x, this.z);
    }

    /**
     * Returns whether the ExtendedBlockStorages containing levels (in blocks) from arg 1 to arg 2 are fully empty
     * (true) or not (false).
     */
    public boolean getAreLevelsEmpty(int par1, int par2)
    {
        if (par1 < 0)
        {
            par1 = 0;
        }

        if (par2 >= 256)
        {
            par2 = 255;
        }

        for (int var3 = par1; var3 <= par2; var3 += 16)
        {
            ChunkSection var4 = this.sections[var3 >> 4];

            if (var4 != null && !var4.isEmpty())
            {
                return false;
            }
        }

        return true;
    }

    public void a(ChunkSection[] achunksection)
    {
        this.sections = achunksection;
    }

    /**
     * This method retrieves the biome at a set of coordinates
     */
    public BiomeBase getBiomeGenForWorldCoords(int i, int j, WorldChunkManager worldchunkmanager)
    {
        int k = this.blockBiomeArray[j << 4 | i] & 255;

        if (k == 255)
        {
            BiomeBase biomebase = worldchunkmanager.getBiome((this.x << 4) + i, (this.z << 4) + j);
            k = biomebase.id;
            this.blockBiomeArray[j << 4 | i] = (byte)(k & 255);
        }

        return BiomeBase.biomes[k] == null ? BiomeBase.PLAINS : BiomeBase.biomes[k];
    }

    /**
     * Returns an array containing a 16x16 mapping on the X/Z of block positions in this Chunk to biome IDs.
     */
    public byte[] getBiomeArray()
    {
        return this.blockBiomeArray;
    }

    /**
     * Accepts a 256-entry array that contains a 16x16 mapping on the X/Z plane of block positions in this Chunk to
     * biome IDs.
     */
    public void setBiomeArray(byte[] par1ArrayOfByte)
    {
        this.blockBiomeArray = par1ArrayOfByte;
    }

    /**
     * Resets the relight check index to 0 for this Chunk.
     */
    public void resetRelightChecks()
    {
        this.queuedLightChecks = 0;
    }

    /**
     * Called once-per-chunk-per-tick, and advances the round-robin relight check index by up to 8 blocks at a time. In
     * a worst-case scenario, can potentially take up to 25.6 seconds, calculated via (4096/8)/20, to re-check all
     * blocks in a chunk, which may explain lagging light updates on initial world generation.
     */
    public void enqueueRelightChecks()
    {
        for (int var1 = 0; var1 < 8; ++var1)
        {
            if (this.queuedLightChecks >= 4096)
            {
                return;
            }

            int var2 = this.queuedLightChecks % 16;
            int var3 = this.queuedLightChecks / 16 % 16;
            int var4 = this.queuedLightChecks / 256;
            ++this.queuedLightChecks;
            int var5 = (this.x << 4) + var3;
            int var6 = (this.z << 4) + var4;

            for (int var7 = 0; var7 < 16; ++var7)
            {
                int var8 = (var2 << 4) + var7;

                if (this.sections[var2] == null && (var7 == 0 || var7 == 15 || var3 == 0 || var3 == 15 || var4 == 0 || var4 == 15) || this.sections[var2] != null && this.sections[var2].getTypeId(var3, var7, var4) == 0)
                {
                    if (Block.lightEmission[this.world.getTypeId(var5, var8 - 1, var6)] > 0)
                    {
                        this.world.updateAllLightTypes(var5, var8 - 1, var6);
                    }

                    if (Block.lightEmission[this.world.getTypeId(var5, var8 + 1, var6)] > 0)
                    {
                        this.world.updateAllLightTypes(var5, var8 + 1, var6);
                    }

                    if (Block.lightEmission[this.world.getTypeId(var5 - 1, var8, var6)] > 0)
                    {
                        this.world.updateAllLightTypes(var5 - 1, var8, var6);
                    }

                    if (Block.lightEmission[this.world.getTypeId(var5 + 1, var8, var6)] > 0)
                    {
                        this.world.updateAllLightTypes(var5 + 1, var8, var6);
                    }

                    if (Block.lightEmission[this.world.getTypeId(var5, var8, var6 - 1)] > 0)
                    {
                        this.world.updateAllLightTypes(var5, var8, var6 - 1);
                    }

                    if (Block.lightEmission[this.world.getTypeId(var5, var8, var6 + 1)] > 0)
                    {
                        this.world.updateAllLightTypes(var5, var8, var6 + 1);
                    }

                    this.world.updateAllLightTypes(var5, var8, var6);
                }
            }
        }
    }
}
