package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.entity.EntityInteractEvent;

public abstract class BlockButtonAbstract extends Block
{
    /**
     * used as foreach item, if item.tab = current tab, display it on the screen
     */
    private final boolean displayOnCreativeTab;

    protected BlockButtonAbstract(int i, boolean flag)
    {
        super(i, Material.ORIENTABLE);
        this.setTickRandomly(true);
        this.a(CreativeModeTab.d);
        this.displayOnCreativeTab = flag;
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        return null;
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World world)
    {
        return this.displayOnCreativeTab ? 30 : 20;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public boolean canPlace(World world, int i, int j, int k, int l)
    {
        return l == 2 && world.isBlockNormalCube(i, j, k + 1) ? true : (l == 3 && world.isBlockNormalCube(i, j, k - 1) ? true : (l == 4 && world.isBlockNormalCube(i + 1, j, k) ? true : l == 5 && world.isBlockNormalCube(i - 1, j, k)));
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        return world.isBlockNormalCube(i - 1, j, k) ? true : (world.isBlockNormalCube(i + 1, j, k) ? true : (world.isBlockNormalCube(i, j, k - 1) ? true : world.isBlockNormalCube(i, j, k + 1)));
    }

    public int getPlacedData(World world, int i, int j, int k, int l, float f, float f1, float f2, int i1)
    {
        int j1 = world.getData(i, j, k);
        int k1 = j1 & 8;
        j1 &= 7;

        if (l == 2 && world.isBlockNormalCube(i, j, k + 1))
        {
            j1 = 4;
        }
        else if (l == 3 && world.isBlockNormalCube(i, j, k - 1))
        {
            j1 = 3;
        }
        else if (l == 4 && world.isBlockNormalCube(i + 1, j, k))
        {
            j1 = 2;
        }
        else if (l == 5 && world.isBlockNormalCube(i - 1, j, k))
        {
            j1 = 1;
        }
        else
        {
            j1 = this.k(world, i, j, k);
        }

        return j1 + k1;
    }

    private int k(World world, int i, int j, int k)
    {
        return world.isBlockNormalCube(i - 1, j, k) ? 1 : (world.isBlockNormalCube(i + 1, j, k) ? 2 : (world.isBlockNormalCube(i, j, k - 1) ? 3 : (world.isBlockNormalCube(i, j, k + 1) ? 4 : 1)));
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (this.m(world, i, j, k))
        {
            int i1 = world.getData(i, j, k) & 7;
            boolean flag = false;

            if (!world.isBlockNormalCube(i - 1, j, k) && i1 == 1)
            {
                flag = true;
            }

            if (!world.isBlockNormalCube(i + 1, j, k) && i1 == 2)
            {
                flag = true;
            }

            if (!world.isBlockNormalCube(i, j, k - 1) && i1 == 3)
            {
                flag = true;
            }

            if (!world.isBlockNormalCube(i, j, k + 1) && i1 == 4)
            {
                flag = true;
            }

            if (flag)
            {
                this.dropBlockAsItem(world, i, j, k, world.getData(i, j, k), 0);
                world.setAir(i, j, k);
            }
        }
    }

    private boolean m(World world, int i, int j, int k)
    {
        if (!this.canPlace(world, i, j, k))
        {
            this.dropBlockAsItem(world, i, j, k, world.getData(i, j, k), 0);
            world.setAir(i, j, k);
            return false;
        }
        else
        {
            return true;
        }
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = iblockaccess.getData(i, j, k);
        this.d(l);
    }

    private void d(int i)
    {
        int j = i & 7;
        boolean flag = (i & 8) > 0;
        float f = 0.375F;
        float f1 = 0.625F;
        float f2 = 0.1875F;
        float f3 = 0.125F;

        if (flag)
        {
            f3 = 0.0625F;
        }

        if (j == 1)
        {
            this.setBlockBounds(0.0F, f, 0.5F - f2, f3, f1, 0.5F + f2);
        }
        else if (j == 2)
        {
            this.setBlockBounds(1.0F - f3, f, 0.5F - f2, 1.0F, f1, 0.5F + f2);
        }
        else if (j == 3)
        {
            this.setBlockBounds(0.5F - f2, f, 0.0F, 0.5F + f2, f1, f3);
        }
        else if (j == 4)
        {
            this.setBlockBounds(0.5F - f2, f, 1.0F - f3, 0.5F + f2, f1, 1.0F);
        }
    }

    public void attack(World world, int i, int j, int k, EntityHuman entityhuman) {}

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        int i1 = world.getData(i, j, k);
        int j1 = i1 & 7;
        int k1 = 8 - (i1 & 8);

        if (k1 == 0)
        {
            return true;
        }
        else
        {
            org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
            int old = k1 != 8 ? 15 : 0;
            int current = k1 == 8 ? 15 : 0;
            BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, old, current);
            world.getServer().getPluginManager().callEvent(eventRedstone);

            if (eventRedstone.getNewCurrent() > 0 != (k1 == 8))
            {
                return true;
            }
            else
            {
                world.setData(i, j, k, j1 + k1, 3);
                world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
                world.makeSound((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D, "random.click", 0.3F, 0.6F);
                this.d(world, i, j, k, j1);
                world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
                return true;
            }
        }
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        if ((i1 & 8) > 0)
        {
            int j1 = i1 & 7;
            this.d(world, i, j, k, j1);
        }

        super.remove(world, i, j, k, l, i1);
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return (iblockaccess.getData(i, j, k) & 8) > 0 ? 15 : 0;
    }

    /**
     * Returns true if the block is emitting direct/strong redstone power on the specified side. Args: World, X, Y, Z,
     * side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingStrongPower(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        int i1 = iblockaccess.getData(i, j, k);

        if ((i1 & 8) == 0)
        {
            return 0;
        }
        else
        {
            int j1 = i1 & 7;
            return j1 == 5 && l == 1 ? 15 : (j1 == 4 && l == 2 ? 15 : (j1 == 3 && l == 3 ? 15 : (j1 == 2 && l == 4 ? 15 : (j1 == 1 && l == 5 ? 15 : 0))));
        }
    }

    public boolean isPowerSource()
    {
        return true;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        if (!world.isStatic)
        {
            int l = world.getData(i, j, k);

            if ((l & 8) != 0)
            {
                org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
                BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, 15, 0);
                world.getServer().getPluginManager().callEvent(eventRedstone);

                if (eventRedstone.getNewCurrent() > 0)
                {
                    return;
                }

                if (this.displayOnCreativeTab)
                {
                    this.n(world, i, j, k);
                }
                else
                {
                    world.setData(i, j, k, l & 7, 3);
                    int i1 = l & 7;
                    this.d(world, i, j, k, i1);
                    world.makeSound((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D, "random.click", 0.3F, 0.5F);
                    world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
                }
            }
        }
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        float f = 0.1875F;
        float f1 = 0.125F;
        float f2 = 0.125F;
        this.setBlockBounds(0.5F - f, 0.5F - f1, 0.5F - f2, 0.5F + f, 0.5F + f1, 0.5F + f2);
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
    {
        if (!world.isStatic && this.displayOnCreativeTab && (world.getData(i, j, k) & 8) == 0)
        {
            this.n(world, i, j, k);
        }
    }

    private void n(World world, int i, int j, int k)
    {
        int l = world.getData(i, j, k);
        int i1 = l & 7;
        boolean flag = (l & 8) != 0;
        this.d(l);
        List list = world.getEntitiesWithinAABB(EntityArrow.class, AxisAlignedBB.getAABBPool().getAABB((double)i + this.minX, (double)j + this.minY, (double)k + this.minZ, (double)i + this.maxX, (double)j + this.maxY, (double)k + this.maxZ));
        boolean flag1 = !list.isEmpty();

        if (flag != flag1 && flag1)
        {
            org.bukkit.block.Block block = world.getWorld().getBlockAt(i, j, k);
            boolean allowed = false;
            Iterator i$ = list.iterator();

            while (i$.hasNext())
            {
                Object object = i$.next();

                if (object != null)
                {
                    EntityInteractEvent event = new EntityInteractEvent(((Entity)object).getBukkitEntity(), block);
                    world.getServer().getPluginManager().callEvent(event);

                    if (!event.isCancelled())
                    {
                        allowed = true;
                        break;
                    }
                }
            }

            if (!allowed)
            {
                return;
            }
        }

        if (flag1 && !flag)
        {
            world.setData(i, j, k, i1 | 8, 3);
            this.d(world, i, j, k, i1);
            world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
            world.makeSound((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D, "random.click", 0.3F, 0.6F);
        }

        if (!flag1 && flag)
        {
            world.setData(i, j, k, i1, 3);
            this.d(world, i, j, k, i1);
            world.markBlockRangeForRenderUpdate(i, j, k, i, j, k);
            world.makeSound((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D, "random.click", 0.3F, 0.5F);
        }

        if (flag1)
        {
            world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
        }
    }

    private void d(World world, int i, int j, int k, int l)
    {
        world.applyPhysics(i, j, k, this.id);

        if (l == 1)
        {
            world.applyPhysics(i - 1, j, k, this.id);
        }
        else if (l == 2)
        {
            world.applyPhysics(i + 1, j, k, this.id);
        }
        else if (l == 3)
        {
            world.applyPhysics(i, j, k - 1, this.id);
        }
        else if (l == 4)
        {
            world.applyPhysics(i, j, k + 1, this.id);
        }
        else
        {
            world.applyPhysics(i, j - 1, k, this.id);
        }
    }
}
