package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntityWitch extends EntityMonster implements IRangedEntity
{
    private static final UUID field_110184_bp = UUID.fromString("5CD17E52-A79A-43D3-A529-90FDE04B181E");
    private static final AttributeModifier field_110185_bq = (new AttributeModifier(field_110184_bp, "Drinking speed penalty", -0.25D, 0)).setSaved(false);

    /** List of items a witch should drop on death. */
    private static final int[] witchDrops = new int[] {Item.GLOWSTONE_DUST.id, Item.SUGAR.id, Item.REDSTONE.id, Item.SPIDER_EYE.id, Item.GLASS_BOTTLE.id, Item.SULPHUR.id, Item.STICK.id, Item.STICK.id};

    /**
     * Timer used as interval for a witch's attack, decremented every tick if aggressive and when reaches zero the witch
     * will throw a potion at the target entity.
     */
    private int witchAttackTimer;

    public EntityWitch(World par1World)
    {
        super(par1World);
        this.goalSelector.a(1, new PathfinderGoalFloat(this));
        this.goalSelector.a(2, new PathfinderGoalArrowAttack(this, 1.0D, 60, 10.0F));
        this.goalSelector.a(2, new PathfinderGoalRandomStroll(this, 1.0D));
        this.goalSelector.a(3, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
        this.goalSelector.a(3, new PathfinderGoalRandomLookaround(this));
        this.targetSelector.a(1, new PathfinderGoalHurtByTarget(this, false));
        this.targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, EntityHuman.class, 0, true));
    }

    protected void entityInit()
    {
        super.entityInit();
        this.getDataWatcher().addObject(21, Byte.valueOf((byte)0));
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return "mob.witch.idle";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.witch.hurt";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.witch.death";
    }

    /**
     * Set whether this witch is aggressive at an entity.
     */
    public void setAggressive(boolean par1)
    {
        this.getDataWatcher().watch(21, Byte.valueOf((byte)(par1 ? 1 : 0)));
    }

    /**
     * Return whether this witch is aggressive at an entity.
     */
    public boolean getAggressive()
    {
        return this.getDataWatcher().getByte(21) == 1;
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.a).setValue(26.0D);
        this.getAttributeInstance(GenericAttributes.d).setValue(0.25D);
    }

    /**
     * Returns true if the newer Entity AI code should be run
     */
    public boolean isAIEnabled()
    {
        return true;
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
        if (!this.world.isStatic)
        {
            if (this.getAggressive())
            {
                if (this.witchAttackTimer-- <= 0)
                {
                    this.setAggressive(false);
                    ItemStack var1 = this.getHeldItem();
                    this.setEquipment(0, (ItemStack)null);

                    if (var1 != null && var1.id == Item.POTION.id)
                    {
                        List var2 = Item.POTION.getEffects(var1);

                        if (var2 != null)
                        {
                            Iterator var3 = var2.iterator();

                            while (var3.hasNext())
                            {
                                MobEffect var4 = (MobEffect)var3.next();
                                this.addEffect(new MobEffect(var4));
                            }
                        }
                    }

                    this.getAttributeInstance(GenericAttributes.d).removeModifier(field_110185_bq);
                }
            }
            else
            {
                short var5 = -1;

                if (this.random.nextFloat() < 0.15F && this.isBurning() && !this.hasEffect(MobEffectList.FIRE_RESISTANCE))
                {
                    var5 = 16307;
                }
                else if (this.random.nextFloat() < 0.05F && this.getHealth() < this.getMaxHealth())
                {
                    var5 = 16341;
                }
                else if (this.random.nextFloat() < 0.25F && this.getGoalTarget() != null && !this.hasEffect(MobEffectList.FASTER_MOVEMENT) && this.getGoalTarget().getDistanceSqToEntity(this) > 121.0D)
                {
                    var5 = 16274;
                }
                else if (this.random.nextFloat() < 0.25F && this.getGoalTarget() != null && !this.hasEffect(MobEffectList.FASTER_MOVEMENT) && this.getGoalTarget().getDistanceSqToEntity(this) > 121.0D)
                {
                    var5 = 16274;
                }

                if (var5 > -1)
                {
                    this.setEquipment(0, new ItemStack(Item.POTION, 1, var5));
                    this.witchAttackTimer = this.getHeldItem().getMaxItemUseDuration();
                    this.setAggressive(true);
                    AttributeInstance var6 = this.getAttributeInstance(GenericAttributes.d);
                    var6.removeModifier(field_110185_bq);
                    var6.applyModifier(field_110185_bq);
                }
            }

            if (this.random.nextFloat() < 7.5E-4F)
            {
                this.world.broadcastEntityEffect(this, (byte)15);
            }
        }

        super.onLivingUpdate();
    }

    /**
     * Reduces damage, depending on potions
     */
    protected float applyPotionDamageCalculations(DamageSource par1DamageSource, float par2)
    {
        par2 = super.applyPotionDamageCalculations(par1DamageSource, par2);

        if (par1DamageSource.getEntity() == this)
        {
            par2 = 0.0F;
        }

        if (par1DamageSource.isMagicDamage())
        {
            par2 = (float)((double)par2 * 0.15D);
        }

        return par2;
    }

    protected void dropDeathLoot(boolean flag, int i)
    {
        ArrayList loot = new ArrayList();
        int j = this.random.nextInt(3) + 1;

        for (int k = 0; k < j; ++k)
        {
            int l = this.random.nextInt(3);
            int i1 = witchDrops[this.random.nextInt(witchDrops.length)];

            if (i > 0)
            {
                l += this.random.nextInt(i + 1);
            }

            loot.add(new org.bukkit.inventory.ItemStack(i1, l));
        }

        CraftEventFactory.callEntityDeathEvent(this, loot);
    }

    public void a(EntityLiving entityliving, float f)
    {
        if (!this.getAggressive())
        {
            EntityPotion entitypotion = new EntityPotion(this.world, this, 32732);
            entitypotion.pitch -= -20.0F;
            double d0 = entityliving.locX + entityliving.motX - this.locX;
            double d1 = entityliving.locY + (double)entityliving.getHeadHeight() - 1.100000023841858D - this.locY;
            double d2 = entityliving.locZ + entityliving.motZ - this.locZ;
            float f1 = MathHelper.sqrt(d0 * d0 + d2 * d2);

            if (f1 >= 8.0F && !entityliving.hasEffect(MobEffectList.SLOWER_MOVEMENT))
            {
                entitypotion.setPotionValue(32698);
            }
            else if (entityliving.getHealth() >= 8.0F && !entityliving.hasEffect(MobEffectList.POISON))
            {
                entitypotion.setPotionValue(32660);
            }
            else if (f1 <= 3.0F && !entityliving.hasEffect(MobEffectList.WEAKNESS) && this.random.nextFloat() < 0.25F)
            {
                entitypotion.setPotionValue(32696);
            }

            entitypotion.shoot(d0, d1 + (double)(f1 * 0.2F), d2, 0.75F, 8.0F);
            this.world.addEntity(entitypotion);
        }
    }
}
