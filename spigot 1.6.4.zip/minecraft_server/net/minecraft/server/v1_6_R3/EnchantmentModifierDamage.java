package net.minecraft.server.v1_6_R3;

final class EnchantmentModifierDamage implements EnchantmentModifier
{
    /**
     * Used to calculate the damage modifier (extra armor) on enchantments that the player have on equipped armors.
     */
    public float damageModifier;

    /**
     * Used as parameter to calculate the damage modifier (extra armor) on enchantments that the player have on equipped
     * armors.
     */
    public EntityLiving source;

    private EnchantmentModifierDamage() {}

    /**
     * Generic method use to calculate modifiers of offensive or defensive enchantment values.
     */
    public void calculateModifier(Enchantment par1Enchantment, int par2)
    {
        this.damageModifier += par1Enchantment.a(par2, this.source);
    }

    EnchantmentModifierDamage(EmptyClass var1)
    {
        this();
    }
}
