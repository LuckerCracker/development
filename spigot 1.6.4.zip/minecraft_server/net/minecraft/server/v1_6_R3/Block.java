package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class Block
{
    private CreativeModeTab creativeTab;
    protected String textureName;
    public static final StepSound soundPowderFootstep = new StepSound("stone", 1.0F, 1.0F);
    public static final StepSound soundWoodFootstep = new StepSound("wood", 1.0F, 1.0F);
    public static final StepSound soundGravelFootstep = new StepSound("gravel", 1.0F, 1.0F);
    public static final StepSound soundGrassFootstep = new StepSound("grass", 1.0F, 1.0F);
    public static final StepSound soundStoneFootstep = new StepSound("stone", 1.0F, 1.0F);
    public static final StepSound soundMetalFootstep = new StepSound("stone", 1.0F, 1.5F);
    public static final StepSound soundGlassFootstep = new StepSoundStone("stone", 1.0F, 1.0F);
    public static final StepSound soundClothFootstep = new StepSound("cloth", 1.0F, 1.0F);
    public static final StepSound soundSandFootstep = new StepSound("sand", 1.0F, 1.0F);
    public static final StepSound soundSnowFootstep = new StepSound("snow", 1.0F, 1.0F);
    public static final StepSound soundLadderFootstep = new StepSoundLadder("ladder", 1.0F, 1.0F);
    public static final StepSound soundAnvilFootstep = new StepSoundAnvil("anvil", 0.3F, 1.0F);
    public static final Block[] byId = new Block[4096];

    /**
     * An array of 4096 booleans corresponding to the result of the isOpaqueCube() method for each block ID
     */
    public static final boolean[] opaqueCubeLookup = new boolean[4096];
    public static final int[] lightBlock = new int[4096];

    /** Array of booleans that tells if a block can grass */
    public static final boolean[] canBlockGrass = new boolean[4096];
    public static final int[] lightEmission = new int[4096];

    /**
     * Flag if block ID should use the brightest neighbor light value as its own
     */
    public static boolean[] useNeighborBrightness = new boolean[4096];
    public static final Block STONE = (new BlockStone(1)).setHardness(1.5F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("stone").setTextureName("stone");
    public static final BlockGrass GRASS = (BlockGrass)(new BlockGrass(2)).setHardness(0.6F).setStepSound(soundGrassFootstep).setUnlocalizedName("grass").setTextureName("grass");
    public static final Block DIRT = (new BlockDirt(3)).setHardness(0.5F).setStepSound(soundGravelFootstep).setUnlocalizedName("dirt").setTextureName("dirt");
    public static final Block COBBLESTONE = (new Block(4, Material.STONE)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("stonebrick").a(CreativeModeTab.b).setTextureName("cobblestone");
    public static final Block WOOD = (new BlockWood(5)).setHardness(2.0F).setResistance(5.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("wood").setTextureName("planks");
    public static final Block SAPLING = (new BlockSapling(6)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("sapling").setTextureName("sapling");
    public static final Block BEDROCK = (new Block(7, Material.STONE)).setBlockUnbreakable().setResistance(6000000.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("bedrock").disableStats().a(CreativeModeTab.b).setTextureName("bedrock");
    public static final BlockFluids WATER = (BlockFluids)(new BlockFlowing(8, Material.WATER)).setHardness(100.0F).setLightOpacity(3).setUnlocalizedName("water").disableStats().setTextureName("water_flow");
    public static final Block STATIONARY_WATER = (new BlockStationary(9, Material.WATER)).setHardness(100.0F).setLightOpacity(3).setUnlocalizedName("water").disableStats().setTextureName("water_still");
    public static final BlockFluids LAVA = (BlockFluids)(new BlockFlowing(10, Material.LAVA)).setHardness(0.0F).setLightValue(1.0F).setUnlocalizedName("lava").disableStats().setTextureName("lava_flow");
    public static final Block STATIONARY_LAVA = (new BlockStationary(11, Material.LAVA)).setHardness(100.0F).setLightValue(1.0F).setUnlocalizedName("lava").disableStats().setTextureName("lava_still");
    public static final Block SAND = (new BlockSand(12)).setHardness(0.5F).setStepSound(soundSandFootstep).setUnlocalizedName("sand").setTextureName("sand");
    public static final Block GRAVEL = (new BlockGravel(13)).setHardness(0.6F).setStepSound(soundGravelFootstep).setUnlocalizedName("gravel").setTextureName("gravel");
    public static final Block GOLD_ORE = (new BlockOre(14)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreGold").setTextureName("gold_ore");
    public static final Block IRON_ORE = (new BlockOre(15)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreIron").setTextureName("iron_ore");
    public static final Block COAL_ORE = (new BlockOre(16)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreCoal").setTextureName("coal_ore");
    public static final Block LOG = (new BlockLog(17)).setHardness(2.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("log").setTextureName("log");
    public static final BlockLeaves LEAVES = (BlockLeaves)(new BlockLeaves(18)).setHardness(0.2F).setLightOpacity(1).setStepSound(soundGrassFootstep).setUnlocalizedName("leaves").setTextureName("leaves");
    public static final Block SPONGE = (new BlockSponge(19)).setHardness(0.6F).setStepSound(soundGrassFootstep).setUnlocalizedName("sponge").setTextureName("sponge");
    public static final Block GLASS = (new BlockGlass(20, Material.SHATTERABLE, false)).setHardness(0.3F).setStepSound(soundGlassFootstep).setUnlocalizedName("glass").setTextureName("glass");
    public static final Block LAPIS_ORE = (new BlockOre(21)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreLapis").setTextureName("lapis_ore");
    public static final Block LAPIS_BLOCK = (new Block(22, Material.STONE)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("blockLapis").a(CreativeModeTab.b).setTextureName("lapis_block");
    public static final Block DISPENSER = (new BlockDispenser(23)).setHardness(3.5F).setStepSound(soundStoneFootstep).setUnlocalizedName("dispenser").setTextureName("dispenser");
    public static final Block SANDSTONE = (new BlockSandStone(24)).setStepSound(soundStoneFootstep).setHardness(0.8F).setUnlocalizedName("sandStone").setTextureName("sandstone");
    public static final Block NOTE_BLOCK = (new BlockNote(25)).setHardness(0.8F).setUnlocalizedName("musicBlock").setTextureName("noteblock");
    public static final Block BED = (new BlockBed(26)).setHardness(0.2F).setUnlocalizedName("bed").disableStats().setTextureName("bed");
    public static final Block GOLDEN_RAIL = (new BlockPoweredRail(27)).setHardness(0.7F).setStepSound(soundMetalFootstep).setUnlocalizedName("goldenRail").setTextureName("rail_golden");
    public static final Block DETECTOR_RAIL = (new BlockMinecartDetector(28)).setHardness(0.7F).setStepSound(soundMetalFootstep).setUnlocalizedName("detectorRail").setTextureName("rail_detector");
    public static final BlockPiston PISTON_STICKY = (BlockPiston)(new BlockPiston(29, true)).setUnlocalizedName("pistonStickyBase");
    public static final Block WEB = (new BlockWeb(30)).setLightOpacity(1).setHardness(4.0F).setUnlocalizedName("web").setTextureName("web");
    public static final BlockLongGrass LONG_GRASS = (BlockLongGrass)(new BlockLongGrass(31)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("tallgrass");
    public static final BlockDeadBush DEAD_BUSH = (BlockDeadBush)(new BlockDeadBush(32)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("deadbush").setTextureName("deadbush");
    public static final BlockPiston PISTON = (BlockPiston)(new BlockPiston(33, false)).setUnlocalizedName("pistonBase");
    public static final BlockPistonExtension PISTON_EXTENSION = new BlockPistonExtension(34);
    public static final Block WOOL = (new BlockCloth(35, Material.CLOTH)).setHardness(0.8F).setStepSound(soundClothFootstep).setUnlocalizedName("cloth").setTextureName("wool_colored");
    public static final BlockPistonMoving PISTON_MOVING = new BlockPistonMoving(36);
    public static final BlockFlower YELLOW_FLOWER = (BlockFlower)(new BlockFlower(37)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("flower").setTextureName("flower_dandelion");
    public static final BlockFlower RED_ROSE = (BlockFlower)(new BlockFlower(38)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("rose").setTextureName("flower_rose");
    public static final BlockFlower BROWN_MUSHROOM = (BlockFlower)(new BlockMushroom(39)).setHardness(0.0F).setStepSound(soundGrassFootstep).setLightValue(0.125F).setUnlocalizedName("mushroom").setTextureName("mushroom_brown");
    public static final BlockFlower RED_MUSHROOM = (BlockFlower)(new BlockMushroom(40)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("mushroom").setTextureName("mushroom_red");
    public static final Block GOLD_BLOCK = (new BlockOreBlock(41)).setHardness(3.0F).setResistance(10.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("blockGold").setTextureName("gold_block");
    public static final Block IRON_BLOCK = (new BlockOreBlock(42)).setHardness(5.0F).setResistance(10.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("blockIron").setTextureName("iron_block");
    public static final BlockStepAbstract DOUBLE_STEP = (BlockStepAbstract)(new BlockStep(43, true)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("stoneSlab");
    public static final BlockStepAbstract STEP = (BlockStepAbstract)(new BlockStep(44, false)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("stoneSlab");
    public static final Block BRICK = (new Block(45, Material.STONE)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("brick").a(CreativeModeTab.b).setTextureName("brick");
    public static final Block TNT = (new BlockTNT(46)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("tnt").setTextureName("tnt");
    public static final Block BOOKSHELF = (new BlockBookshelf(47)).setHardness(1.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("bookshelf").setTextureName("bookshelf");
    public static final Block MOSSY_COBBLESTONE = (new Block(48, Material.STONE)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("stoneMoss").a(CreativeModeTab.b).setTextureName("cobblestone_mossy");
    public static final Block OBSIDIAN = (new BlockObsidian(49)).setHardness(50.0F).setResistance(2000.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("obsidian").setTextureName("obsidian");
    public static final Block TORCH = (new BlockTorch(50)).setHardness(0.0F).setLightValue(0.9375F).setStepSound(soundWoodFootstep).setUnlocalizedName("torch").setTextureName("torch_on");
    public static final BlockFire FIRE = (BlockFire)(new BlockFire(51)).setHardness(0.0F).setLightValue(1.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("fire").disableStats().setTextureName("fire");
    public static final Block MOB_SPAWNER = (new BlockMobSpawner(52)).setHardness(5.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("mobSpawner").disableStats().setTextureName("mob_spawner");
    public static final Block WOOD_STAIRS = (new BlockStairs(53, WOOD, 0)).setUnlocalizedName("stairsWood");
    public static final BlockChest CHEST = (BlockChest)(new BlockChest(54, 0)).setHardness(2.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("chest");
    public static final BlockRedstoneWire REDSTONE_WIRE = (BlockRedstoneWire)(new BlockRedstoneWire(55)).setHardness(0.0F).setStepSound(soundPowderFootstep).setUnlocalizedName("redstoneDust").disableStats().setTextureName("redstone_dust");
    public static final Block DIAMOND_ORE = (new BlockOre(56)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreDiamond").setTextureName("diamond_ore");
    public static final Block DIAMOND_BLOCK = (new BlockOreBlock(57)).setHardness(5.0F).setResistance(10.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("blockDiamond").setTextureName("diamond_block");
    public static final Block WORKBENCH = (new BlockWorkbench(58)).setHardness(2.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("workbench").setTextureName("crafting_table");
    public static final Block CROPS = (new BlockCrops(59)).setUnlocalizedName("crops").setTextureName("wheat");
    public static final Block SOIL = (new BlockSoil(60)).setHardness(0.6F).setStepSound(soundGravelFootstep).setUnlocalizedName("farmland").setTextureName("farmland");
    public static final Block FURNACE = (new BlockFurnace(61, false)).setHardness(3.5F).setStepSound(soundStoneFootstep).setUnlocalizedName("furnace").a(CreativeModeTab.c);
    public static final Block BURNING_FURNACE = (new BlockFurnace(62, true)).setHardness(3.5F).setStepSound(soundStoneFootstep).setLightValue(0.875F).setUnlocalizedName("furnace");
    public static final Block SIGN_POST = (new BlockSign(63, TileEntitySign.class, true)).setHardness(1.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("sign").disableStats();
    public static final Block WOODEN_DOOR = (new BlockDoor(64, Material.WOOD)).setHardness(3.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("doorWood").disableStats().setTextureName("door_wood");
    public static final Block LADDER = (new BlockLadder(65)).setHardness(0.4F).setStepSound(soundLadderFootstep).setUnlocalizedName("ladder").setTextureName("ladder");
    public static final Block RAILS = (new BlockMinecartTrack(66)).setHardness(0.7F).setStepSound(soundMetalFootstep).setUnlocalizedName("rail").setTextureName("rail_normal");
    public static final Block COBBLESTONE_STAIRS = (new BlockStairs(67, COBBLESTONE, 0)).setUnlocalizedName("stairsStone");
    public static final Block WALL_SIGN = (new BlockSign(68, TileEntitySign.class, false)).setHardness(1.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("sign").disableStats();
    public static final Block LEVER = (new BlockLever(69)).setHardness(0.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("lever").setTextureName("lever");
    public static final Block STONE_PLATE = (new BlockPressurePlateBinary(70, "stone", Material.STONE, EnumMobType.MOBS)).setHardness(0.5F).setStepSound(soundStoneFootstep).setUnlocalizedName("pressurePlate");
    public static final Block IRON_DOOR_BLOCK = (new BlockDoor(71, Material.ORE)).setHardness(5.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("doorIron").disableStats().setTextureName("door_iron");
    public static final Block WOOD_PLATE = (new BlockPressurePlateBinary(72, "planks_oak", Material.WOOD, EnumMobType.EVERYTHING)).setHardness(0.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("pressurePlate");
    public static final Block REDSTONE_ORE = (new BlockRedstoneOre(73, false)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreRedstone").a(CreativeModeTab.b).setTextureName("redstone_ore");
    public static final Block GLOWING_REDSTONE_ORE = (new BlockRedstoneOre(74, true)).setLightValue(0.625F).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreRedstone").setTextureName("redstone_ore");
    public static final Block REDSTONE_TORCH_OFF = (new BlockRedstoneTorch(75, false)).setHardness(0.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("notGate").setTextureName("redstone_torch_off");
    public static final Block REDSTONE_TORCH_ON = (new BlockRedstoneTorch(76, true)).setHardness(0.0F).setLightValue(0.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("notGate").a(CreativeModeTab.d).setTextureName("redstone_torch_on");
    public static final Block STONE_BUTTON = (new BlockStoneButton(77)).setHardness(0.5F).setStepSound(soundStoneFootstep).setUnlocalizedName("button");
    public static final Block SNOW = (new BlockSnow(78)).setHardness(0.1F).setStepSound(soundSnowFootstep).setUnlocalizedName("snow").setLightOpacity(0).setTextureName("snow");
    public static final Block ICE = (new BlockIce(79)).setHardness(0.5F).setLightOpacity(3).setStepSound(soundGlassFootstep).setUnlocalizedName("ice").setTextureName("ice");
    public static final Block SNOW_BLOCK = (new BlockSnowBlock(80)).setHardness(0.2F).setStepSound(soundSnowFootstep).setUnlocalizedName("snow").setTextureName("snow");
    public static final Block CACTUS = (new BlockCactus(81)).setHardness(0.4F).setStepSound(soundClothFootstep).setUnlocalizedName("cactus").setTextureName("cactus");
    public static final Block CLAY = (new BlockClay(82)).setHardness(0.6F).setStepSound(soundGravelFootstep).setUnlocalizedName("clay").setTextureName("clay");
    public static final Block SUGAR_CANE_BLOCK = (new BlockReed(83)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("reeds").disableStats().setTextureName("reeds");
    public static final Block JUKEBOX = (new BlockJukeBox(84)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("jukebox").setTextureName("jukebox");
    public static final Block FENCE = (new BlockFence(85, "planks_oak", Material.WOOD)).setHardness(2.0F).setResistance(5.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("fence");
    public static final Block PUMPKIN = (new BlockPumpkin(86, false)).setHardness(1.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("pumpkin").setTextureName("pumpkin");
    public static final Block NETHERRACK = (new BlockBloodStone(87)).setHardness(0.4F).setStepSound(soundStoneFootstep).setUnlocalizedName("hellrock").setTextureName("netherrack");
    public static final Block SOUL_SAND = (new BlockSlowSand(88)).setHardness(0.5F).setStepSound(soundSandFootstep).setUnlocalizedName("hellsand").setTextureName("soul_sand");
    public static final Block GLOWSTONE = (new BlockLightStone(89, Material.SHATTERABLE)).setHardness(0.3F).setStepSound(soundGlassFootstep).setLightValue(1.0F).setUnlocalizedName("lightgem").setTextureName("glowstone");
    public static final BlockPortal PORTAL = (BlockPortal)(new BlockPortal(90)).setHardness(-1.0F).setStepSound(soundGlassFootstep).setLightValue(0.75F).setUnlocalizedName("portal").setTextureName("portal");
    public static final Block JACK_O_LANTERN = (new BlockPumpkin(91, true)).setHardness(1.0F).setStepSound(soundWoodFootstep).setLightValue(1.0F).setUnlocalizedName("litpumpkin").setTextureName("pumpkin");
    public static final Block CAKE_BLOCK = (new BlockCake(92)).setHardness(0.5F).setStepSound(soundClothFootstep).setUnlocalizedName("cake").disableStats().setTextureName("cake");
    public static final BlockRepeater DIODE_OFF = (BlockRepeater)(new BlockRepeater(93, false)).setHardness(0.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("diode").disableStats().setTextureName("repeater_off");
    public static final BlockRepeater DIODE_ON = (BlockRepeater)(new BlockRepeater(94, true)).setHardness(0.0F).setLightValue(0.625F).setStepSound(soundWoodFootstep).setUnlocalizedName("diode").disableStats().setTextureName("repeater_on");
    public static final Block LOCKED_CHEST = (new BlockLockedChest(95)).setHardness(0.0F).setLightValue(1.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("lockedchest").setTickRandomly(true);
    public static final Block TRAP_DOOR = (new BlockTrapdoor(96, Material.WOOD)).setHardness(3.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("trapdoor").disableStats().setTextureName("trapdoor");
    public static final Block MONSTER_EGGS = (new BlockMonsterEggs(97)).setHardness(0.75F).setUnlocalizedName("monsterStoneEgg");
    public static final Block SMOOTH_BRICK = (new BlockSmoothBrick(98)).setHardness(1.5F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("stonebricksmooth").setTextureName("stonebrick");
    public static final Block BIG_MUSHROOM_1 = (new BlockHugeMushroom(99, Material.WOOD, 0)).setHardness(0.2F).setStepSound(soundWoodFootstep).setUnlocalizedName("mushroom").setTextureName("mushroom_block");
    public static final Block BIG_MUSHROOM_2 = (new BlockHugeMushroom(100, Material.WOOD, 1)).setHardness(0.2F).setStepSound(soundWoodFootstep).setUnlocalizedName("mushroom").setTextureName("mushroom_block");
    public static final Block IRON_FENCE = (new BlockThinFence(101, "iron_bars", "iron_bars", Material.ORE, true)).setHardness(5.0F).setResistance(10.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("fenceIron");
    public static final Block THIN_GLASS = (new BlockThinFence(102, "glass", "glass_pane_top", Material.SHATTERABLE, false)).setHardness(0.3F).setStepSound(soundGlassFootstep).setUnlocalizedName("thinGlass");
    public static final Block MELON = (new BlockMelon(103)).setHardness(1.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("melon").setTextureName("melon");
    public static final Block PUMPKIN_STEM = (new BlockStem(104, PUMPKIN)).setHardness(0.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("pumpkinStem").setTextureName("pumpkin_stem");
    public static final Block MELON_STEM = (new BlockStem(105, MELON)).setHardness(0.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("pumpkinStem").setTextureName("melon_stem");
    public static final Block VINE = (new BlockVine(106)).setHardness(0.2F).setStepSound(soundGrassFootstep).setUnlocalizedName("vine").setTextureName("vine");
    public static final Block FENCE_GATE = (new BlockFenceGate(107)).setHardness(2.0F).setResistance(5.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("fenceGate");
    public static final Block BRICK_STAIRS = (new BlockStairs(108, BRICK, 0)).setUnlocalizedName("stairsBrick");
    public static final Block STONE_STAIRS = (new BlockStairs(109, SMOOTH_BRICK, 0)).setUnlocalizedName("stairsStoneBrickSmooth");
    public static final BlockMycel MYCEL = (BlockMycel)(new BlockMycel(110)).setHardness(0.6F).setStepSound(soundGrassFootstep).setUnlocalizedName("mycel").setTextureName("mycelium");
    public static final Block WATER_LILY = (new BlockWaterLily(111)).setHardness(0.0F).setStepSound(soundGrassFootstep).setUnlocalizedName("waterlily").setTextureName("waterlily");
    public static final Block NETHER_BRICK = (new Block(112, Material.STONE)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("netherBrick").a(CreativeModeTab.b).setTextureName("nether_brick");
    public static final Block NETHER_FENCE = (new BlockFence(113, "nether_brick", Material.STONE)).setHardness(2.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("netherFence");
    public static final Block NETHER_BRICK_STAIRS = (new BlockStairs(114, NETHER_BRICK, 0)).setUnlocalizedName("stairsNetherBrick");
    public static final Block NETHER_WART = (new BlockNetherWart(115)).setUnlocalizedName("netherStalk").setTextureName("nether_wart");
    public static final Block ENCHANTMENT_TABLE = (new BlockEnchantmentTable(116)).setHardness(5.0F).setResistance(2000.0F).setUnlocalizedName("enchantmentTable").setTextureName("enchanting_table");
    public static final Block BREWING_STAND = (new BlockBrewingStand(117)).setHardness(0.5F).setLightValue(0.125F).setUnlocalizedName("brewingStand").setTextureName("brewing_stand");
    public static final BlockCauldron CAULDRON = (BlockCauldron)(new BlockCauldron(118)).setHardness(2.0F).setUnlocalizedName("cauldron").setTextureName("cauldron");
    public static final Block ENDER_PORTAL = (new BlockEnderPortal(119, Material.PORTAL)).setHardness(-1.0F).setResistance(6000000.0F);
    public static final Block ENDER_PORTAL_FRAME = (new BlockEnderPortalFrame(120)).setStepSound(soundGlassFootstep).setLightValue(0.125F).setHardness(-1.0F).setUnlocalizedName("endPortalFrame").setResistance(6000000.0F).a(CreativeModeTab.c).setTextureName("endframe");
    public static final Block WHITESTONE = (new Block(121, Material.STONE)).setHardness(3.0F).setResistance(15.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("whiteStone").a(CreativeModeTab.b).setTextureName("end_stone");
    public static final Block DRAGON_EGG = (new BlockDragonEgg(122)).setHardness(3.0F).setResistance(15.0F).setStepSound(soundStoneFootstep).setLightValue(0.125F).setUnlocalizedName("dragonEgg").setTextureName("dragon_egg");
    public static final Block REDSTONE_LAMP_OFF = (new BlockRedstoneLamp(123, false)).setHardness(0.3F).setStepSound(soundGlassFootstep).setUnlocalizedName("redstoneLight").a(CreativeModeTab.d).setTextureName("redstone_lamp_off");
    public static final Block REDSTONE_LAMP_ON = (new BlockRedstoneLamp(124, true)).setHardness(0.3F).setStepSound(soundGlassFootstep).setUnlocalizedName("redstoneLight").setTextureName("redstone_lamp_on");
    public static final BlockStepAbstract WOOD_DOUBLE_STEP = (BlockStepAbstract)(new BlockWoodStep(125, true)).setHardness(2.0F).setResistance(5.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("woodSlab");
    public static final BlockStepAbstract WOOD_STEP = (BlockStepAbstract)(new BlockWoodStep(126, false)).setHardness(2.0F).setResistance(5.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("woodSlab");
    public static final Block COCOA = (new BlockCocoa(127)).setHardness(0.2F).setResistance(5.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("cocoa").setTextureName("cocoa");
    public static final Block SANDSTONE_STAIRS = (new BlockStairs(128, SANDSTONE, 0)).setUnlocalizedName("stairsSandStone");
    public static final Block EMERALD_ORE = (new BlockOre(129)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("oreEmerald").setTextureName("emerald_ore");
    public static final Block ENDER_CHEST = (new BlockEnderChest(130)).setHardness(22.5F).setResistance(1000.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("enderChest").setLightValue(0.5F);
    public static final BlockTripwireHook TRIPWIRE_SOURCE = (BlockTripwireHook)(new BlockTripwireHook(131)).setUnlocalizedName("tripWireSource").setTextureName("trip_wire_source");
    public static final Block TRIPWIRE = (new BlockTripwire(132)).setUnlocalizedName("tripWire").setTextureName("trip_wire");
    public static final Block EMERALD_BLOCK = (new BlockOreBlock(133)).setHardness(5.0F).setResistance(10.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("blockEmerald").setTextureName("emerald_block");
    public static final Block SPRUCE_WOOD_STAIRS = (new BlockStairs(134, WOOD, 1)).setUnlocalizedName("stairsWoodSpruce");
    public static final Block BIRCH_WOOD_STAIRS = (new BlockStairs(135, WOOD, 2)).setUnlocalizedName("stairsWoodBirch");
    public static final Block JUNGLE_WOOD_STAIRS = (new BlockStairs(136, WOOD, 3)).setUnlocalizedName("stairsWoodJungle");
    public static final Block COMMAND = (new BlockCommand(137)).setBlockUnbreakable().setResistance(6000000.0F).setUnlocalizedName("commandBlock").setTextureName("command_block");
    public static final BlockBeacon BEACON = (BlockBeacon)(new BlockBeacon(138)).setUnlocalizedName("beacon").setLightValue(1.0F).setTextureName("beacon");
    public static final Block COBBLE_WALL = (new BlockCobbleWall(139, COBBLESTONE)).setUnlocalizedName("cobbleWall");
    public static final Block FLOWER_POT = (new BlockFlowerPot(140)).setHardness(0.0F).setStepSound(soundPowderFootstep).setUnlocalizedName("flowerPot").setTextureName("flower_pot");
    public static final Block CARROTS = (new BlockCarrots(141)).setUnlocalizedName("carrots").setTextureName("carrots");
    public static final Block POTATOES = (new BlockPotatoes(142)).setUnlocalizedName("potatoes").setTextureName("potatoes");
    public static final Block WOOD_BUTTON = (new BlockWoodButton(143)).setHardness(0.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("button");
    public static final Block SKULL = (new BlockSkull(144)).setHardness(1.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("skull").setTextureName("skull");
    public static final Block ANVIL = (new BlockAnvil(145)).setHardness(5.0F).setStepSound(soundAnvilFootstep).setResistance(2000.0F).setUnlocalizedName("anvil");
    public static final Block TRAPPED_CHEST = (new BlockChest(146, 1)).setHardness(2.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("chestTrap");
    public static final Block GOLD_PLATE = (new BlockPressurePlateWeighted(147, "gold_block", Material.ORE, 64)).setHardness(0.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("weightedPlate_light");
    public static final Block IRON_PLATE = (new BlockPressurePlateWeighted(148, "iron_block", Material.ORE, 640)).setHardness(0.5F).setStepSound(soundWoodFootstep).setUnlocalizedName("weightedPlate_heavy");
    public static final BlockRedstoneComparator REDSTONE_COMPARATOR_OFF = (BlockRedstoneComparator)(new BlockRedstoneComparator(149, false)).setHardness(0.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("comparator").disableStats().setTextureName("comparator_off");
    public static final BlockRedstoneComparator REDSTONE_COMPARATOR_ON = (BlockRedstoneComparator)(new BlockRedstoneComparator(150, true)).setHardness(0.0F).setLightValue(0.625F).setStepSound(soundWoodFootstep).setUnlocalizedName("comparator").disableStats().setTextureName("comparator_on");
    public static final BlockDaylightDetector DAYLIGHT_DETECTOR = (BlockDaylightDetector)(new BlockDaylightDetector(151)).setHardness(0.2F).setStepSound(soundWoodFootstep).setUnlocalizedName("daylightDetector").setTextureName("daylight_detector");
    public static final Block REDSTONE_BLOCK = (new BlockRedstone(152)).setHardness(5.0F).setResistance(10.0F).setStepSound(soundMetalFootstep).setUnlocalizedName("blockRedstone").setTextureName("redstone_block");
    public static final Block QUARTZ_ORE = (new BlockOre(153)).setHardness(3.0F).setResistance(5.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("netherquartz").setTextureName("quartz_ore");
    public static final BlockHopper HOPPER = (BlockHopper)(new BlockHopper(154)).setHardness(3.0F).setResistance(8.0F).setStepSound(soundWoodFootstep).setUnlocalizedName("hopper").setTextureName("hopper");
    public static final Block QUARTZ_BLOCK = (new BlockQuartz(155)).setStepSound(soundStoneFootstep).setHardness(0.8F).setUnlocalizedName("quartzBlock").setTextureName("quartz_block");
    public static final Block QUARTZ_STAIRS = (new BlockStairs(156, QUARTZ_BLOCK, 0)).setUnlocalizedName("stairsQuartz");
    public static final Block ACTIVATOR_RAIL = (new BlockPoweredRail(157)).setHardness(0.7F).setStepSound(soundMetalFootstep).setUnlocalizedName("activatorRail").setTextureName("rail_activator");
    public static final Block DROPPER = (new BlockDropper(158)).setHardness(3.5F).setStepSound(soundStoneFootstep).setUnlocalizedName("dropper").setTextureName("dropper");
    public static final Block STAINED_HARDENED_CLAY = (new BlockCloth(159, Material.STONE)).setHardness(1.25F).setResistance(7.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("clayHardenedStained").setTextureName("hardened_clay_stained");
    public static final Block HAY_BLOCK = (new BlockHay(170)).setHardness(0.5F).setStepSound(soundGrassFootstep).setUnlocalizedName("hayBlock").a(CreativeModeTab.b).setTextureName("hay_block");
    public static final Block WOOL_CARPET = (new BlockCarpet(171)).setHardness(0.1F).setStepSound(soundClothFootstep).setUnlocalizedName("woolCarpet").setLightOpacity(0);
    public static final Block HARDENED_CLAY = (new Block(172, Material.STONE)).setHardness(1.25F).setResistance(7.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("clayHardened").a(CreativeModeTab.b).setTextureName("hardened_clay");
    public static final Block COAL_BLOCK = (new Block(173, Material.STONE)).setHardness(5.0F).setResistance(10.0F).setStepSound(soundStoneFootstep).setUnlocalizedName("blockCoal").a(CreativeModeTab.b).setTextureName("coal_block");
    public final int id;
    protected float strength;
    protected float durability;

    /**
     * set to true when Block's constructor is called through the chain of super()'s. Note: Never used
     */
    protected boolean blockConstructorCalled = true;

    /**
     * If this field is true, the block is counted for statistics (mined or placed)
     */
    protected boolean enableStats = true;

    /**
     * Flags whether or not this block is of a type that needs random ticking. Ref-counted by ExtendedBlockStorage in
     * order to broadly cull a chunk from the random chunk update list for efficiency's sake.
     */
    protected boolean needsRandomTick;
    protected boolean isTileEntity;
    protected double minX;
    protected double minY;
    protected double minZ;
    protected double maxX;
    protected double maxY;
    protected double maxZ;
    public StepSound stepSound;
    public float blockParticleGravity;
    public final Material material;
    public float frictionFactor;
    private String name;

    protected Block(int par1, Material par2Material)
    {
        this.stepSound = soundPowderFootstep;
        this.blockParticleGravity = 1.0F;
        this.frictionFactor = 0.6F;

        if (byId[par1] != null)
        {
            throw new IllegalArgumentException("Slot " + par1 + " is already occupied by " + byId[par1] + " when adding " + this);
        }
        else
        {
            this.material = par2Material;
            byId[par1] = this;
            this.id = par1;
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
            opaqueCubeLookup[par1] = this.isOpaqueCube();
            lightBlock[par1] = this.isOpaqueCube() ? 255 : 0;
            canBlockGrass[par1] = !par2Material.blocksLight();
        }
    }

    /**
     * This method is called on a block after all other blocks gets already created. You can use it to reference and
     * configure something on the block that needs the others ones.
     */
    protected void initializeBlock() {}

    /**
     * Sets the footstep sound for the block. Returns the object for convenience in constructing.
     */
    protected Block setStepSound(StepSound par1StepSound)
    {
        this.stepSound = par1StepSound;
        return this;
    }

    /**
     * Sets how much light is blocked going through this block. Returns the object for convenience in constructing.
     */
    protected Block setLightOpacity(int par1)
    {
        lightBlock[this.id] = par1;
        return this;
    }

    /**
     * Sets the amount of light emitted by a block from 0.0f to 1.0f (converts internally to 0-15). Returns the object
     * for convenience in constructing.
     */
    protected Block setLightValue(float par1)
    {
        lightEmission[this.id] = (int)(15.0F * par1);
        return this;
    }

    /**
     * Sets the the blocks resistance to explosions. Returns the object for convenience in constructing.
     */
    protected Block setResistance(float par1)
    {
        this.durability = par1 * 3.0F;
        return this;
    }

    public static boolean isNormalCube(int par0)
    {
        Block var1 = byId[par0];
        return var1 == null ? false : var1.material.isOpaque() && var1.renderAsNormalBlock() && !var1.isPowerSource();
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return true;
    }

    public boolean getBlocksMovement(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return !this.material.isSolid();
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 0;
    }

    /**
     * Sets how many hits it takes to break a block.
     */
    protected Block setHardness(float par1)
    {
        this.strength = par1;

        if (this.durability < par1 * 5.0F)
        {
            this.durability = par1 * 5.0F;
        }

        return this;
    }

    /**
     * This method will make the hardness of the block equals to -1, and the block is indestructible.
     */
    protected Block setBlockUnbreakable()
    {
        this.setHardness(-1.0F);
        return this;
    }

    /**
     * Returns the block hardness at a location. Args: world, x, y, z
     */
    public float getBlockHardness(World par1World, int par2, int par3, int par4)
    {
        return this.strength;
    }

    /**
     * Sets whether this block type will receive random update ticks
     */
    protected Block setTickRandomly(boolean par1)
    {
        this.needsRandomTick = par1;
        return this;
    }

    public boolean isTicking()
    {
        return this.needsRandomTick;
    }

    public boolean hasTileEntity()
    {
        return this.isTileEntity;
    }

    /**
     * Sets the bounds of the block.  minX, minY, minZ, maxX, maxY, maxZ
     */
    protected final void setBlockBounds(float par1, float par2, float par3, float par4, float par5, float par6)
    {
        this.minX = (double)par1;
        this.minY = (double)par2;
        this.minZ = (double)par3;
        this.maxX = (double)par4;
        this.maxY = (double)par5;
        this.maxZ = (double)par6;
    }

    /**
     * Returns Returns true if the given side of this block type should be rendered (if it's solid or not), if the
     * adjacent block is at the given coordinates. Args: blockAccess, x, y, z, side
     */
    public boolean isBlockSolid(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        return par1IBlockAccess.getMaterial(par2, par3, par4).isBuildable();
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World par1World, int par2, int par3, int par4, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity)
    {
        AxisAlignedBB var8 = this.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);

        if (var8 != null && par5AxisAlignedBB.intersectsWith(var8))
        {
            par6List.add(var8);
        }
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return AxisAlignedBB.getAABBPool().getAABB((double)par2 + this.minX, (double)par3 + this.minY, (double)par4 + this.minZ, (double)par2 + this.maxX, (double)par3 + this.maxY, (double)par4 + this.maxZ);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return true;
    }

    /**
     * Returns whether this block is collideable based on the arguments passed in Args: blockMetaData, unknownFlag
     */
    public boolean canCollideCheck(int par1, boolean par2)
    {
        return this.isCollidable();
    }

    /**
     * Returns if this block is collidable (only used by Fire). Args: x, y, z
     */
    public boolean isCollidable()
    {
        return true;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random) {}

    public void postBreak(World world, int i, int j, int k, int l) {}

    public void doPhysics(World world, int i, int j, int k, int l) {}

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World par1World)
    {
        return 10;
    }

    public void onPlace(World world, int i, int j, int k)
    {
        if (Thread.currentThread() != MinecraftServer.getServer().primaryThread)
        {
            throw new IllegalStateException("Asynchronous block onPlace!");
        }
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        if (Thread.currentThread() != MinecraftServer.getServer().primaryThread)
        {
            throw new IllegalStateException("Asynchronous block remove!");
        }
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 1;
    }

    public int getDropType(int i, Random random, int j)
    {
        return this.id;
    }

    public float getDamage(EntityHuman entityhuman, World world, int i, int j, int k)
    {
        float f = this.getBlockHardness(world, i, j, k);
        return f < 0.0F ? 0.0F : (!entityhuman.canHarvestBlock(this) ? entityhuman.getCurrentPlayerStrVsBlock(this, false) / f / 100.0F : entityhuman.getCurrentPlayerStrVsBlock(this, true) / f / 30.0F);
    }

    /**
     * Drops the specified block items
     */
    public final void dropBlockAsItem(World par1World, int par2, int par3, int par4, int par5, int par6)
    {
        this.dropNaturally(par1World, par2, par3, par4, par5, 1.0F, par6);
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        if (!world.isStatic)
        {
            int j1 = this.getDropCount(i1, world.random);

            for (int k1 = 0; k1 < j1; ++k1)
            {
                if (world.random.nextFloat() < f)
                {
                    int l1 = this.getDropType(l, world.random, i1);

                    if (l1 > 0)
                    {
                        this.dropBlockAsItem_do(world, i, j, k, new ItemStack(l1, 1, this.getDropData(l)));
                    }
                }
            }
        }
    }

    /**
     * Spawns EntityItem in the world for the given ItemStack if the world is not remote.
     */
    protected void dropBlockAsItem_do(World par1World, int par2, int par3, int par4, ItemStack par5ItemStack)
    {
        if (!par1World.isStatic && par1World.getGameRules().getBoolean("doTileDrops"))
        {
            float var6 = 0.7F;
            double var7 = (double)(par1World.random.nextFloat() * var6) + (double)(1.0F - var6) * 0.5D;
            double var9 = (double)(par1World.random.nextFloat() * var6) + (double)(1.0F - var6) * 0.5D;
            double var11 = (double)(par1World.random.nextFloat() * var6) + (double)(1.0F - var6) * 0.5D;
            EntityItem var13 = new EntityItem(par1World, (double)par2 + var7, (double)par3 + var9, (double)par4 + var11, par5ItemStack);
            var13.pickupDelay = 10;
            par1World.addEntity(var13);
        }
    }

    /**
     * called by spawner, ore, redstoneOre blocks
     */
    protected void dropXpOnBlockBreak(World par1World, int par2, int par3, int par4, int par5)
    {
        if (!par1World.isStatic)
        {
            while (par5 > 0)
            {
                int var6 = EntityExperienceOrb.getOrbValue(par5);
                par5 -= var6;
                par1World.addEntity(new EntityExperienceOrb(par1World, (double)par2 + 0.5D, (double)par3 + 0.5D, (double)par4 + 0.5D, var6));
            }
        }
    }

    public int getDropData(int i)
    {
        return 0;
    }

    /**
     * Returns how much this block can resist explosions from the passed in entity.
     */
    public float getExplosionResistance(Entity par1Entity)
    {
        return this.durability / 5.0F;
    }

    public MovingObjectPosition a(World world, int i, int j, int k, Vec3D vec3d, Vec3D vec3d1)
    {
        this.updateShape(world, i, j, k);
        vec3d = vec3d.add((double)(-i), (double)(-j), (double)(-k));
        vec3d1 = vec3d1.add((double)(-i), (double)(-j), (double)(-k));
        Vec3D vec3d2 = vec3d.b(vec3d1, this.minX);
        Vec3D vec3d3 = vec3d.b(vec3d1, this.maxX);
        Vec3D vec3d4 = vec3d.c(vec3d1, this.minY);
        Vec3D vec3d5 = vec3d.c(vec3d1, this.maxY);
        Vec3D vec3d6 = vec3d.d(vec3d1, this.minZ);
        Vec3D vec3d7 = vec3d.d(vec3d1, this.maxZ);

        if (!this.a(vec3d2))
        {
            vec3d2 = null;
        }

        if (!this.a(vec3d3))
        {
            vec3d3 = null;
        }

        if (!this.b(vec3d4))
        {
            vec3d4 = null;
        }

        if (!this.b(vec3d5))
        {
            vec3d5 = null;
        }

        if (!this.c(vec3d6))
        {
            vec3d6 = null;
        }

        if (!this.c(vec3d7))
        {
            vec3d7 = null;
        }

        Vec3D vec3d8 = null;

        if (vec3d2 != null && (vec3d8 == null || vec3d.distanceSquared(vec3d2) < vec3d.distanceSquared(vec3d8)))
        {
            vec3d8 = vec3d2;
        }

        if (vec3d3 != null && (vec3d8 == null || vec3d.distanceSquared(vec3d3) < vec3d.distanceSquared(vec3d8)))
        {
            vec3d8 = vec3d3;
        }

        if (vec3d4 != null && (vec3d8 == null || vec3d.distanceSquared(vec3d4) < vec3d.distanceSquared(vec3d8)))
        {
            vec3d8 = vec3d4;
        }

        if (vec3d5 != null && (vec3d8 == null || vec3d.distanceSquared(vec3d5) < vec3d.distanceSquared(vec3d8)))
        {
            vec3d8 = vec3d5;
        }

        if (vec3d6 != null && (vec3d8 == null || vec3d.distanceSquared(vec3d6) < vec3d.distanceSquared(vec3d8)))
        {
            vec3d8 = vec3d6;
        }

        if (vec3d7 != null && (vec3d8 == null || vec3d.distanceSquared(vec3d7) < vec3d.distanceSquared(vec3d8)))
        {
            vec3d8 = vec3d7;
        }

        if (vec3d8 == null)
        {
            return null;
        }
        else
        {
            byte b0 = -1;

            if (vec3d8 == vec3d2)
            {
                b0 = 4;
            }

            if (vec3d8 == vec3d3)
            {
                b0 = 5;
            }

            if (vec3d8 == vec3d4)
            {
                b0 = 0;
            }

            if (vec3d8 == vec3d5)
            {
                b0 = 1;
            }

            if (vec3d8 == vec3d6)
            {
                b0 = 2;
            }

            if (vec3d8 == vec3d7)
            {
                b0 = 3;
            }

            return new MovingObjectPosition(i, j, k, b0, vec3d8.add((double)i, (double)j, (double)k));
        }
    }

    private boolean a(Vec3D vec3d)
    {
        return vec3d == null ? false : vec3d.d >= this.minY && vec3d.d <= this.maxY && vec3d.e >= this.minZ && vec3d.e <= this.maxZ;
    }

    private boolean b(Vec3D vec3d)
    {
        return vec3d == null ? false : vec3d.c >= this.minX && vec3d.c <= this.maxX && vec3d.e >= this.minZ && vec3d.e <= this.maxZ;
    }

    private boolean c(Vec3D vec3d)
    {
        return vec3d == null ? false : vec3d.c >= this.minX && vec3d.c <= this.maxX && vec3d.d >= this.minY && vec3d.d <= this.maxY;
    }

    public void wasExploded(World world, int i, int j, int k, Explosion explosion) {}

    public boolean canPlace(World world, int i, int j, int k, int l, ItemStack itemstack)
    {
        return this.canPlace(world, i, j, k, l);
    }

    public boolean canPlace(World world, int i, int j, int k, int l)
    {
        return this.canPlace(world, i, j, k);
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j, k);
        return l == 0 || byId[l].material.isReplaceable();
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        return false;
    }

    /**
     * Called whenever an entity is walking on top of this block. Args: world, x, y, z, entity
     */
    public void onEntityWalking(World par1World, int par2, int par3, int par4, Entity par5Entity) {}

    public int getPlacedData(World world, int i, int j, int k, int l, float f, float f1, float f2, int i1)
    {
        return i1;
    }

    public void attack(World world, int i, int j, int k, EntityHuman entityhuman) {}

    public void a(World world, int i, int j, int k, Entity entity, Vec3D vec3d) {}

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k) {}

    /**
     * returns the block bounderies minX value
     */
    public final double getMinX()
    {
        return this.minX;
    }

    /**
     * returns the block bounderies maxX value
     */
    public final double getBlockBoundsMaxX()
    {
        return this.maxX;
    }

    /**
     * returns the block bounderies minY value
     */
    public final double getBlockBoundsMinY()
    {
        return this.minY;
    }

    /**
     * returns the block bounderies maxY value
     */
    public final double getBlockBoundsMaxY()
    {
        return this.maxY;
    }

    /**
     * returns the block bounderies minZ value
     */
    public final double getBlockBoundsMinZ()
    {
        return this.minZ;
    }

    /**
     * returns the block bounderies maxZ value
     */
    public final double getBlockBoundsMaxZ()
    {
        return this.maxZ;
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        return 0;
    }

    public boolean isPowerSource()
    {
        return false;
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void onEntityCollidedWithBlock(World par1World, int par2, int par3, int par4, Entity par5Entity) {}

    /**
     * Returns true if the block is emitting direct/strong redstone power on the specified side. Args: World, X, Y, Z,
     * side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingStrongPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        return 0;
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender() {}

    public void a(World world, EntityHuman entityhuman, int i, int j, int k, int l)
    {
        entityhuman.addStat(StatisticList.C[this.id], 1);
        entityhuman.addExhaustion(0.025F);

        if (this.canSilkHarvest() && EnchantmentManager.hasSilkTouchEnchantment(entityhuman))
        {
            ItemStack i11 = this.createStackedBlock(l);

            if (i11 != null)
            {
                this.dropBlockAsItem_do(world, i, j, k, i11);
            }
        }
        else
        {
            int i1 = EnchantmentManager.getBonusBlockLootEnchantmentLevel(entityhuman);
            this.dropBlockAsItem(world, i, j, k, l, i1);
        }
    }

    /**
     * Return true if a player with Silk Touch can harvest this block directly, and not its normal drops.
     */
    protected boolean canSilkHarvest()
    {
        return this.renderAsNormalBlock() && !this.isTileEntity;
    }

    /**
     * Returns an item stack containing a single instance of the current block type. 'i' is the block's subtype/damage
     * and is ignored for blocks which do not support subtypes. Blocks which cannot be harvested should return null.
     */
    protected ItemStack createStackedBlock(int par1)
    {
        int var2 = 0;

        if (this.id >= 0 && this.id < Item.byId.length && Item.byId[this.id].getHasSubtypes())
        {
            var2 = par1;
        }

        return new ItemStack(this.id, 1, var2);
    }

    public int getDropCount(int i, Random random)
    {
        return this.quantityDropped(random);
    }

    /**
     * Can this block stay at this position.  Similar to canPlaceBlockAt except gets checked often with plants.
     */
    public boolean canBlockStay(World par1World, int par2, int par3, int par4)
    {
        return true;
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack) {}

    public void postPlace(World world, int i, int j, int k, int l) {}

    public Block setUnlocalizedName(String par1Str)
    {
        this.name = par1Str;
        return this;
    }

    public String getName()
    {
        return LocaleI18n.get(this.getUnlocalizedName() + ".name");
    }

    /**
     * Returns the unlocalized name of this block.
     */
    public String getUnlocalizedName()
    {
        return "tile." + this.name;
    }

    /**
     * Called when the block receives a BlockEvent - see World.addBlockEvent. By default, passes it on to the tile
     * entity at this location. Args: world, x, y, z, blockID, EventID, event parameter
     */
    public boolean onBlockEventReceived(World par1World, int par2, int par3, int par4, int par5, int par6)
    {
        return false;
    }

    /**
     * Return the state of blocks statistics flags - if the block is counted for mined and placed.
     */
    public boolean getEnableStats()
    {
        return this.enableStats;
    }

    /**
     * Disable statistics for the block, the block will no count for mined or placed.
     */
    protected Block disableStats()
    {
        this.enableStats = false;
        return this;
    }

    /**
     * Returns the mobility information of the block, 0 = free, 1 = can't push but can move over, 2 = total immobility
     * and stop pistons
     */
    public int getMobilityFlag()
    {
        return this.material.getPushReaction();
    }

    /**
     * Block's chance to react to an entity falling on it.
     */
    public void onFallenUpon(World par1World, int par2, int par3, int par4, Entity par5Entity, float par6) {}

    public int getDropData(World world, int i, int j, int k)
    {
        return this.getDropData(world.getData(i, j, k));
    }

    public Block a(CreativeModeTab creativemodetab)
    {
        this.creativeTab = creativemodetab;
        return this;
    }

    public void a(World world, int i, int j, int k, int l, EntityHuman entityhuman) {}

    /**
     * Called on server worlds only when the block is about to be replaced by a different block or the same block with a
     * different metadata value. Args: world, x, y, z, old metadata
     */
    public void onBlockPreDestroy(World par1World, int par2, int par3, int par4, int par5) {}

    /**
     * currently only used by BlockCauldron to incrament meta-data during rain
     */
    public void fillWithRain(World par1World, int par2, int par3, int par4) {}

    public boolean func_82506_l()
    {
        return true;
    }

    /**
     * Return whether this block can drop from an explosion.
     */
    public boolean canDropFromExplosion(Explosion par1Explosion)
    {
        return true;
    }

    /**
     * Returns true if the given block ID is equivalent to this one. Example: redstoneTorchOn matches itself and
     * redstoneTorchOff, and vice versa. Most blocks only match themselves.
     */
    public boolean isAssociatedBlockID(int par1)
    {
        return this.id == par1;
    }

    /**
     * Static version of isAssociatedBlockID.
     */
    public static boolean isAssociatedBlockID(int par0, int par1)
    {
        return par0 == par1 ? true : (par0 != 0 && par1 != 0 && byId[par0] != null && byId[par1] != null ? byId[par0].isAssociatedBlockID(par1) : false);
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return false;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        return 0;
    }

    protected Block setTextureName(String par1Str)
    {
        this.textureName = par1Str;
        return this;
    }

    public int getExpDrop(World world, int data, int enchantmentLevel)
    {
        return 0;
    }

    public static float range(float min, float value, float max)
    {
        return value < min ? min : (value > max ? max : value);
    }

    static
    {
        Item.byId[WOOL.id] = (new ItemCloth(WOOL.id - 256)).setUnlocalizedName("cloth");
        Item.byId[STAINED_HARDENED_CLAY.id] = (new ItemCloth(STAINED_HARDENED_CLAY.id - 256)).setUnlocalizedName("clayHardenedStained");
        Item.byId[WOOL_CARPET.id] = (new ItemCloth(WOOL_CARPET.id - 256)).setUnlocalizedName("woolCarpet");
        Item.byId[LOG.id] = (new ItemMultiTexture(LOG.id - 256, LOG, BlockLog.woodType)).setUnlocalizedName("log");
        Item.byId[WOOD.id] = (new ItemMultiTexture(WOOD.id - 256, WOOD, BlockWood.woodType)).setUnlocalizedName("wood");
        Item.byId[MONSTER_EGGS.id] = (new ItemMultiTexture(MONSTER_EGGS.id - 256, MONSTER_EGGS, BlockMonsterEggs.displayOnCreativeTab)).setUnlocalizedName("monsterStoneEgg");
        Item.byId[SMOOTH_BRICK.id] = (new ItemMultiTexture(SMOOTH_BRICK.id - 256, SMOOTH_BRICK, BlockSmoothBrick.displayOnCreativeTab)).setUnlocalizedName("stonebricksmooth");
        Item.byId[SANDSTONE.id] = (new ItemMultiTexture(SANDSTONE.id - 256, SANDSTONE, BlockSandStone.SAND_STONE_TYPES)).setUnlocalizedName("sandStone");
        Item.byId[QUARTZ_BLOCK.id] = (new ItemMultiTexture(QUARTZ_BLOCK.id - 256, QUARTZ_BLOCK, BlockQuartz.quartzBlockTypes)).setUnlocalizedName("quartzBlock");
        Item.byId[STEP.id] = (new ItemStep(STEP.id - 256, STEP, DOUBLE_STEP, false)).setUnlocalizedName("stoneSlab");
        Item.byId[DOUBLE_STEP.id] = (new ItemStep(DOUBLE_STEP.id - 256, STEP, DOUBLE_STEP, true)).setUnlocalizedName("stoneSlab");
        Item.byId[WOOD_STEP.id] = (new ItemStep(WOOD_STEP.id - 256, WOOD_STEP, WOOD_DOUBLE_STEP, false)).setUnlocalizedName("woodSlab");
        Item.byId[WOOD_DOUBLE_STEP.id] = (new ItemStep(WOOD_DOUBLE_STEP.id - 256, WOOD_STEP, WOOD_DOUBLE_STEP, true)).setUnlocalizedName("woodSlab");
        Item.byId[SAPLING.id] = (new ItemMultiTexture(SAPLING.id - 256, SAPLING, BlockSapling.WOOD_TYPES)).setUnlocalizedName("sapling");
        Item.byId[LEAVES.id] = (new ItemLeaves(LEAVES.id - 256)).setUnlocalizedName("leaves");
        Item.byId[VINE.id] = new ItemWithAuxData(VINE.id - 256, false);
        Item.byId[LONG_GRASS.id] = (new ItemWithAuxData(LONG_GRASS.id - 256, true)).a(new String[] {"shrub", "grass", "fern"});
        Item.byId[SNOW.id] = new ItemSnow(SNOW.id - 256, SNOW);
        Item.byId[WATER_LILY.id] = new ItemWaterLily(WATER_LILY.id - 256);
        Item.byId[PISTON.id] = new ItemPiston(PISTON.id - 256);
        Item.byId[PISTON_STICKY.id] = new ItemPiston(PISTON_STICKY.id - 256);
        Item.byId[COBBLE_WALL.id] = (new ItemMultiTexture(COBBLE_WALL.id - 256, COBBLE_WALL, BlockCobbleWall.displayOnCreativeTab)).setUnlocalizedName("cobbleWall");
        Item.byId[ANVIL.id] = (new ItemAnvil(ANVIL)).setUnlocalizedName("anvil");
        Item.byId[BIG_MUSHROOM_1.id] = new ItemWithAuxData(BIG_MUSHROOM_1.id - 256, true);
        Item.byId[BIG_MUSHROOM_2.id] = new ItemWithAuxData(BIG_MUSHROOM_2.id - 256, true);
        Item.byId[MOB_SPAWNER.id] = new ItemWithAuxData(MOB_SPAWNER.id - 256, true);

        for (int i = 0; i < 256; ++i)
        {
            if (byId[i] != null)
            {
                if (Item.byId[i] == null)
                {
                    Item.byId[i] = new ItemBlock(i - 256);
                    byId[i].initializeBlock();
                }

                boolean flag = false;

                if (i > 0 && byId[i].getRenderType() == 10)
                {
                    flag = true;
                }

                if (i > 0 && byId[i] instanceof BlockStepAbstract)
                {
                    flag = true;
                }

                if (i == SOIL.id)
                {
                    flag = true;
                }

                if (canBlockGrass[i])
                {
                    flag = true;
                }

                if (lightBlock[i] == 0)
                {
                    flag = true;
                }

                useNeighborBrightness[i] = flag;
            }
        }

        canBlockGrass[0] = true;
        StatisticList.b();
    }
}
