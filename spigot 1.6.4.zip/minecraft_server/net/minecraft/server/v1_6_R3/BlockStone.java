package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockStone extends Block
{
    public BlockStone(int par1)
    {
        super(par1, Material.STONE);
        this.a(CreativeModeTab.b);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Block.COBBLESTONE.id;
    }
}
