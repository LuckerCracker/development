package net.minecraft.server.v1_6_R3;

public class CommandToggleDownfall extends CommandAbstract
{
    public String getCommandName()
    {
        return "toggledownfall";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.downfall.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        this.toggleDownfall();
        a(var1, "commands.downfall.success", new Object[0]);
    }

    /**
     * Toggle rain and enable thundering.
     */
    protected void toggleDownfall()
    {
        MinecraftServer.getServer().worldServer[0].commandToggleDownfall();
        MinecraftServer.getServer().worldServer[0].getWorldData().setThundering(true);
    }
}
