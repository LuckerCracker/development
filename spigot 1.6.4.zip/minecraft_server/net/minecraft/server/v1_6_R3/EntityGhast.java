package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;

import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.entity.EntityTargetEvent;

public class EntityGhast extends EntityFlying implements IMonster {
	public int courseChangeCooldown;
	public double waypointX;
	public double waypointY;
	public double waypointZ;
	private Entity target;

	/** Cooldown time between target loss and new target aquirement. */
	private int aggroCooldown;
	public int prevAttackCounter;
	public int attackCounter;
	private int explosionPower = 1;

	public EntityGhast(World par1World) {
		super(par1World);
		this.setSize(4.0F, 4.0F);
		this.fireProof = true;
		this.experienceValue = 5;
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else if ("fireball".equals(damagesource.getDamageType()) && damagesource.getEntity() instanceof EntityHuman) {
			super.attackEntityFrom(damagesource, 1000.0F);
			((EntityHuman) damagesource.getEntity()).triggerAchievement((Statistic) AchievementList.ghast);
			return true;
		} else {
			return super.attackEntityFrom(damagesource, f);
		}
	}

	protected void entityInit() {
		super.entityInit();
		this.datawatcher.addObject(16, Byte.valueOf((byte) 0));
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.a).setValue(10.0D);
	}

	protected void updateEntityActionState() {
		if (!this.world.isStatic && this.world.difficulty == 0) {
			this.die();
		}

		this.despawnEntity();
		this.prevAttackCounter = this.attackCounter;
		double var1 = this.waypointX - this.locX;
		double var3 = this.waypointY - this.locY;
		double var5 = this.waypointZ - this.locZ;
		double var7 = var1 * var1 + var3 * var3 + var5 * var5;

		if (var7 < 1.0D || var7 > 3600.0D) {
			this.waypointX = this.locX + (double) ((this.random.nextFloat() * 2.0F - 1.0F) * 16.0F);
			this.waypointY = this.locY + (double) ((this.random.nextFloat() * 2.0F - 1.0F) * 16.0F);
			this.waypointZ = this.locZ + (double) ((this.random.nextFloat() * 2.0F - 1.0F) * 16.0F);
		}

		if (this.courseChangeCooldown-- <= 0) {
			this.courseChangeCooldown += this.random.nextInt(5) + 2;
			var7 = (double) MathHelper.sqrt(var7);

			if (this.isCourseTraversable(this.waypointX, this.waypointY, this.waypointZ, var7)) {
				this.motX += var1 / var7 * 0.1D;
				this.motY += var3 / var7 * 0.1D;
				this.motZ += var5 / var7 * 0.1D;
			} else {
				this.waypointX = this.locX;
				this.waypointY = this.locY;
				this.waypointZ = this.locZ;
			}
		}

		if (this.target != null && this.target.dead) {
			EntityTargetEvent var9 = new EntityTargetEvent(this.getBukkitEntity(), (org.bukkit.entity.Entity) null,
					EntityTargetEvent.TargetReason.TARGET_DIED);
			this.world.getServer().getPluginManager().callEvent(var9);

			if (!var9.isCancelled()) {
				if (var9.getTarget() == null) {
					this.target = null;
				} else {
					this.target = ((CraftEntity) var9.getTarget()).getHandle();
				}
			}
		}

		if (this.target == null || this.aggroCooldown-- <= 0) {
			EntityHuman var25 = this.world.findNearbyVulnerablePlayer(this, 100.0D);

			if (var25 != null) {
				EntityTargetEvent var10 = new EntityTargetEvent(this.getBukkitEntity(), var25.getBukkitEntity(),
						EntityTargetEvent.TargetReason.CLOSEST_PLAYER);
				this.world.getServer().getPluginManager().callEvent(var10);

				if (!var10.isCancelled()) {
					if (var10.getTarget() == null) {
						this.target = null;
					} else {
						this.target = ((CraftEntity) var10.getTarget()).getHandle();
					}
				}
			}

			if (this.target != null) {
				this.aggroCooldown = 20;
			}
		}

		double var11 = 64.0D;

		if (this.target != null && this.target.getDistanceSqToEntity(this) < var11 * var11) {
			double var13 = this.target.locX - this.locX;
			double var15 = this.target.boundingBox.minY + (double) (this.target.length / 2.0F)
					- (this.locY + (double) (this.length / 2.0F));
			double var17 = this.target.locZ - this.locZ;
			this.renderYawOffset = this.yaw = -((float) Math.atan2(var13, var17)) * 180.0F / (float) Math.PI;

			if (this.canEntityBeSeen(this.target)) {
				if (this.attackCounter == 10) {
					this.world.a((EntityHuman) null, 1007, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
				}

				++this.attackCounter;

				if (this.attackCounter == 20) {
					this.world.a((EntityHuman) null, 1008, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
					EntityLargeFireball var19 = new EntityLargeFireball(this.world, this, var13, var15, var17);
					var19.bukkitYield = (float) (var19.yield = this.explosionPower);
					double var20 = 4.0D;
					Vec3D var22 = this.getLook(1.0F);
					var19.locX = this.locX + var22.c * var20;
					var19.locY = this.locY + (double) (this.length / 2.0F) + 0.5D;
					var19.locZ = this.locZ + var22.e * var20;
					this.world.addEntity(var19);
					this.attackCounter = -40;
				}
			} else if (this.attackCounter > 0) {
				--this.attackCounter;
			}
		} else {
			this.renderYawOffset = this.yaw = -((float) Math.atan2(this.motX, this.motZ)) * 180.0F / (float) Math.PI;

			if (this.attackCounter > 0) {
				--this.attackCounter;
			}
		}

		if (!this.world.isStatic) {
			byte var23 = this.datawatcher.getByte(16);
			byte var24 = (byte) (this.attackCounter > 10 ? 1 : 0);

			if (var23 != var24) {
				this.datawatcher.watch(16, Byte.valueOf(var24));
			}
		}
	}

	/**
	 * True if the ghast has an unobstructed line of travel to the waypoint.
	 */
	private boolean isCourseTraversable(double par1, double par3, double par5, double par7) {
		double var9 = (this.waypointX - this.locX) / par7;
		double var11 = (this.waypointY - this.locY) / par7;
		double var13 = (this.waypointZ - this.locZ) / par7;
		AxisAlignedBB var15 = this.boundingBox.clone();

		for (int var16 = 1; (double) var16 < par7; ++var16) {
			var15.offset(var9, var11, var13);

			if (!this.world.getCubes(this, var15).isEmpty()) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return "mob.ghast.moan";
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.ghast.scream";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.ghast.death";
	}

	protected int getLootId() {
		return Item.SULPHUR.id;
	}

	protected void dropDeathLoot(boolean flag, int i) {
		ArrayList loot = new ArrayList();
		int j = this.random.nextInt(2) + this.random.nextInt(1 + i);

		if (j > 0) {
			loot.add(CraftItemStack.asNewCraftStack(Item.GHAST_TEAR, j));
		}

		j = this.random.nextInt(3) + this.random.nextInt(1 + i);

		if (j > 0) {
			loot.add(CraftItemStack.asNewCraftStack(Item.SULPHUR, j));
		}

		CraftEventFactory.callEntityDeathEvent(this, loot);
	}

	/**
	 * Returns the volume for the sounds this mob makes.
	 */
	protected float getSoundVolume() {
		return 10.0F;
	}

	public boolean canSpawn() {
		return this.random.nextInt(20) == 0 && super.canSpawn() && this.world.difficulty > 0;
	}

	/**
	 * Will return how many at most can spawn in a chunk at once.
	 */
	public int getMaxSpawnedInChunk() {
		return 1;
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		par1NBTTagCompound.setInt("ExplosionPower", this.explosionPower);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);

		if (par1NBTTagCompound.hasKey("ExplosionPower")) {
			this.explosionPower = par1NBTTagCompound.getInt("ExplosionPower");
		}
	}
}
