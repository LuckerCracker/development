package net.minecraft.server.v1_6_R3;

public class BlockEnchantmentTable extends BlockContainer
{
    protected BlockEnchantmentTable(int par1)
    {
        super(par1, Material.STONE);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
        this.setLightOpacity(0);
        this.a(CreativeModeTab.c);
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityEnchantTable();
    }

    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7, float var8, float var9)
    {
        if (var1.isStatic)
        {
            return true;
        }
        else
        {
            TileEntityEnchantTable var10 = (TileEntityEnchantTable)var1.getTileEntity(var2, var3, var4);
            var5.startEnchanting(var2, var3, var4, var10.b() ? var10.a() : null);
            return true;
        }
    }

    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5, ItemStack var6)
    {
        super.postPlace(var1, var2, var3, var4, var5, var6);

        if (var6.hasName())
        {
            ((TileEntityEnchantTable)var1.getTileEntity(var2, var3, var4)).a(var6.getName());
        }
    }
}
