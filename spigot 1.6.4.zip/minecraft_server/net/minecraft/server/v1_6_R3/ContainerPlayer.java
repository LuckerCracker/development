package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryCrafting;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public class ContainerPlayer extends Container {
	public InventoryCrafting craftInventory = new InventoryCrafting(this, 2, 2);
	public IInventory resultInventory = new InventoryCraftResult();

	/** Determines if inventory manipulation should be handled. */
	public boolean isLocalWorld;
	private final EntityHuman thePlayer;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public ContainerPlayer(PlayerInventory playerinventory, boolean flag, EntityHuman entityhuman) {
		this.isLocalWorld = flag;
		this.thePlayer = entityhuman;
		this.resultInventory = new InventoryCraftResult();
		this.craftInventory = new InventoryCrafting(this, 2, 2, playerinventory.player);
		this.craftInventory.resultInventory = this.resultInventory;
		this.player = playerinventory;
		this.addSlotToContainer(
				new SlotResult(playerinventory.player, this.craftInventory, this.resultInventory, 0, 144, 36));
		int i;
		int j;

		for (i = 0; i < 2; ++i) {
			for (j = 0; j < 2; ++j) {
				this.addSlotToContainer(new Slot(this.craftInventory, j + i * 2, 88 + j * 18, 26 + i * 18));
			}
		}

		for (i = 0; i < 4; ++i) {
			this.addSlotToContainer(
					new SlotArmor(this, playerinventory, playerinventory.getSize() - 1 - i, 8, 8 + i * 18, i));
		}

		for (i = 0; i < 3; ++i) {
			for (j = 0; j < 9; ++j) {
				this.addSlotToContainer(new Slot(playerinventory, j + (i + 1) * 9, 8 + j * 18, 84 + i * 18));
			}
		}

		for (i = 0; i < 9; ++i) {
			this.addSlotToContainer(new Slot(playerinventory, i, 8 + i * 18, 142));
		}
	}

	/**
	 * Callback for when the crafting matrix is changed.
	 */
	public void onCraftMatrixChanged(IInventory par1IInventory) {
		CraftingManager.getInstance().lastCraftView = this.getBukkitView();
		ItemStack var2 = CraftingManager.getInstance().craft(this.craftInventory, this.thePlayer.world);
		this.resultInventory.setItem(0, var2);

		if (super.listeners.size() >= 1) {
			EntityPlayer var3 = (EntityPlayer) super.listeners.get(0);
			var3.playerConnection.sendPacket(new Packet103SetSlot(var3.activeContainer.windowId, 0, var2));
		}
	}

	public void b(EntityHuman entityhuman) {
		super.b(entityhuman);

		for (int i = 0; i < 4; ++i) {
			ItemStack itemstack = this.craftInventory.splitWithoutUpdate(i);

			if (itemstack != null) {
				entityhuman.drop(itemstack);
			}
		}

		this.resultInventory.setItem(0, (ItemStack) null);
	}

	public boolean a(EntityHuman entityhuman) {
		return true;
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i == 0) {
				if (!this.mergeItemStack(itemstack1, 9, 45, true)) {
					return null;
				}

				slot.onSlotChange(itemstack1, itemstack);
			} else if (i >= 1 && i < 5) {
				if (!this.mergeItemStack(itemstack1, 9, 45, false)) {
					return null;
				}
			} else if (i >= 5 && i < 9) {
				if (!this.mergeItemStack(itemstack1, 9, 45, false)) {
					return null;
				}
			} else if (itemstack.getItem() instanceof ItemArmor
					&& !((Slot) this.inventorySlots.get(5 + ((ItemArmor) itemstack.getItem()).armorType))
							.getHasStack()) {
				int j = 5 + ((ItemArmor) itemstack.getItem()).armorType;

				if (!this.mergeItemStack(itemstack1, j, j + 1, false)) {
					return null;
				}
			} else if (i >= 9 && i < 36) {
				if (!this.mergeItemStack(itemstack1, 36, 45, false)) {
					return null;
				}
			} else if (i >= 36 && i < 45) {
				if (!this.mergeItemStack(itemstack1, 9, 36, false)) {
					return null;
				}
			} else if (!this.mergeItemStack(itemstack1, 9, 45, false)) {
				return null;
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}

	public boolean func_94530_a(ItemStack par1ItemStack, Slot par2Slot) {
		return par2Slot.inventory != this.resultInventory && super.func_94530_a(par1ItemStack, par2Slot);
	}

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			CraftInventoryCrafting inventory = new CraftInventoryCrafting(this.craftInventory, this.resultInventory);
			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(), inventory, this);
			return this.bukkitEntity;
		}
	}
}
