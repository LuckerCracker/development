package net.minecraft.server.v1_6_R3;

import org.bukkit.inventory.InventoryView;

class ContainerSheepBreed extends Container {
	final EntitySheep a;

	ContainerSheepBreed(EntitySheep var1) {
		this.a = var1;
	}

	public boolean a(EntityHuman var1) {
		return false;
	}

	@Override
	public InventoryView getBukkitView() {
		// TODO Auto-generated method stub
		return null;
	}
}
