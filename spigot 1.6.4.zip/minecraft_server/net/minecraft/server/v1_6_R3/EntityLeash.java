package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntityLeash extends EntityHanging
{
    public EntityLeash(World world)
    {
        super(world);
    }

    public EntityLeash(World world, int i, int j, int k)
    {
        super(world, i, j, k, 0);
        this.setPosition((double)i + 0.5D, (double)j + 0.5D, (double)k + 0.5D);
    }

    protected void entityInit()
    {
        super.entityInit();
    }

    public void setDirection(int i) {}

    public int getWidthPixels()
    {
        return 9;
    }

    public int getHeightPixels()
    {
        return 9;
    }

    /**
     * Called when this entity is broken. Entity parameter may be null.
     */
    public void onBroken(Entity entity) {}

    /**
     * Either write this entity to the NBT tag given and return true, or return false without doing anything. If this
     * returns false the entity is not saved on disk. Ridden entities return false here as they are saved with their
     * rider.
     */
    public boolean writeToNBTOptional(NBTTagCompound nbttagcompound)
    {
        return false;
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound nbttagcompound) {}

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound nbttagcompound) {}

    public boolean c(EntityHuman entityhuman)
    {
        ItemStack itemstack = entityhuman.getHeldItem();
        boolean flag = false;
        double d0;
        List list;
        Iterator iterator;
        EntityInsentient entityinsentient;

        if (itemstack != null && itemstack.id == Item.LEASH.id && !this.world.isStatic)
        {
            d0 = 7.0D;
            list = this.world.getEntitiesWithinAABB(EntityInsentient.class, AxisAlignedBB.getAABBPool().getAABB(this.locX - d0, this.locY - d0, this.locZ - d0, this.locX + d0, this.locY + d0, this.locZ + d0));

            if (list != null)
            {
                iterator = list.iterator();

                while (iterator.hasNext())
                {
                    entityinsentient = (EntityInsentient)iterator.next();

                    if (entityinsentient.getLeashed() && entityinsentient.getLeashHolder() == entityhuman)
                    {
                        if (CraftEventFactory.callPlayerLeashEntityEvent(entityinsentient, this, entityhuman).isCancelled())
                        {
                            ((EntityPlayer)entityhuman).playerConnection.sendPacket(new Packet39AttachEntity(1, entityinsentient, entityinsentient.getLeashHolder()));
                        }
                        else
                        {
                            entityinsentient.setLeashHolder(this, true);
                            flag = true;
                        }
                    }
                }
            }
        }

        if (!this.world.isStatic && !flag)
        {
            boolean die = true;
            d0 = 7.0D;
            list = this.world.getEntitiesWithinAABB(EntityInsentient.class, AxisAlignedBB.getAABBPool().getAABB(this.locX - d0, this.locY - d0, this.locZ - d0, this.locX + d0, this.locY + d0, this.locZ + d0));

            if (list != null)
            {
                iterator = list.iterator();

                while (iterator.hasNext())
                {
                    entityinsentient = (EntityInsentient)iterator.next();

                    if (entityinsentient.getLeashed() && entityinsentient.getLeashHolder() == this)
                    {
                        if (CraftEventFactory.callPlayerUnleashEntityEvent(entityinsentient, entityhuman).isCancelled())
                        {
                            die = false;
                        }
                        else
                        {
                            entityinsentient.unleash(true, !entityhuman.abilities.canInstantlyBuild);
                        }
                    }
                }
            }

            if (die)
            {
                this.die();
            }
        }

        return true;
    }

    public boolean survives()
    {
        int i = this.world.getTypeId(this.motionX, this.motionY, this.motionZ);
        return Block.byId[i] != null && Block.byId[i].getRenderType() == 11;
    }

    public static EntityLeash a(World world, int i, int j, int k)
    {
        EntityLeash entityleash = new EntityLeash(world, i, j, k);
        entityleash.forceSpawn = true;
        world.addEntity(entityleash);
        return entityleash;
    }

    public static EntityLeash b(World world, int i, int j, int k)
    {
        List list = world.getEntitiesWithinAABB(EntityLeash.class, AxisAlignedBB.getAABBPool().getAABB((double)i - 1.0D, (double)j - 1.0D, (double)k - 1.0D, (double)i + 1.0D, (double)j + 1.0D, (double)k + 1.0D));
        Object object = null;

        if (list != null)
        {
            Iterator iterator = list.iterator();

            while (iterator.hasNext())
            {
                EntityLeash entityleash = (EntityLeash)iterator.next();

                if (entityleash.motionX == i && entityleash.motionY == j && entityleash.motionZ == k)
                {
                    return entityleash;
                }
            }
        }

        return null;
    }
}
