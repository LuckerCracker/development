package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockSpreadEvent;

public class BlockGrass extends Block
{
    protected BlockGrass(int par1)
    {
        super(par1, Material.GRASS);
        this.setTickRandomly(true);
        this.a(CreativeModeTab.b);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (!par1World.isStatic)
        {
            if (par1World.getLightLevel(par2, par3 + 1, par4) < 4 && Block.lightBlock[par1World.getTypeId(par2, par3 + 1, par4)] > 2)
            {
                CraftWorld var15 = par1World.getWorld();
                BlockState var16 = var15.getBlockAt(par2, par3, par4).getState();
                var16.setTypeId(Block.DIRT.id);
                BlockFadeEvent var17 = new BlockFadeEvent(var16.getBlock(), var16);
                par1World.getServer().getPluginManager().callEvent(var17);

                if (!var17.isCancelled())
                {
                    var16.update(true);
                }
            }
            else if (par1World.getLightLevel(par2, par3 + 1, par4) >= 9)
            {
                int var6 = Math.min(4, Math.max(20, (int)(400.0F / par1World.growthOdds)));

                for (int var7 = 0; var7 < var6; ++var7)
                {
                    int var8 = par2 + par5Random.nextInt(3) - 1;
                    int var9 = par3 + par5Random.nextInt(5) - 3;
                    int var10 = par4 + par5Random.nextInt(3) - 1;
                    int var11 = par1World.getTypeId(var8, var9 + 1, var10);

                    if (par1World.getTypeId(var8, var9, var10) == Block.DIRT.id && par1World.getLightLevel(var8, var9 + 1, var10) >= 4 && Block.lightBlock[var11] <= 2)
                    {
                        CraftWorld var12 = par1World.getWorld();
                        BlockState var13 = var12.getBlockAt(var8, var9, var10).getState();
                        var13.setTypeId(Block.GRASS.id);
                        BlockSpreadEvent var14 = new BlockSpreadEvent(var13.getBlock(), var12.getBlockAt(par2, par3, par4), var13);
                        par1World.getServer().getPluginManager().callEvent(var14);

                        if (!var14.isCancelled())
                        {
                            var13.update(true);
                        }
                    }
                }
            }
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Block.DIRT.getDropType(0, random, j);
    }
}
