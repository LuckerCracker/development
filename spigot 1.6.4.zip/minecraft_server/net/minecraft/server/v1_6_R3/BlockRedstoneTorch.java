package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.plugin.PluginManager;

public class BlockRedstoneTorch extends BlockTorch
{
    private boolean isOn;

    /** Map of ArrayLists of RedstoneUpdateInfo. Key of map is World. */
    private static Map redstoneUpdateInfoCache = new WeakHashMap();

    private boolean checkForBurnout(World par1World, int par2, int par3, int par4, boolean par5)
    {
        if (!redstoneUpdateInfoCache.containsKey(par1World))
        {
            redstoneUpdateInfoCache.put(par1World, new ArrayList());
        }

        List var6 = (List)redstoneUpdateInfoCache.get(par1World);

        if (par5)
        {
            var6.add(new RedstoneUpdateInfo(par2, par3, par4, par1World.getTime()));
        }

        int var7 = 0;

        for (int var8 = 0; var8 < var6.size(); ++var8)
        {
            RedstoneUpdateInfo var9 = (RedstoneUpdateInfo)var6.get(var8);

            if (var9.x == par2 && var9.y == par3 && var9.z == par4)
            {
                ++var7;

                if (var7 >= 8)
                {
                    return true;
                }
            }
        }

        return false;
    }

    protected BlockRedstoneTorch(int par1, boolean par2)
    {
        super(par1);
        this.isOn = par2;
        this.setTickRandomly(true);
        this.a((CreativeModeTab)null);
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World par1World)
    {
        return 2;
    }

    public void onPlace(World world, int i, int j, int k)
    {
        if (world.getData(i, j, k) == 0)
        {
            super.onPlace(world, i, j, k);
        }

        if (this.isOn)
        {
            world.applyPhysics(i, j - 1, k, this.id);
            world.applyPhysics(i, j + 1, k, this.id);
            world.applyPhysics(i - 1, j, k, this.id);
            world.applyPhysics(i + 1, j, k, this.id);
            world.applyPhysics(i, j, k - 1, this.id);
            world.applyPhysics(i, j, k + 1, this.id);
        }
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        if (this.isOn)
        {
            world.applyPhysics(i, j - 1, k, this.id);
            world.applyPhysics(i, j + 1, k, this.id);
            world.applyPhysics(i - 1, j, k, this.id);
            world.applyPhysics(i + 1, j, k, this.id);
            world.applyPhysics(i, j, k - 1, this.id);
            world.applyPhysics(i, j, k + 1, this.id);
        }
    }

    /**
     * Returns true if the block is emitting indirect/weak redstone power on the specified side. If isBlockNormalCube
     * returns true, standard redstone propagation rules will apply instead and this will not be called. Args: World, X,
     * Y, Z, side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingWeakPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        if (!this.isOn)
        {
            return 0;
        }
        else
        {
            int var6 = par1IBlockAccess.getData(par2, par3, par4);
            return var6 == 5 && par5 == 1 ? 0 : (var6 == 3 && par5 == 3 ? 0 : (var6 == 4 && par5 == 2 ? 0 : (var6 == 1 && par5 == 5 ? 0 : (var6 == 2 && par5 == 4 ? 0 : 15))));
        }
    }

    /**
     * Returns true or false based on whether the block the torch is attached to is providing indirect power.
     */
    private boolean isIndirectlyPowered(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4);
        return var5 == 5 && par1World.isBlockFacePowered(par2, par3 - 1, par4, 0) ? true : (var5 == 3 && par1World.isBlockFacePowered(par2, par3, par4 - 1, 2) ? true : (var5 == 4 && par1World.isBlockFacePowered(par2, par3, par4 + 1, 3) ? true : (var5 == 1 && par1World.isBlockFacePowered(par2 - 1, par3, par4, 4) ? true : var5 == 2 && par1World.isBlockFacePowered(par2 + 1, par3, par4, 5))));
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        boolean var6 = this.isIndirectlyPowered(par1World, par2, par3, par4);
        List var7 = (List)redstoneUpdateInfoCache.get(par1World);

        while (var7 != null && !var7.isEmpty() && par1World.getTime() - ((RedstoneUpdateInfo)var7.get(0)).updateTime > 60L)
        {
            var7.remove(0);
        }

        PluginManager var8 = par1World.getServer().getPluginManager();
        org.bukkit.block.Block var9 = par1World.getWorld().getBlockAt(par2, par3, par4);
        int var10 = this.isOn ? 15 : 0;
        BlockRedstoneEvent var11 = new BlockRedstoneEvent(var9, var10, var10);

        if (this.isOn)
        {
            if (var6)
            {
                if (var10 != 0)
                {
                    var11.setNewCurrent(0);
                    var8.callEvent(var11);

                    if (var11.getNewCurrent() != 0)
                    {
                        return;
                    }
                }

                par1World.setTypeIdAndData(par2, par3, par4, Block.REDSTONE_TORCH_OFF.id, par1World.getData(par2, par3, par4), 3);

                if (this.checkForBurnout(par1World, par2, par3, par4, true))
                {
                    par1World.makeSound((double)((float)par2 + 0.5F), (double)((float)par3 + 0.5F), (double)((float)par4 + 0.5F), "random.fizz", 0.5F, 2.6F + (par1World.random.nextFloat() - par1World.random.nextFloat()) * 0.8F);

                    for (int var12 = 0; var12 < 5; ++var12)
                    {
                        double var13 = (double)par2 + par5Random.nextDouble() * 0.6D + 0.2D;
                        double var15 = (double)par3 + par5Random.nextDouble() * 0.6D + 0.2D;
                        double var17 = (double)par4 + par5Random.nextDouble() * 0.6D + 0.2D;
                        par1World.addParticle("smoke", var13, var15, var17, 0.0D, 0.0D, 0.0D);
                    }
                }
            }
        }
        else if (!var6 && !this.checkForBurnout(par1World, par2, par3, par4, false))
        {
            if (var10 != 15)
            {
                var11.setNewCurrent(15);
                var8.callEvent(var11);

                if (var11.getNewCurrent() != 15)
                {
                    return;
                }
            }

            par1World.setTypeIdAndData(par2, par3, par4, Block.REDSTONE_TORCH_ON.id, par1World.getData(par2, par3, par4), 3);
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        if (!this.func_94397_d(world, i, j, k, l))
        {
            boolean flag = this.isIndirectlyPowered(world, i, j, k);

            if (this.isOn && flag || !this.isOn && !flag)
            {
                world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
            }
        }
    }

    /**
     * Returns true if the block is emitting direct/strong redstone power on the specified side. Args: World, X, Y, Z,
     * side. Note that the side is reversed - eg it is 1 (up) when checking the bottom of the block.
     */
    public int isProvidingStrongPower(IBlockAccess par1IBlockAccess, int par2, int par3, int par4, int par5)
    {
        return par5 == 0 ? this.isProvidingWeakPower(par1IBlockAccess, par2, par3, par4, par5) : 0;
    }

    public int getDropType(int i, Random random, int j)
    {
        return Block.REDSTONE_TORCH_ON.id;
    }

    public boolean isPowerSource()
    {
        return true;
    }

    /**
     * Returns true if the given block ID is equivalent to this one. Example: redstoneTorchOn matches itself and
     * redstoneTorchOff, and vice versa. Most blocks only match themselves.
     */
    public boolean isAssociatedBlockID(int par1)
    {
        return par1 == Block.REDSTONE_TORCH_OFF.id || par1 == Block.REDSTONE_TORCH_ON.id;
    }
}
