package net.minecraft.server.v1_6_R3;

public class BlockSandStone extends Block
{
    public static final String[] SAND_STONE_TYPES = new String[] {"default", "chiseled", "smooth"};
    private static final String[] field_94405_b = new String[] {"normal", "carved", "smooth"};

    public BlockSandStone(int par1)
    {
        super(par1, Material.STONE);
        this.a(CreativeModeTab.b);
    }

    public int getDropData(int var1)
    {
        return var1;
    }
}
