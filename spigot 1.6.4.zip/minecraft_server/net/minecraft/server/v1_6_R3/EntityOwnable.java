package net.minecraft.server.v1_6_R3;

public interface EntityOwnable
{
    String getOwnerName();

    Entity getOwner();
}
