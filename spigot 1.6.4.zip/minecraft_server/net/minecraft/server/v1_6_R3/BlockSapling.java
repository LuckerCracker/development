package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.Random;
import net.minecraft.server.v1_6_R3.BlockSapling$TreeGenerator;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.TreeType;
import org.bukkit.block.BlockState;
import org.bukkit.craftbukkit.v1_6_R3.util.StructureGrowDelegate;
import org.bukkit.entity.Player;
import org.bukkit.event.world.StructureGrowEvent;

public class BlockSapling extends BlockFlower
{
    public static final String[] WOOD_TYPES = new String[] {"oak", "spruce", "birch", "jungle"};

    protected BlockSapling(int par1)
    {
        super(par1);
        float var2 = 0.4F;
        this.setBlockBounds(0.5F - var2, 0.0F, 0.5F - var2, 0.5F + var2, var2 * 2.0F, 0.5F + var2);
        this.a(CreativeModeTab.c);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (!par1World.isStatic)
        {
            super.updateTick(par1World, par2, par3, par4, par5Random);

            if (par1World.getLightLevel(par2, par3 + 1, par4) >= 9 && par5Random.nextInt(Math.max(2, (int)(par1World.growthOdds / (float)par1World.spigotConfig.saplingModifier * 7.0F + 0.5F))) == 0)
            {
                this.grow(par1World, par2, par3, par4, par5Random, false, (Player)null, (ItemStack)null);
            }
        }
    }

    public void grow(World world, int i, int j, int k, Random random, boolean bonemeal, Player player, ItemStack itemstack)
    {
        int l = world.getData(i, j, k);

        if ((l & 8) == 0)
        {
            world.setData(i, j, k, l | 8, 4);
        }
        else
        {
            this.d(world, i, j, k, random, bonemeal, player, itemstack);
        }
    }

    public void d(World world, int i, int j, int k, Random random, boolean bonemeal, Player player, ItemStack itemstack)
    {
        int l = world.getData(i, j, k) & 3;
        Object object = null;
        int i1 = 0;
        int j1 = 0;
        boolean flag = false;
        StructureGrowDelegate delegate = new StructureGrowDelegate(world);
        TreeType treeType = null;
        Object gen = null;
        boolean grownTree = false;

        if (l == 1)
        {
            treeType = TreeType.REDWOOD;
            gen = new WorldGenTaiga2(false);
        }
        else if (l == 2)
        {
            treeType = TreeType.BIRCH;
            gen = new WorldGenForest(false);
        }
        else if (l == 3)
        {
            for (i1 = 0; i1 >= -1; --i1)
            {
                for (j1 = 0; j1 >= -1; --j1)
                {
                    if (this.isSameSapling(world, i + i1, j, k + j1, 3) && this.isSameSapling(world, i + i1 + 1, j, k + j1, 3) && this.isSameSapling(world, i + i1, j, k + j1 + 1, 3) && this.isSameSapling(world, i + i1 + 1, j, k + j1 + 1, 3))
                    {
                        treeType = TreeType.JUNGLE;
                        gen = new WorldGenMegaTree(false, 10 + random.nextInt(20), 3, 3);
                        flag = true;
                        break;
                    }
                }

                if (gen != null)
                {
                    break;
                }
            }

            if (gen == null)
            {
                j1 = 0;
                i1 = 0;
                treeType = TreeType.SMALL_JUNGLE;
                gen = new WorldGenTrees(false, 4 + random.nextInt(7), 3, 3, false);
            }
        }
        else
        {
            treeType = TreeType.TREE;
            gen = new WorldGenTrees(false);

            if (random.nextInt(10) == 0)
            {
                treeType = TreeType.BIG_TREE;
                gen = new WorldGenBigTree(false);
            }
        }

        if (flag)
        {
            world.setTypeIdAndData(i + i1, j, k + j1, 0, 0, 4);
            world.setTypeIdAndData(i + i1 + 1, j, k + j1, 0, 0, 4);
            world.setTypeIdAndData(i + i1, j, k + j1 + 1, 0, 0, 4);
            world.setTypeIdAndData(i + i1 + 1, j, k + j1 + 1, 0, 0, 4);
        }
        else
        {
            world.setTypeIdAndData(i, j, k, 0, 0, 4);
        }

        grownTree = ((BlockSapling$TreeGenerator)gen).generate(delegate, random, i + i1, j, k + j1);

        if (grownTree)
        {
            Location location = new Location(world.getWorld(), (double)i, (double)j, (double)k);
            StructureGrowEvent event = new StructureGrowEvent(location, treeType, bonemeal, player, delegate.getBlocks());
            Bukkit.getPluginManager().callEvent(event);

            if (event.isCancelled())
            {
                grownTree = false;
            }
            else
            {
                Iterator i$ = event.getBlocks().iterator();

                while (i$.hasNext())
                {
                    BlockState state = (BlockState)i$.next();
                    state.update(true);
                }

                if (event.isFromBonemeal() && itemstack != null)
                {
                    --itemstack.count;
                }
            }
        }
        else if (bonemeal && itemstack != null)
        {
            --itemstack.count;
        }

        if (!grownTree)
        {
            if (flag)
            {
                world.setTypeIdAndData(i + i1, j, k + j1, this.id, l, 4);
                world.setTypeIdAndData(i + i1 + 1, j, k + j1, this.id, l, 4);
                world.setTypeIdAndData(i + i1, j, k + j1 + 1, this.id, l, 4);
                world.setTypeIdAndData(i + i1 + 1, j, k + j1 + 1, this.id, l, 4);
            }
            else
            {
                world.setTypeIdAndData(i, j, k, this.id, l, 4);
            }
        }
    }

    /**
     * Determines if the same sapling is present at the given location.
     */
    public boolean isSameSapling(World par1World, int par2, int par3, int par4, int par5)
    {
        return par1World.getTypeId(par2, par3, par4) == this.id && (par1World.getData(par2, par3, par4) & 3) == par5;
    }

    public int getDropData(int i)
    {
        return i & 3;
    }
}
