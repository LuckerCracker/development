package net.minecraft.server.v1_6_R3;

import com.google.common.collect.Sets;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class AttributeMapServer extends AttributeMapBase {
	private final Set field_111162_d = Sets.newHashSet();
	protected final Map field_111163_c = new InsensitiveStringMap();

	public AttributeModifiable c(IAttribute var1) {
		return (AttributeModifiable) super.a(var1);
	}

	public AttributeModifiable b(String var1) {
		AttributeInstance var2 = super.a(var1);

		if (var2 == null) {
			var2 = (AttributeInstance) this.field_111163_c.get(var1);
		}

		return (AttributeModifiable) var2;
	}

	public AttributeInstance b(IAttribute var1) {
		if (this.b.containsKey(var1.getAttributeUnlocalizedName())) {
			throw new IllegalArgumentException("Attribute is already registered!");
		} else {
			AttributeModifiable var2 = new AttributeModifiable(this, var1);
			this.b.put(var1.getAttributeUnlocalizedName(), var2);

			if (var1 instanceof AttributeRanged && ((AttributeRanged) var1).f() != null) {
				this.field_111163_c.put(((AttributeRanged) var1).f(), var2);
			}

			this.a.put(var1, var2);
			return var2;
		}
	}

	public void a(AttributeModifiable var1) {
		if (var1.a().getShouldWatch()) {
			this.field_111162_d.add(var1);
		}
	}

	public Set func_111161_b() {
		return this.field_111162_d;
	}

	public Collection func_111160_c() {
		HashSet var1 = Sets.newHashSet();
		Iterator var2 = this.a().iterator();

		while (var2.hasNext()) {
			AttributeInstance var3 = (AttributeInstance) var2.next();

			if (var3.a().getShouldWatch()) {
				var1.add(var3);
			}
		}

		return var1;
	}

	public AttributeInstance getAttributeInstanceByName(String var1) {
		return this.b(var1);
	}

	public AttributeInstance a(IAttribute var1) {
		return this.c(var1);
	}
}
