package net.minecraft.server.v1_6_R3;

public class CommandStop extends CommandAbstract
{
    public String getCommandName()
    {
        return "stop";
    }

    public int a()
    {
        return 4;
    }

    public String c(ICommandListener var1)
    {
        return "commands.stop.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        a(var1, "commands.stop.start", new Object[0]);
        MinecraftServer.getServer().safeShutdown();
    }
}
