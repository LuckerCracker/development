package net.minecraft.server.v1_6_R3;

import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.util.Vector;

final class DispenseBehaviorArmor extends DispenseBehaviorItem
{
    protected ItemStack b(ISourceBlock isourceblock, ItemStack itemstack)
    {
        EnumFacing enumfacing = BlockDispenser.getFacing(isourceblock.h());
        int i = isourceblock.getBlockX() + enumfacing.getFrontOffsetX();
        int j = isourceblock.getBlockY() + enumfacing.getFrontOffsetY();
        int k = isourceblock.getBlockZ() + enumfacing.getFrontOffsetZ();
        AxisAlignedBB axisalignedbb = AxisAlignedBB.getAABBPool().getAABB((double)i, (double)j, (double)k, (double)(i + 1), (double)(j + 1), (double)(k + 1));
        List list = isourceblock.k().selectEntitiesWithinAABB(EntityLiving.class, axisalignedbb, new EntitySelectorEquipable(itemstack));

        if (list.size() > 0)
        {
            EntityLiving entityliving = (EntityLiving)list.get(0);
            int l = entityliving instanceof EntityHuman ? 1 : 0;
            int i1 = EntityInsentient.getArmorPosition(itemstack);
            ItemStack itemstack1 = itemstack.splitStack(1);
            World world = isourceblock.k();
            org.bukkit.block.Block block = world.getWorld().getBlockAt(isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ());
            CraftItemStack craftItem = CraftItemStack.asCraftMirror(itemstack1);
            BlockDispenseEvent event = new BlockDispenseEvent(block, craftItem.clone(), new Vector(0, 0, 0));

            if (!BlockDispenser.eventFired)
            {
                world.getServer().getPluginManager().callEvent(event);
            }

            if (event.isCancelled())
            {
                ++itemstack.count;
                return itemstack;
            }
            else
            {
                if (!event.getItem().equals(craftItem))
                {
                    ++itemstack.count;
                    ItemStack eventStack = CraftItemStack.asNMSCopy(event.getItem());
                    IDispenseBehavior idispensebehavior = (IDispenseBehavior)BlockDispenser.dispenseBehaviorRegistry.getObject(eventStack.getItem());

                    if (idispensebehavior != IDispenseBehavior.a && idispensebehavior != this)
                    {
                        idispensebehavior.a(isourceblock, eventStack);
                        return itemstack;
                    }
                }

                itemstack1.count = 1;
                entityliving.setEquipment(i1 - l, itemstack1);

                if (entityliving instanceof EntityInsentient)
                {
                    ((EntityInsentient)entityliving).setEquipmentDropChance(i1, 2.0F);
                }

                return itemstack;
            }
        }
        else
        {
            return super.b(isourceblock, itemstack);
        }
    }
}
