package net.minecraft.server.v1_6_R3;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;
import java.util.regex.Pattern;

class ConsoleLogFormatter extends Formatter
{
    private SimpleDateFormat b;
    final ConsoleLogManager a;
    private Pattern pattern;
    private boolean strip;

    private ConsoleLogFormatter(ConsoleLogManager consolelogmanager)
    {
        this.pattern = Pattern.compile("\\x1B\\[([0-9]{1,2}(;[0-9]{1,2})*)?[m|K]");
        this.strip = false;
        this.a = consolelogmanager;
        this.b = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        this.strip = MinecraftServer.getServer().options.has("log-strip-color");
    }

    public String format(LogRecord logrecord)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(this.b.format(Long.valueOf(logrecord.getMillis())));

        if (ConsoleLogManager.a(this.a) != null)
        {
            stringbuilder.append(ConsoleLogManager.a(this.a));
        }

        stringbuilder.append(" [").append(logrecord.getLevel().getName()).append("] ");
        stringbuilder.append(this.formatMessage(logrecord));
        stringbuilder.append('\n');
        Throwable throwable = logrecord.getThrown();

        if (throwable != null)
        {
            StringWriter stringwriter = new StringWriter();
            throwable.printStackTrace(new PrintWriter(stringwriter));
            stringbuilder.append(stringwriter.toString());
        }

        return this.strip ? this.pattern.matcher(stringbuilder.toString()).replaceAll("") : stringbuilder.toString();
    }

    ConsoleLogFormatter(ConsoleLogManager consolelogmanager, EmptyClass3 emptyclass3)
    {
        this(consolelogmanager);
    }
}
