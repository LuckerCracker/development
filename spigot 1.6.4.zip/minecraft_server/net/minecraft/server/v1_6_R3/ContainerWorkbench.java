package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryCrafting;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.inventory.InventoryView;

public class ContainerWorkbench extends Container {
	public InventoryCrafting craftInventory;
	public IInventory resultInventory = new InventoryCraftResult();
	private World worldObj;
	private int posX;
	private int posY;
	private int posZ;
	private CraftInventoryView bukkitEntity = null;
	private PlayerInventory player;

	public ContainerWorkbench(PlayerInventory playerinventory, World world, int i, int j, int k) {
		this.craftInventory = new InventoryCrafting(this, 3, 3, playerinventory.player);
		this.craftInventory.resultInventory = this.resultInventory;
		this.player = playerinventory;
		this.worldObj = world;
		this.posX = i;
		this.posY = j;
		this.posZ = k;
		this.addSlotToContainer(
				new SlotResult(playerinventory.player, this.craftInventory, this.resultInventory, 0, 124, 35));
		int l;
		int i1;

		for (l = 0; l < 3; ++l) {
			for (i1 = 0; i1 < 3; ++i1) {
				this.addSlotToContainer(new Slot(this.craftInventory, i1 + l * 3, 30 + i1 * 18, 17 + l * 18));
			}
		}

		for (l = 0; l < 3; ++l) {
			for (i1 = 0; i1 < 9; ++i1) {
				this.addSlotToContainer(new Slot(playerinventory, i1 + l * 9 + 9, 8 + i1 * 18, 84 + l * 18));
			}
		}

		for (l = 0; l < 9; ++l) {
			this.addSlotToContainer(new Slot(playerinventory, l, 8 + l * 18, 142));
		}

		this.onCraftMatrixChanged(this.craftInventory);
	}

	/**
	 * Callback for when the crafting matrix is changed.
	 */
	public void onCraftMatrixChanged(IInventory par1IInventory) {
		CraftingManager.getInstance().lastCraftView = this.getBukkitView();
		ItemStack var2 = CraftingManager.getInstance().craft(this.craftInventory, this.worldObj);
		this.resultInventory.setItem(0, var2);

		if (super.listeners.size() >= 1) {
			EntityPlayer var3 = (EntityPlayer) super.listeners.get(0);
			var3.playerConnection.sendPacket(new Packet103SetSlot(var3.activeContainer.windowId, 0, var2));
		}
	}

	public void b(EntityHuman entityhuman) {
		super.b(entityhuman);

		if (!this.worldObj.isStatic) {
			for (int i = 0; i < 9; ++i) {
				ItemStack itemstack = this.craftInventory.splitWithoutUpdate(i);

				if (itemstack != null) {
					entityhuman.drop(itemstack);
				}
			}
		}
	}

	public boolean a(EntityHuman entityhuman) {
		return !this.checkReachable ? true
				: (this.worldObj.getTypeId(this.posX, this.posY, this.posZ) != Block.WORKBENCH.id ? false
						: entityhuman.getDistanceSq((double) this.posX + 0.5D, (double) this.posY + 0.5D,
								(double) this.posZ + 0.5D) <= 64.0D);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i == 0) {
				if (!this.mergeItemStack(itemstack1, 10, 46, true)) {
					return null;
				}

				slot.onSlotChange(itemstack1, itemstack);
			} else if (i >= 10 && i < 37) {
				if (!this.mergeItemStack(itemstack1, 37, 46, false)) {
					return null;
				}
			} else if (i >= 37 && i < 46) {
				if (!this.mergeItemStack(itemstack1, 10, 37, false)) {
					return null;
				}
			} else if (!this.mergeItemStack(itemstack1, 10, 46, false)) {
				return null;
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}

	public boolean func_94530_a(ItemStack par1ItemStack, Slot par2Slot) {
		return par2Slot.inventory != this.resultInventory && super.func_94530_a(par1ItemStack, par2Slot);
	}

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			CraftInventoryCrafting inventory = new CraftInventoryCrafting(this.craftInventory, this.resultInventory);
			this.bukkitEntity = new CraftInventoryView(this.player.player.getBukkitEntity(), inventory, this);
			return this.bukkitEntity;
		}
	}
}
