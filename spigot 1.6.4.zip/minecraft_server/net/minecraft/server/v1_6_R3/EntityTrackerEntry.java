package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.util.Vector;

public class EntityTrackerEntry
{
    public Entity tracker;
    public int trackingDistanceThreshold;

    /** check for sync when ticks % updateFrequency==0 */
    public int updateFrequency;
    public int xLoc;
    public int yLoc;
    public int zLoc;
    public int yRot;
    public int xRot;
    public int lastHeadMotion;
    public double lastTrackedEntityMotionX;
    public double lastTrackedEntityMotionY;
    public double motionZ;
    public int updateCounter;
    private double lastTrackedEntityPosX;
    private double lastTrackedEntityPosY;
    private double lastTrackedEntityPosZ;
    private boolean firstUpdateDone;
    private boolean isMoving;

    /**
     * every 400 ticks a  full teleport packet is sent, rather than just a "move me +x" command, so that position
     * remains fully synced.
     */
    private int ticksSinceLastForcedTeleport;
    private Entity field_85178_v;
    private boolean ridingEntity;
    public boolean playerEntitiesUpdated;
    public Set trackedPlayers = new HashSet();

    public EntityTrackerEntry(Entity par1Entity, int par2, int par3, boolean par4)
    {
        this.tracker = par1Entity;
        this.trackingDistanceThreshold = par2;
        this.updateFrequency = par3;
        this.isMoving = par4;
        this.xLoc = MathHelper.floor(par1Entity.locX * 32.0D);
        this.yLoc = MathHelper.floor(par1Entity.locY * 32.0D);
        this.zLoc = MathHelper.floor(par1Entity.locZ * 32.0D);
        this.yRot = MathHelper.floor_float(par1Entity.yaw * 256.0F / 360.0F);
        this.xRot = MathHelper.floor_float(par1Entity.pitch * 256.0F / 360.0F);
        this.lastHeadMotion = MathHelper.floor_float(par1Entity.getHeadRotation() * 256.0F / 360.0F);
    }

    public boolean equals(Object par1Obj)
    {
        return par1Obj instanceof EntityTrackerEntry ? ((EntityTrackerEntry)par1Obj).tracker.id == this.tracker.id : false;
    }

    public int hashCode()
    {
        return this.tracker.id;
    }

    public void track(List list)
    {
        this.playerEntitiesUpdated = false;

        if (!this.firstUpdateDone || this.tracker.getDistanceSq(this.lastTrackedEntityPosX, this.lastTrackedEntityPosY, this.lastTrackedEntityPosZ) > 16.0D)
        {
            this.lastTrackedEntityPosX = this.tracker.locX;
            this.lastTrackedEntityPosY = this.tracker.locY;
            this.lastTrackedEntityPosZ = this.tracker.locZ;
            this.firstUpdateDone = true;
            this.playerEntitiesUpdated = true;
            this.scanPlayers(list);
        }

        if (this.field_85178_v != this.tracker.vehicle || this.tracker.vehicle != null && this.updateCounter % 60 == 0)
        {
            this.field_85178_v = this.tracker.vehicle;
            this.broadcast(new Packet39AttachEntity(0, this.tracker, this.tracker.vehicle));
        }

        if (this.tracker instanceof EntityItemFrame)
        {
            EntityItemFrame cancelled = (EntityItemFrame)this.tracker;
            ItemStack player = cancelled.getItem();

            if (this.updateCounter % 10 == 0 && player != null && player.getItem() instanceof ItemWorldMap)
            {
                WorldMap velocity = Item.MAP.getSavedMap(player, this.tracker.world);
                Iterator event = this.trackedPlayers.iterator();

                while (event.hasNext())
                {
                    EntityHuman i1 = (EntityHuman)event.next();
                    EntityPlayer j1 = (EntityPlayer)i1;
                    velocity.a(j1, player);

                    if (j1.playerConnection.lowPriorityCount() <= 5)
                    {
                        Packet k1 = Item.MAP.c(player, this.tracker.world, j1);

                        if (k1 != null)
                        {
                            j1.playerConnection.sendPacket(k1);
                        }
                    }
                }
            }

            this.func_111190_b();
        }
        else if (this.updateCounter % this.updateFrequency == 0 || this.tracker.isAirBorne || this.tracker.getDataWatcher().hasObjectChanged())
        {
            int var23;
            int var24;

            if (this.tracker.vehicle == null)
            {
                ++this.ticksSinceLastForcedTeleport;
                var23 = this.tracker.myEntitySize.multiplyBy32AndRound(this.tracker.locX);
                var24 = MathHelper.floor(this.tracker.locY * 32.0D);
                int var27 = this.tracker.myEntitySize.multiplyBy32AndRound(this.tracker.locZ);
                int var30 = MathHelper.floor_float(this.tracker.yaw * 256.0F / 360.0F);
                int var32 = MathHelper.floor_float(this.tracker.pitch * 256.0F / 360.0F);
                int var33 = var23 - this.xLoc;
                int var34 = var24 - this.yLoc;
                int l1 = var27 - this.zLoc;
                Object object = null;
                boolean flag = Math.abs(var33) >= 4 || Math.abs(var34) >= 4 || Math.abs(l1) >= 4 || this.updateCounter % 60 == 0;
                boolean flag1 = Math.abs(var30 - this.yRot) >= 4 || Math.abs(var32 - this.xRot) >= 4;

                if (flag)
                {
                    this.xLoc = var23;
                    this.yLoc = var24;
                    this.zLoc = var27;
                }

                if (flag1)
                {
                    this.yRot = var30;
                    this.xRot = var32;
                }

                if (this.updateCounter > 0 || this.tracker instanceof EntityArrow)
                {
                    if (var33 >= -128 && var33 < 128 && var34 >= -128 && var34 < 128 && l1 >= -128 && l1 < 128 && this.ticksSinceLastForcedTeleport <= 400 && !this.ridingEntity)
                    {
                        if (flag && flag1)
                        {
                            object = new Packet33RelEntityMoveLook(this.tracker.id, (byte)var33, (byte)var34, (byte)l1, (byte)var30, (byte)var32);
                        }
                        else if (flag)
                        {
                            object = new Packet31RelEntityMove(this.tracker.id, (byte)var33, (byte)var34, (byte)l1);
                        }
                        else if (flag1)
                        {
                            object = new Packet32EntityLook(this.tracker.id, (byte)var30, (byte)var32);
                        }
                    }
                    else
                    {
                        this.ticksSinceLastForcedTeleport = 0;

                        if (this.tracker instanceof EntityPlayer)
                        {
                            this.scanPlayers(new ArrayList(this.trackedPlayers));
                        }

                        object = new Packet34EntityTeleport(this.tracker.id, var23, var24, var27, (byte)var30, (byte)var32);
                    }
                }

                if (this.isMoving)
                {
                    double d0 = this.tracker.motX - this.lastTrackedEntityMotionX;
                    double d1 = this.tracker.motY - this.lastTrackedEntityMotionY;
                    double d2 = this.tracker.motZ - this.motionZ;
                    double d3 = 0.02D;
                    double d4 = d0 * d0 + d1 * d1 + d2 * d2;

                    if (d4 > d3 * d3 || d4 > 0.0D && this.tracker.motX == 0.0D && this.tracker.motY == 0.0D && this.tracker.motZ == 0.0D)
                    {
                        this.lastTrackedEntityMotionX = this.tracker.motX;
                        this.lastTrackedEntityMotionY = this.tracker.motY;
                        this.motionZ = this.tracker.motZ;
                        this.broadcast(new Packet28EntityVelocity(this.tracker.id, this.lastTrackedEntityMotionX, this.lastTrackedEntityMotionY, this.motionZ));
                    }
                }

                if (object != null)
                {
                    this.broadcast((Packet)object);
                }

                this.func_111190_b();
                this.ridingEntity = false;
            }
            else
            {
                var23 = MathHelper.floor_float(this.tracker.yaw * 256.0F / 360.0F);
                var24 = MathHelper.floor_float(this.tracker.pitch * 256.0F / 360.0F);
                boolean var28 = Math.abs(var23 - this.yRot) >= 4 || Math.abs(var24 - this.xRot) >= 4;

                if (var28)
                {
                    this.broadcast(new Packet32EntityLook(this.tracker.id, (byte)var23, (byte)var24));
                    this.yRot = var23;
                    this.xRot = var24;
                }

                this.xLoc = this.tracker.myEntitySize.multiplyBy32AndRound(this.tracker.locX);
                this.yLoc = MathHelper.floor(this.tracker.locY * 32.0D);
                this.zLoc = this.tracker.myEntitySize.multiplyBy32AndRound(this.tracker.locZ);
                this.func_111190_b();
                this.ridingEntity = true;
            }

            var23 = MathHelper.floor_float(this.tracker.getHeadRotation() * 256.0F / 360.0F);

            if (Math.abs(var23 - this.lastHeadMotion) >= 4)
            {
                this.broadcast(new Packet35EntityHeadRotation(this.tracker.id, (byte)var23));
                this.lastHeadMotion = var23;
            }

            this.tracker.isAirBorne = false;
        }

        ++this.updateCounter;

        if (this.tracker.velocityChanged)
        {
            boolean var25 = false;

            if (this.tracker instanceof EntityPlayer)
            {
                Player var26 = (Player)this.tracker.getBukkitEntity();
                Vector var29 = var26.getVelocity();
                PlayerVelocityEvent var31 = new PlayerVelocityEvent(var26, var29);
                this.tracker.world.getServer().getPluginManager().callEvent(var31);

                if (var31.isCancelled())
                {
                    var25 = true;
                }
                else if (!var29.equals(var31.getVelocity()))
                {
                    var26.setVelocity(var29);
                }
            }

            if (!var25)
            {
                this.broadcastIncludingSelf(new Packet28EntityVelocity(this.tracker));
            }

            this.tracker.velocityChanged = false;
        }
    }

    private void func_111190_b()
    {
        DataWatcher var1 = this.tracker.getDataWatcher();

        if (var1.hasObjectChanged())
        {
            this.broadcastIncludingSelf(new Packet40EntityMetadata(this.tracker.id, var1, false));
        }

        if (this.tracker instanceof EntityLiving)
        {
            AttributeMapServer var2 = (AttributeMapServer)((EntityLiving)this.tracker).getAttributeMap();
            Set var3 = var2.func_111161_b();

            if (!var3.isEmpty())
            {
                if (this.tracker instanceof EntityPlayer)
                {
                    ((EntityPlayer)this.tracker).getBukkitEntity().injectScaledMaxHealth(var3, false);
                }

                this.broadcastIncludingSelf(new Packet44UpdateAttributes(this.tracker.id, var3));
            }

            var3.clear();
        }
    }

    public void broadcast(Packet packet)
    {
        Iterator iterator = this.trackedPlayers.iterator();

        while (iterator.hasNext())
        {
            EntityPlayer entityplayer = (EntityPlayer)iterator.next();
            entityplayer.playerConnection.sendPacket(packet);
        }
    }

    public void broadcastIncludingSelf(Packet packet)
    {
        this.broadcast(packet);

        if (this.tracker instanceof EntityPlayer)
        {
            ((EntityPlayer)this.tracker).playerConnection.sendPacket(packet);
        }
    }

    public void sendDestroyEntityPacketToTrackedPlayers()
    {
        Iterator var1 = this.trackedPlayers.iterator();

        while (var1.hasNext())
        {
            EntityPlayer var2 = (EntityPlayer)var1.next();
            var2.removeQueue.add(Integer.valueOf(this.tracker.id));
        }
    }

    public void a(EntityPlayer entityplayer)
    {
        if (this.trackedPlayers.contains(entityplayer))
        {
            entityplayer.removeQueue.add(Integer.valueOf(this.tracker.id));
            this.trackedPlayers.remove(entityplayer);
        }
    }

    public void updatePlayer(EntityPlayer entityplayer)
    {
        if (Thread.currentThread() != MinecraftServer.getServer().primaryThread)
        {
            throw new IllegalStateException("Asynchronous player tracker update!");
        }
        else
        {
            if (entityplayer != this.tracker)
            {
                double d0 = entityplayer.locX - (double)(this.xLoc / 32);
                double d1 = entityplayer.locZ - (double)(this.zLoc / 32);

                if (d0 >= (double)(-this.trackingDistanceThreshold) && d0 <= (double)this.trackingDistanceThreshold && d1 >= (double)(-this.trackingDistanceThreshold) && d1 <= (double)this.trackingDistanceThreshold)
                {
                    if (!this.trackedPlayers.contains(entityplayer) && (this.d(entityplayer) || this.tracker.forceSpawn))
                    {
                        if (this.tracker instanceof EntityPlayer)
                        {
                            CraftPlayer packet = ((EntityPlayer)this.tracker).getBukkitEntity();

                            if (!entityplayer.getBukkitEntity().canSee(packet))
                            {
                                return;
                            }
                        }

                        entityplayer.removeQueue.remove(Integer.valueOf(this.tracker.id));
                        this.trackedPlayers.add(entityplayer);
                        Packet var10 = this.getSpawnPacket();
                        entityplayer.playerConnection.sendPacket(var10);

                        if (!this.tracker.getDataWatcher().getIsBlank())
                        {
                            entityplayer.playerConnection.sendPacket(new Packet40EntityMetadata(this.tracker.id, this.tracker.getDataWatcher(), true));
                        }

                        if (this.tracker instanceof EntityLiving)
                        {
                            AttributeMapServer entityliving = (AttributeMapServer)((EntityLiving)this.tracker).getAttributeMap();
                            Collection iterator = entityliving.func_111160_c();

                            if (this.tracker.id == entityplayer.id)
                            {
                                ((EntityPlayer)this.tracker).getBukkitEntity().injectScaledMaxHealth(iterator, false);
                            }

                            if (!iterator.isEmpty())
                            {
                                entityplayer.playerConnection.sendPacket(new Packet44UpdateAttributes(this.tracker.id, iterator));
                            }
                        }

                        this.lastTrackedEntityMotionX = this.tracker.motX;
                        this.lastTrackedEntityMotionY = this.tracker.motY;
                        this.motionZ = this.tracker.motZ;

                        if (this.isMoving && !(var10 instanceof Packet24MobSpawn))
                        {
                            entityplayer.playerConnection.sendPacket(new Packet28EntityVelocity(this.tracker.id, this.tracker.motX, this.tracker.motY, this.tracker.motZ));
                        }

                        if (this.tracker.vehicle != null)
                        {
                            entityplayer.playerConnection.sendPacket(new Packet39AttachEntity(0, this.tracker, this.tracker.vehicle));
                        }

                        if (this.tracker.passenger != null)
                        {
                            entityplayer.playerConnection.sendPacket(new Packet39AttachEntity(0, this.tracker.passenger, this.tracker));
                        }

                        if (this.tracker instanceof EntityInsentient && ((EntityInsentient)this.tracker).getLeashHolder() != null)
                        {
                            entityplayer.playerConnection.sendPacket(new Packet39AttachEntity(1, this.tracker, ((EntityInsentient)this.tracker).getLeashHolder()));
                        }

                        if (this.tracker instanceof EntityLiving)
                        {
                            for (int var11 = 0; var11 < 5; ++var11)
                            {
                                ItemStack var13 = ((EntityLiving)this.tracker).getEquipment(var11);

                                if (var13 != null)
                                {
                                    entityplayer.playerConnection.sendPacket(new Packet5EntityEquipment(this.tracker.id, var11, var13));
                                }
                            }
                        }

                        if (this.tracker instanceof EntityHuman)
                        {
                            EntityHuman var12 = (EntityHuman)this.tracker;

                            if (var12.isSleeping())
                            {
                                entityplayer.playerConnection.sendPacket(new Packet17EntityLocationAction(this.tracker, 0, MathHelper.floor(this.tracker.locX), MathHelper.floor(this.tracker.locY), MathHelper.floor(this.tracker.locZ)));
                            }
                        }

                        this.lastHeadMotion = MathHelper.floor_float(this.tracker.getHeadRotation() * 256.0F / 360.0F);
                        this.broadcast(new Packet35EntityHeadRotation(this.tracker.id, (byte)this.lastHeadMotion));

                        if (this.tracker instanceof EntityLiving)
                        {
                            EntityLiving var14 = (EntityLiving)this.tracker;
                            Iterator var15 = var14.getEffects().iterator();

                            while (var15.hasNext())
                            {
                                MobEffect mobeffect = (MobEffect)var15.next();
                                entityplayer.playerConnection.sendPacket(new Packet41MobEffect(this.tracker.id, mobeffect));
                            }
                        }
                    }
                }
                else if (this.trackedPlayers.contains(entityplayer))
                {
                    this.trackedPlayers.remove(entityplayer);
                    entityplayer.removeQueue.add(Integer.valueOf(this.tracker.id));
                }
            }
        }
    }

    private boolean d(EntityPlayer entityplayer)
    {
        return entityplayer.p().getPlayerChunkMap().a(entityplayer, this.tracker.chunkCoordX, this.tracker.chunkCoordZ);
    }

    public void scanPlayers(List list)
    {
        for (int i = 0; i < list.size(); ++i)
        {
            this.updatePlayer((EntityPlayer)list.get(i));
        }
    }

    private Packet getSpawnPacket()
    {
        if (this.tracker.dead)
        {
            return null;
        }
        else if (this.tracker instanceof EntityItem)
        {
            return new Packet23VehicleSpawn(this.tracker, 2, 1);
        }
        else if (this.tracker instanceof EntityPlayer)
        {
            return new Packet20NamedEntitySpawn((EntityHuman)this.tracker);
        }
        else if (this.tracker instanceof EntityMinecartAbstract)
        {
            EntityMinecartAbstract var9 = (EntityMinecartAbstract)this.tracker;
            return new Packet23VehicleSpawn(this.tracker, 10, var9.getType());
        }
        else if (this.tracker instanceof EntityBoat)
        {
            return new Packet23VehicleSpawn(this.tracker, 1);
        }
        else if (!(this.tracker instanceof IAnimal) && !(this.tracker instanceof EntityEnderDragon))
        {
            if (this.tracker instanceof EntityFishingHook)
            {
                EntityHuman var8 = ((EntityFishingHook)this.tracker).owner;
                return new Packet23VehicleSpawn(this.tracker, 90, var8 != null ? var8.id : this.tracker.id);
            }
            else if (this.tracker instanceof EntityArrow)
            {
                Entity var6 = ((EntityArrow)this.tracker).shooter;
                return new Packet23VehicleSpawn(this.tracker, 60, var6 != null ? var6.id : this.tracker.id);
            }
            else if (this.tracker instanceof EntitySnowball)
            {
                return new Packet23VehicleSpawn(this.tracker, 61);
            }
            else if (this.tracker instanceof EntityPotion)
            {
                return new Packet23VehicleSpawn(this.tracker, 73, ((EntityPotion)this.tracker).getPotionValue());
            }
            else if (this.tracker instanceof EntityThrownExpBottle)
            {
                return new Packet23VehicleSpawn(this.tracker, 75);
            }
            else if (this.tracker instanceof EntityEnderPearl)
            {
                return new Packet23VehicleSpawn(this.tracker, 65);
            }
            else if (this.tracker instanceof EntityEnderSignal)
            {
                return new Packet23VehicleSpawn(this.tracker, 72);
            }
            else if (this.tracker instanceof EntityFireworks)
            {
                return new Packet23VehicleSpawn(this.tracker, 76);
            }
            else
            {
                Packet23VehicleSpawn var1;

                if (this.tracker instanceof EntityFireball)
                {
                    EntityFireball var7 = (EntityFireball)this.tracker;
                    var1 = null;
                    byte var3 = 63;

                    if (this.tracker instanceof EntitySmallFireball)
                    {
                        var3 = 64;
                    }
                    else if (this.tracker instanceof EntityWitherSkull)
                    {
                        var3 = 66;
                    }

                    if (var7.shooter != null)
                    {
                        var1 = new Packet23VehicleSpawn(this.tracker, var3, ((EntityFireball)this.tracker).shooter.id);
                    }
                    else
                    {
                        var1 = new Packet23VehicleSpawn(this.tracker, var3, 0);
                    }

                    var1.speedX = (int)(var7.dirX * 8000.0D);
                    var1.speedY = (int)(var7.dirY * 8000.0D);
                    var1.speedZ = (int)(var7.dirZ * 8000.0D);
                    return var1;
                }
                else if (this.tracker instanceof EntityEgg)
                {
                    return new Packet23VehicleSpawn(this.tracker, 62);
                }
                else if (this.tracker instanceof EntityTNTPrimed)
                {
                    return new Packet23VehicleSpawn(this.tracker, 50);
                }
                else if (this.tracker instanceof EntityEnderCrystal)
                {
                    return new Packet23VehicleSpawn(this.tracker, 51);
                }
                else if (this.tracker instanceof EntityFallingBlock)
                {
                    EntityFallingBlock var5 = (EntityFallingBlock)this.tracker;
                    return new Packet23VehicleSpawn(this.tracker, 70, var5.id | var5.data << 16);
                }
                else if (this.tracker instanceof EntityPainting)
                {
                    return new Packet25EntityPainting((EntityPainting)this.tracker);
                }
                else if (this.tracker instanceof EntityItemFrame)
                {
                    EntityItemFrame var4 = (EntityItemFrame)this.tracker;
                    var1 = new Packet23VehicleSpawn(this.tracker, 71, var4.direction);
                    var1.xPosition = MathHelper.floor_float((float)(var4.motionX * 32));
                    var1.yPosition = MathHelper.floor_float((float)(var4.motionY * 32));
                    var1.zPosition = MathHelper.floor_float((float)(var4.motionZ * 32));
                    return var1;
                }
                else if (this.tracker instanceof EntityLeash)
                {
                    EntityLeash var2 = (EntityLeash)this.tracker;
                    var1 = new Packet23VehicleSpawn(this.tracker, 77);
                    var1.xPosition = MathHelper.floor_float((float)(var2.motionX * 32));
                    var1.yPosition = MathHelper.floor_float((float)(var2.motionY * 32));
                    var1.zPosition = MathHelper.floor_float((float)(var2.motionZ * 32));
                    return var1;
                }
                else if (this.tracker instanceof EntityExperienceOrb)
                {
                    return new Packet26AddExpOrb((EntityExperienceOrb)this.tracker);
                }
                else
                {
                    throw new IllegalArgumentException("Don\'t know how to add " + this.tracker.getClass() + "!");
                }
            }
        }
        else
        {
            this.lastHeadMotion = MathHelper.floor_float(this.tracker.getHeadRotation() * 256.0F / 360.0F);
            return new Packet24MobSpawn((EntityLiving)this.tracker);
        }
    }

    public void clear(EntityPlayer entityplayer)
    {
        if (Thread.currentThread() != MinecraftServer.getServer().primaryThread)
        {
            throw new IllegalStateException("Asynchronous player tracker clear!");
        }
        else
        {
            if (this.trackedPlayers.contains(entityplayer))
            {
                this.trackedPlayers.remove(entityplayer);
                entityplayer.removeQueue.add(Integer.valueOf(this.tracker.id));
            }
        }
    }
}
