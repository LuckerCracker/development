package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandGamerule extends CommandAbstract
{
    public String getCommandName()
    {
        return "gamerule";
    }

    public int a()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.gamerule.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        String var6;

        if (var2.length == 2)
        {
            var6 = var2[0];
            String var7 = var2[1];
            GameRules var8 = this.d();

            if (var8.hasRule(var6))
            {
                var8.set(var6, var7);
                a(var1, "commands.gamerule.success", new Object[0]);
            }
            else
            {
                a(var1, "commands.gamerule.norule", new Object[] {var6});
            }
        }
        else if (var2.length == 1)
        {
            var6 = var2[0];
            GameRules var4 = this.d();

            if (var4.hasRule(var6))
            {
                String var5 = var4.get(var6);
                var1.sendMessage(ChatMessage.d(var6).a(" = ").a(var5));
            }
            else
            {
                a(var1, "commands.gamerule.norule", new Object[] {var6});
            }
        }
        else if (var2.length == 0)
        {
            GameRules var3 = this.d();
            var1.sendMessage(ChatMessage.d(a(var3.getRules())));
        }
        else
        {
            throw new ExceptionUsage("commands.gamerule.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, this.d().getRules()) : (var2.length == 2 ? a(var2, new String[] {"true", "false"}): null);
    }

    private GameRules d()
    {
        return MinecraftServer.getServer().getWorldServer(0).getGameRules();
    }
}
