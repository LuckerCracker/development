package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftHumanEntity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.InventoryHolder;

public abstract class EntityMinecartContainer extends EntityMinecartAbstract implements IInventory {
	private ItemStack[] items = new ItemStack[27];

	/**
	 * When set to true, the minecart will drop all items when setDead() is
	 * called. When false (such as when travelling dimensions) it preserves its
	 * contents.
	 */
	private boolean dropContentsWhenDead = true;
	public List<HumanEntity> transaction = new ArrayList();
	private int maxStack = 64;

	public ItemStack[] getContents() {
		return this.items;
	}

	public void onOpen(CraftHumanEntity who) {
		this.transaction.add(who);
	}

	public void onClose(CraftHumanEntity who) {
		this.transaction.remove(who);
	}

	public List<HumanEntity> getViewers() {
		return this.transaction;
	}

	public InventoryHolder getOwner() {
		CraftEntity cart = this.getBukkitEntity();
		return cart instanceof InventoryHolder ? (InventoryHolder) cart : null;
	}

	public void setMaxStackSize(int size) {
		this.maxStack = size;
	}

	public EntityMinecartContainer(World par1World) {
		super(par1World);
	}

	public EntityMinecartContainer(World par1World, double par2, double par4, double par6) {
		super(par1World, par2, par4, par6);
	}

	public void killMinecart(DamageSource par1DamageSource) {
		super.a(par1DamageSource);

		for (int var2 = 0; var2 < this.getSize(); ++var2) {
			ItemStack var3 = this.getItem(var2);

			if (var3 != null) {
				float var4 = this.random.nextFloat() * 0.8F + 0.1F;
				float var5 = this.random.nextFloat() * 0.8F + 0.1F;
				float var6 = this.random.nextFloat() * 0.8F + 0.1F;

				while (var3.count > 0) {
					int var7 = this.random.nextInt(21) + 10;

					if (var7 > var3.count) {
						var7 = var3.count;
					}

					var3.count -= var7;
					EntityItem var8 = new EntityItem(this.world, this.locX + (double) var4, this.locY + (double) var5,
							this.locZ + (double) var6, new ItemStack(var3.id, var7, var3.getData()));
					float var9 = 0.05F;
					var8.motX = (double) ((float) this.random.nextGaussian() * var9);
					var8.motY = (double) ((float) this.random.nextGaussian() * var9 + 0.2F);
					var8.motZ = (double) ((float) this.random.nextGaussian() * var9);
					this.world.addEntity(var8);
				}
			}
		}
	}

	public ItemStack getItem(int i) {
		return this.items[i];
	}

	public ItemStack splitStack(int i, int j) {
		if (this.items[i] != null) {
			ItemStack itemstack;

			if (this.items[i].count <= j) {
				itemstack = this.items[i];
				this.items[i] = null;
				return itemstack;
			} else {
				itemstack = this.items[i].splitStack(j);

				if (this.items[i].count == 0) {
					this.items[i] = null;
				}

				return itemstack;
			}
		} else {
			return null;
		}
	}

	public ItemStack splitWithoutUpdate(int i) {
		if (this.items[i] != null) {
			ItemStack itemstack = this.items[i];
			this.items[i] = null;
			return itemstack;
		} else {
			return null;
		}
	}

	public void setItem(int i, ItemStack itemstack) {
		this.items[i] = itemstack;

		if (itemstack != null && itemstack.count > this.getMaxStackSize()) {
			itemstack.count = this.getMaxStackSize();
		}
	}

	public void update() {
	}

	public boolean a(EntityHuman entityhuman) {
		return this.dead ? false : entityhuman.getDistanceSqToEntity(this) <= 64.0D;
	}

	public void startOpen() {
	}

	public void closeChest() {
	}

	/**
	 * Returns true if automation is allowed to insert the given stack (ignoring
	 * stack size) into the given slot.
	 */
	public boolean isItemValidForSlot(int par1, ItemStack par2ItemStack) {
		return true;
	}

	public String getName() {
		return this.isInvNameLocalized() ? this.t() : "container.minecart";
	}

	public int getMaxStackSize() {
		return 64;
	}

	/**
	 * Teleports the entity to another dimension. Params: Dimension number to
	 * teleport to
	 */
	public void travelToDimension(int par1) {
		Iterator var2 = (new ArrayList(this.transaction)).iterator();

		while (var2.hasNext()) {
			HumanEntity var3 = (HumanEntity) var2.next();
			var3.closeInventory();
		}

		this.dropContentsWhenDead = false;
		super.travelToDimension(par1);
	}

	public void die() {
		if (this.dropContentsWhenDead) {
			for (int i = 0; i < this.getSize(); ++i) {
				ItemStack itemstack = this.getItem(i);

				if (itemstack != null) {
					float f = this.random.nextFloat() * 0.8F + 0.1F;
					float f1 = this.random.nextFloat() * 0.8F + 0.1F;
					float f2 = this.random.nextFloat() * 0.8F + 0.1F;

					while (itemstack.count > 0) {
						int j = this.random.nextInt(21) + 10;

						if (j > itemstack.count) {
							j = itemstack.count;
						}

						itemstack.count -= j;
						EntityItem entityitem = new EntityItem(this.world, this.locX + (double) f,
								this.locY + (double) f1, this.locZ + (double) f2,
								new ItemStack(itemstack.id, j, itemstack.getData()));

						if (itemstack.hasTag()) {
							entityitem.getItemStack().setTag((NBTTagCompound) itemstack.getTag().clone());
						}

						float f3 = 0.05F;
						entityitem.motX = (double) ((float) this.random.nextGaussian() * f3);
						entityitem.motY = (double) ((float) this.random.nextGaussian() * f3 + 0.2F);
						entityitem.motZ = (double) ((float) this.random.nextGaussian() * f3);
						this.world.addEntity(entityitem);
					}
				}
			}
		}

		super.die();
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	protected void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);
		NBTTagList var2 = new NBTTagList();

		for (int var3 = 0; var3 < this.items.length; ++var3) {
			if (this.items[var3] != null) {
				NBTTagCompound var4 = new NBTTagCompound();
				var4.setByte("Slot", (byte) var3);
				this.items[var3].save(var4);
				var2.add(var4);
			}
		}

		par1NBTTagCompound.set("Items", var2);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	protected void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);
		NBTTagList var2 = par1NBTTagCompound.getList("Items");
		this.items = new ItemStack[this.getSize()];

		for (int var3 = 0; var3 < var2.size(); ++var3) {
			NBTTagCompound var4 = (NBTTagCompound) var2.get(var3);
			int var5 = var4.getByte("Slot") & 255;

			if (var5 >= 0 && var5 < this.items.length) {
				this.items[var5] = ItemStack.createStack(var4);
			}
		}
	}

	public boolean c(EntityHuman entityhuman) {
		if (!this.world.isStatic) {
			entityhuman.openContainer(this);
		}

		return true;
	}

	protected void applyDrag() {
		int var1 = 15 - Container.calcRedstoneFromInventory(this);
		float var2 = 0.98F + (float) var1 * 0.001F;
		this.motX *= (double) var2;
		this.motY *= 0.0D;
		this.motZ *= (double) var2;
	}
}
