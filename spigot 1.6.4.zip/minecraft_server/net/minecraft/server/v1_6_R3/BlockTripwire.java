package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.Cancellable;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.plugin.PluginManager;

public class BlockTripwire extends Block
{
    public BlockTripwire(int i)
    {
        super(i, Material.ORIENTABLE);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.15625F, 1.0F);
        this.setTickRandomly(true);
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World world)
    {
        return 10;
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        return null;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 30;
    }

    public int getDropType(int i, Random random, int j)
    {
        return Item.STRING.id;
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        int i1 = world.getData(i, j, k);
        boolean flag = (i1 & 2) == 2;
        boolean flag1 = !world.doesBlockHaveSolidTopSurface(i, j - 1, k);

        if (flag != flag1)
        {
            this.dropBlockAsItem(world, i, j, k, i1, 0);
            world.setAir(i, j, k);
        }
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = iblockaccess.getData(i, j, k);
        boolean flag = (l & 4) == 4;
        boolean flag1 = (l & 2) == 2;

        if (!flag1)
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.09375F, 1.0F);
        }
        else if (!flag)
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
        }
        else
        {
            this.setBlockBounds(0.0F, 0.0625F, 0.0F, 1.0F, 0.15625F, 1.0F);
        }
    }

    public void onPlace(World world, int i, int j, int k)
    {
        int l = world.doesBlockHaveSolidTopSurface(i, j - 1, k) ? 0 : 2;
        world.setData(i, j, k, l, 3);
        this.d(world, i, j, k, l);
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        this.d(world, i, j, k, i1 | 1);
    }

    public void a(World world, int i, int j, int k, int l, EntityHuman entityhuman)
    {
        if (!world.isStatic && entityhuman.getCurrentEquippedItem() != null && entityhuman.getCurrentEquippedItem().id == Item.SHEARS.id)
        {
            world.setData(i, j, k, l | 8, 4);
        }
    }

    private void d(World world, int i, int j, int k, int l)
    {
        int i1 = 0;

        while (i1 < 2)
        {
            int j1 = 1;

            while (true)
            {
                if (j1 < 42)
                {
                    int k1 = i + Direction.offsetX[i1] * j1;
                    int l1 = k + Direction.offsetZ[i1] * j1;
                    int i2 = world.getTypeId(k1, j, l1);

                    if (i2 == Block.TRIPWIRE_SOURCE.id)
                    {
                        int j2 = world.getData(k1, j, l1) & 3;

                        if (j2 == Direction.rotateOpposite[i1])
                        {
                            Block.TRIPWIRE_SOURCE.a(world, k1, j, l1, i2, world.getData(k1, j, l1), true, j1, l);
                        }
                    }
                    else if (i2 == Block.TRIPWIRE.id)
                    {
                        ++j1;
                        continue;
                    }
                }

                ++i1;
                break;
            }
        }
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
    {
        if (!world.isStatic && (world.getData(i, j, k) & 1) != 1)
        {
            this.k(world, i, j, k);
        }
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        if (!world.isStatic && (world.getData(i, j, k) & 1) == 1)
        {
            this.k(world, i, j, k);
        }
    }

    private void k(World world, int i, int j, int k)
    {
        int l = world.getData(i, j, k);
        boolean flag = (l & 1) == 1;
        boolean flag1 = false;
        List list = world.getEntities((Entity)null, AxisAlignedBB.getAABBPool().getAABB((double)i + this.minX, (double)j + this.minY, (double)k + this.minZ, (double)i + this.maxX, (double)j + this.maxY, (double)k + this.maxZ));

        if (!list.isEmpty())
        {
            Iterator bworld = list.iterator();

            while (bworld.hasNext())
            {
                Entity manager = (Entity)bworld.next();

                if (!manager.doesEntityNotTriggerPressurePlate())
                {
                    flag1 = true;
                    break;
                }
            }
        }

        if (flag != flag1 && flag1 && (world.getData(i, j, k) & 4) == 4)
        {
            CraftWorld bworld1 = world.getWorld();
            PluginManager manager1 = world.getServer().getPluginManager();
            org.bukkit.block.Block block = bworld1.getBlockAt(i, j, k);
            boolean allowed = false;
            Iterator i$ = list.iterator();

            while (i$.hasNext())
            {
                Object object = i$.next();

                if (object != null)
                {
                    Object cancellable;

                    if (object instanceof EntityHuman)
                    {
                        cancellable = CraftEventFactory.callPlayerInteractEvent((EntityHuman)object, Action.PHYSICAL, i, j, k, -1, (ItemStack)null);
                    }
                    else
                    {
                        if (!(object instanceof Entity))
                        {
                            continue;
                        }

                        cancellable = new EntityInteractEvent(((Entity)object).getBukkitEntity(), block);
                        manager1.callEvent((EntityInteractEvent)cancellable);
                    }

                    if (!((Cancellable)cancellable).isCancelled())
                    {
                        allowed = true;
                        break;
                    }
                }
            }

            if (!allowed)
            {
                return;
            }
        }

        if (flag1 && !flag)
        {
            l |= 1;
        }

        if (!flag1 && flag)
        {
            l &= -2;
        }

        if (flag1 != flag)
        {
            world.setData(i, j, k, l, 3);
            this.d(world, i, j, k, l);
        }

        if (flag1)
        {
            world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
        }
    }
}
