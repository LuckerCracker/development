package net.minecraft.server.v1_6_R3;

import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntityLightning extends EntityWeather
{
    private int lifeTicks;
    public long a;

    /**
     * The distance that has to be exceeded in order to triger a new step sound and an onEntityWalking event on a block
     */
    private int nextStepDistance;
    public boolean isEffect;

    public EntityLightning(World world, double d0, double d1, double d2)
    {
        this(world, d0, d1, d2, false);
    }

    public EntityLightning(World world, double d0, double d1, double d2, boolean isEffect)
    {
        super(world);
        this.isEffect = false;
        this.isEffect = isEffect;
        this.setPositionRotation(d0, d1, d2, 0.0F, 0.0F);
        this.lifeTicks = 2;
        this.a = this.random.nextLong();
        this.nextStepDistance = this.random.nextInt(3) + 1;

        if (!isEffect && !world.isStatic && world.getGameRules().getBoolean("doFireTick") && world.difficulty >= 2 && world.areChunksLoaded(MathHelper.floor(d0), MathHelper.floor(d1), MathHelper.floor(d2), 10))
        {
            int i = MathHelper.floor(d0);
            int j = MathHelper.floor(d1);
            int k = MathHelper.floor(d2);

            if (world.getTypeId(i, j, k) == 0 && Block.FIRE.canPlace(world, i, j, k) && !CraftEventFactory.callBlockIgniteEvent(world, i, j, k, (Entity)this).isCancelled())
            {
                world.setTypeIdUpdate(i, j, k, Block.FIRE.id);
            }

            for (i = 0; i < 4; ++i)
            {
                j = MathHelper.floor(d0) + this.random.nextInt(3) - 1;
                k = MathHelper.floor(d1) + this.random.nextInt(3) - 1;
                int l = MathHelper.floor(d2) + this.random.nextInt(3) - 1;

                if (world.getTypeId(j, k, l) == 0 && Block.FIRE.canPlace(world, j, k, l) && !CraftEventFactory.callBlockIgniteEvent(world, j, k, l, (Entity)this).isCancelled())
                {
                    world.setTypeIdUpdate(j, k, l, Block.FIRE.id);
                }
            }
        }
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (this.lifeTicks == 2)
        {
            this.world.makeSound(this.locX, this.locY, this.locZ, "ambient.weather.thunder", 10000.0F, 0.8F + this.random.nextFloat() * 0.2F);
            this.world.makeSound(this.locX, this.locY, this.locZ, "random.explode", 2.0F, 0.5F + this.random.nextFloat() * 0.2F);
        }

        --this.lifeTicks;

        if (this.lifeTicks < 0)
        {
            if (this.nextStepDistance == 0)
            {
                this.die();
            }
            else if (this.lifeTicks < -this.random.nextInt(10))
            {
                --this.nextStepDistance;
                this.lifeTicks = 1;
                this.a = this.random.nextLong();

                if (!this.isEffect && !this.world.isStatic && this.world.getGameRules().getBoolean("doFireTick") && this.world.areChunksLoaded(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ), 10))
                {
                    int i = MathHelper.floor(this.locX);
                    int j = MathHelper.floor(this.locY);
                    int list = MathHelper.floor(this.locZ);

                    if (this.world.getTypeId(i, j, list) == 0 && Block.FIRE.canPlace(this.world, i, j, list) && !CraftEventFactory.callBlockIgniteEvent(this.world, i, j, list, (Entity)this).isCancelled())
                    {
                        this.world.setTypeIdUpdate(i, j, list, Block.FIRE.id);
                    }
                }
            }
        }

        if (this.lifeTicks >= 0 && !this.isEffect)
        {
            if (this.world.isStatic)
            {
                this.world.lastLightningBolt = 2;
            }
            else
            {
                double d0 = 3.0D;
                List var8 = this.world.getEntities(this, AxisAlignedBB.getAABBPool().getAABB(this.locX - d0, this.locY - d0, this.locZ - d0, this.locX + d0, this.locY + 6.0D + d0, this.locZ + d0));

                for (int l = 0; l < var8.size(); ++l)
                {
                    Entity entity = (Entity)var8.get(l);
                    entity.a(this);
                }
            }
        }
    }

    protected void entityInit() {}

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    protected void readEntityFromNBT(NBTTagCompound nbttagcompound) {}

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    protected void writeEntityToNBT(NBTTagCompound nbttagcompound) {}
}
