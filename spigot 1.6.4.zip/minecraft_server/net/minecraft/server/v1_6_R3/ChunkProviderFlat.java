package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ChunkProviderFlat implements IChunkProvider
{
    private World worldObj;
    private Random random;
    private final byte[] cachedBlockIDs = new byte[256];
    private final byte[] cachedBlockMetadata = new byte[256];
    private final WorldGenFlatInfo flatWorldGenInfo;
    private final List structureGenerators = new ArrayList();
    private final boolean hasDecoration;
    private final boolean hasDungeons;
    private WorldGenLakes waterLakeGenerator;
    private WorldGenLakes lavaLakeGenerator;

    public ChunkProviderFlat(World par1World, long par2, boolean par4, String par5Str)
    {
        this.worldObj = par1World;
        this.random = new Random(par2);
        this.flatWorldGenInfo = WorldGenFlatInfo.a(par5Str);

        if (par4)
        {
            Map var6 = this.flatWorldGenInfo.b();

            if (var6.containsKey("village"))
            {
                Map var7 = (Map)var6.get("village");

                if (!var7.containsKey("size"))
                {
                    var7.put("size", "1");
                }

                this.structureGenerators.add(new WorldGenVillage(var7));
            }

            if (var6.containsKey("biome_1"))
            {
                this.structureGenerators.add(new WorldGenLargeFeature((Map)var6.get("biome_1")));
            }

            if (var6.containsKey("mineshaft"))
            {
                this.structureGenerators.add(new WorldGenMineshaft((Map)var6.get("mineshaft")));
            }

            if (var6.containsKey("stronghold"))
            {
                this.structureGenerators.add(new WorldGenStronghold((Map)var6.get("stronghold")));
            }
        }

        this.hasDecoration = this.flatWorldGenInfo.b().containsKey("decoration");

        if (this.flatWorldGenInfo.b().containsKey("lake"))
        {
            this.waterLakeGenerator = new WorldGenLakes(Block.STATIONARY_WATER.id);
        }

        if (this.flatWorldGenInfo.b().containsKey("lava_lake"))
        {
            this.lavaLakeGenerator = new WorldGenLakes(Block.STATIONARY_LAVA.id);
        }

        this.hasDungeons = this.flatWorldGenInfo.b().containsKey("dungeon");
        Iterator var9 = this.flatWorldGenInfo.c().iterator();

        while (var9.hasNext())
        {
            WorldGenFlatLayerInfo var10 = (WorldGenFlatLayerInfo)var9.next();

            for (int var8 = var10.d(); var8 < var10.d() + var10.a(); ++var8)
            {
                this.cachedBlockIDs[var8] = (byte)(var10.b() & 255);
                this.cachedBlockMetadata[var8] = (byte)var10.c();
            }
        }
    }

    public Chunk getChunkAt(int var1, int var2)
    {
        return this.getOrCreateChunk(var1, var2);
    }

    public Chunk getOrCreateChunk(int var1, int var2)
    {
        Chunk var3 = new Chunk(this.worldObj, var1, var2);

        for (int var4 = 0; var4 < this.cachedBlockIDs.length; ++var4)
        {
            int var5 = var4 >> 4;
            ChunkSection var6 = var3.i()[var5];

            if (var6 == null)
            {
                var6 = new ChunkSection(var4, !this.worldObj.worldProvider.hasNoSky);
                var3.i()[var5] = var6;
            }

            for (int var7 = 0; var7 < 16; ++var7)
            {
                for (int var8 = 0; var8 < 16; ++var8)
                {
                    var6.setTypeId(var7, var4 & 15, var8, this.cachedBlockIDs[var4] & 255);
                    var6.setData(var7, var4 & 15, var8, this.cachedBlockMetadata[var4]);
                }
            }
        }

        var3.initLighting();
        BiomeBase[] var9 = this.worldObj.getWorldChunkManager().getBiomeBlock((BiomeBase[])null, var1 * 16, var2 * 16, 16, 16);
        byte[] var10 = var3.getBiomeArray();

        for (int var11 = 0; var11 < var10.length; ++var11)
        {
            var10[var11] = (byte)var9[var11].id;
        }

        Iterator var12 = this.structureGenerators.iterator();

        while (var12.hasNext())
        {
            StructureGenerator var13 = (StructureGenerator)var12.next();
            var13.a(this, this.worldObj, var1, var2, (byte[])null);
        }

        var3.initLighting();
        return var3;
    }

    public boolean isChunkLoaded(int var1, int var2)
    {
        return true;
    }

    public void getChunkAt(IChunkProvider var1, int var2, int var3)
    {
        int var4 = var2 * 16;
        int var5 = var3 * 16;
        BiomeBase var6 = this.worldObj.getBiome(var4 + 16, var5 + 16);
        boolean var7 = false;
        this.random.setSeed(this.worldObj.getSeed());
        long var8 = this.random.nextLong() / 2L * 2L + 1L;
        long var10 = this.random.nextLong() / 2L * 2L + 1L;
        this.random.setSeed((long)var2 * var8 + (long)var3 * var10 ^ this.worldObj.getSeed());
        Iterator var12 = this.structureGenerators.iterator();

        while (var12.hasNext())
        {
            StructureGenerator var13 = (StructureGenerator)var12.next();
            boolean var14 = var13.a(this.worldObj, this.random, var2, var3);

            if (var13 instanceof WorldGenVillage)
            {
                var7 |= var14;
            }
        }

        int var16;
        int var17;
        int var18;

        if (this.waterLakeGenerator != null && !var7 && this.random.nextInt(4) == 0)
        {
            var16 = var4 + this.random.nextInt(16) + 8;
            var17 = this.random.nextInt(128);
            var18 = var5 + this.random.nextInt(16) + 8;
            this.waterLakeGenerator.generate(this.worldObj, this.random, var16, var17, var18);
        }

        if (this.lavaLakeGenerator != null && !var7 && this.random.nextInt(8) == 0)
        {
            var16 = var4 + this.random.nextInt(16) + 8;
            var17 = this.random.nextInt(this.random.nextInt(120) + 8);
            var18 = var5 + this.random.nextInt(16) + 8;

            if (var17 < 63 || this.random.nextInt(10) == 0)
            {
                this.lavaLakeGenerator.generate(this.worldObj, this.random, var16, var17, var18);
            }
        }

        if (this.hasDungeons)
        {
            for (var16 = 0; var16 < 8; ++var16)
            {
                var17 = var4 + this.random.nextInt(16) + 8;
                var18 = this.random.nextInt(128);
                int var15 = var5 + this.random.nextInt(16) + 8;
                (new WorldGenDungeons()).generate(this.worldObj, this.random, var17, var18, var15);
            }
        }

        if (this.hasDecoration)
        {
            var6.decorate(this.worldObj, this.random, var4, var5);
        }
    }

    public boolean saveChunks(boolean var1, IProgressUpdate var2)
    {
        return true;
    }

    /**
     * Save extra data not associated with any Chunk.  Not saved during autosave, only during world unload.  Currently
     * unimplemented.
     */
    public void saveExtraData() {}

    public boolean unloadChunks()
    {
        return false;
    }

    public boolean canSave()
    {
        return true;
    }

    public String getName()
    {
        return "FlatLevelSource";
    }

    public List getMobsFor(EnumCreatureType var1, int var2, int var3, int var4)
    {
        BiomeBase var5 = this.worldObj.getBiome(var2, var4);
        return var5 == null ? null : var5.getMobs(var1);
    }

    public ChunkPosition findNearestMapFeature(World var1, String var2, int var3, int var4, int var5)
    {
        if ("Stronghold".equals(var2))
        {
            Iterator var6 = this.structureGenerators.iterator();

            while (var6.hasNext())
            {
                StructureGenerator var7 = (StructureGenerator)var6.next();

                if (var7 instanceof WorldGenStronghold)
                {
                    return var7.getNearestGeneratedFeature(var1, var3, var4, var5);
                }
            }
        }

        return null;
    }

    public int getLoadedChunks()
    {
        return 0;
    }

    public void recreateStructures(int var1, int var2)
    {
        Iterator var3 = this.structureGenerators.iterator();

        while (var3.hasNext())
        {
            StructureGenerator var4 = (StructureGenerator)var3.next();
            var4.a(this, this.worldObj, var1, var2, (byte[])null);
        }
    }
}
