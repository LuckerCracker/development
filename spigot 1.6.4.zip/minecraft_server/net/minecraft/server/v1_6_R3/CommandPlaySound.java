package net.minecraft.server.v1_6_R3;

public class CommandPlaySound extends CommandAbstract
{
    public String getCommandName()
    {
        return "playsound";
    }

    /**
     * Return the required permission level for this command.
     */
    public int getRequiredPermissionLevel()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.playsound.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length < 2)
        {
            throw new ExceptionUsage(this.c(var1), new Object[0]);
        }
        else
        {
            byte var3 = 0;
            int var36 = var3 + 1;
            String var4 = var2[var3];
            EntityPlayer var5 = d(var1, var2[var36++]);
            double var6 = (double)var5.b().x;
            double var8 = (double)var5.b().y;
            double var10 = (double)var5.b().z;
            double var12 = 1.0D;
            double var14 = 1.0D;
            double var16 = 0.0D;

            if (var2.length > var36)
            {
                var6 = a(var1, var6, var2[var36++]);
            }

            if (var2.length > var36)
            {
                var8 = a(var1, var8, var2[var36++], 0, 0);
            }

            if (var2.length > var36)
            {
                var10 = a(var1, var10, var2[var36++]);
            }

            if (var2.length > var36)
            {
                var12 = a(var1, var2[var36++], 0.0D, 3.4028234663852886E38D);
            }

            if (var2.length > var36)
            {
                var14 = a(var1, var2[var36++], 0.0D, 2.0D);
            }

            if (var2.length > var36)
            {
                var16 = a(var1, var2[var36++], 0.0D, 1.0D);
            }

            double var18 = var12 > 1.0D ? var12 * 16.0D : 16.0D;
            double var20 = var5.getDistance(var6, var8, var10);

            if (var20 > var18)
            {
                if (var16 <= 0.0D)
                {
                    throw new CommandException("commands.playsound.playerTooFar", new Object[] {var5.getLocalizedName()});
                }

                double var22 = var6 - var5.locX;
                double var24 = var8 - var5.locY;
                double var26 = var10 - var5.locZ;
                double var28 = Math.sqrt(var22 * var22 + var24 * var24 + var26 * var26);
                double var30 = var5.locX;
                double var32 = var5.locY;
                double var34 = var5.locZ;

                if (var28 > 0.0D)
                {
                    var30 += var22 / var28 * 2.0D;
                    var32 += var24 / var28 * 2.0D;
                    var34 += var26 / var28 * 2.0D;
                }

                var5.playerConnection.sendPacket(new Packet62NamedSoundEffect(var4, var30, var32, var34, (float)var16, (float)var14));
            }
            else
            {
                var5.playerConnection.sendPacket(new Packet62NamedSoundEffect(var4, var6, var8, var10, (float)var12, (float)var14));
            }

            a(var1, "commands.playsound.success", new Object[] {var4, var5.getLocalizedName()});
        }
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] par1ArrayOfStr, int par2)
    {
        return par2 == 1;
    }
}
