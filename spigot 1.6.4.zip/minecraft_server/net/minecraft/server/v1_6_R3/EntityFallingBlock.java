package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.Iterator;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.entity.EntityDamageEvent;

public class EntityFallingBlock extends Entity {
	public int id;
	public int data;

	/**
	 * The distance that has to be exceeded in order to triger a new step sound
	 * and an onEntityWalking event on a block
	 */
	public int nextStepDistance;
	public boolean dropItem;
	private boolean entityRiderPitchDelta;
	private boolean hurtEntities;
	private int fallHurtMax;
	private float fallHurtAmount;
	public NBTTagCompound tileEntityData;

	public EntityFallingBlock(World world) {
		super(world);
		this.dropItem = true;
		this.fallHurtMax = 40;
		this.fallHurtAmount = 2.0F;
	}

	public EntityFallingBlock(World world, double d0, double d1, double d2, int i) {
		this(world, d0, d1, d2, i, 0);
	}

	public EntityFallingBlock(World world, double d0, double d1, double d2, int i, int j) {
		super(world);
		this.dropItem = true;
		this.fallHurtMax = 40;
		this.fallHurtAmount = 2.0F;
		this.id = i;
		this.data = j;
		this.preventEntitySpawning = true;
		this.setSize(0.98F, 0.98F);
		this.height = this.length / 2.0F;
		this.setPosition(d0, d1, d2);
		this.motX = 0.0D;
		this.motY = 0.0D;
		this.motZ = 0.0D;
		this.lastX = d0;
		this.lastY = d1;
		this.lastZ = d2;
	}

	/**
	 * returns if this entity triggers Block.onEntityWalking on the blocks they
	 * walk on. used for spiders and wolves to prevent them from trampling crops
	 */
	protected boolean canTriggerWalking() {
		return false;
	}

	protected void entityInit() {
	}

	/**
	 * Returns true if other Entities should be prevented from moving through
	 * this Entity.
	 */
	public boolean canBeCollidedWith() {
		return !this.dead;
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		if (this.id == 0) {
			this.die();
		} else {
			this.lastX = this.locX;
			this.lastY = this.locY;
			this.lastZ = this.locZ;
			++this.nextStepDistance;
			this.motY -= 0.03999999910593033D;
			this.move(this.motX, this.motY, this.motZ);
			this.motX *= 0.9800000190734863D;
			this.motY *= 0.9800000190734863D;
			this.motZ *= 0.9800000190734863D;

			if (!this.world.isStatic) {
				int i = MathHelper.floor(this.locX);
				int j = MathHelper.floor(this.locY);
				int k = MathHelper.floor(this.locZ);

				if (this.nextStepDistance == 1) {
					if (this.nextStepDistance != 1 || this.world.getTypeId(i, j, k) != this.id
							|| this.world.getData(i, j, k) != this.data
							|| CraftEventFactory.callEntityChangeBlockEvent(this, i, j, k, 0, 0).isCancelled()) {
						this.die();
						return;
					}

					this.world.setAir(i, j, k);
					this.world.spigotConfig.antiXrayInstance.updateNearbyBlocks(this.world, i, j, k);
				}

				if (this.onGround) {
					this.motX *= 0.699999988079071D;
					this.motZ *= 0.699999988079071D;
					this.motY *= -0.5D;

					if (this.world.getTypeId(i, j, k) != Block.PISTON_MOVING.id) {
						this.die();

						if (!this.entityRiderPitchDelta
								&& this.world.mayPlace(this.id, i, j, k, true, 1, (Entity) null, (ItemStack) null)
								&& !BlockSand.canFall(this.world, i, j - 1, k) && i >= -30000000 && k >= -30000000
								&& i < 30000000 && k < 30000000 && j > 0 && j < 256
								&& (this.world.getTypeId(i, j, k) != this.id
										|| this.world.getData(i, j, k) != this.data)) {
							if (CraftEventFactory.callEntityChangeBlockEvent(this, i, j, k, this.id, this.data)
									.isCancelled()) {
								return;
							}

							this.world.setTypeIdAndData(i, j, k, this.id, this.data, 3);
							this.world.spigotConfig.antiXrayInstance.updateNearbyBlocks(this.world, i, j, k);

							if (Block.byId[this.id] instanceof BlockSand) {
								((BlockSand) Block.byId[this.id]).onFinishFalling(this.world, i, j, k, this.data);
							}

							if (this.tileEntityData != null && Block.byId[this.id] instanceof IContainer) {
								TileEntity tileentity = this.world.getTileEntity(i, j, k);

								if (tileentity != null) {
									NBTTagCompound nbttagcompound = new NBTTagCompound();
									tileentity.writeToNBT(nbttagcompound);
									Iterator iterator = this.tileEntityData.getTags().iterator();

									while (iterator.hasNext()) {
										NBTBase nbtbase = (NBTBase) iterator.next();

										if (!nbtbase.getName().equals("x") && !nbtbase.getName().equals("y")
												&& !nbtbase.getName().equals("z")) {
											nbttagcompound.set(nbtbase.getName(), nbtbase.clone());
										}
									}

									tileentity.readFromNBT(nbttagcompound);
									tileentity.update();
								}
							}
						} else if (this.dropItem && !this.entityRiderPitchDelta) {
							this.entityDropItem(new ItemStack(this.id, 1, Block.byId[this.id].getDropData(this.data)),
									0.0F);
						}
					}
				} else if (this.nextStepDistance > 100 && !this.world.isStatic && (j < 1 || j > 256)
						|| this.nextStepDistance > 600) {
					if (this.dropItem) {
						this.entityDropItem(new ItemStack(this.id, 1, Block.byId[this.id].getDropData(this.data)),
								0.0F);
					}

					this.die();
				}
			}
		}
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float f) {
		if (this.hurtEntities) {
			int i = MathHelper.ceiling_float_int(f - 1.0F);

			if (i > 0) {
				ArrayList arraylist = new ArrayList(this.world.getEntities(this, this.boundingBox));
				DamageSource damagesource = this.id == Block.ANVIL.id ? DamageSource.ANVIL : DamageSource.FALLING_BLOCK;
				Iterator iterator = arraylist.iterator();

				while (iterator.hasNext()) {
					Entity j = (Entity) iterator.next();
					float k = (float) Math.min(MathHelper.floor_float((float) i * this.fallHurtAmount),
							this.fallHurtMax);
					EntityDamageEvent event = CraftEventFactory.callEntityDamageEvent(this, j,
							EntityDamageEvent.DamageCause.FALLING_BLOCK, (double) k);

					if (!event.isCancelled()) {
						j.attackEntityFrom(damagesource, (float) event.getDamage());
					}
				}

				if (this.id == Block.ANVIL.id
						&& (double) this.random.nextFloat() < 0.05000000074505806D + (double) i * 0.05D) {
					int var9 = this.data >> 2;
					int var10 = this.data & 3;
					++var9;

					if (var9 > 2) {
						this.entityRiderPitchDelta = true;
					} else {
						this.data = var10 | var9 << 2;
					}
				}
			}
		}
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	protected void writeEntityToNBT(NBTTagCompound nbttagcompound) {
		nbttagcompound.setByte("Tile", (byte) this.id);
		nbttagcompound.setInt("TileID", this.id);
		nbttagcompound.setByte("Data", (byte) this.data);
		nbttagcompound.setByte("Time", (byte) this.nextStepDistance);
		nbttagcompound.setBoolean("DropItem", this.dropItem);
		nbttagcompound.setBoolean("HurtEntities", this.hurtEntities);
		nbttagcompound.setFloat("FallHurtAmount", this.fallHurtAmount);
		nbttagcompound.setInt("FallHurtMax", this.fallHurtMax);

		if (this.tileEntityData != null) {
			nbttagcompound.setCompound("TileEntityData", this.tileEntityData);
		}
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	protected void readEntityFromNBT(NBTTagCompound nbttagcompound) {
		if (nbttagcompound.hasKey("TileID")) {
			this.id = nbttagcompound.getInt("TileID");
		} else {
			this.id = nbttagcompound.getByte("Tile") & 255;
		}

		this.data = nbttagcompound.getByte("Data") & 255;
		this.nextStepDistance = nbttagcompound.getByte("Time") & 255;

		if (nbttagcompound.hasKey("HurtEntities")) {
			this.hurtEntities = nbttagcompound.getBoolean("HurtEntities");
			this.fallHurtAmount = nbttagcompound.getFloat("FallHurtAmount");
			this.fallHurtMax = nbttagcompound.getInt("FallHurtMax");
		} else if (this.id == Block.ANVIL.id) {
			this.hurtEntities = true;
		}

		if (nbttagcompound.hasKey("DropItem")) {
			this.dropItem = nbttagcompound.getBoolean("DropItem");
		}

		if (nbttagcompound.hasKey("TileEntityData")) {
			this.tileEntityData = nbttagcompound.getCompound("TileEntityData");
		}

		if (nbttagcompound.hasKey("Bukkit.tileData")) {
			this.tileEntityData = (NBTTagCompound) nbttagcompound.getCompound("Bukkit.tileData").clone();
		}

		if (this.id == 0) {
			this.id = Block.SAND.id;
		}
	}

	public void a(boolean flag) {
		this.hurtEntities = flag;
	}

	public void a(CrashReportSystemDetails crashreportsystemdetails) {
		super.a(crashreportsystemdetails);
		crashreportsystemdetails.a("Immitating block ID", (Object) Integer.valueOf(this.id));
		crashreportsystemdetails.a("Immitating block data", (Object) Integer.valueOf(this.data));
	}
}
