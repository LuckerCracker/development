package net.minecraft.server.v1_6_R3;

public class BlockCloth extends Block
{
    public BlockCloth(int var1, Material var2)
    {
        super(var1, var2);
        this.a(CreativeModeTab.b);
    }

    public int getDropData(int var1)
    {
        return var1;
    }

    public static int j_(int var0)
    {
        return ~var0 & 15;
    }

    public static int c(int var0)
    {
        return ~var0 & 15;
    }
}
