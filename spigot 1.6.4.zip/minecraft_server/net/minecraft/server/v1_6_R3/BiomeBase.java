package net.minecraft.server.v1_6_R3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public abstract class BiomeBase
{
    public static final BiomeBase[] biomes = new BiomeBase[256];
    public static final BiomeBase OCEAN = (new BiomeOcean(0)).setColor(112).setBiomeName("Ocean").setMinMaxHeight(-1.0F, 0.4F);
    public static final BiomeBase PLAINS = (new BiomePlains(1)).setColor(9286496).setBiomeName("Plains").setTemperatureRainfall(0.8F, 0.4F);
    public static final BiomeBase DESERT = (new BiomeDesert(2)).setColor(16421912).setBiomeName("Desert").setDisableRain().setTemperatureRainfall(2.0F, 0.0F).setMinMaxHeight(0.1F, 0.2F);
    public static final BiomeBase EXTREME_HILLS = (new BiomeBigHills(3)).setColor(6316128).setBiomeName("Extreme Hills").setMinMaxHeight(0.3F, 1.5F).setTemperatureRainfall(0.2F, 0.3F);
    public static final BiomeBase FOREST = (new BiomeForest(4)).setColor(353825).setBiomeName("Forest").func_76733_a(5159473).setTemperatureRainfall(0.7F, 0.8F);
    public static final BiomeBase TAIGA = (new BiomeTaiga(5)).setColor(747097).setBiomeName("Taiga").func_76733_a(5159473).setEnableSnow().setTemperatureRainfall(0.05F, 0.8F).setMinMaxHeight(0.1F, 0.4F);
    public static final BiomeBase SWAMPLAND = (new BiomeSwamp(6)).setColor(522674).setBiomeName("Swampland").func_76733_a(9154376).setMinMaxHeight(-0.2F, 0.1F).setTemperatureRainfall(0.8F, 0.9F);
    public static final BiomeBase RIVER = (new BiomeRiver(7)).setColor(255).setBiomeName("River").setMinMaxHeight(-0.5F, 0.0F);
    public static final BiomeBase HELL = (new BiomeHell(8)).setColor(16711680).setBiomeName("Hell").setDisableRain().setTemperatureRainfall(2.0F, 0.0F);
    public static final BiomeBase SKY = (new BiomeTheEnd(9)).setColor(8421631).setBiomeName("Sky").setDisableRain();
    public static final BiomeBase FROZEN_OCEAN = (new BiomeOcean(10)).setColor(9474208).setBiomeName("FrozenOcean").setEnableSnow().setMinMaxHeight(-1.0F, 0.5F).setTemperatureRainfall(0.0F, 0.5F);
    public static final BiomeBase FROZEN_RIVER = (new BiomeRiver(11)).setColor(10526975).setBiomeName("FrozenRiver").setEnableSnow().setMinMaxHeight(-0.5F, 0.0F).setTemperatureRainfall(0.0F, 0.5F);
    public static final BiomeBase ICE_PLAINS = (new BiomeIcePlains(12)).setColor(16777215).setBiomeName("Ice Plains").setEnableSnow().setTemperatureRainfall(0.0F, 0.5F);
    public static final BiomeBase ICE_MOUNTAINS = (new BiomeIcePlains(13)).setColor(10526880).setBiomeName("Ice Mountains").setEnableSnow().setMinMaxHeight(0.3F, 1.3F).setTemperatureRainfall(0.0F, 0.5F);
    public static final BiomeBase MUSHROOM_ISLAND = (new BiomeMushrooms(14)).setColor(16711935).setBiomeName("MushroomIsland").setTemperatureRainfall(0.9F, 1.0F).setMinMaxHeight(0.2F, 1.0F);
    public static final BiomeBase MUSHROOM_SHORE = (new BiomeMushrooms(15)).setColor(10486015).setBiomeName("MushroomIslandShore").setTemperatureRainfall(0.9F, 1.0F).setMinMaxHeight(-1.0F, 0.1F);
    public static final BiomeBase BEACH = (new BiomeBeach(16)).setColor(16440917).setBiomeName("Beach").setTemperatureRainfall(0.8F, 0.4F).setMinMaxHeight(0.0F, 0.1F);
    public static final BiomeBase DESERT_HILLS = (new BiomeDesert(17)).setColor(13786898).setBiomeName("DesertHills").setDisableRain().setTemperatureRainfall(2.0F, 0.0F).setMinMaxHeight(0.3F, 0.8F);
    public static final BiomeBase FOREST_HILLS = (new BiomeForest(18)).setColor(2250012).setBiomeName("ForestHills").func_76733_a(5159473).setTemperatureRainfall(0.7F, 0.8F).setMinMaxHeight(0.3F, 0.7F);
    public static final BiomeBase TAIGA_HILLS = (new BiomeTaiga(19)).setColor(1456435).setBiomeName("TaigaHills").setEnableSnow().func_76733_a(5159473).setTemperatureRainfall(0.05F, 0.8F).setMinMaxHeight(0.3F, 0.8F);
    public static final BiomeBase SMALL_MOUNTAINS = (new BiomeBigHills(20)).setColor(7501978).setBiomeName("Extreme Hills Edge").setMinMaxHeight(0.2F, 0.8F).setTemperatureRainfall(0.2F, 0.3F);
    public static final BiomeBase JUNGLE = (new BiomeJungle(21)).setColor(5470985).setBiomeName("Jungle").func_76733_a(5470985).setTemperatureRainfall(1.2F, 0.9F).setMinMaxHeight(0.2F, 0.4F);
    public static final BiomeBase JUNGLE_HILLS = (new BiomeJungle(22)).setColor(2900485).setBiomeName("JungleHills").func_76733_a(5470985).setTemperatureRainfall(1.2F, 0.9F).setMinMaxHeight(1.8F, 0.5F);
    public String biomeName;
    public int color;

    /** The block expected to be on the top of this biome */
    public byte topBlock;

    /** The block to fill spots in when not on the top */
    public byte fillerBlock;
    public int field_76754_C;

    /** The minimum height of this biome. Default 0.1. */
    public float minHeight;

    /** The maximum height of this biome. Default 0.3. */
    public float maxHeight;
    public float temperature;
    public float humidity;

    /** Color tint applied to water depending on biome */
    public int waterColorMultiplier;

    /** The biome decorator. */
    public BiomeDecorator theBiomeDecorator;

    /**
     * Holds the classes of IMobs (hostile mobs) that can be spawned in the biome.
     */
    protected List spawnableMonsterList;

    /**
     * Holds the classes of any creature that can be spawned in the biome as friendly creature.
     */
    protected List spawnableCreatureList;

    /**
     * Holds the classes of any aquatic creature that can be spawned in the water of the biome.
     */
    protected List spawnableWaterCreatureList;
    protected List spawnableCaveCreatureList;

    /** Set to true if snow is enabled for this biome. */
    private boolean enableSnow;

    /**
     * Is true (default) if the biome support rain (desert and nether can't have rain)
     */
    private boolean enableRain;
    public final int id;

    /** The tree generator. */
    protected WorldGenTrees worldGeneratorTrees;

    /** The big tree generator. */
    protected WorldGenBigTree worldGeneratorBigTree;

    /** The forest generator. */
    protected WorldGenForest worldGeneratorForest;

    /** The swamp tree generator. */
    protected WorldGenSwampTree worldGeneratorSwamp;

    protected BiomeBase(int var1)
    {
        this.topBlock = (byte)Block.GRASS.id;
        this.fillerBlock = (byte)Block.DIRT.id;
        this.field_76754_C = 5169201;
        this.minHeight = 0.1F;
        this.maxHeight = 0.3F;
        this.temperature = 0.5F;
        this.humidity = 0.5F;
        this.waterColorMultiplier = 16777215;
        this.spawnableMonsterList = new ArrayList();
        this.spawnableCreatureList = new ArrayList();
        this.spawnableWaterCreatureList = new ArrayList();
        this.spawnableCaveCreatureList = new ArrayList();
        this.enableRain = true;
        this.worldGeneratorTrees = new WorldGenTrees(false);
        this.worldGeneratorBigTree = new WorldGenBigTree(false);
        this.worldGeneratorForest = new WorldGenForest(false);
        this.worldGeneratorSwamp = new WorldGenSwampTree();
        this.id = var1;
        biomes[var1] = this;
        this.theBiomeDecorator = this.createBiomeDecorator();
        this.spawnableCreatureList.add(new BiomeMeta(EntitySheep.class, 12, 4, 4));
        this.spawnableCreatureList.add(new BiomeMeta(EntityPig.class, 10, 4, 4));
        this.spawnableCreatureList.add(new BiomeMeta(EntityChicken.class, 10, 4, 4));
        this.spawnableCreatureList.add(new BiomeMeta(EntityCow.class, 8, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntitySpider.class, 10, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntityZombie.class, 10, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntitySkeleton.class, 10, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntityCreeper.class, 10, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntitySlime.class, 10, 4, 4));
        this.spawnableMonsterList.add(new BiomeMeta(EntityEnderman.class, 1, 1, 4));
        this.spawnableWaterCreatureList.add(new BiomeMeta(EntitySquid.class, 10, 4, 4));
        this.spawnableCaveCreatureList.add(new BiomeMeta(EntityBat.class, 10, 8, 8));
    }

    /**
     * Allocate a new BiomeDecorator for this BiomeGenBase
     */
    protected BiomeDecorator createBiomeDecorator()
    {
        return new BiomeDecorator(this);
    }

    /**
     * Sets the temperature and rainfall of this biome.
     */
    private BiomeBase setTemperatureRainfall(float var1, float var2)
    {
        if (var1 > 0.1F && var1 < 0.2F)
        {
            throw new IllegalArgumentException("Please avoid temperatures in the range 0.1 - 0.2 because of snow");
        }
        else
        {
            this.temperature = var1;
            this.humidity = var2;
            return this;
        }
    }

    /**
     * Sets the minimum and maximum height of this biome. Seems to go from -2.0 to 2.0.
     */
    private BiomeBase setMinMaxHeight(float var1, float var2)
    {
        this.minHeight = var1;
        this.maxHeight = var2;
        return this;
    }

    /**
     * Disable the rain for the biome.
     */
    private BiomeBase setDisableRain()
    {
        this.enableRain = false;
        return this;
    }

    /**
     * Gets a WorldGen appropriate for this biome.
     */
    public WorldGenerator getRandomWorldGenForTrees(Random var1)
    {
        return (WorldGenerator)(var1.nextInt(10) == 0 ? this.worldGeneratorBigTree : this.worldGeneratorTrees);
    }

    /**
     * Gets a WorldGen appropriate for this biome.
     */
    public WorldGenerator getRandomWorldGenForGrass(Random var1)
    {
        return new WorldGenGrass(Block.LONG_GRASS.id, 1);
    }

    /**
     * sets enableSnow to true during biome initialization. returns BiomeGenBase.
     */
    protected BiomeBase setEnableSnow()
    {
        this.enableSnow = true;
        return this;
    }

    protected BiomeBase setBiomeName(String var1)
    {
        this.biomeName = var1;
        return this;
    }

    protected BiomeBase func_76733_a(int var1)
    {
        this.field_76754_C = var1;
        return this;
    }

    protected BiomeBase setColor(int var1)
    {
        this.color = var1;
        return this;
    }

    public List getMobs(EnumCreatureType var1)
    {
        return var1 == EnumCreatureType.MONSTER ? this.spawnableMonsterList : (var1 == EnumCreatureType.CREATURE ? this.spawnableCreatureList : (var1 == EnumCreatureType.WATER_CREATURE ? this.spawnableWaterCreatureList : (var1 == EnumCreatureType.AMBIENT ? this.spawnableCaveCreatureList : null)));
    }

    /**
     * Returns true if the biome have snowfall instead a normal rain.
     */
    public boolean getEnableSnow()
    {
        return this.enableSnow;
    }

    /**
     * Return true if the biome supports lightning bolt spawn, either by have the bolts enabled and have rain enabled.
     */
    public boolean canSpawnLightningBolt()
    {
        return this.enableSnow ? false : this.enableRain;
    }

    /**
     * Checks to see if the rainfall level of the biome is extremely high
     */
    public boolean isHighHumidity()
    {
        return this.humidity > 0.85F;
    }

    /**
     * returns the chance a creature has to spawn.
     */
    public float getSpawningChance()
    {
        return 0.1F;
    }

    /**
     * Gets an integer representation of this biome's rainfall
     */
    public final int getIntRainfall()
    {
        return (int)(this.humidity * 65536.0F);
    }

    /**
     * Gets an integer representation of this biome's temperature
     */
    public final int getIntTemperature()
    {
        return (int)(this.temperature * 65536.0F);
    }

    /**
     * Gets a floating point representation of this biome's temperature
     */
    public final float getFloatTemperature()
    {
        return this.temperature;
    }

    public void decorate(World var1, Random var2, int var3, int var4)
    {
        this.theBiomeDecorator.decorate(var1, var2, var3, var4);
    }
}
