package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.util.Vector;

final class DispenseBehaviorFilledBucket extends DispenseBehaviorItem
{
    private final DispenseBehaviorItem b = new DispenseBehaviorItem();

    public ItemStack b(ISourceBlock isourceblock, ItemStack itemstack)
    {
        ItemBucket itembucket = (ItemBucket)itemstack.getItem();
        int i = isourceblock.getBlockX();
        int j = isourceblock.getBlockY();
        int k = isourceblock.getBlockZ();
        EnumFacing enumfacing = BlockDispenser.getFacing(isourceblock.h());
        World world = isourceblock.k();
        int x = i + enumfacing.getFrontOffsetX();
        int y = j + enumfacing.getFrontOffsetY();
        int z = k + enumfacing.getFrontOffsetZ();

        if (world.isEmpty(x, y, z) || !world.getMaterial(x, y, z).isBuildable())
        {
            org.bukkit.block.Block item = world.getWorld().getBlockAt(i, j, k);
            CraftItemStack craftItem = CraftItemStack.asCraftMirror(itemstack);
            BlockDispenseEvent event = new BlockDispenseEvent(item, craftItem.clone(), new Vector(x, y, z));

            if (!BlockDispenser.eventFired)
            {
                world.getServer().getPluginManager().callEvent(event);
            }

            if (event.isCancelled())
            {
                return itemstack;
            }

            if (!event.getItem().equals(craftItem))
            {
                ItemStack eventStack = CraftItemStack.asNMSCopy(event.getItem());
                IDispenseBehavior idispensebehavior = (IDispenseBehavior)BlockDispenser.dispenseBehaviorRegistry.getObject(eventStack.getItem());

                if (idispensebehavior != IDispenseBehavior.a && idispensebehavior != this)
                {
                    idispensebehavior.a(isourceblock, eventStack);
                    return itemstack;
                }
            }

            itembucket = (ItemBucket)CraftItemStack.asNMSCopy(event.getItem()).getItem();
        }

        if (itembucket.tryPlaceContainedLiquid(isourceblock.k(), i + enumfacing.getFrontOffsetX(), j + enumfacing.getFrontOffsetY(), k + enumfacing.getFrontOffsetZ()))
        {
            Item var17 = Item.BUCKET;

            if (--itemstack.count == 0)
            {
                itemstack.id = var17.id;
                itemstack.count = 1;
            }
            else if (((TileEntityDispenser)isourceblock.getTileEntity()).addItem(new ItemStack(var17)) < 0)
            {
                this.b.a(isourceblock, new ItemStack(var17));
            }

            return itemstack;
        }
        else
        {
            return this.b.a(isourceblock, itemstack);
        }
    }
}
