package net.minecraft.server.v1_6_R3;

public class ControllerJump
{
    private EntityInsentient a;
    private boolean b;

    public ControllerJump(EntityInsentient var1)
    {
        this.a = var1;
    }

    public void a()
    {
        this.b = true;
    }

    public void b()
    {
        this.a.setJumping(this.b);
        this.b = false;
    }
}
