package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Callable;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.TravelAgent;
import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.v1_6_R3.CraftServer;
import org.bukkit.craftbukkit.v1_6_R3.CraftTravelAgent;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_6_R3.SpigotTimings;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Painting;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.entity.EntityCombustByBlockEvent;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPortalEvent;
import org.bukkit.event.painting.PaintingBreakByEntityEvent;
import org.bukkit.event.vehicle.VehicleBlockCollisionEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.plugin.PluginManager;
import org.spigotmc.ActivationRange;
import org.spigotmc.CustomTimingsHandler;
import org.spigotmc.event.entity.EntityDismountEvent;
import org.spigotmc.event.entity.EntityMountEvent;

public abstract class Entity {
	private static final int CURRENT_LEVEL = 2;
	private static int entityCount;
	public int id;
	public double renderDistanceWeight;

	/**
	 * Blocks entities from spawning when they do their AABB check to make sure
	 * the spot is clear of entities that can prevent spawning.
	 */
	public boolean preventEntitySpawning;
	public Entity passenger;
	public Entity vehicle;
	public boolean forceSpawn;
	public World world;
	public double lastX;
	public double lastY;
	public double lastZ;
	public double locX;
	public double locY;
	public double locZ;
	public double motX;
	public double motY;
	public double motZ;
	public float yaw;
	public float pitch;
	public float lastYaw;
	public float lastPitch;
	public final AxisAlignedBB boundingBox;
	public boolean onGround;
	public boolean positionChanged;

	/**
	 * True if after a move this entity has collided with something on Y-axis
	 */
	public boolean isCollidedVertically;

	/**
	 * True if after a move this entity has collided with something either
	 * vertically or horizontally
	 */
	public boolean isCollided;
	public boolean velocityChanged;
	protected boolean isInWeb;
	public boolean field_70135_K;
	public boolean dead;
	public float height;
	public float width;
	public float length;

	/** The previous ticks distance walked multiplied by 0.6 */
	public float prevDistanceWalkedModified;

	/** The distance walked multiplied by 0.6 */
	public float distanceWalkedModified;
	public float distanceWalkedOnStepModified;
	public float fallDistance;

	/**
	 * The distance that has to be exceeded in order to triger a new step sound
	 * and an onEntityWalking event on a block
	 */
	private int nextStepDistance;

	/**
	 * The entity's X coordinate at the previous tick, used to calculate
	 * position during rendering routines
	 */
	public double lastTickPosX;

	/**
	 * The entity's Y coordinate at the previous tick, used to calculate
	 * position during rendering routines
	 */
	public double lastTickPosY;

	/**
	 * The entity's Z coordinate at the previous tick, used to calculate
	 * position during rendering routines
	 */
	public double lastTickPosZ;
	public float ySize;

	/**
	 * How high this entity can step up when running into a block to try to get
	 * over it (currently make note the entity will always step up this amount
	 * and not just the amount needed)
	 */
	public float stepHeight;

	/**
	 * Whether this entity won't clip with collision or not (make note it won't
	 * disable gravity)
	 */
	public boolean noClip;

	/**
	 * Reduces the velocity applied by entity collisions by the specified
	 * percent.
	 */
	public float entityCollisionReduction;
	protected Random random;
	public int ticksLived;
	public int maxFireTicks;
	public int fireTicks;
	public boolean inWater;
	public int noDamageTicks;
	private boolean justCreated;
	protected boolean fireProof;
	protected DataWatcher datawatcher;
	private double entityRiderPitchDelta;
	private double entityRiderYawDelta;

	/** Has this entity been added to the chunk its within */
	public boolean addedToChunk;
	public int chunkCoordX;
	public int chunkCoordY;
	public int chunkCoordZ;

	/**
	 * Render entity even if it is outside the camera frustum. Only true in
	 * EntityFish for now. Used in RenderGlobal: render if ignoreFrustumCheck or
	 * in frustum.
	 */
	public boolean ignoreFrustumCheck;
	public boolean isAirBorne;
	public int portalCooldown;

	/** Whether the entity is inside a Portal */
	protected boolean inPortal;
	protected int portalCounter;
	public int dimension;
	protected int teleportDirection;
	private boolean invulnerable;
	public UUID uniqueID;
	public EnumEntitySize myEntitySize;
	public boolean valid;
	public CustomTimingsHandler tickTimer = SpigotTimings.getEntityTimings(this);
	public final byte activationType = ActivationRange.initializeEntityActivationType(this);
	public final boolean defaultActivationState;
	public long activatedTick = 0L;
	protected CraftEntity bukkitEntity;

	static boolean isLevelAtLeast(NBTTagCompound tag, int level) {
		return tag.hasKey("Bukkit.updateLevel") && tag.getInt("Bukkit.updateLevel") >= level;
	}

	public void inactiveTick() {
	}

	public Entity(World par1World) {
		this.id = entityCount++;
		this.renderDistanceWeight = 1.0D;
		this.boundingBox = AxisAlignedBB.getBoundingBox(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
		this.field_70135_K = true;
		this.width = 0.6F;
		this.length = 1.8F;
		this.nextStepDistance = 1;
		this.random = new Random();
		this.maxFireTicks = 1;
		this.justCreated = true;
		this.datawatcher = new DataWatcher();
		this.uniqueID = new UUID(this.random.nextLong(), this.random.nextLong());
		this.myEntitySize = EnumEntitySize.SIZE_2;
		this.world = par1World;
		this.setPosition(0.0D, 0.0D, 0.0D);

		if (par1World != null) {
			this.dimension = par1World.worldProvider.dimension;
			this.defaultActivationState = ActivationRange.initializeEntityActivationState(this, par1World.spigotConfig);
		} else {
			this.defaultActivationState = false;
		}

		this.datawatcher.addObject(0, Byte.valueOf((byte) 0));
		this.datawatcher.addObject(1, Short.valueOf((short) 300));
		this.entityInit();
	}

	protected abstract void entityInit();

	public DataWatcher getDataWatcher() {
		return this.datawatcher;
	}

	public boolean equals(Object par1Obj) {
		return par1Obj instanceof Entity ? ((Entity) par1Obj).id == this.id : false;
	}

	public int hashCode() {
		return this.id;
	}

	public void die() {
		this.dead = true;
	}

	/**
	 * Sets the width and height of the entity. Args: width, height
	 */
	protected void setSize(float par1, float par2) {
		float var3;

		if (par1 != this.width || par2 != this.length) {
			var3 = this.width;
			this.width = par1;
			this.length = par2;
			this.boundingBox.maxX = this.boundingBox.minX + (double) this.width;
			this.boundingBox.maxZ = this.boundingBox.minZ + (double) this.width;
			this.boundingBox.maxY = this.boundingBox.minY + (double) this.length;

			if (this.width > var3 && !this.justCreated && !this.world.isStatic) {
				this.move((double) (var3 - this.width), 0.0D, (double) (var3 - this.width));
			}
		}

		var3 = par1 % 2.0F;

		if ((double) var3 < 0.375D) {
			this.myEntitySize = EnumEntitySize.SIZE_1;
		} else if ((double) var3 < 0.75D) {
			this.myEntitySize = EnumEntitySize.SIZE_2;
		} else if ((double) var3 < 1.0D) {
			this.myEntitySize = EnumEntitySize.SIZE_3;
		} else if ((double) var3 < 1.375D) {
			this.myEntitySize = EnumEntitySize.SIZE_4;
		} else if ((double) var3 < 1.75D) {
			this.myEntitySize = EnumEntitySize.SIZE_5;
		} else {
			this.myEntitySize = EnumEntitySize.SIZE_6;
		}
	}

	/**
	 * Sets the rotation of the entity. Args: yaw, pitch (both in degrees)
	 */
	protected void setRotation(float par1, float par2) {
		if (Float.isNaN(par1)) {
			par1 = 0.0F;
		}

		if (par1 == Float.POSITIVE_INFINITY || par1 == Float.NEGATIVE_INFINITY) {
			if (this instanceof EntityPlayer) {
				this.world.getServer().getLogger().warning(((CraftPlayer) this.getBukkitEntity()).getName()
						+ " was caught trying to crash the server with an invalid yaw");
				((CraftPlayer) this.getBukkitEntity()).kickPlayer("Nope");
			}

			par1 = 0.0F;
		}

		if (Float.isNaN(par2)) {
			par2 = 0.0F;
		}

		if (par2 == Float.POSITIVE_INFINITY || par2 == Float.NEGATIVE_INFINITY) {
			if (this instanceof EntityPlayer) {
				this.world.getServer().getLogger().warning(((CraftPlayer) this.getBukkitEntity()).getName()
						+ " was caught trying to crash the server with an invalid pitch");
				((CraftPlayer) this.getBukkitEntity()).kickPlayer("Nope");
			}

			par2 = 0.0F;
		}

		this.yaw = par1 % 360.0F;
		this.pitch = par2 % 360.0F;
	}

	public void setPosition(double d0, double d1, double d2) {
		this.locX = d0;
		this.locY = d1;
		this.locZ = d2;
		float f = this.width / 2.0F;
		float f1 = this.length;
		this.boundingBox.setBounds(d0 - (double) f, d1 - (double) this.height + (double) this.ySize, d2 - (double) f,
				d0 + (double) f, d1 - (double) this.height + (double) this.ySize + (double) f1, d2 + (double) f);
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		this.onEntityUpdate();
	}

	/**
	 * Gets called every tick from main Entity class
	 */
	public void onEntityUpdate() {
		this.world.methodProfiler.a("entityBaseTick");

		if (this.vehicle != null && this.vehicle.dead) {
			this.vehicle = null;
		}

		this.prevDistanceWalkedModified = this.distanceWalkedModified;
		this.lastX = this.locX;
		this.lastY = this.locY;
		this.lastZ = this.locZ;
		this.lastPitch = this.pitch;
		this.lastYaw = this.yaw;
		int var2;

		if (!this.world.isStatic && this.world instanceof WorldServer) {
			this.world.methodProfiler.a("portal");
			MinecraftServer var1 = ((WorldServer) this.world).getMinecraftServer();
			var2 = this.getMaxInPortalTime();

			if (this.inPortal) {
				if (this.vehicle == null && this.portalCounter++ >= var2) {
					this.portalCounter = var2;
					this.portalCooldown = this.getPortalCooldown();
					byte var3;

					if (this.world.worldProvider.dimension == -1) {
						var3 = 0;
					} else {
						var3 = -1;
					}

					this.travelToDimension(var3);
				}

				this.inPortal = false;
			} else {
				if (this.portalCounter > 0) {
					this.portalCounter -= 4;
				}

				if (this.portalCounter < 0) {
					this.portalCounter = 0;
				}
			}

			if (this.portalCooldown > 0) {
				--this.portalCooldown;
			}

			this.world.methodProfiler.b();
		}

		if (this.isSprinting() && !this.isInWater()) {
			int var5 = MathHelper.floor(this.locX);
			var2 = MathHelper.floor(this.locY - 0.20000000298023224D - (double) this.height);
			int var6 = MathHelper.floor(this.locZ);
			int var4 = this.world.getTypeId(var5, var2, var6);

			if (var4 > 0) {
				this.world.addParticle("tilecrack_" + var4 + "_" + this.world.getData(var5, var2, var6),
						this.locX + ((double) this.random.nextFloat() - 0.5D) * (double) this.width,
						this.boundingBox.minY + 0.1D,
						this.locZ + ((double) this.random.nextFloat() - 0.5D) * (double) this.width, -this.motX * 4.0D,
						1.5D, -this.motZ * 4.0D);
			}
		}

		this.handleWaterMovement();

		if (this.world.isStatic) {
			this.fireTicks = 0;
		} else if (this.fireTicks > 0) {
			if (this.fireProof) {
				this.fireTicks -= 4;

				if (this.fireTicks < 0) {
					this.fireTicks = 0;
				}
			} else {
				if (this.fireTicks % 20 == 0) {
					this.attackEntityFrom(DamageSource.BURN, 1.0F);
				}

				--this.fireTicks;
			}
		}

		if (this.handleLavaMovement()) {
			this.setOnFireFromLava();
			this.fallDistance *= 0.5F;
		}

		if (this.locY < -64.0D) {
			this.kill();
		}

		if (!this.world.isStatic) {
			this.setFlag(0, this.fireTicks > 0);
		}

		this.justCreated = false;
		this.world.methodProfiler.b();
	}

	/**
	 * Return the amount of time this entity should stay in a portal before
	 * being transported.
	 */
	public int getMaxInPortalTime() {
		return 0;
	}

	/**
	 * Called whenever the entity is walking inside of lava.
	 */
	protected void setOnFireFromLava() {
		if (!this.fireProof) {
			if (this instanceof EntityLiving) {
				CraftServer var1 = this.world.getServer();
				Object var2 = null;
				CraftEntity var3 = this.getBukkitEntity();
				EntityDamageByBlockEvent var4 = new EntityDamageByBlockEvent((org.bukkit.block.Block) var2, var3,
						EntityDamageEvent.DamageCause.LAVA, 4.0D);
				var1.getPluginManager().callEvent(var4);

				if (!var4.isCancelled()) {
					var3.setLastDamageCause(var4);
					this.attackEntityFrom(DamageSource.LAVA, (float) var4.getDamage());
				}

				if (this.fireTicks <= 0) {
					EntityCombustByBlockEvent var5 = new EntityCombustByBlockEvent((org.bukkit.block.Block) var2, var3,
							15);
					var1.getPluginManager().callEvent(var5);

					if (!var5.isCancelled()) {
						this.setOnFire(var5.getDuration());
					}
				} else {
					this.setOnFire(15);
				}

				return;
			}

			this.attackEntityFrom(DamageSource.LAVA, 4.0F);
			this.setOnFire(15);
		}
	}

	public void setOnFire(int i) {
		int j = i * 20;
		j = EnchantmentProtection.getFireTimeForEntity(this, j);

		if (this.fireTicks < j) {
			this.fireTicks = j;
		}
	}

	public void extinguish() {
		this.fireTicks = 0;
	}

	/**
	 * sets the dead flag. Used when you fall off the bottom of the world.
	 */
	protected void kill() {
		this.die();
	}

	/**
	 * Checks if the offset position from the entity's current position is
	 * inside of liquid. Args: x, y, z
	 */
	public boolean isOffsetPositionInLiquid(double par1, double par3, double par5) {
		AxisAlignedBB var7 = this.boundingBox.getOffsetBoundingBox(par1, par3, par5);
		List var8 = this.world.getCubes(this, var7);
		return !var8.isEmpty() ? false : !this.world.containsLiquid(var7);
	}

	public void move(double d0, double d1, double d2) {
		if (d0 != 0.0D || d1 != 0.0D || d2 != 0.0D || this.vehicle != null || this.passenger != null) {
			SpigotTimings.entityMoveTimer.startTiming();

			if (this.noClip) {
				this.boundingBox.offset(d0, d1, d2);
				this.locX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0D;
				this.locY = this.boundingBox.minY + (double) this.height - (double) this.ySize;
				this.locZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0D;
			} else {
				this.world.methodProfiler.a("move");
				this.ySize *= 0.4F;
				double d3 = this.locX;
				double d4 = this.locY;
				double d5 = this.locZ;

				if (this.isInWeb) {
					this.isInWeb = false;
					d0 *= 0.25D;
					d1 *= 0.05000000074505806D;
					d2 *= 0.25D;
					this.motX = 0.0D;
					this.motY = 0.0D;
					this.motZ = 0.0D;
				}

				double d6 = d0;
				double d7 = d1;
				double d8 = d2;
				AxisAlignedBB axisalignedbb = this.boundingBox.clone();
				boolean flag = this.onGround && this.isSneaking() && this instanceof EntityHuman;

				if (flag) {
					double d9;

					for (d9 = 0.05D; d0 != 0.0D
							&& this.world.getCubes(this, this.boundingBox.getOffsetBoundingBox(d0, -1.0D, 0.0D))
									.isEmpty(); d6 = d0) {
						if (d0 < d9 && d0 >= -d9) {
							d0 = 0.0D;
						} else if (d0 > 0.0D) {
							d0 -= d9;
						} else {
							d0 += d9;
						}
					}

					for (; d2 != 0.0D
							&& this.world.getCubes(this, this.boundingBox.getOffsetBoundingBox(0.0D, -1.0D, d2))
									.isEmpty(); d8 = d2) {
						if (d2 < d9 && d2 >= -d9) {
							d2 = 0.0D;
						} else if (d2 > 0.0D) {
							d2 -= d9;
						} else {
							d2 += d9;
						}
					}

					while (d0 != 0.0D && d2 != 0.0D && this.world
							.getCubes(this, this.boundingBox.getOffsetBoundingBox(d0, -1.0D, d2)).isEmpty()) {
						if (d0 < d9 && d0 >= -d9) {
							d0 = 0.0D;
						} else if (d0 > 0.0D) {
							d0 -= d9;
						} else {
							d0 += d9;
						}

						if (d2 < d9 && d2 >= -d9) {
							d2 = 0.0D;
						} else if (d2 > 0.0D) {
							d2 -= d9;
						} else {
							d2 += d9;
						}

						d6 = d0;
						d8 = d2;
					}
				}

				List list = this.world.getCubes(this, this.boundingBox.addCoord(d0, d1, d2));

				for (int flag1 = 0; flag1 < list.size(); ++flag1) {
					d1 = ((AxisAlignedBB) list.get(flag1)).calculateYOffset(this.boundingBox, d1);
				}

				this.boundingBox.offset(0.0D, d1, 0.0D);

				if (!this.field_70135_K && d7 != d1) {
					d2 = 0.0D;
					d1 = 0.0D;
					d0 = 0.0D;
				}

				boolean var38 = this.onGround || d7 != d1 && d7 < 0.0D;
				int j;

				for (j = 0; j < list.size(); ++j) {
					d0 = ((AxisAlignedBB) list.get(j)).calculateXOffset(this.boundingBox, d0);
				}

				this.boundingBox.offset(d0, 0.0D, 0.0D);

				if (!this.field_70135_K && d6 != d0) {
					d2 = 0.0D;
					d1 = 0.0D;
					d0 = 0.0D;
				}

				for (j = 0; j < list.size(); ++j) {
					d2 = ((AxisAlignedBB) list.get(j)).calculateZOffset(this.boundingBox, d2);
				}

				this.boundingBox.offset(0.0D, 0.0D, d2);

				if (!this.field_70135_K && d8 != d2) {
					d2 = 0.0D;
					d1 = 0.0D;
					d0 = 0.0D;
				}

				double d10;
				double d11;
				double d12;
				int k;

				if (this.stepHeight > 0.0F && var38 && (flag || this.ySize < 0.05F) && (d6 != d0 || d8 != d2)) {
					d10 = d0;
					d11 = d1;
					d12 = d2;
					d0 = d6;
					d1 = (double) this.stepHeight;
					d2 = d8;
					AxisAlignedBB flag2 = this.boundingBox.clone();
					this.boundingBox.setBB(axisalignedbb);
					list = this.world.getCubes(this, this.boundingBox.addCoord(d6, d1, d8));

					for (k = 0; k < list.size(); ++k) {
						d1 = ((AxisAlignedBB) list.get(k)).calculateYOffset(this.boundingBox, d1);
					}

					this.boundingBox.offset(0.0D, d1, 0.0D);

					if (!this.field_70135_K && d7 != d1) {
						d2 = 0.0D;
						d1 = 0.0D;
						d0 = 0.0D;
					}

					for (k = 0; k < list.size(); ++k) {
						d0 = ((AxisAlignedBB) list.get(k)).calculateXOffset(this.boundingBox, d0);
					}

					this.boundingBox.offset(d0, 0.0D, 0.0D);

					if (!this.field_70135_K && d6 != d0) {
						d2 = 0.0D;
						d1 = 0.0D;
						d0 = 0.0D;
					}

					for (k = 0; k < list.size(); ++k) {
						d2 = ((AxisAlignedBB) list.get(k)).calculateZOffset(this.boundingBox, d2);
					}

					this.boundingBox.offset(0.0D, 0.0D, d2);

					if (!this.field_70135_K && d8 != d2) {
						d2 = 0.0D;
						d1 = 0.0D;
						d0 = 0.0D;
					}

					if (!this.field_70135_K && d7 != d1) {
						d2 = 0.0D;
						d1 = 0.0D;
						d0 = 0.0D;
					} else {
						d1 = (double) (-this.stepHeight);

						for (k = 0; k < list.size(); ++k) {
							d1 = ((AxisAlignedBB) list.get(k)).calculateYOffset(this.boundingBox, d1);
						}

						this.boundingBox.offset(0.0D, d1, 0.0D);
					}

					if (d10 * d10 + d12 * d12 >= d0 * d0 + d2 * d2) {
						d0 = d10;
						d1 = d11;
						d2 = d12;
						this.boundingBox.setBB(flag2);
					}
				}

				this.world.methodProfiler.b();
				this.world.methodProfiler.a("rest");
				this.locX = (this.boundingBox.minX + this.boundingBox.maxX) / 2.0D;
				this.locY = this.boundingBox.minY + (double) this.height - (double) this.ySize;
				this.locZ = (this.boundingBox.minZ + this.boundingBox.maxZ) / 2.0D;
				this.positionChanged = d6 != d0 || d8 != d2;
				this.isCollidedVertically = d7 != d1;
				this.onGround = d7 != d1 && d7 < 0.0D;
				this.isCollided = this.positionChanged || this.isCollidedVertically;
				this.updateFallState(d1, this.onGround);

				if (d6 != d0) {
					this.motX = 0.0D;
				}

				if (d7 != d1) {
					this.motY = 0.0D;
				}

				if (d8 != d2) {
					this.motZ = 0.0D;
				}

				d10 = this.locX - d3;
				d11 = this.locY - d4;
				d12 = this.locZ - d5;

				if (this.positionChanged && this.getBukkitEntity() instanceof Vehicle) {
					Vehicle var39 = (Vehicle) this.getBukkitEntity();
					org.bukkit.block.Block event = this.world.getWorld().getBlockAt(MathHelper.floor(this.locX),
							MathHelper.floor(this.locY - (double) this.height), MathHelper.floor(this.locZ));

					if (d6 > d0) {
						event = event.getRelative(BlockFace.EAST);
					} else if (d6 < d0) {
						event = event.getRelative(BlockFace.WEST);
					} else if (d8 > d2) {
						event = event.getRelative(BlockFace.SOUTH);
					} else if (d8 < d2) {
						event = event.getRelative(BlockFace.NORTH);
					}

					VehicleBlockCollisionEvent crashreportsystemdetails = new VehicleBlockCollisionEvent(var39, event);
					this.world.getServer().getPluginManager().callEvent(crashreportsystemdetails);
				}

				if (this.canTriggerWalking() && !flag && this.vehicle == null) {
					int var40 = MathHelper.floor(this.locX);
					k = MathHelper.floor(this.locY - 0.20000000298023224D - (double) this.height);
					int var43 = MathHelper.floor(this.locZ);
					int var42 = this.world.getTypeId(var40, k, var43);

					if (var42 == 0) {
						int f = this.world.blockGetRenderType(var40, k - 1, var43);

						if (f == 11 || f == 32 || f == 21) {
							var42 = this.world.getTypeId(var40, k - 1, var43);
						}
					}

					if (var42 != Block.LADDER.id) {
						d11 = 0.0D;
					}

					this.distanceWalkedModified = (float) ((double) this.distanceWalkedModified
							+ (double) MathHelper.sqrt(d10 * d10 + d12 * d12) * 0.6D);
					this.distanceWalkedOnStepModified = (float) ((double) this.distanceWalkedOnStepModified
							+ (double) MathHelper.sqrt(d10 * d10 + d11 * d11 + d12 * d12) * 0.6D);

					if (this.distanceWalkedOnStepModified > (float) this.nextStepDistance && var42 > 0) {
						this.nextStepDistance = (int) this.distanceWalkedOnStepModified + 1;

						if (this.isInWater()) {
							float var46 = MathHelper.sqrt(this.motX * this.motX * 0.20000000298023224D
									+ this.motY * this.motY + this.motZ * this.motZ * 0.20000000298023224D) * 0.35F;

							if (var46 > 1.0F) {
								var46 = 1.0F;
							}

							this.makeSound("liquid.swim", var46,
									1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.4F);
						}

						this.playStepSound(var40, k, var43, var42);
						Block.byId[var42].onEntityWalking(this.world, var40, k, var43, this);
					}
				}

				try {
					this.doBlockCollisions();
				} catch (Throwable var37) {
					CrashReport var44 = CrashReport.makeCrashReport(var37, "Checking entity tile collision");
					CrashReportSystemDetails var45 = var44.a("Entity being checked for collision");
					this.a(var45);
					throw new ReportedException(var44);
				}

				boolean var41 = this.isWet();

				if (this.world.isBoundingBoxBurning(this.boundingBox.shrink(0.001D, 0.001D, 0.001D))) {
					this.burn(1.0F);

					if (!var41) {
						++this.fireTicks;

						if (this.fireTicks <= 0) {
							EntityCombustEvent var47 = new EntityCombustEvent(this.getBukkitEntity(), 8);
							this.world.getServer().getPluginManager().callEvent(var47);

							if (!var47.isCancelled()) {
								this.setOnFire(var47.getDuration());
							}
						} else {
							this.setOnFire(8);
						}
					}
				} else if (this.fireTicks <= 0) {
					this.fireTicks = -this.maxFireTicks;
				}

				if (var41 && this.fireTicks > 0) {
					this.makeSound("random.fizz", 0.7F,
							1.6F + (this.random.nextFloat() - this.random.nextFloat()) * 0.4F);
					this.fireTicks = -this.maxFireTicks;
				}

				this.world.methodProfiler.b();
			}

			SpigotTimings.entityMoveTimer.stopTiming();
		}
	}

	/**
	 * Checks for block collisions, and calls the associated onBlockCollided
	 * method for the collided block.
	 */
	protected void doBlockCollisions() {
		int var1 = MathHelper.floor(this.boundingBox.minX + 0.001D);
		int var2 = MathHelper.floor(this.boundingBox.minY + 0.001D);
		int var3 = MathHelper.floor(this.boundingBox.minZ + 0.001D);
		int var4 = MathHelper.floor(this.boundingBox.maxX - 0.001D);
		int var5 = MathHelper.floor(this.boundingBox.maxY - 0.001D);
		int var6 = MathHelper.floor(this.boundingBox.maxZ - 0.001D);

		if (this.world.checkChunksExist(var1, var2, var3, var4, var5, var6)) {
			for (int var7 = var1; var7 <= var4; ++var7) {
				for (int var8 = var2; var8 <= var5; ++var8) {
					for (int var9 = var3; var9 <= var6; ++var9) {
						int var10 = this.world.getTypeId(var7, var8, var9);

						if (var10 > 0) {
							try {
								Block.byId[var10].onEntityCollidedWithBlock(this.world, var7, var8, var9, this);
							} catch (Throwable var14) {
								CrashReport var12 = CrashReport.makeCrashReport(var14, "Colliding entity with tile");
								CrashReportSystemDetails var13 = var12.a("Tile being collided with");
								CrashReportSystemDetails.a(var13, var7, var8, var9, var10,
										this.world.getData(var7, var8, var9));
								throw new ReportedException(var12);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Plays step sound at given x, y, z for the entity
	 */
	protected void playStepSound(int par1, int par2, int par3, int par4) {
		StepSound var5 = Block.byId[par4].stepSound;

		if (this.world.getTypeId(par1, par2 + 1, par3) == Block.SNOW.id) {
			var5 = Block.SNOW.stepSound;
			this.makeSound(var5.getStepSound(), var5.getVolume1() * 0.15F, var5.getVolume2());
		} else if (!Block.byId[par4].material.isLiquid()) {
			this.makeSound(var5.getStepSound(), var5.getVolume1() * 0.15F, var5.getVolume2());
		}
	}

	public void makeSound(String s, float f, float f1) {
		this.world.makeSound(this, s, f, f1);
	}

	/**
	 * returns if this entity triggers Block.onEntityWalking on the blocks they
	 * walk on. used for spiders and wolves to prevent them from trampling crops
	 */
	protected boolean canTriggerWalking() {
		return true;
	}

	/**
	 * Takes in the distance the entity has fallen this tick and whether its on
	 * the ground to update the fall distance and deal fall damage if landing on
	 * the ground. Args: distanceFallenThisTick, onGround
	 */
	protected void updateFallState(double par1, boolean par3) {
		if (par3) {
			if (this.fallDistance > 0.0F) {
				this.fall(this.fallDistance);
				this.fallDistance = 0.0F;
			}
		} else if (par1 < 0.0D) {
			this.fallDistance = (float) ((double) this.fallDistance - par1);
		}
	}

	/**
	 * returns the bounding box for this entity
	 */
	public AxisAlignedBB getBoundingBox() {
		return null;
	}

	protected void burn(float i) {
		if (!this.fireProof) {
			this.attackEntityFrom(DamageSource.FIRE, i);
		}
	}

	public final boolean isFireproof() {
		return this.fireProof;
	}

	/**
	 * Called when the mob is falling. Calculates and applies fall damage.
	 */
	protected void fall(float par1) {
		if (this.passenger != null) {
			this.passenger.fall(par1);
		}
	}

	/**
	 * Checks if this entity is either in water or on an open air block in rain
	 * (used in wolves).
	 */
	public boolean isWet() {
		return this.inWater
				|| this.world.isRainingAt(MathHelper.floor(this.locX), MathHelper.floor(this.locY),
						MathHelper.floor(this.locZ))
				|| this.world.isRainingAt(MathHelper.floor(this.locX),
						MathHelper.floor(this.locY + (double) this.length), MathHelper.floor(this.locZ));
	}

	/**
	 * Checks if this entity is inside water (if inWater field is true as a
	 * result of handleWaterMovement() returning true)
	 */
	public boolean isInWater() {
		return this.inWater;
	}

	/**
	 * Returns if this entity is in water and will end up adding the waters
	 * velocity to the entity
	 */
	public boolean handleWaterMovement() {
		if (this.world.handleMaterialAcceleration(
				this.boundingBox.grow(0.0D, -0.4000000059604645D, 0.0D).shrink(0.001D, 0.001D, 0.001D), Material.WATER,
				this)) {
			if (!this.inWater && !this.justCreated) {
				float var1 = MathHelper.sqrt(this.motX * this.motX * 0.20000000298023224D + this.motY * this.motY
						+ this.motZ * this.motZ * 0.20000000298023224D) * 0.2F;

				if (var1 > 1.0F) {
					var1 = 1.0F;
				}

				this.makeSound("liquid.splash", var1,
						1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.4F);
				float var2 = (float) MathHelper.floor(this.boundingBox.minY);
				int var3;
				float var4;
				float var5;

				for (var3 = 0; (float) var3 < 1.0F + this.width * 20.0F; ++var3) {
					var4 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
					var5 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
					this.world.addParticle("bubble", this.locX + (double) var4, (double) (var2 + 1.0F),
							this.locZ + (double) var5, this.motX, this.motY - (double) (this.random.nextFloat() * 0.2F),
							this.motZ);
				}

				for (var3 = 0; (float) var3 < 1.0F + this.width * 20.0F; ++var3) {
					var4 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
					var5 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
					this.world.addParticle("splash", this.locX + (double) var4, (double) (var2 + 1.0F),
							this.locZ + (double) var5, this.motX, this.motY, this.motZ);
				}
			}

			this.fallDistance = 0.0F;
			this.inWater = true;
			this.fireTicks = 0;
		} else {
			this.inWater = false;
		}

		return this.inWater;
	}

	/**
	 * Checks if the current block the entity is within of the specified
	 * material type
	 */
	public boolean isInsideOfMaterial(Material par1Material) {
		double var2 = this.locY + (double) this.getHeadHeight();
		int var4 = MathHelper.floor(this.locX);
		int var5 = MathHelper.floor_float((float) MathHelper.floor(var2));
		int var6 = MathHelper.floor(this.locZ);
		int var7 = this.world.getTypeId(var4, var5, var6);

		if (var7 != 0 && Block.byId[var7].material == par1Material) {
			float var8 = BlockFluids.d(this.world.getData(var4, var5, var6)) - 0.11111111F;
			float var9 = (float) (var5 + 1) - var8;
			return var2 < (double) var9;
		} else {
			return false;
		}
	}

	public float getHeadHeight() {
		return 0.0F;
	}

	/**
	 * Whether or not the current entity is in lava
	 */
	public boolean handleLavaMovement() {
		return this.world.isMaterialInBB(
				this.boundingBox.grow(-0.10000000149011612D, -0.4000000059604645D, -0.10000000149011612D),
				Material.LAVA);
	}

	/**
	 * Used in both water and by flying objects
	 */
	public void moveFlying(float par1, float par2, float par3) {
		float var4 = par1 * par1 + par2 * par2;

		if (var4 >= 1.0E-4F) {
			var4 = MathHelper.sqrt_float(var4);

			if (var4 < 1.0F) {
				var4 = 1.0F;
			}

			var4 = par3 / var4;
			par1 *= var4;
			par2 *= var4;
			float var5 = MathHelper.sin(this.yaw * (float) Math.PI / 180.0F);
			float var6 = MathHelper.cos(this.yaw * (float) Math.PI / 180.0F);
			this.motX += (double) (par1 * var6 - par2 * var5);
			this.motZ += (double) (par2 * var6 + par1 * var5);
		}
	}

	/**
	 * Gets how bright this entity is.
	 */
	public float getBrightness(float par1) {
		int var2 = MathHelper.floor(this.locX);
		int var3 = MathHelper.floor(this.locZ);

		if (this.world.isLoaded(var2, 0, var3)) {
			double var4 = (this.boundingBox.maxY - this.boundingBox.minY) * 0.66D;
			int var6 = MathHelper.floor(this.locY - (double) this.height + var4);
			return this.world.getLightBrightness(var2, var6, var3);
		} else {
			return 0.0F;
		}
	}

	public void spawnIn(World world) {
		if (world == null) {
			this.die();
			this.world = ((CraftWorld) Bukkit.getServer().getWorlds().get(0)).getHandle();
		} else {
			this.world = world;
		}
	}

	public void setLocation(double d0, double d1, double d2, float f, float f1) {
		this.lastX = this.locX = d0;
		this.lastY = this.locY = d1;
		this.lastZ = this.locZ = d2;
		this.lastYaw = this.yaw = f;
		this.lastPitch = this.pitch = f1;
		this.ySize = 0.0F;
		double d3 = (double) (this.lastYaw - f);

		if (d3 < -180.0D) {
			this.lastYaw += 360.0F;
		}

		if (d3 >= 180.0D) {
			this.lastYaw -= 360.0F;
		}

		this.setPosition(this.locX, this.locY, this.locZ);
		this.setRotation(f, f1);
	}

	public void setPositionRotation(double d0, double d1, double d2, float f, float f1) {
		this.lastTickPosX = this.lastX = this.locX = d0;
		this.lastTickPosY = this.lastY = this.locY = d1 + (double) this.height;
		this.lastTickPosZ = this.lastZ = this.locZ = d2;
		this.yaw = f;
		this.pitch = f1;
		this.setPosition(this.locX, this.locY, this.locZ);
	}

	/**
	 * Returns the distance to the entity. Args: entity
	 */
	public float getDistanceToEntity(Entity par1Entity) {
		float var2 = (float) (this.locX - par1Entity.locX);
		float var3 = (float) (this.locY - par1Entity.locY);
		float var4 = (float) (this.locZ - par1Entity.locZ);
		return MathHelper.sqrt_float(var2 * var2 + var3 * var3 + var4 * var4);
	}

	/**
	 * Gets the squared distance to the position. Args: x, y, z
	 */
	public double getDistanceSq(double par1, double par3, double par5) {
		double var7 = this.locX - par1;
		double var9 = this.locY - par3;
		double var11 = this.locZ - par5;
		return var7 * var7 + var9 * var9 + var11 * var11;
	}

	/**
	 * Gets the distance to the position. Args: x, y, z
	 */
	public double getDistance(double par1, double par3, double par5) {
		double var7 = this.locX - par1;
		double var9 = this.locY - par3;
		double var11 = this.locZ - par5;
		return (double) MathHelper.sqrt(var7 * var7 + var9 * var9 + var11 * var11);
	}

	/**
	 * Returns the squared distance to the entity. Args: entity
	 */
	public double getDistanceSqToEntity(Entity par1Entity) {
		double var2 = this.locX - par1Entity.locX;
		double var4 = this.locY - par1Entity.locY;
		double var6 = this.locZ - par1Entity.locZ;
		return var2 * var2 + var4 * var4 + var6 * var6;
	}

	public void b_(EntityHuman entityhuman) {
	}

	public void collide(Entity entity) {
		if (entity.passenger != this && entity.vehicle != this) {
			double d0 = entity.locX - this.locX;
			double d1 = entity.locZ - this.locZ;
			double d2 = MathHelper.abs_max(d0, d1);

			if (d2 >= 0.009999999776482582D) {
				d2 = (double) MathHelper.sqrt(d2);
				d0 /= d2;
				d1 /= d2;
				double d3 = 1.0D / d2;

				if (d3 > 1.0D) {
					d3 = 1.0D;
				}

				d0 *= d3;
				d1 *= d3;
				d0 *= 0.05000000074505806D;
				d1 *= 0.05000000074505806D;
				d0 *= (double) (1.0F - this.entityCollisionReduction);
				d1 *= (double) (1.0F - this.entityCollisionReduction);
				this.addVelocity(-d0, 0.0D, -d1);
				entity.addVelocity(d0, 0.0D, d1);
			}
		}
	}

	/**
	 * Adds to the current velocity of the entity. Args: x, y, z
	 */
	public void addVelocity(double par1, double par3, double par5) {
		this.motX += par1;
		this.motY += par3;
		this.motZ += par5;
		this.isAirBorne = true;
	}

	/**
	 * Sets that this entity has been attacked.
	 */
	protected void setBeenAttacked() {
		this.velocityChanged = true;
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (this.isInvulnerable()) {
			return false;
		} else {
			this.setBeenAttacked();
			return false;
		}
	}

	/**
	 * Returns true if other Entities should be prevented from moving through
	 * this Entity.
	 */
	public boolean canBeCollidedWith() {
		return false;
	}

	/**
	 * Returns true if this entity should push and be pushed by other entities
	 * when colliding.
	 */
	public boolean canBePushed() {
		return false;
	}

	/**
	 * Adds a value to the player score. Currently not actually used and the
	 * entity passed in does nothing. Args: entity, scoreToAdd
	 */
	public void addToPlayerScore(Entity par1Entity, int par2) {
	}

	/**
	 * Like writeToNBTOptional but does not check if the entity is ridden. Used
	 * for saving ridden entities with their riders.
	 */
	public boolean writeMountToNBT(NBTTagCompound par1NBTTagCompound) {
		String var2 = this.getEntityString();

		if (!this.dead && var2 != null) {
			par1NBTTagCompound.setString("id", var2);
			this.writeToNBT(par1NBTTagCompound);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Either write this entity to the NBT tag given and return true, or return
	 * false without doing anything. If this returns false the entity is not
	 * saved on disk. Ridden entities return false here as they are saved with
	 * their rider.
	 */
	public boolean writeToNBTOptional(NBTTagCompound par1NBTTagCompound) {
		String var2 = this.getEntityString();

		if (!this.dead && var2 != null && this.passenger == null) {
			par1NBTTagCompound.setString("id", var2);
			this.writeToNBT(par1NBTTagCompound);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Save the entity to NBT (calls an abstract helper method to write extra
	 * data)
	 */
	public void writeToNBT(NBTTagCompound par1NBTTagCompound) {
		try {
			par1NBTTagCompound.set("Pos",
					this.newDoubleNBTList(new double[] { this.locX, this.locY + (double) this.ySize, this.locZ }));
			par1NBTTagCompound.set("Motion", this.newDoubleNBTList(new double[] { this.motX, this.motY, this.motZ }));

			if (Float.isNaN(this.yaw)) {
				this.yaw = 0.0F;
			}

			if (Float.isNaN(this.pitch)) {
				this.pitch = 0.0F;
			}

			par1NBTTagCompound.set("Rotation", this.newFloatNBTList(new float[] { this.yaw, this.pitch }));
			par1NBTTagCompound.setFloat("FallDistance", this.fallDistance);
			par1NBTTagCompound.setShort("Fire", (short) this.fireTicks);
			par1NBTTagCompound.setShort("Air", (short) this.getAirTicks());
			par1NBTTagCompound.setBoolean("OnGround", this.onGround);
			par1NBTTagCompound.setInt("Dimension", this.dimension);
			par1NBTTagCompound.setBoolean("Invulnerable", this.invulnerable);
			par1NBTTagCompound.setInt("PortalCooldown", this.portalCooldown);
			par1NBTTagCompound.setLong("UUIDMost", this.uniqueID.getMostSignificantBits());
			par1NBTTagCompound.setLong("UUIDLeast", this.uniqueID.getLeastSignificantBits());
			par1NBTTagCompound.setLong("WorldUUIDLeast",
					this.world.getDataManager().getUUID().getLeastSignificantBits());
			par1NBTTagCompound.setLong("WorldUUIDMost", this.world.getDataManager().getUUID().getMostSignificantBits());
			par1NBTTagCompound.setInt("Bukkit.updateLevel", 2);
			this.writeEntityToNBT(par1NBTTagCompound);

			if (this.vehicle != null) {
				NBTTagCompound var2 = new NBTTagCompound("Riding");

				if (this.vehicle.writeMountToNBT(var2)) {
					par1NBTTagCompound.set("Riding", var2);
				}
			}
		} catch (Throwable var5) {
			CrashReport var3 = CrashReport.makeCrashReport(var5, "Saving entity NBT");
			CrashReportSystemDetails var4 = var3.a("Entity being saved");
			this.a(var4);
			throw new ReportedException(var3);
		}
	}

	/**
	 * Reads the entity from NBT (calls an abstract helper method to read
	 * specialized data)
	 */
	public void readFromNBT(NBTTagCompound par1NBTTagCompound) {
		try {
			NBTTagList var2 = par1NBTTagCompound.getList("Pos");
			NBTTagList var10 = par1NBTTagCompound.getList("Motion");
			NBTTagList var11 = par1NBTTagCompound.getList("Rotation");
			this.motX = ((NBTTagDouble) var10.get(0)).data;
			this.motY = ((NBTTagDouble) var10.get(1)).data;
			this.motZ = ((NBTTagDouble) var10.get(2)).data;
			this.lastX = this.lastTickPosX = this.locX = ((NBTTagDouble) var2.get(0)).data;
			this.lastY = this.lastTickPosY = this.locY = ((NBTTagDouble) var2.get(1)).data;
			this.lastZ = this.lastTickPosZ = this.locZ = ((NBTTagDouble) var2.get(2)).data;
			this.lastYaw = this.yaw = ((NBTTagFloat) var11.get(0)).data;
			this.lastPitch = this.pitch = ((NBTTagFloat) var11.get(1)).data;
			this.fallDistance = par1NBTTagCompound.getFloat("FallDistance");
			this.fireTicks = par1NBTTagCompound.getShort("Fire");
			this.setAirTicks(par1NBTTagCompound.getShort("Air"));
			this.onGround = par1NBTTagCompound.getBoolean("OnGround");
			this.dimension = par1NBTTagCompound.getInt("Dimension");
			this.invulnerable = par1NBTTagCompound.getBoolean("Invulnerable");
			this.portalCooldown = par1NBTTagCompound.getInt("PortalCooldown");

			if (par1NBTTagCompound.hasKey("UUIDMost") && par1NBTTagCompound.hasKey("UUIDLeast")) {
				this.uniqueID = new UUID(par1NBTTagCompound.getLong("UUIDMost"),
						par1NBTTagCompound.getLong("UUIDLeast"));
			}

			this.setPosition(this.locX, this.locY, this.locZ);
			this.setRotation(this.yaw, this.pitch);
			this.readEntityFromNBT(par1NBTTagCompound);

			if (this.shouldSetPosAfterLoading()) {
				this.setPosition(this.locX, this.locY, this.locZ);
			}

			EntityInsentient var6;

			if (this instanceof EntityLiving) {
				EntityLiving var5 = (EntityLiving) this;

				if (var5 instanceof EntityTameableAnimal && !isLevelAtLeast(par1NBTTagCompound, 2)
						&& !par1NBTTagCompound.getBoolean("PersistenceRequired")) {
					var6 = (EntityInsentient) var5;
					var6.persistent = !var6.isTypeNotPersistent();
				}
			}

			if (!(this.getBukkitEntity() instanceof Vehicle)) {
				if (Math.abs(this.motX) > 10.0D) {
					this.motX = 0.0D;
				}

				if (Math.abs(this.motY) > 10.0D) {
					this.motY = 0.0D;
				}

				if (Math.abs(this.motZ) > 10.0D) {
					this.motZ = 0.0D;
				}
			}

			if (this instanceof EntityPlayer) {
				Server var12 = Bukkit.getServer();
				var6 = null;
				String var7 = par1NBTTagCompound.getString("World");
				Object var13;

				if (par1NBTTagCompound.hasKey("WorldUUIDMost") && par1NBTTagCompound.hasKey("WorldUUIDLeast")) {
					UUID var8 = new UUID(par1NBTTagCompound.getLong("WorldUUIDMost"),
							par1NBTTagCompound.getLong("WorldUUIDLeast"));
					var13 = var12.getWorld(var8);
				} else {
					var13 = var12.getWorld(var7);
				}

				if (var13 == null) {
					EntityPlayer var14 = (EntityPlayer) this;
					var13 = ((CraftServer) var12).getServer().getWorldServer(var14.dimension).getWorld();
				}

				this.spawnIn(var13 == null ? null : ((CraftWorld) var13).getHandle());
			}
		} catch (Throwable var9) {
			CrashReport var3 = CrashReport.makeCrashReport(var9, "Loading entity NBT");
			CrashReportSystemDetails var4 = var3.a("Entity being loaded");
			this.a(var4);
			throw new ReportedException(var3);
		}
	}

	protected boolean shouldSetPosAfterLoading() {
		return true;
	}

	/**
	 * Returns the string that identifies this Entity's class
	 */
	protected final String getEntityString() {
		return EntityTypes.b(this);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	protected abstract void readEntityFromNBT(NBTTagCompound var1);

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	protected abstract void writeEntityToNBT(NBTTagCompound var1);

	public void onChunkLoad() {
	}

	/**
	 * creates a NBT list from the array of doubles passed to this function
	 */
	protected NBTTagList newDoubleNBTList(double... par1ArrayOfDouble) {
		NBTTagList var2 = new NBTTagList();
		double[] var3 = par1ArrayOfDouble;
		int var4 = par1ArrayOfDouble.length;

		for (int var5 = 0; var5 < var4; ++var5) {
			double var6 = var3[var5];
			var2.add(new NBTTagDouble((String) null, var6));
		}

		return var2;
	}

	/**
	 * Returns a new NBTTagList filled with the specified floats
	 */
	protected NBTTagList newFloatNBTList(float... par1ArrayOfFloat) {
		NBTTagList var2 = new NBTTagList();
		float[] var3 = par1ArrayOfFloat;
		int var4 = par1ArrayOfFloat.length;

		for (int var5 = 0; var5 < var4; ++var5) {
			float var6 = var3[var5];
			var2.add(new NBTTagFloat((String) null, var6));
		}

		return var2;
	}

	/**
	 * Drops an item stack at the entity's position. Args: itemID, count
	 */
	public EntityItem dropItem(int par1, int par2) {
		return this.dropItemWithOffset(par1, par2, 0.0F);
	}

	/**
	 * Drops an item stack with a specified y offset. Args: itemID, count,
	 * yOffset
	 */
	public EntityItem dropItemWithOffset(int par1, int par2, float par3) {
		return this.entityDropItem(new ItemStack(par1, par2, 0), par3);
	}

	/**
	 * Drops an item at the position of the entity.
	 */
	public EntityItem entityDropItem(ItemStack par1ItemStack, float par2) {
		if (par1ItemStack.count == 0) {
			return null;
		} else {
			EntityItem var3 = new EntityItem(this.world, this.locX, this.locY + (double) par2, this.locZ,
					par1ItemStack);
			var3.pickupDelay = 10;
			this.world.addEntity(var3);
			return var3;
		}
	}

	public boolean isAlive() {
		return !this.dead;
	}

	public boolean inBlock() {
		for (int i = 0; i < 8; ++i) {
			float f = ((float) ((i >> 0) % 2) - 0.5F) * this.width * 0.8F;
			float f1 = ((float) ((i >> 1) % 2) - 0.5F) * 0.1F;
			float f2 = ((float) ((i >> 2) % 2) - 0.5F) * this.width * 0.8F;
			int j = MathHelper.floor(this.locX + (double) f);
			int k = MathHelper.floor(this.locY + (double) this.getHeadHeight() + (double) f1);
			int l = MathHelper.floor(this.locZ + (double) f2);

			if (this.world.isBlockNormalCube(j, k, l)) {
				return true;
			}
		}

		return false;
	}

	public boolean c(EntityHuman entityhuman) {
		return false;
	}

	/**
	 * Returns a boundingBox used to collide the entity with other entities and
	 * blocks. This enables the entity to be pushable on contact, like boats or
	 * minecarts.
	 */
	public AxisAlignedBB getCollisionBox(Entity par1Entity) {
		return null;
	}

	/**
	 * Handles updating while being ridden by an entity
	 */
	public void updateRidden() {
		if (this.vehicle.dead) {
			this.vehicle = null;
		} else {
			this.motX = 0.0D;
			this.motY = 0.0D;
			this.motZ = 0.0D;
			this.onUpdate();

			if (this.vehicle != null) {
				this.vehicle.updateRiderPosition();
				this.entityRiderYawDelta += (double) (this.vehicle.yaw - this.vehicle.lastYaw);

				for (this.entityRiderPitchDelta += (double) (this.vehicle.pitch
						- this.vehicle.lastPitch); this.entityRiderYawDelta >= 180.0D; this.entityRiderYawDelta -= 360.0D) {
					;
				}

				while (this.entityRiderYawDelta < -180.0D) {
					this.entityRiderYawDelta += 360.0D;
				}

				while (this.entityRiderPitchDelta >= 180.0D) {
					this.entityRiderPitchDelta -= 360.0D;
				}

				while (this.entityRiderPitchDelta < -180.0D) {
					this.entityRiderPitchDelta += 360.0D;
				}

				double var1 = this.entityRiderYawDelta * 0.5D;
				double var3 = this.entityRiderPitchDelta * 0.5D;
				float var5 = 10.0F;

				if (var1 > (double) var5) {
					var1 = (double) var5;
				}

				if (var1 < (double) (-var5)) {
					var1 = (double) (-var5);
				}

				if (var3 > (double) var5) {
					var3 = (double) var5;
				}

				if (var3 < (double) (-var5)) {
					var3 = (double) (-var5);
				}

				this.entityRiderYawDelta -= var1;
				this.entityRiderPitchDelta -= var3;
			}
		}
	}

	public void updateRiderPosition() {
		if (this.passenger != null) {
			this.passenger.setPosition(this.locX, this.locY + this.getMountedYOffset() + this.passenger.getYOffset(),
					this.locZ);
		}
	}

	/**
	 * Returns the Y Offset of this entity.
	 */
	public double getYOffset() {
		return (double) this.height;
	}

	/**
	 * Returns the Y offset from the entity's position for any entity riding
	 * this one.
	 */
	public double getMountedYOffset() {
		return (double) this.length * 0.75D;
	}

	public void mount(Entity entity) {
		this.setPassengerOf(entity);
	}

	public CraftEntity getBukkitEntity() {
		if (this.bukkitEntity == null) {
			this.bukkitEntity = CraftEntity.getEntity(this.world.getServer(), this);
		}

		return this.bukkitEntity;
	}

	public void setPassengerOf(Entity entity) {
		Entity originalVehicle = this.vehicle;
		Entity originalPassenger = this.vehicle == null ? null : this.vehicle.passenger;
		PluginManager pluginManager = Bukkit.getPluginManager();
		this.getBukkitEntity();
		this.entityRiderPitchDelta = 0.0D;
		this.entityRiderYawDelta = 0.0D;
		VehicleExitEvent event;

		if (entity == null) {
			if (this.vehicle != null) {
				if (this.bukkitEntity instanceof LivingEntity && this.vehicle.getBukkitEntity() instanceof Vehicle) {
					event = new VehicleExitEvent((Vehicle) this.vehicle.getBukkitEntity(),
							(LivingEntity) this.bukkitEntity);
					pluginManager.callEvent(event);

					if (event.isCancelled() || this.vehicle != originalVehicle) {
						return;
					}
				}

				pluginManager
						.callEvent(new EntityDismountEvent(this.getBukkitEntity(), this.vehicle.getBukkitEntity()));
				this.setPositionRotation(this.vehicle.locX,
						this.vehicle.boundingBox.minY + (double) this.vehicle.length, this.vehicle.locZ, this.yaw,
						this.pitch);
				this.vehicle.passenger = null;
			}

			this.vehicle = null;
		} else {
			if (this.bukkitEntity instanceof LivingEntity && entity.getBukkitEntity() instanceof Vehicle
					&& entity.world.isChunkLoaded((int) entity.locX >> 4, (int) entity.locZ >> 4)) {
				event = null;

				if (this.vehicle != null && this.vehicle.getBukkitEntity() instanceof Vehicle) {
					event = new VehicleExitEvent((Vehicle) this.vehicle.getBukkitEntity(),
							(LivingEntity) this.bukkitEntity);
					pluginManager.callEvent(event);

					if (event.isCancelled() || this.vehicle != originalVehicle
							|| this.vehicle != null && this.vehicle.passenger != originalPassenger) {
						return;
					}
				}

				VehicleEnterEvent event1 = new VehicleEnterEvent((Vehicle) entity.getBukkitEntity(), this.bukkitEntity);
				pluginManager.callEvent(event1);

				if (event1.isCancelled() || this.vehicle != originalVehicle
						|| this.vehicle != null && this.vehicle.passenger != originalPassenger) {
					if (event != null && this.vehicle == originalVehicle && this.vehicle != null
							&& this.vehicle.passenger == originalPassenger) {
						this.setPositionRotation(this.vehicle.locX,
								this.vehicle.boundingBox.minY + (double) this.vehicle.length, this.vehicle.locZ,
								this.yaw, this.pitch);
						this.vehicle.passenger = null;
						this.vehicle = null;
					}

					return;
				}
			}

			if (entity.world.isChunkLoaded((int) entity.locX >> 4, (int) entity.locZ >> 4)) {
				EntityMountEvent event2 = new EntityMountEvent(this.getBukkitEntity(), entity.getBukkitEntity());
				pluginManager.callEvent(event2);

				if (event2.isCancelled()) {
					return;
				}
			}

			if (this.vehicle != null) {
				this.vehicle.passenger = null;
			}

			this.vehicle = entity;
			entity.passenger = this;
		}
	}

	public float getCollisionBorderSize() {
		return 0.1F;
	}

	public Vec3D getLookVec() {
		return null;
	}

	/**
	 * Called by portal blocks when an entity is within it.
	 */
	public void setInPortal() {
		if (this.portalCooldown > 0) {
			this.portalCooldown = this.getPortalCooldown();
		} else {
			double var1 = this.lastX - this.locX;
			double var3 = this.lastZ - this.locZ;

			if (!this.world.isStatic && !this.inPortal) {
				this.teleportDirection = Direction.getMovementDirection(var1, var3);
			}

			this.inPortal = true;
		}
	}

	/**
	 * Return the amount of cooldown before this entity can use a portal again.
	 */
	public int getPortalCooldown() {
		return 900;
	}

	public ItemStack[] getEquipment() {
		return null;
	}

	public void setEquipment(int i, ItemStack itemstack) {
	}

	public boolean isBurning() {
		return !this.fireProof && (this.fireTicks > 0 || this.getFlag(0));
	}

	/**
	 * Returns true if the entity is riding another entity, used by render to
	 * rotate the legs to be in 'sit' position for players.
	 */
	public boolean isRiding() {
		return this.vehicle != null;
	}

	public boolean isSneaking() {
		return this.getFlag(1);
	}

	public void setSneaking(boolean flag) {
		this.setFlag(1, flag);
	}

	public boolean isSprinting() {
		return this.getFlag(3);
	}

	public void setSprinting(boolean flag) {
		this.setFlag(3, flag);
	}

	public boolean isInvisible() {
		return this.getFlag(5);
	}

	public void setInvisible(boolean flag) {
		this.setFlag(5, flag);
	}

	public void setEating(boolean par1) {
		this.setFlag(4, par1);
	}

	/**
	 * Returns true if the flag is active for the entity. Known flags: 0) is
	 * burning; 1) is sneaking; 2) is riding something; 3) is sprinting; 4) is
	 * eating
	 */
	protected boolean getFlag(int par1) {
		return (this.datawatcher.getByte(0) & 1 << par1) != 0;
	}

	/**
	 * Enable or disable a entity flag, see getEntityFlag to read the know
	 * flags.
	 */
	protected void setFlag(int par1, boolean par2) {
		byte var3 = this.datawatcher.getByte(0);

		if (par2) {
			this.datawatcher.watch(0, Byte.valueOf((byte) (var3 | 1 << par1)));
		} else {
			this.datawatcher.watch(0, Byte.valueOf((byte) (var3 & ~(1 << par1))));
		}
	}

	public int getAirTicks() {
		return this.datawatcher.getShort(1);
	}

	public void setAirTicks(int i) {
		this.datawatcher.watch(1, Short.valueOf((short) i));
	}

	public void a(EntityLightning entitylightning) {
		CraftEntity thisBukkitEntity = this.getBukkitEntity();
		CraftEntity stormBukkitEntity = entitylightning.getBukkitEntity();
		PluginManager pluginManager = Bukkit.getPluginManager();

		if (thisBukkitEntity instanceof Painting) {
			PaintingBreakByEntityEvent event = new PaintingBreakByEntityEvent((Painting) thisBukkitEntity,
					stormBukkitEntity);
			pluginManager.callEvent(event);

			if (event.isCancelled()) {
				return;
			}
		}

		EntityDamageEvent var7 = CraftEventFactory.callEntityDamageEvent(entitylightning, this,
				EntityDamageEvent.DamageCause.LIGHTNING, 5.0D);

		if (!var7.isCancelled()) {
			this.burn((float) var7.getDamage());
			++this.fireTicks;

			if (this.fireTicks == 0) {
				EntityCombustByEntityEvent entityCombustEvent = new EntityCombustByEntityEvent(stormBukkitEntity,
						thisBukkitEntity, 8);
				pluginManager.callEvent(entityCombustEvent);

				if (!entityCombustEvent.isCancelled()) {
					this.setOnFire(entityCombustEvent.getDuration());
				}
			}
		}
	}

	public void onKillEntity(EntityLiving entityliving) {
	}

	/**
	 * Adds velocity to push the entity out of blocks at the specified x, y, z
	 * position Args: x, y, z
	 */
	protected boolean pushOutOfBlocks(double par1, double par3, double par5) {
		int var7 = MathHelper.floor(par1);
		int var8 = MathHelper.floor(par3);
		int var9 = MathHelper.floor(par5);
		double var10 = par1 - (double) var7;
		double var12 = par3 - (double) var8;
		double var14 = par5 - (double) var9;
		List var16 = this.world.getCollidingBlockBounds(this.boundingBox);

		if (var16.isEmpty() && !this.world.isBlockFullCube(var7, var8, var9)) {
			return false;
		} else {
			boolean var17 = !this.world.isBlockFullCube(var7 - 1, var8, var9);
			boolean var18 = !this.world.isBlockFullCube(var7 + 1, var8, var9);
			boolean var19 = !this.world.isBlockFullCube(var7, var8 - 1, var9);
			boolean var20 = !this.world.isBlockFullCube(var7, var8 + 1, var9);
			boolean var21 = !this.world.isBlockFullCube(var7, var8, var9 - 1);
			boolean var22 = !this.world.isBlockFullCube(var7, var8, var9 + 1);
			byte var23 = 3;
			double var24 = 9999.0D;

			if (var17 && var10 < var24) {
				var24 = var10;
				var23 = 0;
			}

			if (var18 && 1.0D - var10 < var24) {
				var24 = 1.0D - var10;
				var23 = 1;
			}

			if (var20 && 1.0D - var12 < var24) {
				var24 = 1.0D - var12;
				var23 = 3;
			}

			if (var21 && var14 < var24) {
				var24 = var14;
				var23 = 4;
			}

			if (var22 && 1.0D - var14 < var24) {
				var24 = 1.0D - var14;
				var23 = 5;
			}

			float var26 = this.random.nextFloat() * 0.2F + 0.1F;

			if (var23 == 0) {
				this.motX = (double) (-var26);
			}

			if (var23 == 1) {
				this.motX = (double) var26;
			}

			if (var23 == 2) {
				this.motY = (double) (-var26);
			}

			if (var23 == 3) {
				this.motY = (double) var26;
			}

			if (var23 == 4) {
				this.motZ = (double) (-var26);
			}

			if (var23 == 5) {
				this.motZ = (double) var26;
			}

			return true;
		}
	}

	/**
	 * Sets the Entity inside a web block.
	 */
	public void setInWeb() {
		this.isInWeb = true;
		this.fallDistance = 0.0F;
	}

	public String getLocalizedName() {
		String s = EntityTypes.b(this);

		if (s == null) {
			s = "generic";
		}

		return LocaleI18n.get("entity." + s + ".name");
	}

	/**
	 * Return the Entity parts making up this Entity (currently only for
	 * dragons)
	 */
	public Entity[] getParts() {
		return null;
	}

	/**
	 * Returns true if Entity argument is equal to this Entity
	 */
	public boolean isEntityEqual(Entity par1Entity) {
		return this == par1Entity;
	}

	public float getHeadRotation() {
		return 0.0F;
	}

	/**
	 * If returns false, the item will not inflict any damage against entities.
	 */
	public boolean canAttackWithItem() {
		return true;
	}

	/**
	 * Called when a player attacks an entity. If this returns true the attack
	 * will not happen.
	 */
	public boolean hitByEntity(Entity par1Entity) {
		return false;
	}

	public String toString() {
		return String.format("%s[\'%s\'/%d, l=\'%s\', x=%.2f, y=%.2f, z=%.2f]",
				new Object[] { this.getClass().getSimpleName(), this.getLocalizedName(), Integer.valueOf(this.id),
						this.world == null ? "~NULL~" : this.world.getWorldData().getName(), Double.valueOf(this.locX),
						Double.valueOf(this.locY), Double.valueOf(this.locZ) });
	}

	public boolean isInvulnerable() {
		return this.invulnerable;
	}

	/**
	 * Sets this entity's location and angles to the location and angles of the
	 * passed in entity.
	 */
	public void copyLocationAndAnglesFrom(Entity par1Entity) {
		this.setPositionRotation(par1Entity.locX, par1Entity.locY, par1Entity.locZ, par1Entity.yaw, par1Entity.pitch);
	}

	/**
	 * Copies important data from another entity to this entity. Used when
	 * teleporting entities between worlds, as this actually deletes the
	 * teleporting entity and re-creates it on the other side. Params: Entity to
	 * copy from, unused (always true)
	 */
	public void copyDataFrom(Entity par1Entity, boolean par2) {
		NBTTagCompound var3 = new NBTTagCompound();
		par1Entity.writeToNBT(var3);
		this.readFromNBT(var3);
		this.portalCooldown = par1Entity.portalCooldown;
		this.teleportDirection = par1Entity.teleportDirection;
	}

	/**
	 * Teleports the entity to another dimension. Params: Dimension number to
	 * teleport to
	 */
	public void travelToDimension(int par1) {
		if (!this.world.isStatic && !this.dead) {
			this.world.methodProfiler.a("changeDimension");
			MinecraftServer var2 = MinecraftServer.getServer();
			WorldServer var3 = null;

			if (this.dimension < 10) {
				Iterator var4 = var2.worlds.iterator();

				while (var4.hasNext()) {
					WorldServer var5 = (WorldServer) var4.next();

					if (var5.dimension == par1) {
						var3 = var5;
					}
				}
			}

			Location var9 = this.getBukkitEntity().getLocation();
			Location var10 = var3 != null ? var2.getPlayerList().calculateTarget(var9, var2.getWorldServer(par1))
					: null;
			boolean var6 = var3 != null && (this.dimension != 1 || var3.dimension != 1);
			TravelAgent var7 = var10 != null ? (TravelAgent) ((CraftWorld) var10.getWorld()).getHandle().t()
					: CraftTravelAgent.DEFAULT;
			EntityPortalEvent var8 = new EntityPortalEvent(this.getBukkitEntity(), var9, var10, var7);
			var8.useTravelAgent(var6);
			var8.getEntity().getServer().getPluginManager().callEvent(var8);

			if (var8.isCancelled() || var8.getTo() == null || !this.isAlive()) {
				return;
			}

			var10 = var8.useTravelAgent() ? var8.getPortalTravelAgent().findOrCreate(var8.getTo()) : var8.getTo();
			this.teleportTo(var10, true);
		}
	}

	public void teleportTo(Location exit, boolean portal) {
		WorldServer worldserver = ((CraftWorld) this.getBukkitEntity().getLocation().getWorld()).getHandle();
		WorldServer worldserver1 = ((CraftWorld) exit.getWorld()).getHandle();
		int i = worldserver1.dimension;
		this.dimension = i;
		this.world.kill(this);
		this.dead = false;
		this.world.methodProfiler.a("reposition");
		boolean before = worldserver1.chunkProviderServer.forceChunkLoad;
		worldserver1.chunkProviderServer.forceChunkLoad = true;
		worldserver1.getMinecraftServer().getPlayerList().repositionEntity(this, exit, portal);
		worldserver1.chunkProviderServer.forceChunkLoad = before;
		this.world.methodProfiler.c("reloading");
		Entity entity = EntityTypes.createEntityByName(EntityTypes.b(this), worldserver1);

		if (entity != null) {
			entity.copyDataFrom(this, true);
			worldserver1.addEntity(entity);
			this.getBukkitEntity().setHandle(entity);
			entity.bukkitEntity = this.getBukkitEntity();
		}

		this.dead = true;
		this.world.methodProfiler.b();
		worldserver.resetUpdateEntityTick();
		worldserver1.resetUpdateEntityTick();
		this.world.methodProfiler.b();
	}

	/**
	 * Gets a block's resistance to this entity's explosion. Used to make rails
	 * immune to TNT minecarts' explosions and Wither skulls more destructive.
	 */
	public float getBlockExplosionResistance(Explosion par1Explosion, World par2World, int par3, int par4, int par5,
			Block par6Block) {
		return par6Block.getExplosionResistance(this);
	}

	public boolean shouldExplodeBlock(Explosion par1Explosion, World par2World, int par3, int par4, int par5, int par6,
			float par7) {
		return true;
	}

	/**
	 * The number of iterations PathFinder.getSafePoint will execute before
	 * giving up.
	 */
	public int getMaxSafePointTries() {
		return 3;
	}

	public int getTeleportDirection() {
		return this.teleportDirection;
	}

	/**
	 * Return whether this entity should NOT trigger a pressure plate or a
	 * tripwire.
	 */
	public boolean doesEntityNotTriggerPressurePlate() {
		return false;
	}

	public void a(CrashReportSystemDetails crashreportsystemdetails) {
		crashreportsystemdetails.a("Entity Type", (Callable) (new CrashReportEntityType(this)));
		crashreportsystemdetails.a("Entity ID", (Object) Integer.valueOf(this.id));
		crashreportsystemdetails.a("Entity Name", (Callable) (new CrashReportEntityName(this)));
		crashreportsystemdetails.a("Entity\'s Exact location", (Object) String.format("%.2f, %.2f, %.2f",
				new Object[] { Double.valueOf(this.locX), Double.valueOf(this.locY), Double.valueOf(this.locZ) }));
		crashreportsystemdetails.a("Entity\'s Block location", (Object) CrashReportSystemDetails
				.a(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ)));
		crashreportsystemdetails.a("Entity\'s Momentum", (Object) String.format("%.2f, %.2f, %.2f",
				new Object[] { Double.valueOf(this.motX), Double.valueOf(this.motY), Double.valueOf(this.motZ) }));
	}

	public UUID getUniqueID() {
		return this.uniqueID;
	}

	public boolean isPushedByWater() {
		return true;
	}

	public String getScoreboardDisplayName() {
		return this.getLocalizedName();
	}
}
