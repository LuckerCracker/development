package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class BlockHopper extends BlockContainer
{
    private final Random field_94457_a = new Random();

    public BlockHopper(int par1)
    {
        super(par1, Material.ORE);
        this.a(CreativeModeTab.d);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World par1World, int par2, int par3, int par4, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity)
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.625F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        float var8 = 0.125F;
        this.setBlockBounds(0.0F, 0.0F, 0.0F, var8, 1.0F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var8);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBounds(1.0F - var8, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBounds(0.0F, 0.0F, 1.0F - var8, 1.0F, 1.0F, 1.0F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    public int getPlacedData(World world, int i, int j, int k, int l, float f, float f1, float f2, int i1)
    {
        int j1 = Facing.OPPOSITE_FACING[l];

        if (j1 == 1)
        {
            j1 = 0;
        }

        return j1;
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityHopper();
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack)
    {
        super.postPlace(world, i, j, k, entityliving, itemstack);

        if (itemstack.hasName())
        {
            TileEntityHopper tileentityhopper = getHopperTile(world, i, j, k);
            tileentityhopper.setInventoryName(itemstack.getName());
        }
    }

    public void onPlace(World world, int i, int j, int k)
    {
        super.onPlace(world, i, j, k);
        this.updateMetadata(world, i, j, k);
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        if (world.isStatic)
        {
            return true;
        }
        else
        {
            TileEntityHopper tileentityhopper = getHopperTile(world, i, j, k);

            if (tileentityhopper != null)
            {
                entityhuman.openHopper(tileentityhopper);
            }

            return true;
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        this.updateMetadata(world, i, j, k);
    }

    /**
     * Updates the Metadata to include if the Hopper gets powered by Redstone or not
     */
    private void updateMetadata(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4);
        int var6 = getDirectionFromMetadata(var5);
        boolean var7 = !par1World.isBlockIndirectlyPowered(par2, par3, par4);
        boolean var8 = getIsBlockNotPoweredFromMetadata(var5);

        if (var7 != var8)
        {
            par1World.setData(par2, par3, par4, var6 | (var7 ? 0 : 8), 4);
        }
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        TileEntityHopper tileentityhopper = (TileEntityHopper)world.getTileEntity(i, j, k);

        if (tileentityhopper != null)
        {
            for (int j1 = 0; j1 < tileentityhopper.getSize(); ++j1)
            {
                ItemStack itemstack = tileentityhopper.getItem(j1);

                if (itemstack != null)
                {
                    float f = this.field_94457_a.nextFloat() * 0.8F + 0.1F;
                    float f1 = this.field_94457_a.nextFloat() * 0.8F + 0.1F;
                    float f2 = this.field_94457_a.nextFloat() * 0.8F + 0.1F;

                    while (itemstack.count > 0)
                    {
                        int k1 = this.field_94457_a.nextInt(21) + 10;

                        if (k1 > itemstack.count)
                        {
                            k1 = itemstack.count;
                        }

                        itemstack.count -= k1;
                        EntityItem entityitem = new EntityItem(world, (double)((float)i + f), (double)((float)j + f1), (double)((float)k + f2), new ItemStack(itemstack.id, k1, itemstack.getData()));

                        if (itemstack.hasTag())
                        {
                            entityitem.getItemStack().setTag((NBTTagCompound)itemstack.getTag().clone());
                        }

                        float f3 = 0.05F;
                        entityitem.motX = (double)((float)this.field_94457_a.nextGaussian() * f3);
                        entityitem.motY = (double)((float)this.field_94457_a.nextGaussian() * f3 + 0.2F);
                        entityitem.motZ = (double)((float)this.field_94457_a.nextGaussian() * f3);
                        world.addEntity(entityitem);
                    }
                }
            }

            world.func_96440_m(i, j, k, l);
        }

        super.remove(world, i, j, k, l, i1);
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 38;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    public static int getDirectionFromMetadata(int par0)
    {
        return Math.min(par0 & 7, 5);
    }

    public static boolean getIsBlockNotPoweredFromMetadata(int par0)
    {
        return (par0 & 8) != 8;
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        return Container.calcRedstoneFromInventory(getHopperTile(par1World, par2, par3, par4));
    }

    public static TileEntityHopper getHopperTile(IBlockAccess par0IBlockAccess, int par1, int par2, int par3)
    {
        return (TileEntityHopper)par0IBlockAccess.getTileEntity(par1, par2, par3);
    }
}
