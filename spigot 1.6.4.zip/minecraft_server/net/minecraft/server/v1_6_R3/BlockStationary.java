package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockStationary extends BlockFluids
{
    protected BlockStationary(int par1, Material par2Material)
    {
        super(par1, par2Material);
        this.setTickRandomly(false);

        if (par2Material == Material.LAVA)
        {
            this.setTickRandomly(true);
        }
    }

    public boolean getBlocksMovement(IBlockAccess par1IBlockAccess, int par2, int par3, int par4)
    {
        return this.material != Material.LAVA;
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        super.doPhysics(world, i, j, k, l);

        if (world.getTypeId(i, j, k) == this.id)
        {
            this.setNotStationary(world, i, j, k);
        }
    }

    /**
     * Changes the block ID to that of an updating fluid.
     */
    private void setNotStationary(World par1World, int par2, int par3, int par4)
    {
        int var5 = par1World.getData(par2, par3, par4);
        par1World.setTypeIdAndData(par2, par3, par4, this.id - 1, var5, 2);
        par1World.scheduleBlockUpdate(par2, par3, par4, this.id - 1, this.tickRate(par1World));
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (this.material == Material.LAVA)
        {
            int var6 = par5Random.nextInt(3);
            int var7 = par2;
            int var8 = par3;
            int var9 = par4;
            int var10 = 0;

            while (true)
            {
                int var11;

                if (var10 >= var6)
                {
                    if (var6 == 0)
                    {
                        var10 = par2;
                        var11 = par4;

                        for (int var12 = 0; var12 < 3; ++var12)
                        {
                            par2 = var10 + par5Random.nextInt(3) - 1;
                            par4 = var11 + par5Random.nextInt(3) - 1;

                            if (par1World.isEmpty(par2, par3 + 1, par4) && this.isFlammable(par1World, par2, par3, par4) && (par1World.getTypeId(par2, par3 + 1, par4) == Block.FIRE.id || !CraftEventFactory.callBlockIgniteEvent(par1World, par2, par3 + 1, par4, var7, var8, var9).isCancelled()))
                            {
                                par1World.setTypeIdUpdate(par2, par3 + 1, par4, Block.FIRE.id);
                            }
                        }
                    }

                    break;
                }

                par2 += par5Random.nextInt(3) - 1;
                ++par3;
                par4 += par5Random.nextInt(3) - 1;
                var11 = par1World.getTypeId(par2, par3, par4);

                if (var11 == 0)
                {
                    if ((this.isFlammable(par1World, par2 - 1, par3, par4) || this.isFlammable(par1World, par2 + 1, par3, par4) || this.isFlammable(par1World, par2, par3, par4 - 1) || this.isFlammable(par1World, par2, par3, par4 + 1) || this.isFlammable(par1World, par2, par3 - 1, par4) || this.isFlammable(par1World, par2, par3 + 1, par4)) && (par1World.getTypeId(par2, par3, par4) == Block.FIRE.id || !CraftEventFactory.callBlockIgniteEvent(par1World, par2, par3, par4, var7, var8, var9).isCancelled()))
                    {
                        par1World.setTypeIdUpdate(par2, par3, par4, Block.FIRE.id);
                        return;
                    }
                }
                else if (Block.byId[var11].material.isSolid())
                {
                    return;
                }

                ++var10;
            }
        }
    }

    /**
     * Checks to see if the block is flammable.
     */
    private boolean isFlammable(World par1World, int par2, int par3, int par4)
    {
        return par1World.getMaterial(par2, par3, par4).isBurnable();
    }
}
