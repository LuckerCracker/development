package net.minecraft.server.v1_6_R3;

final class CreativeModeTab9 extends CreativeModeTab
{
    CreativeModeTab9(int var1, String var2)
    {
        super(var1, var2);
    }
}
