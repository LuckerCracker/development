package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

public class CrashReportProfilerPosition implements Callable
{
    final MinecraftServer a;

    public CrashReportProfilerPosition(MinecraftServer var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return this.a.methodProfiler.a ? this.a.methodProfiler.c() : "N/A (disabled)";
    }

    public Object call()
    {
        return this.a();
    }
}
