package net.minecraft.server.v1_6_R3;

class DispenseBehaviorThrownPotion extends DispenseBehaviorProjectile
{
    final ItemStack b;

    final DispenseBehaviorPotion c;

    DispenseBehaviorThrownPotion(DispenseBehaviorPotion var1, ItemStack var2)
    {
        this.c = var1;
        this.b = var2;
    }

    protected IProjectile a(World var1, IPosition var2)
    {
        return new EntityPotion(var1, var2.getX(), var2.getY(), var2.getZ(), this.b.cloneItemStack());
    }

    protected float a()
    {
        return super.a() * 0.5F;
    }

    protected float b()
    {
        return super.b() * 1.25F;
    }
}
