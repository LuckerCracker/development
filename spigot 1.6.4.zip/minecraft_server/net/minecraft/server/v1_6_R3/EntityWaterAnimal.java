package net.minecraft.server.v1_6_R3;

public abstract class EntityWaterAnimal extends EntityCreature implements IAnimal
{
    public EntityWaterAnimal(World var1)
    {
        super(var1);
    }

    public boolean canBreatheUnderwater()
    {
        return true;
    }

    public boolean canSpawn()
    {
        return this.world.checkNoEntityCollision(this.boundingBox);
    }

    /**
     * Get number of ticks, at least during which the living entity will be silent.
     */
    public int getTalkInterval()
    {
        return 120;
    }

    protected boolean isTypeNotPersistent()
    {
        return true;
    }

    protected int getExpValue(EntityHuman var1)
    {
        return 1 + this.world.random.nextInt(3);
    }

    /**
     * Gets called every tick from main Entity class
     */
    public void onEntityUpdate()
    {
        int var1 = this.getAirTicks();
        super.onEntityUpdate();

        if (this.isAlive() && !this.isInWater())
        {
            --var1;
            this.setAirTicks(var1);

            if (this.getAirTicks() == -20)
            {
                this.setAirTicks(0);
                this.attackEntityFrom(DamageSource.DROWN, 2.0F);
            }
        }
        else
        {
            this.setAirTicks(300);
        }
    }
}
