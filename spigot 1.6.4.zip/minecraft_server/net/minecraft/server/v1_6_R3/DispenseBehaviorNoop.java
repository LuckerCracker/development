package net.minecraft.server.v1_6_R3;

final class DispenseBehaviorNoop implements IDispenseBehavior
{
    public ItemStack a(ISourceBlock var1, ItemStack var2)
    {
        return var2;
    }
}
