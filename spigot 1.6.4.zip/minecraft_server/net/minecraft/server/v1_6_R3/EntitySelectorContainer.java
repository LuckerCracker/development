package net.minecraft.server.v1_6_R3;

final class EntitySelectorContainer implements IEntitySelector
{
    /**
     * Return whether the specified entity is applicable to this filter.
     */
    public boolean isEntityApplicable(Entity var1)
    {
        return var1 instanceof IInventory && var1.isAlive();
    }
}
