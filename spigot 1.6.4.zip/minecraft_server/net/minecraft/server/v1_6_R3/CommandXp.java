package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandXp extends CommandAbstract
{
    public String getCommandName()
    {
        return "xp";
    }

    public int a()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.xp.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length <= 0)
        {
            throw new ExceptionUsage("commands.xp.usage", new Object[0]);
        }
        else
        {
            String var3 = var2[0];
            boolean var4 = var3.endsWith("l") || var3.endsWith("L");

            if (var4 && var3.length() > 1)
            {
                var3 = var3.substring(0, var3.length() - 1);
            }

            int var5 = a(var1, var3);
            boolean var6 = var5 < 0;

            if (var6)
            {
                var5 *= -1;
            }

            EntityPlayer var7;

            if (var2.length > 1)
            {
                var7 = d(var1, var2[1]);
            }
            else
            {
                var7 = b(var1);
            }

            if (var4)
            {
                if (var6)
                {
                    var7.levelDown(-var5);
                    a(var1, "commands.xp.success.negative.levels", new Object[] {Integer.valueOf(var5), var7.getLocalizedName()});
                }
                else
                {
                    var7.levelDown(var5);
                    a(var1, "commands.xp.success.levels", new Object[] {Integer.valueOf(var5), var7.getLocalizedName()});
                }
            }
            else
            {
                if (var6)
                {
                    throw new ExceptionUsage("commands.xp.failure.widthdrawXp", new Object[0]);
                }

                var7.giveExp(var5);
                a(var1, "commands.xp.success", new Object[] {Integer.valueOf(var5), var7.getLocalizedName()});
            }
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 2 ? a(var2, this.d()) : null;
    }

    protected String[] d()
    {
        return MinecraftServer.getServer().getPlayers();
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return var2 == 1;
    }
}
