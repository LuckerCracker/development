package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryDoubleChest;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.inventory.Inventory;

public class BlockDropper extends BlockDispenser
{
    private final IDispenseBehavior dropperDefaultBehaviour = new DispenseBehaviorItem();

    protected BlockDropper(int par1)
    {
        super(par1);
    }

    protected IDispenseBehavior a(ItemStack itemstack)
    {
        return this.dropperDefaultBehaviour;
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityDropper();
    }

    public void dispense(World world, int i, int j, int k)
    {
        SourceBlock sourceblock = new SourceBlock(world, i, j, k);
        TileEntityDispenser tileentitydispenser = (TileEntityDispenser)sourceblock.getTileEntity();

        if (tileentitydispenser != null)
        {
            int l = tileentitydispenser.getRandomStackFromInventory();

            if (l < 0)
            {
                world.triggerEffect(1001, i, j, k, 0);
            }
            else
            {
                ItemStack itemstack = tileentitydispenser.getItem(l);
                int i1 = world.getData(i, j, k) & 7;
                IInventory iinventory = TileEntityHopper.getInventoryAt(world, (double)(i + Facing.offsetsXForSide[i1]), (double)(j + Facing.offsetsYForSide[i1]), (double)(k + Facing.offsetsZForSide[i1]));
                ItemStack itemstack1;

                if (iinventory != null)
                {
                    CraftItemStack oitemstack = CraftItemStack.asCraftMirror(itemstack.cloneItemStack().splitStack(1));
                    Object destinationInventory;

                    if (iinventory instanceof InventoryLargeChest)
                    {
                        destinationInventory = new CraftInventoryDoubleChest((InventoryLargeChest)iinventory);
                    }
                    else
                    {
                        destinationInventory = iinventory.getOwner().getInventory();
                    }

                    InventoryMoveItemEvent event = new InventoryMoveItemEvent(tileentitydispenser.getOwner().getInventory(), oitemstack.clone(), (Inventory)destinationInventory, true);
                    world.getServer().getPluginManager().callEvent(event);

                    if (event.isCancelled())
                    {
                        return;
                    }

                    itemstack1 = TileEntityHopper.addItem(iinventory, CraftItemStack.asNMSCopy(event.getItem()), Facing.OPPOSITE_FACING[i1]);

                    if (event.getItem().equals(oitemstack) && itemstack1 == null)
                    {
                        itemstack1 = itemstack.cloneItemStack();

                        if (--itemstack1.count == 0)
                        {
                            itemstack1 = null;
                        }
                    }
                    else
                    {
                        itemstack1 = itemstack.cloneItemStack();
                    }
                }
                else
                {
                    itemstack1 = this.dropperDefaultBehaviour.a(sourceblock, itemstack);

                    if (itemstack1 != null && itemstack1.count == 0)
                    {
                        itemstack1 = null;
                    }
                }

                tileentitydispenser.setItem(l, itemstack1);
            }
        }
    }
}
