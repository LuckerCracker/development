package net.minecraft.server.v1_6_R3;

import java.util.Iterator;

public class CommandDispatcher extends CommandHandler implements ICommandDispatcher
{
    public CommandDispatcher()
    {
        this.registerCommand(new CommandTime());
        this.registerCommand(new CommandGamemode());
        this.registerCommand(new CommandDifficulty());
        this.registerCommand(new CommandGamemodeDefault());
        this.registerCommand(new CommandKill());
        this.registerCommand(new CommandToggleDownfall());
        this.registerCommand(new CommandWeather());
        this.registerCommand(new CommandXp());
        this.registerCommand(new CommandTp());
        this.registerCommand(new CommandGive());
        this.registerCommand(new CommandEffect());
        this.registerCommand(new CommandEnchant());
        this.registerCommand(new CommandMe());
        this.registerCommand(new CommandSeed());
        this.registerCommand(new CommandHelp());
        this.registerCommand(new CommandDebug());
        this.registerCommand(new CommandTell());
        this.registerCommand(new CommandSay());
        this.registerCommand(new CommandSpawnpoint());
        this.registerCommand(new CommandGamerule());
        this.registerCommand(new CommandClear());
        this.registerCommand(new CommandTestFor());
        this.registerCommand(new CommandSpreadPlayers());
        this.registerCommand(new CommandPlaySound());
        this.registerCommand(new CommandScoreboard());

        if (MinecraftServer.getServer().isDedicatedServer())
        {
            this.registerCommand(new CommandOp());
            this.registerCommand(new CommandDeop());
            this.registerCommand(new CommandStop());
            this.registerCommand(new CommandSaveAll());
            this.registerCommand(new CommandSaveOff());
            this.registerCommand(new CommandSaveOn());
            this.registerCommand(new CommandBanIp());
            this.registerCommand(new CommandPardonIP());
            this.registerCommand(new CommandBan());
            this.registerCommand(new CommandBanList());
            this.registerCommand(new CommandPardon());
            this.registerCommand(new CommandKick());
            this.registerCommand(new CommandList());
            this.registerCommand(new CommandWhitelist());
            this.registerCommand(new CommandIdleTimeout());
        }
        else
        {
            this.registerCommand(new CommandPublish());
        }

        CommandAbstract.a((ICommandDispatcher)this);
    }

    public void a(ICommandListener var1, int var2, String var3, Object ... var4)
    {
        boolean var5 = true;

        if (var1 instanceof TileEntityCommand && !MinecraftServer.getServer().worldServer[0].getGameRules().getBoolean("commandBlockOutput"))
        {
            var5 = false;
        }

        ChatMessage var6 = ChatMessage.b("chat.type.admin", new Object[] {var1.getName(), ChatMessage.b(var3, var4)});
        var6.a(EnumChatFormat.GRAY);
        var6.b(Boolean.valueOf(true));

        if (var5)
        {
            Iterator var7 = MinecraftServer.getServer().getPlayerList().players.iterator();

            while (var7.hasNext())
            {
                EntityPlayer var8 = (EntityPlayer)var7.next();

                if (var8 != var1 && MinecraftServer.getServer().getPlayerList().isOp(var8.getName()))
                {
                    var8.sendMessage(var6);
                }
            }
        }

        if (var1 != MinecraftServer.getServer())
        {
            MinecraftServer.getServer().sendMessage(var6);
        }

        if ((var2 & 1) != 1)
        {
            var1.sendMessage(ChatMessage.b(var3, var4));
        }
    }
}
