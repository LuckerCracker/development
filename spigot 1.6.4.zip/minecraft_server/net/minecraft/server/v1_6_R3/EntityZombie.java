package net.minecraft.server.v1_6_R3;

import java.util.Calendar;
import java.util.UUID;

import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityCombustEvent;

public class EntityZombie extends EntityMonster {
	protected static final IAttribute field_110186_bp = (new AttributeRanged("zombie.spawnReinforcements", 0.0D, 0.0D,
			1.0D)).a("Spawn Reinforcements Chance");
	private static final UUID babySpeedBoostUUID = UUID.fromString("B9766B59-9566-4402-BC1F-2EE2A276D836");
	private static final AttributeModifier babySpeedBoostModifier = new AttributeModifier(babySpeedBoostUUID,
			"Baby speed boost", 0.5D, 1);

	/**
	 * Ticker used to determine the time remaining for this zombie to convert
	 * into a villager when cured.
	 */
	private int conversionTime;
	private int lastTick;

	public EntityZombie(World par1World) {
		super(par1World);
		this.lastTick = MinecraftServer.currentTick;
		this.getNavigation().b(true);
		this.goalSelector.a(0, new PathfinderGoalFloat(this));
		this.goalSelector.a(1, new PathfinderGoalBreakDoor(this));
		this.goalSelector.a(2, new PathfinderGoalMeleeAttack(this, EntityHuman.class, 1.0D, false));
		this.goalSelector.a(3, new PathfinderGoalMeleeAttack(this, EntityVillager.class, 1.0D, true));
		this.goalSelector.a(4, new PathfinderGoalMoveTowardsRestriction(this, 1.0D));
		this.goalSelector.a(5, new PathfinderGoalMoveThroughVillage(this, 1.0D, false));
		this.goalSelector.a(6, new PathfinderGoalRandomStroll(this, 1.0D));
		this.goalSelector.a(7, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 8.0F));
		this.goalSelector.a(7, new PathfinderGoalRandomLookaround(this));
		this.targetSelector.a(1, new PathfinderGoalHurtByTarget(this, true));
		this.targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, EntityHuman.class, 0, true));
		this.targetSelector.a(2, new PathfinderGoalNearestAttackableTarget(this, EntityVillager.class, 0, false));
	}

	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getAttributeInstance(GenericAttributes.b).setValue(40.0D);
		this.getAttributeInstance(GenericAttributes.d).setValue(0.23000000417232513D);
		this.getAttributeInstance(GenericAttributes.e).setValue(3.0D);
		this.getAttributeMap().b(field_110186_bp).setValue(this.random.nextDouble() * 0.10000000149011612D);
	}

	protected void entityInit() {
		super.entityInit();
		this.getDataWatcher().addObject(12, Byte.valueOf((byte) 0));
		this.getDataWatcher().addObject(13, Byte.valueOf((byte) 0));
		this.getDataWatcher().addObject(14, Byte.valueOf((byte) 0));
	}

	/**
	 * Returns the current armor value as determined by a call to
	 * InventoryPlayer.getTotalArmorValue
	 */
	public int getTotalArmorValue() {
		int var1 = super.getTotalArmorValue() + 2;

		if (var1 > 20) {
			var1 = 20;
		}

		return var1;
	}

	/**
	 * Returns true if the newer Entity AI code should be run
	 */
	protected boolean isAIEnabled() {
		return true;
	}

	public boolean isBaby() {
		return this.getDataWatcher().getByte(12) == 1;
	}

	public void setBaby(boolean flag) {
		this.getDataWatcher().watch(12, Byte.valueOf((byte) (flag ? 1 : 0)));

		if (this.world != null && !this.world.isStatic) {
			AttributeInstance attributeinstance = this.getAttributeInstance(GenericAttributes.d);
			attributeinstance.removeModifier(babySpeedBoostModifier);

			if (flag) {
				attributeinstance.applyModifier(babySpeedBoostModifier);
			}
		}
	}

	public boolean isVillager() {
		return this.getDataWatcher().getByte(13) == 1;
	}

	public void setVillager(boolean flag) {
		this.getDataWatcher().watch(13, Byte.valueOf((byte) (flag ? 1 : 0)));
	}

	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	public void onLivingUpdate() {
		if (this.world.isDaytime() && !this.world.isStatic && !this.isBaby()) {
			float var1 = this.getBrightness(1.0F);

			if (var1 > 0.5F && this.random.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F && this.world.canBlockSeeTheSky(
					MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ))) {
				boolean var2 = true;
				ItemStack var3 = this.getEquipment(4);

				if (var3 != null) {
					if (var3.isItemStackDamageable()) {
						var3.setData(var3.getItemDamageForDisplay() + this.random.nextInt(2));

						if (var3.getItemDamageForDisplay() >= var3.getMaxDamage()) {
							this.renderBrokenItemStack(var3);
							this.setEquipment(4, (ItemStack) null);
						}
					}

					var2 = false;
				}

				if (var2) {
					EntityCombustEvent var4 = new EntityCombustEvent(this.getBukkitEntity(), 8);
					this.world.getServer().getPluginManager().callEvent(var4);

					if (!var4.isCancelled()) {
						this.setOnFire(var4.getDuration());
					}
				}
			}
		}

		super.onLivingUpdate();
	}

	public boolean attackEntityFrom(DamageSource damagesource, float f) {
		if (!super.attackEntityFrom(damagesource, f)) {
			return false;
		} else {
			EntityLiving entityliving = this.getGoalTarget();

			if (entityliving == null && this.getEntityToAttack() instanceof EntityLiving) {
				entityliving = (EntityLiving) this.getEntityToAttack();
			}

			if (entityliving == null && damagesource.getEntity() instanceof EntityLiving) {
				entityliving = (EntityLiving) damagesource.getEntity();
			}

			if (entityliving != null && this.world.difficulty >= 3
					&& (double) this.random.nextFloat() < this.getAttributeInstance(field_110186_bp).getValue()) {
				int i = MathHelper.floor(this.locX);
				int j = MathHelper.floor(this.locY);
				int k = MathHelper.floor(this.locZ);
				EntityZombie entityzombie = new EntityZombie(this.world);

				for (int l = 0; l < 50; ++l) {
					int i1 = i + MathHelper.nextInt(this.random, 7, 40) * MathHelper.nextInt(this.random, -1, 1);
					int j1 = j + MathHelper.nextInt(this.random, 7, 40) * MathHelper.nextInt(this.random, -1, 1);
					int k1 = k + MathHelper.nextInt(this.random, 7, 40) * MathHelper.nextInt(this.random, -1, 1);

					if (this.world.doesBlockHaveSolidTopSurface(i1, j1 - 1, k1)
							&& this.world.getLightLevel(i1, j1, k1) < 10) {
						entityzombie.setPosition((double) i1, (double) j1, (double) k1);

						if (this.world.checkNoEntityCollision(entityzombie.boundingBox)
								&& this.world.getCubes(entityzombie, entityzombie.boundingBox).isEmpty()
								&& !this.world.containsLiquid(entityzombie.boundingBox)) {
							this.world.addEntity(entityzombie, CreatureSpawnEvent.SpawnReason.REINFORCEMENTS);
							entityzombie.setGoalTarget(entityliving);
							entityzombie.a((GroupDataEntity) null);
							this.getAttributeInstance(field_110186_bp).applyModifier(new AttributeModifier(
									"Zombie reinforcement caller charge", -0.05000000074505806D, 0));
							entityzombie.getAttributeInstance(field_110186_bp).applyModifier(new AttributeModifier(
									"Zombie reinforcement callee charge", -0.05000000074505806D, 0));
							break;
						}
					}
				}
			}

			return true;
		}
	}

	/**
	 * Called to update the entity's position/logic.
	 */
	public void onUpdate() {
		if (!this.world.isStatic && this.isConverting()) {
			int var1 = this.getConversionTimeBoost();
			int var2 = MinecraftServer.currentTick - this.lastTick;
			this.lastTick = MinecraftServer.currentTick;
			var1 *= var2;
			this.conversionTime -= var1;

			if (this.conversionTime <= 0) {
				this.convertToVillager();
			}
		}

		super.onUpdate();
	}

	public boolean attackEntityAsMob(Entity par1Entity) {
		boolean var2 = super.attackEntityAsMob(par1Entity);

		if (var2 && this.getHeldItem() == null && this.isBurning()
				&& this.random.nextFloat() < (float) this.world.difficulty * 0.3F) {
			EntityCombustByEntityEvent var3 = new EntityCombustByEntityEvent(this.getBukkitEntity(),
					par1Entity.getBukkitEntity(), 2 * this.world.difficulty);
			this.world.getServer().getPluginManager().callEvent(var3);

			if (!var3.isCancelled()) {
				par1Entity.setOnFire(var3.getDuration());
			}
		}

		return var2;
	}

	/**
	 * Returns the sound this mob makes while it's alive.
	 */
	protected String getLivingSound() {
		return "mob.zombie.say";
	}

	/**
	 * Returns the sound this mob makes when it is hurt.
	 */
	protected String getHurtSound() {
		return "mob.zombie.hurt";
	}

	/**
	 * Returns the sound this mob makes on death.
	 */
	protected String getDeathSound() {
		return "mob.zombie.death";
	}

	/**
	 * Plays step sound at given x, y, z for the entity
	 */
	protected void playStepSound(int par1, int par2, int par3, int par4) {
		this.makeSound("mob.zombie.step", 0.15F, 1.0F);
	}

	protected int getLootId() {
		return Item.ROTTEN_FLESH.id;
	}

	public EnumMonsterType getMonsterType() {
		return EnumMonsterType.UNDEAD;
	}

	protected ItemStack l(int i) {
		switch (this.random.nextInt(3)) {
		case 0:
			return new ItemStack(Item.IRON_INGOT.id, 1, 0);

		case 1:
			return new ItemStack(Item.CARROT.id, 1, 0);

		case 2:
			return new ItemStack(Item.POTATO.id, 1, 0);

		default:
			return null;
		}
	}

	/**
	 * Makes entity wear random armor based on difficulty
	 */
	protected void addRandomArmor() {
		super.addRandomArmor();

		if (this.random.nextFloat() < (this.world.difficulty == 3 ? 0.05F : 0.01F)) {
			int var1 = this.random.nextInt(3);

			if (var1 == 0) {
				this.setEquipment(0, new ItemStack(Item.IRON_SWORD));
			} else {
				this.setEquipment(0, new ItemStack(Item.IRON_SPADE));
			}
		}
	}

	/**
	 * (abstract) Protected helper method to write subclass entity data to NBT.
	 */
	public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound) {
		super.writeEntityToNBT(par1NBTTagCompound);

		if (this.isBaby()) {
			par1NBTTagCompound.setBoolean("IsBaby", true);
		}

		if (this.isVillager()) {
			par1NBTTagCompound.setBoolean("IsVillager", true);
		}

		par1NBTTagCompound.setInt("ConversionTime", this.isConverting() ? this.conversionTime : -1);
	}

	/**
	 * (abstract) Protected helper method to read subclass entity data from NBT.
	 */
	public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound) {
		super.readEntityFromNBT(par1NBTTagCompound);

		if (par1NBTTagCompound.getBoolean("IsBaby")) {
			this.setBaby(true);
		}

		if (par1NBTTagCompound.getBoolean("IsVillager")) {
			this.setVillager(true);
		}

		if (par1NBTTagCompound.hasKey("ConversionTime") && par1NBTTagCompound.getInt("ConversionTime") > -1) {
			this.startConversion(par1NBTTagCompound.getInt("ConversionTime"));
		}
	}

	public void onKillEntity(EntityLiving entityliving) {
		super.onKillEntity(entityliving);

		if (this.world.difficulty >= 2 && entityliving instanceof EntityVillager) {
			if (this.world.difficulty == 2 && this.random.nextBoolean()) {
				return;
			}

			EntityZombie entityzombie = new EntityZombie(this.world);
			entityzombie.copyLocationAndAnglesFrom(entityliving);
			this.world.kill(entityliving);
			entityzombie.a((GroupDataEntity) null);
			entityzombie.setVillager(true);

			if (entityliving.isBaby()) {
				entityzombie.setBaby(true);
			}

			this.world.addEntity(entityzombie);
			this.world.a((EntityHuman) null, 1016, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
		}
	}

	public GroupDataEntity a(GroupDataEntity groupdataentity) {
		Object object = super.a(groupdataentity);
		float f = this.world.getLocationTensionFactor(this.locX, this.locY, this.locZ);
		this.setCanPickUpLoot(this.random.nextFloat() < 0.55F * f);

		if (object == null) {
			object = new GroupDataZombie(this, this.world.random.nextFloat() < 0.05F,
					this.world.random.nextFloat() < 0.05F, (EmptyClass4) null);
		}

		if (object instanceof GroupDataZombie) {
			GroupDataZombie calendar = (GroupDataZombie) object;

			if (calendar.b) {
				this.setVillager(true);
			}

			if (calendar.a) {
				this.setBaby(true);
			}
		}

		this.addRandomArmor();
		this.enchantEquipment();

		if (this.getEquipment(4) == null) {
			Calendar calendar1 = this.world.getCurrentDate();

			if (calendar1.get(2) + 1 == 10 && calendar1.get(5) == 31 && this.random.nextFloat() < 0.25F) {
				this.setEquipment(4,
						new ItemStack(this.random.nextFloat() < 0.1F ? Block.JACK_O_LANTERN : Block.PUMPKIN));
				this.dropChances[4] = 0.0F;
			}
		}

		this.getAttributeInstance(GenericAttributes.c).applyModifier(
				new AttributeModifier("Random spawn bonus", this.random.nextDouble() * 0.05000000074505806D, 0));
		this.getAttributeInstance(GenericAttributes.b)
				.applyModifier(new AttributeModifier("Random zombie-spawn bonus", this.random.nextDouble() * 1.5D, 2));

		if (this.random.nextFloat() < f * 0.05F) {
			this.getAttributeInstance(field_110186_bp).applyModifier(
					new AttributeModifier("Leader zombie bonus", this.random.nextDouble() * 0.25D + 0.5D, 0));
			this.getAttributeInstance(GenericAttributes.a).applyModifier(
					new AttributeModifier("Leader zombie bonus", this.random.nextDouble() * 3.0D + 1.0D, 2));
		}

		return (GroupDataEntity) object;
	}

	public boolean a(EntityHuman entityhuman) {
		ItemStack itemstack = entityhuman.getCurrentEquippedItem();

		if (itemstack != null && itemstack.getItem() == Item.GOLDEN_APPLE && itemstack.getData() == 0
				&& this.isVillager() && this.hasEffect(MobEffectList.WEAKNESS)) {
			if (!entityhuman.abilities.canInstantlyBuild) {
				--itemstack.count;
			}

			if (itemstack.count <= 0) {
				entityhuman.inventory.setItem(entityhuman.inventory.itemInHandIndex, (ItemStack) null);
			}

			if (!this.world.isStatic) {
				this.startConversion(this.random.nextInt(2401) + 3600);
			}

			return true;
		} else {
			return false;
		}
	}

	/**
	 * Starts converting this zombie into a villager. The zombie converts into a
	 * villager after the specified time in ticks.
	 */
	protected void startConversion(int par1) {
		this.conversionTime = par1;
		this.getDataWatcher().watch(14, Byte.valueOf((byte) 1));
		this.removePotionEffect(MobEffectList.WEAKNESS.id);
		this.addEffect(new MobEffect(MobEffectList.INCREASE_DAMAGE.id, par1, Math.min(this.world.difficulty - 1, 0)));
		this.world.broadcastEntityEffect(this, (byte) 16);
	}

	protected boolean isTypeNotPersistent() {
		return !this.isConverting();
	}

	/**
	 * Returns whether this zombie is in the process of converting to a villager
	 */
	public boolean isConverting() {
		return this.getDataWatcher().getByte(14) == 1;
	}

	/**
	 * Convert this zombie into a villager.
	 */
	protected void convertToVillager() {
		EntityVillager var1 = new EntityVillager(this.world);
		var1.copyLocationAndAnglesFrom(this);
		var1.a((GroupDataEntity) null);
		var1.func_82187_q();

		if (this.isBaby()) {
			var1.setAge(-24000);
		}

		this.world.kill(this);
		this.world.addEntity(var1);
		var1.addEffect(new MobEffect(MobEffectList.CONFUSION.id, 200, 0));
		this.world.a((EntityHuman) null, 1017, (int) this.locX, (int) this.locY, (int) this.locZ, 0);
	}

	/**
	 * Return the amount of time decremented from conversionTime every tick.
	 */
	protected int getConversionTimeBoost() {
		int var1 = 1;

		if (this.random.nextFloat() < 0.01F) {
			int var2 = 0;

			for (int var3 = (int) this.locX - 4; var3 < (int) this.locX + 4 && var2 < 14; ++var3) {
				for (int var4 = (int) this.locY - 4; var4 < (int) this.locY + 4 && var2 < 14; ++var4) {
					for (int var5 = (int) this.locZ - 4; var5 < (int) this.locZ + 4 && var2 < 14; ++var5) {
						int var6 = this.world.getTypeId(var3, var4, var5);

						if (var6 == Block.IRON_FENCE.id || var6 == Block.BED.id) {
							if (this.random.nextFloat() < 0.3F) {
								++var1;
							}

							++var2;
						}
					}
				}
			}
		}

		return var1;
	}
}
