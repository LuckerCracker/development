package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockReed extends Block
{
    protected BlockReed(int par1)
    {
        super(par1, Material.PLANT);
        float var2 = 0.375F;
        this.setBlockBounds(0.5F - var2, 0.0F, 0.5F - var2, 0.5F + var2, 1.0F, 0.5F + var2);
        this.setTickRandomly(true);
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (par1World.isEmpty(par2, par3 + 1, par4))
        {
            int var6;

            for (var6 = 1; par1World.getTypeId(par2, par3 - var6, par4) == this.id; ++var6)
            {
                ;
            }

            if (var6 < 3)
            {
                int var7 = par1World.getData(par2, par3, par4);

                if (var7 >= (byte)((int)range(3.0F, par1World.growthOdds / (float)par1World.spigotConfig.caneModifier * 15.0F + 0.5F, 15.0F)))
                {
                    CraftEventFactory.handleBlockGrowEvent(par1World, par2, par3 + 1, par4, this.id, 0);
                    par1World.setData(par2, par3, par4, 0, 4);
                }
                else
                {
                    par1World.setData(par2, par3, par4, var7 + 1, 4);
                }
            }
        }
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j - 1, k);
        return l == this.id ? true : (l != Block.GRASS.id && l != Block.DIRT.id && l != Block.SAND.id ? false : (world.getMaterial(i - 1, j - 1, k) == Material.WATER ? true : (world.getMaterial(i + 1, j - 1, k) == Material.WATER ? true : (world.getMaterial(i, j - 1, k - 1) == Material.WATER ? true : world.getMaterial(i, j - 1, k + 1) == Material.WATER))));
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        this.checkBlockCoordValid(world, i, j, k);
    }

    /**
     * Checks if current block pos is valid, if not, breaks the block as dropable item. Used for reed and cactus.
     */
    protected final void checkBlockCoordValid(World par1World, int par2, int par3, int par4)
    {
        if (!this.canBlockStay(par1World, par2, par3, par4))
        {
            this.dropBlockAsItem(par1World, par2, par3, par4, par1World.getData(par2, par3, par4), 0);
            par1World.setAir(par2, par3, par4);
        }
    }

    /**
     * Can this block stay at this position.  Similar to canPlaceBlockAt except gets checked often with plants.
     */
    public boolean canBlockStay(World par1World, int par2, int par3, int par4)
    {
        return this.canPlace(par1World, par2, par3, par4);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        return null;
    }

    public int getDropType(int i, Random random, int j)
    {
        return Item.SUGAR_CANE.id;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 1;
    }
}
