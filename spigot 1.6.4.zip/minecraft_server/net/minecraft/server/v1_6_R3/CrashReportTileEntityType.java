package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportTileEntityType implements Callable
{
    final TileEntity a;

    CrashReportTileEntityType(TileEntity var1)
    {
        this.a = var1;
    }

    public String a()
    {
        int var1 = this.a.world.getTypeId(this.a.x, this.a.y, this.a.z);

        try
        {
            return String.format("ID #%d (%s // %s)", new Object[] {Integer.valueOf(var1), Block.byId[var1].getUnlocalizedName(), Block.byId[var1].getClass().getCanonicalName()});
        }
        catch (Throwable var3)
        {
            return "ID #" + var1;
        }
    }

    public Object call()
    {
        return this.a();
    }
}
