package net.minecraft.server.v1_6_R3;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

public class EntityVillager extends EntityAgeable implements IMerchant, NPC
{
    private int profession;
    private boolean isMating;
    private boolean isPlaying;
    Village village;
    private EntityHuman tradingPlayer;

    /** Initialises the MerchantRecipeList.java */
    private MerchantRecipeList buyingList;
    private int timeUntilReset;

    /** addDefaultEquipmentAndRecipies is called if this is true */
    private boolean needsInitilization;
    private int riches;

    /** Last player to trade with this villager, used for aggressivity. */
    private String lastBuyingPlayer;
    private boolean field_82190_bM;
    private float field_82191_bN;

    /** Selling list of Villagers items. */
    private static final Map villagersSellingList = new HashMap();

    /** Selling list of Blacksmith items. */
    private static final Map blacksmithSellingList = new HashMap();

    public EntityVillager(World par1World)
    {
        this(par1World, 0);
    }

    public EntityVillager(World par1World, int par2)
    {
        super(par1World);
        this.setProfession(par2);
        this.setSize(0.6F, 1.8F);
        this.getNavigation().b(true);
        this.getNavigation().a(true);
        this.goalSelector.a(0, new PathfinderGoalFloat(this));
        this.goalSelector.a(1, new PathfinderGoalAvoidPlayer(this, EntityZombie.class, 8.0F, 0.6D, 0.6D));
        this.goalSelector.a(1, new PathfinderGoalTradeWithPlayer(this));
        this.goalSelector.a(1, new PathfinderGoalLookAtTradingPlayer(this));
        this.goalSelector.a(2, new PathfinderGoalMoveIndoors(this));
        this.goalSelector.a(3, new PathfinderGoalRestrictOpenDoor(this));
        this.goalSelector.a(4, new PathfinderGoalOpenDoor(this, true));
        this.goalSelector.a(5, new PathfinderGoalMoveTowardsRestriction(this, 0.6D));
        this.goalSelector.a(6, new PathfinderGoalMakeLove(this));
        this.goalSelector.a(7, new PathfinderGoalTakeFlower(this));
        this.goalSelector.a(8, new PathfinderGoalPlay(this, 0.32D));
        this.goalSelector.a(9, new PathfinderGoalInteract(this, EntityHuman.class, 3.0F, 1.0F));
        this.goalSelector.a(9, new PathfinderGoalInteract(this, EntityVillager.class, 5.0F, 0.02F));
        this.goalSelector.a(9, new PathfinderGoalRandomStroll(this, 0.6D));
        this.goalSelector.a(10, new PathfinderGoalLookAtPlayer(this, EntityInsentient.class, 8.0F));
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.d).setValue(0.5D);
    }

    /**
     * Returns true if the newer Entity AI code should be run
     */
    public boolean isAIEnabled()
    {
        return true;
    }

    /**
     * main AI tick function, replaces updateEntityActionState
     */
    protected void updateAITick()
    {
        if (--this.profession <= 0)
        {
            this.world.villages.addVillagerPosition(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ));
            this.profession = 70 + this.random.nextInt(50);
            this.village = this.world.villages.getClosestVillage(MathHelper.floor(this.locX), MathHelper.floor(this.locY), MathHelper.floor(this.locZ), 32);

            if (this.village == null)
            {
                this.detachHome();
            }
            else
            {
                ChunkCoordinates var1 = this.village.getCenter();
                this.setHomeArea(var1.x, var1.y, var1.z, (int)((float)this.village.getSize() * 0.6F));

                if (this.field_82190_bM)
                {
                    this.field_82190_bM = false;
                    this.village.func_82683_b(5);
                }
            }
        }

        if (!this.isTrading() && this.timeUntilReset > 0)
        {
            --this.timeUntilReset;

            if (this.timeUntilReset <= 0)
            {
                if (this.needsInitilization)
                {
                    if (this.buyingList.size() > 1)
                    {
                        Iterator var3 = this.buyingList.iterator();

                        while (var3.hasNext())
                        {
                            MerchantRecipe var2 = (MerchantRecipe)var3.next();

                            if (var2.func_82784_g())
                            {
                                var2.func_82783_a(this.random.nextInt(6) + this.random.nextInt(6) + 2);
                            }
                        }
                    }

                    this.addDefaultEquipmentAndRecipies(1);
                    this.needsInitilization = false;

                    if (this.village != null && this.lastBuyingPlayer != null)
                    {
                        this.world.broadcastEntityEffect(this, (byte)14);
                        this.village.setReputationForPlayer(this.lastBuyingPlayer, 1);
                    }
                }

                this.addEffect(new MobEffect(MobEffectList.REGENERATION.id, 200, 0));
            }
        }

        super.updateAITick();
    }

    public boolean a(EntityHuman var1)
    {
        ItemStack var2 = var1.inventory.getItemInHand();
        boolean var3 = var2 != null && var2.id == Item.MONSTER_EGG.id;

        if (!var3 && this.isAlive() && !this.isTrading() && !this.isBaby())
        {
            if (!this.world.isStatic)
            {
                this.a_(var1);
                var1.openTrade(this, this.getCustomName());
            }

            return true;
        }
        else
        {
            return super.a(var1);
        }
    }

    protected void entityInit()
    {
        super.entityInit();
        this.datawatcher.addObject(16, Integer.valueOf(0));
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setInt("Profession", this.getProfession());
        par1NBTTagCompound.setInt("Riches", this.riches);

        if (this.buyingList != null)
        {
            par1NBTTagCompound.setCompound("Offers", this.buyingList.getRecipiesAsTags());
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);
        this.setProfession(par1NBTTagCompound.getInt("Profession"));
        this.riches = par1NBTTagCompound.getInt("Riches");

        if (par1NBTTagCompound.hasKey("Offers"))
        {
            NBTTagCompound var2 = par1NBTTagCompound.getCompound("Offers");
            this.buyingList = new MerchantRecipeList(var2);
        }
    }

    protected boolean isTypeNotPersistent()
    {
        return false;
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return this.isTrading() ? "mob.villager.haggle" : "mob.villager.idle";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.villager.hit";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.villager.death";
    }

    public void setProfession(int var1)
    {
        this.datawatcher.watch(16, Integer.valueOf(var1));
    }

    public int getProfession()
    {
        return this.datawatcher.getInt(16);
    }

    public boolean isMating()
    {
        return this.isMating;
    }

    public void setMating(boolean par1)
    {
        this.isMating = par1;
    }

    public void setPlaying(boolean par1)
    {
        this.isPlaying = par1;
    }

    public boolean isPlaying()
    {
        return this.isPlaying;
    }

    public void setRevengeTarget(EntityLiving var1)
    {
        super.setRevengeTarget(var1);

        if (this.village != null && var1 != null)
        {
            this.village.a(var1);

            if (var1 instanceof EntityHuman)
            {
                byte var2 = -1;

                if (this.isBaby())
                {
                    var2 = -3;
                }

                this.village.setReputationForPlayer(((EntityHuman)var1).getName(), var2);

                if (this.isAlive())
                {
                    this.world.broadcastEntityEffect(this, (byte)13);
                }
            }
        }
    }

    public void die(DamageSource var1)
    {
        if (this.village != null)
        {
            Entity var2 = var1.getEntity();

            if (var2 != null)
            {
                if (var2 instanceof EntityHuman)
                {
                    this.village.setReputationForPlayer(((EntityHuman)var2).getName(), -2);
                }
                else if (var2 instanceof IMonster)
                {
                    this.village.endMatingSeason();
                }
            }
            else if (var2 == null)
            {
                EntityHuman var3 = this.world.findNearbyPlayer(this, 16.0D);

                if (var3 != null)
                {
                    this.village.endMatingSeason();
                }
            }
        }

        super.die(var1);
    }

    public void a_(EntityHuman var1)
    {
        this.tradingPlayer = var1;
    }

    public EntityHuman m_()
    {
        return this.tradingPlayer;
    }

    public boolean isTrading()
    {
        return this.tradingPlayer != null;
    }

    public void useRecipe(MerchantRecipe par1MerchantRecipe)
    {
        par1MerchantRecipe.incrementToolUses();
        this.livingSoundTime = -this.getTalkInterval();
        this.makeSound("mob.villager.yes", this.getSoundVolume(), this.getSoundPitch());

        if (par1MerchantRecipe.hasSameIDsAs((MerchantRecipe)this.buyingList.get(this.buyingList.size() - 1)))
        {
            this.timeUntilReset = 40;
            this.needsInitilization = true;

            if (this.tradingPlayer != null)
            {
                this.lastBuyingPlayer = this.tradingPlayer.getName();
            }
            else
            {
                this.lastBuyingPlayer = null;
            }
        }

        if (par1MerchantRecipe.getBuyItem1().id == Item.EMERALD.id)
        {
            this.riches += par1MerchantRecipe.getBuyItem1().count;
        }
    }

    public void func_110297_a_(ItemStack par1ItemStack)
    {
        if (!this.world.isStatic && this.livingSoundTime > -this.getTalkInterval() + 20)
        {
            this.livingSoundTime = -this.getTalkInterval();

            if (par1ItemStack != null)
            {
                this.makeSound("mob.villager.yes", this.getSoundVolume(), this.getSoundPitch());
            }
            else
            {
                this.makeSound("mob.villager.no", this.getSoundVolume(), this.getSoundPitch());
            }
        }
    }

    public MerchantRecipeList getOffers(EntityHuman var1)
    {
        if (this.buyingList == null)
        {
            this.addDefaultEquipmentAndRecipies(1);
        }

        return this.buyingList;
    }

    /**
     * Adjusts the probability of obtaining a given recipe being offered by a villager
     */
    private float adjustProbability(float par1)
    {
        float var2 = par1 + this.field_82191_bN;
        return var2 > 0.9F ? 0.9F - (var2 - 0.9F) : var2;
    }

    /**
     * based on the villagers profession add items, equipment, and recipies adds par1 random items to the list of things
     * that the villager wants to buy. (at most 1 of each wanted type is added)
     */
    private void addDefaultEquipmentAndRecipies(int par1)
    {
        if (this.buyingList != null)
        {
            this.field_82191_bN = MathHelper.sqrt_float((float)this.buyingList.size()) * 0.2F;
        }
        else
        {
            this.field_82191_bN = 0.0F;
        }

        MerchantRecipeList var2;
        var2 = new MerchantRecipeList();
        int var6;
        label50:

        switch (this.getProfession())
        {
            case 0:
                addMerchantItem(var2, Item.WHEAT.id, this.random, this.adjustProbability(0.9F));
                addMerchantItem(var2, Block.WOOL.id, this.random, this.adjustProbability(0.5F));
                addMerchantItem(var2, Item.RAW_CHICKEN.id, this.random, this.adjustProbability(0.5F));
                addMerchantItem(var2, Item.COOKED_FISH.id, this.random, this.adjustProbability(0.4F));
                addBlacksmithItem(var2, Item.BREAD.id, this.random, this.adjustProbability(0.9F));
                addBlacksmithItem(var2, Item.MELON.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.APPLE.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.COOKIE.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.SHEARS.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.FLINT_AND_STEEL.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.COOKED_CHICKEN.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.ARROW.id, this.random, this.adjustProbability(0.5F));

                if (this.random.nextFloat() < this.adjustProbability(0.5F))
                {
                    var2.add(new MerchantRecipe(new ItemStack(Block.GRAVEL, 10), new ItemStack(Item.EMERALD), new ItemStack(Item.FLINT.id, 4 + this.random.nextInt(2), 0)));
                }

                break;

            case 1:
                addMerchantItem(var2, Item.PAPER.id, this.random, this.adjustProbability(0.8F));
                addMerchantItem(var2, Item.BOOK.id, this.random, this.adjustProbability(0.8F));
                addMerchantItem(var2, Item.WRITTEN_BOOK.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Block.BOOKSHELF.id, this.random, this.adjustProbability(0.8F));
                addBlacksmithItem(var2, Block.GLASS.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.COMPASS.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.WATCH.id, this.random, this.adjustProbability(0.2F));

                if (this.random.nextFloat() < this.adjustProbability(0.07F))
                {
                    Enchantment var8 = Enchantment.enchantmentsBookList[this.random.nextInt(Enchantment.enchantmentsBookList.length)];
                    int var10 = MathHelper.nextInt(this.random, var8.getStartLevel(), var8.getMaxLevel());
                    ItemStack var11 = Item.ENCHANTED_BOOK.a(new EnchantmentInstance(var8, var10));
                    var6 = 2 + this.random.nextInt(5 + var10 * 10) + 3 * var10;
                    var2.add(new MerchantRecipe(new ItemStack(Item.BOOK), new ItemStack(Item.EMERALD, var6), var11));
                }

                break;

            case 2:
                addBlacksmithItem(var2, Item.EYE_OF_ENDER.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.EXP_BOTTLE.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.REDSTONE.id, this.random, this.adjustProbability(0.4F));
                addBlacksmithItem(var2, Block.GLOWSTONE.id, this.random, this.adjustProbability(0.3F));
                int[] var3 = new int[] {Item.IRON_SWORD.id, Item.DIAMOND_SWORD.id, Item.IRON_CHESTPLATE.id, Item.DIAMOND_CHESTPLATE.id, Item.IRON_AXE.id, Item.DIAMOND_AXE.id, Item.IRON_PICKAXE.id, Item.DIAMOND_PICKAXE.id};
                int[] var4 = var3;
                int var5 = var3.length;
                var6 = 0;

                while (true)
                {
                    if (var6 >= var5)
                    {
                        break label50;
                    }

                    int var7 = var4[var6];

                    if (this.random.nextFloat() < this.adjustProbability(0.05F))
                    {
                        var2.add(new MerchantRecipe(new ItemStack(var7, 1, 0), new ItemStack(Item.EMERALD, 2 + this.random.nextInt(3), 0), EnchantmentManager.a(this.random, new ItemStack(var7, 1, 0), 5 + this.random.nextInt(15))));
                    }

                    ++var6;
                }

            case 3:
                addMerchantItem(var2, Item.COAL.id, this.random, this.adjustProbability(0.7F));
                addMerchantItem(var2, Item.IRON_INGOT.id, this.random, this.adjustProbability(0.5F));
                addMerchantItem(var2, Item.GOLD_INGOT.id, this.random, this.adjustProbability(0.5F));
                addMerchantItem(var2, Item.DIAMOND.id, this.random, this.adjustProbability(0.5F));
                addBlacksmithItem(var2, Item.IRON_SWORD.id, this.random, this.adjustProbability(0.5F));
                addBlacksmithItem(var2, Item.DIAMOND_SWORD.id, this.random, this.adjustProbability(0.5F));
                addBlacksmithItem(var2, Item.IRON_AXE.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.DIAMOND_AXE.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.IRON_PICKAXE.id, this.random, this.adjustProbability(0.5F));
                addBlacksmithItem(var2, Item.DIAMOND_PICKAXE.id, this.random, this.adjustProbability(0.5F));
                addBlacksmithItem(var2, Item.IRON_SPADE.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.DIAMOND_SPADE.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.IRON_HOE.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.DIAMOND_HOE.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.IRON_BOOTS.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.DIAMOND_BOOTS.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.IRON_HELMET.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.DIAMOND_HELMET.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.IRON_CHESTPLATE.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.DIAMOND_CHESTPLATE.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.IRON_LEGGINGS.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.DIAMOND_LEGGINGS.id, this.random, this.adjustProbability(0.2F));
                addBlacksmithItem(var2, Item.CHAINMAIL_BOOTS.id, this.random, this.adjustProbability(0.1F));
                addBlacksmithItem(var2, Item.CHAINMAIL_HELMET.id, this.random, this.adjustProbability(0.1F));
                addBlacksmithItem(var2, Item.CHAINMAIL_CHESTPLATE.id, this.random, this.adjustProbability(0.1F));
                addBlacksmithItem(var2, Item.CHAINMAIL_LEGGINGS.id, this.random, this.adjustProbability(0.1F));
                break;

            case 4:
                addMerchantItem(var2, Item.COAL.id, this.random, this.adjustProbability(0.7F));
                addMerchantItem(var2, Item.PORK.id, this.random, this.adjustProbability(0.5F));
                addMerchantItem(var2, Item.RAW_BEEF.id, this.random, this.adjustProbability(0.5F));
                addBlacksmithItem(var2, Item.SADDLE.id, this.random, this.adjustProbability(0.1F));
                addBlacksmithItem(var2, Item.LEATHER_CHESTPLATE.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.LEATHER_BOOTS.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.LEATHER_HELMET.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.LEATHER_LEGGINGS.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.GRILLED_PORK.id, this.random, this.adjustProbability(0.3F));
                addBlacksmithItem(var2, Item.COOKED_BEEF.id, this.random, this.adjustProbability(0.3F));
        }

        if (var2.isEmpty())
        {
            addMerchantItem(var2, Item.GOLD_INGOT.id, this.random, 1.0F);
        }

        Collections.shuffle(var2);

        if (this.buyingList == null)
        {
            this.buyingList = new MerchantRecipeList();
        }

        for (int var9 = 0; var9 < par1 && var9 < var2.size(); ++var9)
        {
            this.buyingList.addToListWithCheck((MerchantRecipe)var2.get(var9));
        }
    }

    /**
     * each recipie takes a random stack from villagerStockList and offers it for 1 emerald
     */
    private static void addMerchantItem(MerchantRecipeList par0MerchantRecipeList, int par1, Random par2Random, float par3)
    {
        if (par2Random.nextFloat() < par3)
        {
            par0MerchantRecipeList.add(new MerchantRecipe(getRandomSizedStack(par1, par2Random), Item.EMERALD));
        }
    }

    private static ItemStack getRandomSizedStack(int par0, Random par1Random)
    {
        return new ItemStack(par0, getRandomCountForItem(par0, par1Random), 0);
    }

    /**
     * default to 1, and villagerStockList contains a min/max amount for each index
     */
    private static int getRandomCountForItem(int par0, Random par1Random)
    {
        Tuple var2 = (Tuple)villagersSellingList.get(Integer.valueOf(par0));
        return var2 == null ? 1 : (((Integer)var2.getFirst()).intValue() >= ((Integer)var2.getSecond()).intValue() ? ((Integer)var2.getFirst()).intValue() : ((Integer)var2.getFirst()).intValue() + par1Random.nextInt(((Integer)var2.getSecond()).intValue() - ((Integer)var2.getFirst()).intValue()));
    }

    private static void addBlacksmithItem(MerchantRecipeList par0MerchantRecipeList, int par1, Random par2Random, float par3)
    {
        if (par2Random.nextFloat() < par3)
        {
            int var4 = getRandomCountForBlacksmithItem(par1, par2Random);
            ItemStack var5;
            ItemStack var6;

            if (var4 < 0)
            {
                var5 = new ItemStack(Item.EMERALD.id, 1, 0);
                var6 = new ItemStack(par1, -var4, 0);
            }
            else
            {
                var5 = new ItemStack(Item.EMERALD.id, var4, 0);
                var6 = new ItemStack(par1, 1, 0);
            }

            par0MerchantRecipeList.add(new MerchantRecipe(var5, var6));
        }
    }

    private static int getRandomCountForBlacksmithItem(int par0, Random par1Random)
    {
        Tuple var2 = (Tuple)blacksmithSellingList.get(Integer.valueOf(par0));
        return var2 == null ? 1 : (((Integer)var2.getFirst()).intValue() >= ((Integer)var2.getSecond()).intValue() ? ((Integer)var2.getFirst()).intValue() : ((Integer)var2.getFirst()).intValue() + par1Random.nextInt(((Integer)var2.getSecond()).intValue() - ((Integer)var2.getFirst()).intValue()));
    }

    public GroupDataEntity a(GroupDataEntity var1)
    {
        var1 = super.a(var1);
        this.setProfession(this.world.random.nextInt(5));
        return var1;
    }

    public void func_82187_q()
    {
        this.field_82190_bM = true;
    }

    public EntityVillager func_90012_b(EntityAgeable par1EntityAgeable)
    {
        EntityVillager var2 = new EntityVillager(this.world);
        var2.a((GroupDataEntity)null);
        return var2;
    }

    public boolean allowLeashing()
    {
        return false;
    }

    public EntityAgeable createChild(EntityAgeable var1)
    {
        return this.func_90012_b(var1);
    }

    static
    {
        villagersSellingList.put(Integer.valueOf(Item.COAL.id), new Tuple(Integer.valueOf(16), Integer.valueOf(24)));
        villagersSellingList.put(Integer.valueOf(Item.IRON_INGOT.id), new Tuple(Integer.valueOf(8), Integer.valueOf(10)));
        villagersSellingList.put(Integer.valueOf(Item.GOLD_INGOT.id), new Tuple(Integer.valueOf(8), Integer.valueOf(10)));
        villagersSellingList.put(Integer.valueOf(Item.DIAMOND.id), new Tuple(Integer.valueOf(4), Integer.valueOf(6)));
        villagersSellingList.put(Integer.valueOf(Item.PAPER.id), new Tuple(Integer.valueOf(24), Integer.valueOf(36)));
        villagersSellingList.put(Integer.valueOf(Item.BOOK.id), new Tuple(Integer.valueOf(11), Integer.valueOf(13)));
        villagersSellingList.put(Integer.valueOf(Item.WRITTEN_BOOK.id), new Tuple(Integer.valueOf(1), Integer.valueOf(1)));
        villagersSellingList.put(Integer.valueOf(Item.ENDER_PEARL.id), new Tuple(Integer.valueOf(3), Integer.valueOf(4)));
        villagersSellingList.put(Integer.valueOf(Item.EYE_OF_ENDER.id), new Tuple(Integer.valueOf(2), Integer.valueOf(3)));
        villagersSellingList.put(Integer.valueOf(Item.PORK.id), new Tuple(Integer.valueOf(14), Integer.valueOf(18)));
        villagersSellingList.put(Integer.valueOf(Item.RAW_BEEF.id), new Tuple(Integer.valueOf(14), Integer.valueOf(18)));
        villagersSellingList.put(Integer.valueOf(Item.RAW_CHICKEN.id), new Tuple(Integer.valueOf(14), Integer.valueOf(18)));
        villagersSellingList.put(Integer.valueOf(Item.COOKED_FISH.id), new Tuple(Integer.valueOf(9), Integer.valueOf(13)));
        villagersSellingList.put(Integer.valueOf(Item.SEEDS.id), new Tuple(Integer.valueOf(34), Integer.valueOf(48)));
        villagersSellingList.put(Integer.valueOf(Item.MELON_SEEDS.id), new Tuple(Integer.valueOf(30), Integer.valueOf(38)));
        villagersSellingList.put(Integer.valueOf(Item.PUMPKIN_SEEDS.id), new Tuple(Integer.valueOf(30), Integer.valueOf(38)));
        villagersSellingList.put(Integer.valueOf(Item.WHEAT.id), new Tuple(Integer.valueOf(18), Integer.valueOf(22)));
        villagersSellingList.put(Integer.valueOf(Block.WOOL.id), new Tuple(Integer.valueOf(14), Integer.valueOf(22)));
        villagersSellingList.put(Integer.valueOf(Item.ROTTEN_FLESH.id), new Tuple(Integer.valueOf(36), Integer.valueOf(64)));
        blacksmithSellingList.put(Integer.valueOf(Item.FLINT_AND_STEEL.id), new Tuple(Integer.valueOf(3), Integer.valueOf(4)));
        blacksmithSellingList.put(Integer.valueOf(Item.SHEARS.id), new Tuple(Integer.valueOf(3), Integer.valueOf(4)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_SWORD.id), new Tuple(Integer.valueOf(7), Integer.valueOf(11)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_SWORD.id), new Tuple(Integer.valueOf(12), Integer.valueOf(14)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_AXE.id), new Tuple(Integer.valueOf(6), Integer.valueOf(8)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_AXE.id), new Tuple(Integer.valueOf(9), Integer.valueOf(12)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_PICKAXE.id), new Tuple(Integer.valueOf(7), Integer.valueOf(9)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_PICKAXE.id), new Tuple(Integer.valueOf(10), Integer.valueOf(12)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_SPADE.id), new Tuple(Integer.valueOf(4), Integer.valueOf(6)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_SPADE.id), new Tuple(Integer.valueOf(7), Integer.valueOf(8)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_HOE.id), new Tuple(Integer.valueOf(4), Integer.valueOf(6)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_HOE.id), new Tuple(Integer.valueOf(7), Integer.valueOf(8)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_BOOTS.id), new Tuple(Integer.valueOf(4), Integer.valueOf(6)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_BOOTS.id), new Tuple(Integer.valueOf(7), Integer.valueOf(8)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_HELMET.id), new Tuple(Integer.valueOf(4), Integer.valueOf(6)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_HELMET.id), new Tuple(Integer.valueOf(7), Integer.valueOf(8)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_CHESTPLATE.id), new Tuple(Integer.valueOf(10), Integer.valueOf(14)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_CHESTPLATE.id), new Tuple(Integer.valueOf(16), Integer.valueOf(19)));
        blacksmithSellingList.put(Integer.valueOf(Item.IRON_LEGGINGS.id), new Tuple(Integer.valueOf(8), Integer.valueOf(10)));
        blacksmithSellingList.put(Integer.valueOf(Item.DIAMOND_LEGGINGS.id), new Tuple(Integer.valueOf(11), Integer.valueOf(14)));
        blacksmithSellingList.put(Integer.valueOf(Item.CHAINMAIL_BOOTS.id), new Tuple(Integer.valueOf(5), Integer.valueOf(7)));
        blacksmithSellingList.put(Integer.valueOf(Item.CHAINMAIL_HELMET.id), new Tuple(Integer.valueOf(5), Integer.valueOf(7)));
        blacksmithSellingList.put(Integer.valueOf(Item.CHAINMAIL_CHESTPLATE.id), new Tuple(Integer.valueOf(11), Integer.valueOf(15)));
        blacksmithSellingList.put(Integer.valueOf(Item.CHAINMAIL_LEGGINGS.id), new Tuple(Integer.valueOf(9), Integer.valueOf(11)));
        blacksmithSellingList.put(Integer.valueOf(Item.BREAD.id), new Tuple(Integer.valueOf(-4), Integer.valueOf(-2)));
        blacksmithSellingList.put(Integer.valueOf(Item.MELON.id), new Tuple(Integer.valueOf(-8), Integer.valueOf(-4)));
        blacksmithSellingList.put(Integer.valueOf(Item.APPLE.id), new Tuple(Integer.valueOf(-8), Integer.valueOf(-4)));
        blacksmithSellingList.put(Integer.valueOf(Item.COOKIE.id), new Tuple(Integer.valueOf(-10), Integer.valueOf(-7)));
        blacksmithSellingList.put(Integer.valueOf(Block.GLASS.id), new Tuple(Integer.valueOf(-5), Integer.valueOf(-3)));
        blacksmithSellingList.put(Integer.valueOf(Block.BOOKSHELF.id), new Tuple(Integer.valueOf(3), Integer.valueOf(4)));
        blacksmithSellingList.put(Integer.valueOf(Item.LEATHER_CHESTPLATE.id), new Tuple(Integer.valueOf(4), Integer.valueOf(5)));
        blacksmithSellingList.put(Integer.valueOf(Item.LEATHER_BOOTS.id), new Tuple(Integer.valueOf(2), Integer.valueOf(4)));
        blacksmithSellingList.put(Integer.valueOf(Item.LEATHER_HELMET.id), new Tuple(Integer.valueOf(2), Integer.valueOf(4)));
        blacksmithSellingList.put(Integer.valueOf(Item.LEATHER_LEGGINGS.id), new Tuple(Integer.valueOf(2), Integer.valueOf(4)));
        blacksmithSellingList.put(Integer.valueOf(Item.SADDLE.id), new Tuple(Integer.valueOf(6), Integer.valueOf(8)));
        blacksmithSellingList.put(Integer.valueOf(Item.EXP_BOTTLE.id), new Tuple(Integer.valueOf(-4), Integer.valueOf(-1)));
        blacksmithSellingList.put(Integer.valueOf(Item.REDSTONE.id), new Tuple(Integer.valueOf(-4), Integer.valueOf(-1)));
        blacksmithSellingList.put(Integer.valueOf(Item.COMPASS.id), new Tuple(Integer.valueOf(10), Integer.valueOf(12)));
        blacksmithSellingList.put(Integer.valueOf(Item.WATCH.id), new Tuple(Integer.valueOf(10), Integer.valueOf(12)));
        blacksmithSellingList.put(Integer.valueOf(Block.GLOWSTONE.id), new Tuple(Integer.valueOf(-3), Integer.valueOf(-1)));
        blacksmithSellingList.put(Integer.valueOf(Item.GRILLED_PORK.id), new Tuple(Integer.valueOf(-7), Integer.valueOf(-5)));
        blacksmithSellingList.put(Integer.valueOf(Item.COOKED_BEEF.id), new Tuple(Integer.valueOf(-7), Integer.valueOf(-5)));
        blacksmithSellingList.put(Integer.valueOf(Item.COOKED_CHICKEN.id), new Tuple(Integer.valueOf(-8), Integer.valueOf(-6)));
        blacksmithSellingList.put(Integer.valueOf(Item.EYE_OF_ENDER.id), new Tuple(Integer.valueOf(7), Integer.valueOf(11)));
        blacksmithSellingList.put(Integer.valueOf(Item.ARROW.id), new Tuple(Integer.valueOf(-12), Integer.valueOf(-8)));
    }
}
