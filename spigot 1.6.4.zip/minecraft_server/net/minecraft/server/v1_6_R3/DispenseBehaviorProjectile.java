package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.util.Vector;

public abstract class DispenseBehaviorProjectile extends DispenseBehaviorItem
{
    public ItemStack b(ISourceBlock isourceblock, ItemStack itemstack)
    {
        World world = isourceblock.k();
        IPosition iposition = BlockDispenser.a(isourceblock);
        EnumFacing enumfacing = BlockDispenser.getFacing(isourceblock.h());
        IProjectile iprojectile = this.a(world, iposition);
        ItemStack itemstack1 = itemstack.splitStack(1);
        org.bukkit.block.Block block = world.getWorld().getBlockAt(isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ());
        CraftItemStack craftItem = CraftItemStack.asCraftMirror(itemstack1);
        BlockDispenseEvent event = new BlockDispenseEvent(block, craftItem.clone(), new Vector((double)enumfacing.getFrontOffsetX(), (double)((float)enumfacing.getFrontOffsetY() + 0.1F), (double)enumfacing.getFrontOffsetZ()));

        if (!BlockDispenser.eventFired)
        {
            world.getServer().getPluginManager().callEvent(event);
        }

        if (event.isCancelled())
        {
            ++itemstack.count;
            return itemstack;
        }
        else
        {
            if (!event.getItem().equals(craftItem))
            {
                ++itemstack.count;
                ItemStack eventStack = CraftItemStack.asNMSCopy(event.getItem());
                IDispenseBehavior idispensebehavior = (IDispenseBehavior)BlockDispenser.dispenseBehaviorRegistry.getObject(eventStack.getItem());

                if (idispensebehavior != IDispenseBehavior.a && idispensebehavior != this)
                {
                    idispensebehavior.a(isourceblock, eventStack);
                    return itemstack;
                }
            }

            iprojectile.shoot(event.getVelocity().getX(), event.getVelocity().getY(), event.getVelocity().getZ(), this.b(), this.a());
            world.addEntity((Entity)iprojectile);
            return itemstack;
        }
    }

    protected void a(ISourceBlock isourceblock)
    {
        isourceblock.k().triggerEffect(1002, isourceblock.getBlockX(), isourceblock.getBlockY(), isourceblock.getBlockZ(), 0);
    }

    protected abstract IProjectile a(World var1, IPosition var2);

    protected float a()
    {
        return 6.0F;
    }

    protected float b()
    {
        return 1.1F;
    }
}
