package net.minecraft.server.v1_6_R3;

public class BlockStoneButton extends BlockButtonAbstract
{
    protected BlockStoneButton(int var1)
    {
        super(var1, false);
    }
}
