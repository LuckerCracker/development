package net.minecraft.server.v1_6_R3;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class DedicatedServerConnectionThread extends Thread
{
    private final List a = Collections.synchronizedList(new ArrayList());
    private final HashMap b = new HashMap();
    private int c;
    private final ServerSocket d;
    private ServerConnection e;
    private final InetAddress f;
    private final int g;
    long connectionThrottle;

    public DedicatedServerConnectionThread(ServerConnection serverconnection, InetAddress inetaddress, int i) throws IOException
    {
        super("Listen thread");
        this.e = serverconnection;
        this.g = i;
        this.d = new ServerSocket(i, 0, inetaddress);
        this.f = inetaddress == null ? this.d.getInetAddress() : inetaddress;
        this.d.setPerformancePreferences(0, 2, 1);
    }

    public void a()
    {
        List list = this.a;
        List var2 = this.a;

        synchronized (this.a)
        {
            for (int i = 0; i < this.a.size(); ++i)
            {
                PendingConnection pendingconnection = (PendingConnection)this.a.get(i);

                try
                {
                    pendingconnection.d();
                }
                catch (Exception var7)
                {
                    pendingconnection.disconnect("Internal server error");
                    this.e.d().getLogger().warning("Failed to handle packet for " + pendingconnection.getName() + ": " + var7, (Throwable)var7);
                }

                if (pendingconnection.b)
                {
                    this.a.remove(i--);
                }

                pendingconnection.networkManager.wakeThreads();
            }
        }
    }

    public void run()
    {
        while (this.e.a)
        {
            try
            {
                Socket ioexception = this.d.accept();
                InetAddress address = ioexception.getInetAddress();
                long currentTime = System.currentTimeMillis();

                if (this.e.d().server == null)
                {
                    ioexception.close();
                }
                else
                {
                    this.connectionThrottle = this.e.d().server.getConnectionThrottle();
                    HashMap pendingconnection = this.b;

                    synchronized (this.b)
                    {
                        if (this.b.containsKey(address) && !"127.0.0.1".equals(address.getHostAddress()) && currentTime - ((Long)this.b.get(address)).longValue() < this.connectionThrottle)
                        {
                            this.b.put(address, Long.valueOf(currentTime));
                            ioexception.close();
                            continue;
                        }

                        this.b.put(address, Long.valueOf(currentTime));
                    }

                    PendingConnection pendingconnection1 = new PendingConnection(this.e.d(), ioexception, "Connection #" + this.c++);
                    this.a(pendingconnection1);
                }
            }
            catch (IOException var8)
            {
                this.e.d().getLogger().warning("DSCT: " + var8.getMessage());
            }
        }

        this.e.d().getLogger().info("Closing listening thread");
    }

    private void a(PendingConnection pendingconnection)
    {
        if (pendingconnection == null)
        {
            throw new IllegalArgumentException("Got null pendingconnection!");
        }
        else
        {
            List list = this.a;
            List var3 = this.a;

            synchronized (this.a)
            {
                this.a.add(pendingconnection);
            }
        }
    }

    public void a(InetAddress inetaddress)
    {
        if (inetaddress != null)
        {
            HashMap hashmap = this.b;
            HashMap var3 = this.b;

            synchronized (this.b)
            {
                this.b.remove(inetaddress);
            }
        }
    }

    public void b()
    {
        try
        {
            this.d.close();
        }
        catch (Throwable var2)
        {
            ;
        }
    }
}
