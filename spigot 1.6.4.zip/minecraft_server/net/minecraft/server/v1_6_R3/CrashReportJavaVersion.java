package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportJavaVersion implements Callable
{
    final CrashReport a;

    CrashReportJavaVersion(CrashReport var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return System.getProperty("java.version") + ", " + System.getProperty("java.vendor");
    }

    public Object call()
    {
        return this.a();
    }
}
