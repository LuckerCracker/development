package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandMe extends CommandAbstract
{
    public String getCommandName()
    {
        return "me";
    }

    public int a()
    {
        return 0;
    }

    public String c(ICommandListener var1)
    {
        return "commands.me.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length > 0)
        {
            String var3 = a(var1, var2, 0, var1.a(1, "me"));
            MinecraftServer.getServer().getPlayerList().sendMessage(ChatMessage.b("chat.type.emote", new Object[] {var1.getName(), var3}));
        }
        else
        {
            throw new ExceptionUsage("commands.me.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return a(var2, MinecraftServer.getServer().getPlayers());
    }
}
