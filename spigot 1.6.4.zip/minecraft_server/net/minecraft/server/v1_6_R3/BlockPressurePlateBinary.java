package net.minecraft.server.v1_6_R3;

import java.util.Iterator;
import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.event.Cancellable;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityInteractEvent;
import org.bukkit.plugin.PluginManager;

public class BlockPressurePlateBinary extends BlockPressurePlateAbstract {
	/**
	 * used as foreach item, if item.tab = current tab, display it on the screen
	 */
	private EnumMobType displayOnCreativeTab;

	protected BlockPressurePlateBinary(int i, String s, Material material, EnumMobType enummobtype) {
		super(i, s, material);
		this.displayOnCreativeTab = enummobtype;
	}

	protected int getMetaFromWeight(int i) {
		return i > 0 ? 1 : 0;
	}

	protected int getPowerSupply(int i) {
		return i == 1 ? 15 : 0;
	}

	protected int getPlateState(World world, int i, int j, int k) {
		List list = null;

		if (this.displayOnCreativeTab == EnumMobType.EVERYTHING) {
			list = world.getEntities((Entity) null, this.a(i, j, k));
		}

		if (this.displayOnCreativeTab == EnumMobType.MOBS) {
			list = world.getEntitiesWithinAABB(EntityLiving.class, this.a(i, j, k));
		}

		if (this.displayOnCreativeTab == EnumMobType.PLAYERS) {
			list = world.getEntitiesWithinAABB(EntityHuman.class, this.a(i, j, k));
		}

		if (list != null && !list.isEmpty()) {
			Iterator iterator = list.iterator();

			while (iterator.hasNext()) {
				Entity entity = (Entity) iterator.next();

				if (this.getPowerSupply(world.getData(i, j, k)) == 0) {
					CraftWorld bworld = world.getWorld();
					PluginManager manager = world.getServer().getPluginManager();
					Object cancellable;

					if (entity instanceof EntityHuman) {
						cancellable = CraftEventFactory.callPlayerInteractEvent((EntityHuman) entity, Action.PHYSICAL,
								i, j, k, -1, (ItemStack) null);
					} else {
						cancellable = new EntityInteractEvent(entity.getBukkitEntity(), bworld.getBlockAt(i, j, k));
						manager.callEvent((EntityInteractEvent) cancellable);
					}

					if (((Cancellable) cancellable).isCancelled()) {
						continue;
					}
				}

				if (!entity.doesEntityNotTriggerPressurePlate()) {
					return 15;
				}
			}
		}

		return 0;
	}
}
