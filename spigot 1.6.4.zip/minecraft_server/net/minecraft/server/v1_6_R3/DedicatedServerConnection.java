package net.minecraft.server.v1_6_R3;

import java.io.IOException;
import java.net.InetAddress;

public class DedicatedServerConnection extends ServerConnection
{
    private final DedicatedServerConnectionThread b;

    public DedicatedServerConnection(MinecraftServer var1, InetAddress var2, int var3) throws IOException
    {
        super(var1);
        this.b = new DedicatedServerConnectionThread(this, var2, var3);
        this.b.start();
    }

    public void a()
    {
        super.a();
        this.b.b();
        this.b.interrupt();
    }

    public void b()
    {
        this.b.a();
        super.b();
    }

    public DedicatedServer c()
    {
        return (DedicatedServer)super.d();
    }

    public void a(InetAddress var1)
    {
        this.b.a(var1);
    }

    public MinecraftServer d()
    {
        return this.c();
    }
}
