package net.minecraft.server.v1_6_R3;

public class EntityEnderSignal extends Entity
{
    private double a;
    private double nextEntityID;

    /**
     * The distance that has to be exceeded in order to triger a new step sound and an onEntityWalking event on a block
     */
    private double nextStepDistance;
    private int fire;
    private boolean firstUpdate;

    public EntityEnderSignal(World var1)
    {
        super(var1);
        this.setSize(0.25F, 0.25F);
    }

    protected void entityInit() {}

    public EntityEnderSignal(World var1, double var2, double var4, double var6)
    {
        super(var1);
        this.fire = 0;
        this.setSize(0.25F, 0.25F);
        this.setPosition(var2, var4, var6);
        this.height = 0.0F;
    }

    public void a(double var1, int var3, double var4)
    {
        double var6 = var1 - this.locX;
        double var8 = var4 - this.locZ;
        float var10 = MathHelper.sqrt(var6 * var6 + var8 * var8);

        if (var10 > 12.0F)
        {
            this.a = this.locX + var6 / (double)var10 * 12.0D;
            this.nextStepDistance = this.locZ + var8 / (double)var10 * 12.0D;
            this.nextEntityID = this.locY + 8.0D;
        }
        else
        {
            this.a = var1;
            this.nextEntityID = (double)var3;
            this.nextStepDistance = var4;
        }

        this.fire = 0;
        this.firstUpdate = this.random.nextInt(5) > 0;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        this.lastTickPosX = this.locX;
        this.lastTickPosY = this.locY;
        this.lastTickPosZ = this.locZ;
        super.onUpdate();
        this.locX += this.motX;
        this.locY += this.motY;
        this.locZ += this.motZ;
        float var1 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
        this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);

        for (this.pitch = (float)(Math.atan2(this.motY, (double)var1) * 180.0D / Math.PI); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
        {
            ;
        }

        while (this.pitch - this.lastPitch >= 180.0F)
        {
            this.lastPitch += 360.0F;
        }

        while (this.yaw - this.lastYaw < -180.0F)
        {
            this.lastYaw -= 360.0F;
        }

        while (this.yaw - this.lastYaw >= 180.0F)
        {
            this.lastYaw += 360.0F;
        }

        this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
        this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;

        if (!this.world.isStatic)
        {
            double var2 = this.a - this.locX;
            double var4 = this.nextStepDistance - this.locZ;
            float var6 = (float)Math.sqrt(var2 * var2 + var4 * var4);
            float var7 = (float)Math.atan2(var4, var2);
            double var8 = (double)var1 + (double)(var6 - var1) * 0.0025D;

            if (var6 < 1.0F)
            {
                var8 *= 0.8D;
                this.motY *= 0.8D;
            }

            this.motX = Math.cos((double)var7) * var8;
            this.motZ = Math.sin((double)var7) * var8;

            if (this.locY < this.nextEntityID)
            {
                this.motY += (1.0D - this.motY) * 0.014999999664723873D;
            }
            else
            {
                this.motY += (-1.0D - this.motY) * 0.014999999664723873D;
            }
        }

        float var10 = 0.25F;

        if (this.isInWater())
        {
            for (int var11 = 0; var11 < 4; ++var11)
            {
                this.world.addParticle("bubble", this.locX - this.motX * (double)var10, this.locY - this.motY * (double)var10, this.locZ - this.motZ * (double)var10, this.motX, this.motY, this.motZ);
            }
        }
        else
        {
            this.world.addParticle("portal", this.locX - this.motX * (double)var10 + this.random.nextDouble() * 0.6D - 0.3D, this.locY - this.motY * (double)var10 - 0.5D, this.locZ - this.motZ * (double)var10 + this.random.nextDouble() * 0.6D - 0.3D, this.motX, this.motY, this.motZ);
        }

        if (!this.world.isStatic)
        {
            this.setPosition(this.locX, this.locY, this.locZ);
            ++this.fire;

            if (this.fire > 80 && !this.world.isStatic)
            {
                this.die();

                if (this.firstUpdate)
                {
                    this.world.addEntity(new EntityItem(this.world, this.locX, this.locY, this.locZ, new ItemStack(Item.EYE_OF_ENDER)));
                }
                else
                {
                    this.world.triggerEffect(2003, (int)Math.round(this.locX), (int)Math.round(this.locY), (int)Math.round(this.locZ), 0);
                }
            }
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound var1) {}

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound var1) {}

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float var1)
    {
        return 1.0F;
    }

    /**
     * If returns false, the item will not inflict any damage against entities.
     */
    public boolean canAttackWithItem()
    {
        return false;
    }
}
