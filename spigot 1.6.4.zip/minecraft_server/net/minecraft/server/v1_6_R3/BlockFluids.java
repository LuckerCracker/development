package net.minecraft.server.v1_6_R3;

import java.util.Random;

public abstract class BlockFluids extends Block
{
    protected BlockFluids(int var1, Material var2)
    {
        super(var1, var2);
        float var3 = 0.0F;
        float var4 = 0.0F;
        this.setBlockBounds(0.0F + var4, 0.0F + var3, 0.0F + var4, 1.0F + var4, 1.0F + var3, 1.0F + var4);
        this.setTickRandomly(true);
    }

    public boolean getBlocksMovement(IBlockAccess var1, int var2, int var3, int var4)
    {
        return this.material != Material.LAVA;
    }

    public static float d(int var0)
    {
        if (var0 >= 8)
        {
            var0 = 0;
        }

        return (float)(var0 + 1) / 9.0F;
    }

    protected int l_(World var1, int var2, int var3, int var4)
    {
        return var1.getMaterial(var2, var3, var4) == this.material ? var1.getData(var2, var3, var4) : -1;
    }

    protected int d(IBlockAccess var1, int var2, int var3, int var4)
    {
        if (var1.getMaterial(var2, var3, var4) != this.material)
        {
            return -1;
        }
        else
        {
            int var5 = var1.getData(var2, var3, var4);

            if (var5 >= 8)
            {
                var5 = 0;
            }

            return var5;
        }
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * Returns whether this block is collideable based on the arguments passed in Args: blockMetaData, unknownFlag
     */
    public boolean canCollideCheck(int var1, boolean var2)
    {
        return var2 && var1 == 0;
    }

    /**
     * Returns Returns true if the given side of this block type should be rendered (if it's solid or not), if the
     * adjacent block is at the given coordinates. Args: blockAccess, x, y, z, side
     */
    public boolean isBlockSolid(IBlockAccess var1, int var2, int var3, int var4, int var5)
    {
        Material var6 = var1.getMaterial(var2, var3, var4);
        return var6 == this.material ? false : (var5 == 1 ? true : (var6 == Material.ICE ? false : super.isBlockSolid(var1, var2, var3, var4, var5)));
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World var1, int var2, int var3, int var4)
    {
        return null;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 4;
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return 0;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random var1)
    {
        return 0;
    }

    private Vec3D g(IBlockAccess var1, int var2, int var3, int var4)
    {
        Vec3D var5 = var1.getVec3DPool().create(0.0D, 0.0D, 0.0D);
        int var6 = this.d(var1, var2, var3, var4);

        for (int var7 = 0; var7 < 4; ++var7)
        {
            int var8 = var2;
            int var10 = var4;

            if (var7 == 0)
            {
                var8 = var2 - 1;
            }

            if (var7 == 1)
            {
                var10 = var4 - 1;
            }

            if (var7 == 2)
            {
                ++var8;
            }

            if (var7 == 3)
            {
                ++var10;
            }

            int var11 = this.d(var1, var8, var3, var10);
            int var12;

            if (var11 < 0)
            {
                if (!var1.getMaterial(var8, var3, var10).isSolid())
                {
                    var11 = this.d(var1, var8, var3 - 1, var10);

                    if (var11 >= 0)
                    {
                        var12 = var11 - (var6 - 8);
                        var5 = var5.add((double)((var8 - var2) * var12), (double)((var3 - var3) * var12), (double)((var10 - var4) * var12));
                    }
                }
            }
            else if (var11 >= 0)
            {
                var12 = var11 - var6;
                var5 = var5.add((double)((var8 - var2) * var12), (double)((var3 - var3) * var12), (double)((var10 - var4) * var12));
            }
        }

        if (var1.getData(var2, var3, var4) >= 8)
        {
            boolean var13 = false;

            if (var13 || this.isBlockSolid(var1, var2, var3, var4 - 1, 2))
            {
                var13 = true;
            }

            if (var13 || this.isBlockSolid(var1, var2, var3, var4 + 1, 3))
            {
                var13 = true;
            }

            if (var13 || this.isBlockSolid(var1, var2 - 1, var3, var4, 4))
            {
                var13 = true;
            }

            if (var13 || this.isBlockSolid(var1, var2 + 1, var3, var4, 5))
            {
                var13 = true;
            }

            if (var13 || this.isBlockSolid(var1, var2, var3 + 1, var4 - 1, 2))
            {
                var13 = true;
            }

            if (var13 || this.isBlockSolid(var1, var2, var3 + 1, var4 + 1, 3))
            {
                var13 = true;
            }

            if (var13 || this.isBlockSolid(var1, var2 - 1, var3 + 1, var4, 4))
            {
                var13 = true;
            }

            if (var13 || this.isBlockSolid(var1, var2 + 1, var3 + 1, var4, 5))
            {
                var13 = true;
            }

            if (var13)
            {
                var5 = var5.a().add(0.0D, -6.0D, 0.0D);
            }
        }

        var5 = var5.a();
        return var5;
    }

    public void a(World var1, int var2, int var3, int var4, Entity var5, Vec3D var6)
    {
        Vec3D var7 = this.g(var1, var2, var3, var4);
        var6.c += var7.c;
        var6.d += var7.d;
        var6.e += var7.e;
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World var1)
    {
        return this.material == Material.WATER ? 5 : (this.material == Material.LAVA ? (var1.worldProvider.hasNoSky ? 10 : 30) : 0);
    }

    public void onPlace(World var1, int var2, int var3, int var4)
    {
        this.k(var1, var2, var3, var4);
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        this.k(var1, var2, var3, var4);
    }

    private void k(World var1, int var2, int var3, int var4)
    {
        if (var1.getTypeId(var2, var3, var4) == this.id)
        {
            if (this.material == Material.LAVA)
            {
                boolean var5 = false;

                if (var5 || var1.getMaterial(var2, var3, var4 - 1) == Material.WATER)
                {
                    var5 = true;
                }

                if (var5 || var1.getMaterial(var2, var3, var4 + 1) == Material.WATER)
                {
                    var5 = true;
                }

                if (var5 || var1.getMaterial(var2 - 1, var3, var4) == Material.WATER)
                {
                    var5 = true;
                }

                if (var5 || var1.getMaterial(var2 + 1, var3, var4) == Material.WATER)
                {
                    var5 = true;
                }

                if (var5 || var1.getMaterial(var2, var3 + 1, var4) == Material.WATER)
                {
                    var5 = true;
                }

                if (var5)
                {
                    int var6 = var1.getData(var2, var3, var4);

                    if (var6 == 0)
                    {
                        var1.setTypeIdUpdate(var2, var3, var4, Block.OBSIDIAN.id);
                    }
                    else if (var6 <= 4)
                    {
                        var1.setTypeIdUpdate(var2, var3, var4, Block.COBBLESTONE.id);
                    }

                    this.fizz(var1, var2, var3, var4);
                }
            }
        }
    }

    protected void fizz(World var1, int var2, int var3, int var4)
    {
        var1.makeSound((double)((float)var2 + 0.5F), (double)((float)var3 + 0.5F), (double)((float)var4 + 0.5F), "random.fizz", 0.5F, 2.6F + (var1.random.nextFloat() - var1.random.nextFloat()) * 0.8F);

        for (int var5 = 0; var5 < 8; ++var5)
        {
            var1.addParticle("largesmoke", (double)var2 + Math.random(), (double)var3 + 1.2D, (double)var4 + Math.random(), 0.0D, 0.0D, 0.0D);
        }
    }
}
