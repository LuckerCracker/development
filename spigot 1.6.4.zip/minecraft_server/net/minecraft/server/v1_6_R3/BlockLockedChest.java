package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockLockedChest extends Block
{
    protected BlockLockedChest(int par1)
    {
        super(par1, Material.WOOD);
    }

    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        return true;
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        par1World.setAir(par2, par3, par4);
    }
}
