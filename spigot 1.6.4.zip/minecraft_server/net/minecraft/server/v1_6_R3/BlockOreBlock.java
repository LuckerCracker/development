package net.minecraft.server.v1_6_R3;

public class BlockOreBlock extends Block
{
    public BlockOreBlock(int var1)
    {
        super(var1, Material.ORE);
        this.a(CreativeModeTab.b);
    }
}
