package net.minecraft.server.v1_6_R3;

public class BlockWood extends Block
{
    /** The type of tree this block came from. */
    public static final String[] woodType = new String[] {"oak", "spruce", "birch", "jungle"};

    public BlockWood(int par1)
    {
        super(par1, Material.WOOD);
        this.a(CreativeModeTab.b);
    }

    public int getDropData(int var1)
    {
        return var1;
    }
}
