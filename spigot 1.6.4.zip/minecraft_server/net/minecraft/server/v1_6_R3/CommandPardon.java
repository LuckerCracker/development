package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandPardon extends CommandAbstract
{
    public String getCommandName()
    {
        return "pardon";
    }

    public int a()
    {
        return 3;
    }

    public String c(ICommandListener var1)
    {
        return "commands.unban.usage";
    }

    public boolean a(ICommandListener var1)
    {
        return MinecraftServer.getServer().getPlayerList().getNameBans().isEnabled() && super.a(var1);
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length == 1 && var2[0].length() > 0)
        {
            MinecraftServer.getServer().getPlayerList().getNameBans().remove(var2[0]);
            a(var1, "commands.unban.success", new Object[] {var2[0]});
        }
        else
        {
            throw new ExceptionUsage("commands.unban.usage", new Object[0]);
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, MinecraftServer.getServer().getPlayerList().getNameBans().getEntries().keySet()) : null;
    }
}
