package net.minecraft.server.v1_6_R3;

import java.util.Calendar;

public class EntityBat extends EntityAmbient
{
    /** Coordinates of where the bat spawned. */
    private ChunkCoordinates spawnPosition;

    public EntityBat(World par1World)
    {
        super(par1World);
        this.setSize(0.5F, 0.9F);
        this.setIsBatHanging(true);
    }

    protected void entityInit()
    {
        super.entityInit();
        this.datawatcher.addObject(16, new Byte((byte)0));
    }

    /**
     * Returns the volume for the sounds this mob makes.
     */
    protected float getSoundVolume()
    {
        return 0.1F;
    }

    /**
     * Gets the pitch of living sounds in living entities.
     */
    protected float getSoundPitch()
    {
        return super.getSoundPitch() * 0.95F;
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return this.getIsBatHanging() && this.random.nextInt(4) != 0 ? null : "mob.bat.idle";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.bat.hurt";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.bat.death";
    }

    /**
     * Returns true if this entity should push and be pushed by other entities when colliding.
     */
    public boolean canBePushed()
    {
        return false;
    }

    protected void collideWithEntity(Entity par1Entity) {}

    protected void collideWithNearbyEntities() {}

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.a).setValue(6.0D);
    }

    public boolean getIsBatHanging()
    {
        return (this.datawatcher.getByte(16) & 1) != 0;
    }

    public void setIsBatHanging(boolean par1)
    {
        byte var2 = this.datawatcher.getByte(16);

        if (par1)
        {
            this.datawatcher.watch(16, Byte.valueOf((byte)(var2 | 1)));
        }
        else
        {
            this.datawatcher.watch(16, Byte.valueOf((byte)(var2 & -2)));
        }
    }

    /**
     * Returns true if the newer Entity AI code should be run
     */
    protected boolean isAIEnabled()
    {
        return true;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (this.getIsBatHanging())
        {
            this.motX = this.motY = this.motZ = 0.0D;
            this.locY = (double)MathHelper.floor(this.locY) + 1.0D - (double)this.length;
        }
        else
        {
            this.motY *= 0.6000000238418579D;
        }
    }

    protected void updateAITasks()
    {
        super.updateAITasks();

        if (this.getIsBatHanging())
        {
            if (!this.world.isBlockNormalCube(MathHelper.floor(this.locX), (int)this.locY + 1, MathHelper.floor(this.locZ)))
            {
                this.setIsBatHanging(false);
                this.world.a((EntityHuman)null, 1015, (int)this.locX, (int)this.locY, (int)this.locZ, 0);
            }
            else
            {
                if (this.random.nextInt(200) == 0)
                {
                    this.rotationYawHead = (float)this.random.nextInt(360);
                }

                if (this.world.findNearbyPlayer(this, 4.0D) != null)
                {
                    this.setIsBatHanging(false);
                    this.world.a((EntityHuman)null, 1015, (int)this.locX, (int)this.locY, (int)this.locZ, 0);
                }
            }
        }
        else
        {
            if (this.spawnPosition != null && (!this.world.isEmpty(this.spawnPosition.x, this.spawnPosition.y, this.spawnPosition.z) || this.spawnPosition.y < 1))
            {
                this.spawnPosition = null;
            }

            if (this.spawnPosition == null || this.random.nextInt(30) == 0 || this.spawnPosition.getDistanceSquared((int)this.locX, (int)this.locY, (int)this.locZ) < 4.0F)
            {
                this.spawnPosition = new ChunkCoordinates((int)this.locX + this.random.nextInt(7) - this.random.nextInt(7), (int)this.locY + this.random.nextInt(6) - 2, (int)this.locZ + this.random.nextInt(7) - this.random.nextInt(7));
            }

            double var1 = (double)this.spawnPosition.x + 0.5D - this.locX;
            double var3 = (double)this.spawnPosition.y + 0.1D - this.locY;
            double var5 = (double)this.spawnPosition.z + 0.5D - this.locZ;
            this.motX += (Math.signum(var1) * 0.5D - this.motX) * 0.10000000149011612D;
            this.motY += (Math.signum(var3) * 0.699999988079071D - this.motY) * 0.10000000149011612D;
            this.motZ += (Math.signum(var5) * 0.5D - this.motZ) * 0.10000000149011612D;
            float var7 = (float)(Math.atan2(this.motZ, this.motX) * 180.0D / Math.PI) - 90.0F;
            float var8 = MathHelper.wrapAngleTo180_float(var7 - this.yaw);
            this.moveForward = 0.5F;
            this.yaw += var8;

            if (this.random.nextInt(100) == 0 && this.world.isBlockNormalCube(MathHelper.floor(this.locX), (int)this.locY + 1, MathHelper.floor(this.locZ)))
            {
                this.setIsBatHanging(true);
            }
        }
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    /**
     * Called when the mob is falling. Calculates and applies fall damage.
     */
    protected void fall(float par1) {}

    /**
     * Takes in the distance the entity has fallen this tick and whether its on the ground to update the fall distance
     * and deal fall damage if landing on the ground.  Args: distanceFallenThisTick, onGround
     */
    protected void updateFallState(double par1, boolean par3) {}

    /**
     * Return whether this entity should NOT trigger a pressure plate or a tripwire.
     */
    public boolean doesEntityNotTriggerPressurePlate()
    {
        return true;
    }

    public boolean attackEntityFrom(DamageSource var1, float var2)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else
        {
            if (!this.world.isStatic && this.getIsBatHanging())
            {
                this.setIsBatHanging(false);
            }

            return super.attackEntityFrom(var1, var2);
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);
        this.datawatcher.watch(16, Byte.valueOf(par1NBTTagCompound.getByte("BatFlags")));
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);
        par1NBTTagCompound.setByte("BatFlags", this.datawatcher.getByte(16));
    }

    public boolean canSpawn()
    {
        int var1 = MathHelper.floor(this.boundingBox.minY);

        if (var1 >= 63)
        {
            return false;
        }
        else
        {
            int var2 = MathHelper.floor(this.locX);
            int var3 = MathHelper.floor(this.locZ);
            int var4 = this.world.getLightLevel(var2, var1, var3);
            byte var5 = 4;
            Calendar var6 = this.world.getCurrentDate();

            if ((var6.get(2) + 1 != 10 || var6.get(5) < 20) && (var6.get(2) + 1 != 11 || var6.get(5) > 3))
            {
                if (this.random.nextBoolean())
                {
                    return false;
                }
            }
            else
            {
                var5 = 7;
            }

            return var4 > this.random.nextInt(var5) ? false : super.canSpawn();
        }
    }
}
