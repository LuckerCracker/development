package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportVersion implements Callable
{
    final CrashReport a;

    CrashReportVersion(CrashReport var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return "1.6.4";
    }

    public Object call()
    {
        return this.a();
    }
}
