package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockLadder extends Block
{
    protected BlockLadder(int par1)
    {
        super(par1, Material.ORIENTABLE);
        this.a(CreativeModeTab.c);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB getCollisionBoundingBoxFromPool(World par1World, int par2, int par3, int par4)
    {
        this.updateShape(par1World, par2, par3, par4);
        return super.getCollisionBoundingBoxFromPool(par1World, par2, par3, par4);
    }

    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        this.updateLadderBounds(var1.getData(var2, var3, var4));
    }

    /**
     * Update the ladder block bounds based on the given metadata value.
     */
    public void updateLadderBounds(int par1)
    {
        float var3 = 0.125F;

        if (par1 == 2)
        {
            this.setBlockBounds(0.0F, 0.0F, 1.0F - var3, 1.0F, 1.0F, 1.0F);
        }

        if (par1 == 3)
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var3);
        }

        if (par1 == 4)
        {
            this.setBlockBounds(1.0F - var3, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }

        if (par1 == 5)
        {
            this.setBlockBounds(0.0F, 0.0F, 0.0F, var3, 1.0F, 1.0F);
        }
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 8;
    }

    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        return var1.isBlockNormalCube(var2 - 1, var3, var4) ? true : (var1.isBlockNormalCube(var2 + 1, var3, var4) ? true : (var1.isBlockNormalCube(var2, var3, var4 - 1) ? true : var1.isBlockNormalCube(var2, var3, var4 + 1)));
    }

    public int getPlacedData(World var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, int var9)
    {
        int var10 = var9;

        if ((var9 == 0 || var5 == 2) && var1.isBlockNormalCube(var2, var3, var4 + 1))
        {
            var10 = 2;
        }

        if ((var10 == 0 || var5 == 3) && var1.isBlockNormalCube(var2, var3, var4 - 1))
        {
            var10 = 3;
        }

        if ((var10 == 0 || var5 == 4) && var1.isBlockNormalCube(var2 + 1, var3, var4))
        {
            var10 = 4;
        }

        if ((var10 == 0 || var5 == 5) && var1.isBlockNormalCube(var2 - 1, var3, var4))
        {
            var10 = 5;
        }

        return var10;
    }

    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        int var6 = var1.getData(var2, var3, var4);
        boolean var7 = false;

        if (var6 == 2 && var1.isBlockNormalCube(var2, var3, var4 + 1))
        {
            var7 = true;
        }

        if (var6 == 3 && var1.isBlockNormalCube(var2, var3, var4 - 1))
        {
            var7 = true;
        }

        if (var6 == 4 && var1.isBlockNormalCube(var2 + 1, var3, var4))
        {
            var7 = true;
        }

        if (var6 == 5 && var1.isBlockNormalCube(var2 - 1, var3, var4))
        {
            var7 = true;
        }

        if (!var7)
        {
            this.dropBlockAsItem(var1, var2, var3, var4, var6, 0);
            var1.setAir(var2, var3, var4);
        }

        super.doPhysics(var1, var2, var3, var4, var5);
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random par1Random)
    {
        return 1;
    }
}
