package net.minecraft.server.v1_6_R3;

import com.google.common.primitives.Doubles;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public abstract class CommandAbstract implements ICommand
{
    private static ICommandDispatcher a;

    public int a()
    {
        return 4;
    }

    public List getCommandAliases()
    {
        return null;
    }

    public boolean a(ICommandListener var1)
    {
        return var1.a(this.a(), this.getCommandName());
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return null;
    }

    public static int a(ICommandListener var0, String var1)
    {
        try
        {
            return Integer.parseInt(var1);
        }
        catch (NumberFormatException var3)
        {
            throw new ExceptionInvalidNumber("commands.generic.num.invalid", new Object[] {var1});
        }
    }

    public static int a(ICommandListener var0, String var1, int var2)
    {
        return a(var0, var1, var2, Integer.MAX_VALUE);
    }

    public static int a(ICommandListener var0, String var1, int var2, int var3)
    {
        int var4 = a(var0, var1);

        if (var4 < var2)
        {
            throw new ExceptionInvalidNumber("commands.generic.num.tooSmall", new Object[] {Integer.valueOf(var4), Integer.valueOf(var2)});
        }
        else if (var4 > var3)
        {
            throw new ExceptionInvalidNumber("commands.generic.num.tooBig", new Object[] {Integer.valueOf(var4), Integer.valueOf(var3)});
        }
        else
        {
            return var4;
        }
    }

    public static double b(ICommandListener var0, String var1)
    {
        try
        {
            double var2 = Double.parseDouble(var1);

            if (!Doubles.isFinite(var2))
            {
                throw new ExceptionInvalidNumber("commands.generic.double.invalid", new Object[] {var1});
            }
            else
            {
                return var2;
            }
        }
        catch (NumberFormatException var5)
        {
            throw new ExceptionInvalidNumber("commands.generic.double.invalid", new Object[] {var1});
        }
    }

    public static double a(ICommandListener var0, String var1, double var2)
    {
        return a(var0, var1, var2, Double.MAX_VALUE);
    }

    public static double a(ICommandListener var0, String var1, double var2, double var4)
    {
        double var6 = b(var0, var1);

        if (var6 < var2)
        {
            throw new ExceptionInvalidNumber("commands.generic.double.tooSmall", new Object[] {Double.valueOf(var6), Double.valueOf(var2)});
        }
        else if (var6 > var4)
        {
            throw new ExceptionInvalidNumber("commands.generic.double.tooBig", new Object[] {Double.valueOf(var6), Double.valueOf(var4)});
        }
        else
        {
            return var6;
        }
    }

    public static boolean c(ICommandListener var0, String var1)
    {
        if (!var1.equals("true") && !var1.equals("1"))
        {
            if (!var1.equals("false") && !var1.equals("0"))
            {
                throw new CommandException("commands.generic.boolean.invalid", new Object[] {var1});
            }
            else
            {
                return false;
            }
        }
        else
        {
            return true;
        }
    }

    public static EntityPlayer b(ICommandListener var0)
    {
        if (var0 instanceof EntityPlayer)
        {
            return (EntityPlayer)var0;
        }
        else
        {
            throw new ExceptionPlayerNotFound("You must specify which player you wish to perform this action on.", new Object[0]);
        }
    }

    public static EntityPlayer d(ICommandListener var0, String var1)
    {
        EntityPlayer var2 = PlayerSelector.getPlayer(var0, var1);

        if (var2 != null)
        {
            return var2;
        }
        else
        {
            var2 = MinecraftServer.getServer().getPlayerList().getPlayer(var1);

            if (var2 == null)
            {
                throw new ExceptionPlayerNotFound();
            }
            else
            {
                return var2;
            }
        }
    }

    public static String e(ICommandListener var0, String var1)
    {
        EntityPlayer var2 = PlayerSelector.getPlayer(var0, var1);

        if (var2 != null)
        {
            return var2.getLocalizedName();
        }
        else if (PlayerSelector.isPattern(var1))
        {
            throw new ExceptionPlayerNotFound();
        }
        else
        {
            return var1;
        }
    }

    public static String a(ICommandListener var0, String[] var1, int var2)
    {
        return a(var0, var1, var2, false);
    }

    public static String a(ICommandListener var0, String[] var1, int var2, boolean var3)
    {
        StringBuilder var4 = new StringBuilder();

        for (int var5 = var2; var5 < var1.length; ++var5)
        {
            if (var5 > var2)
            {
                var4.append(" ");
            }

            String var6 = var1[var5];

            if (var3)
            {
                String var7 = PlayerSelector.getPlayerNames(var0, var6);

                if (var7 != null)
                {
                    var6 = var7;
                }
                else if (PlayerSelector.isPattern(var6))
                {
                    throw new ExceptionPlayerNotFound();
                }
            }

            var4.append(var6);
        }

        return var4.toString();
    }

    public static double a(ICommandListener var0, double var1, String var3)
    {
        return a(var0, var1, var3, -30000000, 30000000);
    }

    public static double a(ICommandListener var0, double var1, String var3, int var4, int var5)
    {
        boolean var6 = var3.startsWith("~");

        if (var6 && Double.isNaN(var1))
        {
            throw new ExceptionInvalidNumber("commands.generic.num.invalid", new Object[] {Double.valueOf(var1)});
        }
        else
        {
            double var7 = var6 ? var1 : 0.0D;

            if (!var6 || var3.length() > 1)
            {
                boolean var9 = var3.contains(".");

                if (var6)
                {
                    var3 = var3.substring(1);
                }

                var7 += b(var0, var3);

                if (!var9 && !var6)
                {
                    var7 += 0.5D;
                }
            }

            if (var4 != 0 || var5 != 0)
            {
                if (var7 < (double)var4)
                {
                    throw new ExceptionInvalidNumber("commands.generic.double.tooSmall", new Object[] {Double.valueOf(var7), Integer.valueOf(var4)});
                }

                if (var7 > (double)var5)
                {
                    throw new ExceptionInvalidNumber("commands.generic.double.tooBig", new Object[] {Double.valueOf(var7), Integer.valueOf(var5)});
                }
            }

            return var7;
        }
    }

    public static String a(Object[] var0)
    {
        StringBuilder var1 = new StringBuilder();

        for (int var2 = 0; var2 < var0.length; ++var2)
        {
            String var3 = var0[var2].toString();

            if (var2 > 0)
            {
                if (var2 == var0.length - 1)
                {
                    var1.append(" and ");
                }
                else
                {
                    var1.append(", ");
                }
            }

            var1.append(var3);
        }

        return var1.toString();
    }

    public static String a(Collection var0)
    {
        return a(var0.toArray(new String[var0.size()]));
    }

    public static String b(Collection var0)
    {
        String[] var1 = new String[var0.size()];
        int var2 = 0;
        EntityLiving var4;

        for (Iterator var3 = var0.iterator(); var3.hasNext(); var1[var2++] = var4.getScoreboardDisplayName())
        {
            var4 = (EntityLiving)var3.next();
        }

        return a((Object[])var1);
    }

    public static boolean a(String var0, String var1)
    {
        return var1.regionMatches(true, 0, var0, 0, var0.length());
    }

    public static List a(String[] var0, String ... var1)
    {
        String var2 = var0[var0.length - 1];
        ArrayList var3 = new ArrayList();
        String[] var4 = var1;
        int var5 = var1.length;

        for (int var6 = 0; var6 < var5; ++var6)
        {
            String var7 = var4[var6];

            if (a(var2, var7))
            {
                var3.add(var7);
            }
        }

        return var3;
    }

    public static List a(String[] var0, Iterable var1)
    {
        String var2 = var0[var0.length - 1];
        ArrayList var3 = new ArrayList();
        Iterator var4 = var1.iterator();

        while (var4.hasNext())
        {
            String var5 = (String)var4.next();

            if (a(var2, var5))
            {
                var3.add(var5);
            }
        }

        return var3;
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return false;
    }

    public static void a(ICommandListener var0, String var1, Object ... var2)
    {
        a(var0, 0, var1, var2);
    }

    public static void a(ICommandListener var0, int var1, String var2, Object ... var3)
    {
        if (a != null)
        {
            a.a(var0, var1, var2, var3);
        }
    }

    public static void a(ICommandDispatcher var0)
    {
        a = var0;
    }

    public int a(ICommand var1)
    {
        return this.getCommandName().compareTo(var1.getCommandName());
    }

    public int compareTo(Object var1)
    {
        return this.a((ICommand)var1);
    }
}
