package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandTp extends CommandAbstract
{
    public String getCommandName()
    {
        return "tp";
    }

    public int a()
    {
        return 2;
    }

    public String c(ICommandListener var1)
    {
        return "commands.tp.usage";
    }

    public void b(ICommandListener var1, String[] var2)
    {
        if (var2.length < 1)
        {
            throw new ExceptionUsage("commands.tp.usage", new Object[0]);
        }
        else
        {
            EntityPlayer var3;

            if (var2.length != 2 && var2.length != 4)
            {
                var3 = b(var1);
            }
            else
            {
                var3 = d(var1, var2[0]);

                if (var3 == null)
                {
                    throw new ExceptionPlayerNotFound();
                }
            }

            if (var2.length != 3 && var2.length != 4)
            {
                if (var2.length == 1 || var2.length == 2)
                {
                    EntityPlayer var11 = d(var1, var2[var2.length - 1]);

                    if (var11 == null)
                    {
                        throw new ExceptionPlayerNotFound();
                    }

                    if (var11.world != var3.world)
                    {
                        a(var1, "commands.tp.notSameDimension", new Object[0]);
                        return;
                    }

                    var3.mount((Entity)null);
                    var3.playerConnection.a(var11.locX, var11.locY, var11.locZ, var11.yaw, var11.pitch);
                    a(var1, "commands.tp.success", new Object[] {var3.getLocalizedName(), var11.getLocalizedName()});
                }
            }
            else if (var3.world != null)
            {
                int var4 = var2.length - 3;
                double var5 = a(var1, var3.locX, var2[var4++]);
                double var7 = a(var1, var3.locY, var2[var4++], 0, 0);
                double var9 = a(var1, var3.locZ, var2[var4++]);
                var3.mount((Entity)null);
                var3.enderTeleportTo(var5, var7, var9);
                a(var1, "commands.tp.success.coordinates", new Object[] {var3.getLocalizedName(), Double.valueOf(var5), Double.valueOf(var7), Double.valueOf(var9)});
            }
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length != 1 && var2.length != 2 ? null : a(var2, MinecraftServer.getServer().getPlayers());
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return var2 == 0;
    }
}
