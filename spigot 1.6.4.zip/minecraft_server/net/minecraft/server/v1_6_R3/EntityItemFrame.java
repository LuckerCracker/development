package net.minecraft.server.v1_6_R3;

public class EntityItemFrame extends EntityHanging
{
    /** Chance for this item frame's item to drop from the frame. */
    private float itemDropChance = 1.0F;

    public EntityItemFrame(World par1World)
    {
        super(par1World);
    }

    public EntityItemFrame(World par1World, int par2, int par3, int par4, int par5)
    {
        super(par1World, par2, par3, par4, par5);
        this.setDirection(par5);
    }

    protected void entityInit()
    {
        this.getDataWatcher().addObjectByDataType(2, 5);
        this.getDataWatcher().addObject(3, Byte.valueOf((byte)0));
    }

    public int getWidthPixels()
    {
        return 9;
    }

    public int getHeightPixels()
    {
        return 9;
    }

    /**
     * Called when this entity is broken. Entity parameter may be null.
     */
    public void onBroken(Entity par1Entity)
    {
        ItemStack var2 = this.getItem();

        if (par1Entity instanceof EntityHuman)
        {
            EntityHuman var3 = (EntityHuman)par1Entity;

            if (var3.abilities.canInstantlyBuild)
            {
                this.removeFrameFromMap(var2);
                return;
            }
        }

        this.entityDropItem(new ItemStack(Item.ITEM_FRAME), 0.0F);

        if (var2 != null && this.random.nextFloat() < this.itemDropChance)
        {
            var2 = var2.cloneItemStack();
            this.removeFrameFromMap(var2);
            this.entityDropItem(var2, 0.0F);
        }
    }

    /**
     * Removes the dot representing this frame's position from the map when the item frame is broken.
     */
    private void removeFrameFromMap(ItemStack par1ItemStack)
    {
        if (par1ItemStack != null)
        {
            if (par1ItemStack.id == Item.MAP.id)
            {
                WorldMap var2 = ((ItemWorldMap)par1ItemStack.getItem()).getSavedMap(par1ItemStack, this.world);
                var2.g.remove("frame-" + this.id);
            }

            par1ItemStack.setItemFrame((EntityItemFrame)null);
        }
    }

    public ItemStack getItem()
    {
        return this.getDataWatcher().getItemStack(2);
    }

    public void setItem(ItemStack var1)
    {
        var1 = var1.cloneItemStack();
        var1.count = 1;
        var1.setItemFrame(this);
        this.getDataWatcher().watch(2, var1);
        this.getDataWatcher().setObjectWatched(2);
    }

    public int getRotation()
    {
        return this.getDataWatcher().getByte(3);
    }

    public void setRotation(int var1)
    {
        this.getDataWatcher().watch(3, Byte.valueOf((byte)(var1 % 4)));
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        if (this.getItem() != null)
        {
            par1NBTTagCompound.setCompound("Item", this.getItem().save(new NBTTagCompound()));
            par1NBTTagCompound.setByte("ItemRotation", (byte)this.getRotation());
            par1NBTTagCompound.setFloat("ItemDropChance", this.itemDropChance);
        }

        super.writeEntityToNBT(par1NBTTagCompound);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        NBTTagCompound var2 = par1NBTTagCompound.getCompound("Item");

        if (var2 != null && !var2.isEmpty())
        {
            this.setItem(ItemStack.createStack(var2));
            this.setRotation(par1NBTTagCompound.getByte("ItemRotation"));

            if (par1NBTTagCompound.hasKey("ItemDropChance"))
            {
                this.itemDropChance = par1NBTTagCompound.getFloat("ItemDropChance");
            }
        }

        super.readEntityFromNBT(par1NBTTagCompound);
    }

    public boolean c(EntityHuman var1)
    {
        if (this.getItem() == null)
        {
            ItemStack var2 = var1.getHeldItem();

            if (var2 != null && !this.world.isStatic)
            {
                this.setItem(var2);

                if (!var1.abilities.canInstantlyBuild && --var2.count <= 0)
                {
                    var1.inventory.setItem(var1.inventory.itemInHandIndex, (ItemStack)null);
                }
            }
        }
        else if (!this.world.isStatic)
        {
            this.setRotation(this.getRotation() + 1);
        }

        return true;
    }
}
