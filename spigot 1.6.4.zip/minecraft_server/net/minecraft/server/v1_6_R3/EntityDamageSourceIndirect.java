package net.minecraft.server.v1_6_R3;

public class EntityDamageSourceIndirect extends EntityDamageSource
{
    private Entity owner;

    public EntityDamageSourceIndirect(String par1Str, Entity par2Entity, Entity par3Entity)
    {
        super(par1Str, par2Entity);
        this.owner = par3Entity;
    }

    public Entity getSourceOfDamage()
    {
        return this.damageSourceEntity;
    }

    public Entity getEntity()
    {
        return this.owner;
    }

    public ChatMessage getLocalizedDeathMessage(EntityLiving entityliving)
    {
        String s = this.owner == null ? this.damageSourceEntity.getScoreboardDisplayName() : this.owner.getScoreboardDisplayName();
        ItemStack itemstack = this.owner instanceof EntityLiving ? ((EntityLiving)this.owner).getHeldItem() : null;
        String s1 = "death.attack." + this.translationIndex;
        String s2 = s1 + ".item";
        return itemstack != null && itemstack.hasName() && LocaleI18n.b(s2) ? ChatMessage.b(s2, new Object[] {entityliving.getScoreboardDisplayName(), s, itemstack.getName()}): ChatMessage.b(s1, new Object[] {entityliving.getScoreboardDisplayName(), s});
    }

    public Entity getProximateDamageSource()
    {
        return super.getEntity();
    }
}
