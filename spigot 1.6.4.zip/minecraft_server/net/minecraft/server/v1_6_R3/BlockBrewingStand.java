package net.minecraft.server.v1_6_R3;

import java.util.List;
import java.util.Random;

public class BlockBrewingStand extends BlockContainer
{
    private Random rand = new Random();

    public BlockBrewingStand(int par1)
    {
        super(par1, Material.ORE);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean isOpaqueCube()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 25;
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityBrewingStand();
    }

    /**
     * If this block doesn't render as an ordinary block it will return False (examples: signs, buttons, stairs, etc)
     */
    public boolean renderAsNormalBlock()
    {
        return false;
    }

    /**
     * Adds all intersecting collision boxes to a list. (Be sure to only add boxes to the list if they intersect the
     * mask.) Parameters: World, X, Y, Z, mask, list, colliding entity
     */
    public void addCollisionBoxesToList(World par1World, int par2, int par3, int par4, AxisAlignedBB par5AxisAlignedBB, List par6List, Entity par7Entity)
    {
        this.setBlockBounds(0.4375F, 0.0F, 0.4375F, 0.5625F, 0.875F, 0.5625F);
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
        this.setBlockBoundsForItemRender();
        super.addCollisionBoxesToList(par1World, par2, par3, par4, par5AxisAlignedBB, par6List, par7Entity);
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void setBlockBoundsForItemRender()
    {
        this.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        if (world.isStatic)
        {
            return true;
        }
        else
        {
            TileEntityBrewingStand tileentitybrewingstand = (TileEntityBrewingStand)world.getTileEntity(i, j, k);

            if (tileentitybrewingstand != null)
            {
                entityhuman.openBrewingStand(tileentitybrewingstand);
            }

            return true;
        }
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack)
    {
        if (itemstack.hasName())
        {
            ((TileEntityBrewingStand)world.getTileEntity(i, j, k)).func_94131_a(itemstack.getName());
        }
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        TileEntity tileentity = world.getTileEntity(i, j, k);

        if (tileentity instanceof TileEntityBrewingStand)
        {
            TileEntityBrewingStand tileentitybrewingstand = (TileEntityBrewingStand)tileentity;

            for (int j1 = 0; j1 < tileentitybrewingstand.getSize(); ++j1)
            {
                ItemStack itemstack = tileentitybrewingstand.getItem(j1);

                if (itemstack != null)
                {
                    float f = this.rand.nextFloat() * 0.8F + 0.1F;
                    float f1 = this.rand.nextFloat() * 0.8F + 0.1F;
                    EntityItem entityitem;

                    for (float f2 = this.rand.nextFloat() * 0.8F + 0.1F; itemstack.count > 0; world.addEntity(entityitem))
                    {
                        int k1 = this.rand.nextInt(21) + 10;

                        if (k1 > itemstack.count)
                        {
                            k1 = itemstack.count;
                        }

                        itemstack.count -= k1;
                        entityitem = new EntityItem(world, (double)((float)i + f), (double)((float)j + f1), (double)((float)k + f2), new ItemStack(itemstack.id, k1, itemstack.getData()));
                        float f3 = 0.05F;
                        entityitem.motX = (double)((float)this.rand.nextGaussian() * f3);
                        entityitem.motY = (double)((float)this.rand.nextGaussian() * f3 + 0.2F);
                        entityitem.motZ = (double)((float)this.rand.nextGaussian() * f3);

                        if (itemstack.hasTag())
                        {
                            entityitem.getItemStack().setTag((NBTTagCompound)itemstack.getTag().clone());
                        }
                    }
                }
            }
        }

        super.remove(world, i, j, k, l, i1);
    }

    public int getDropType(int i, Random random, int j)
    {
        return Item.BREWING_STAND.id;
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        return Container.calcRedstoneFromInventory((IInventory)par1World.getTileEntity(par2, par3, par4));
    }
}
