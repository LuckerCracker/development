package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockRedstoneComparator extends BlockDiodeAbstract implements IContainer {
	public BlockRedstoneComparator(int var1, boolean var2) {
		super(var1, var2);
		this.isTileEntity = true;
	}

	public int getDropType(int var1, Random var2, int var3) {
		return Item.REDSTONE_COMPARATOR.id;
	}

	protected int k_(int var1) {
		return 2;
	}

	protected BlockDiodeAbstract i() {
		return Block.REDSTONE_COMPARATOR_ON;
	}

	protected BlockDiodeAbstract j() {
		return Block.REDSTONE_COMPARATOR_OFF;
	}

	/**
	 * The type of render function that is called for this block
	 */
	public int getRenderType() {
		return 37;
	}

	protected boolean c(int var1) {
		return this.displayOnCreativeTab || (var1 & 8) != 0;
	}

	protected int d(IBlockAccess var1, int var2, int var3, int var4, int var5) {
		return this.a_(var1, var2, var3, var4).getOutputSignal();
	}

	private int m(World var1, int var2, int var3, int var4, int var5) {
		return !this.d(var5) ? this.e(var1, var2, var3, var4, var5)
				: Math.max(this.e(var1, var2, var3, var4, var5) - this.e(var1, var2, var3, var4, var5), 0);
	}

	public boolean d(int var1) {
		return (var1 & 4) == 4;
	}

	protected boolean d(World var1, int var2, int var3, int var4, int var5) {
		int var6 = this.e(var1, var2, var3, var4, var5);

		if (var6 >= 15) {
			return true;
		} else if (var6 == 0) {
			return false;
		} else {
			int var7 = e(var1, var2, var3, var4, var5);
			return var7 == 0 ? true : var6 >= var7;
		}
	}

	protected int e(World var1, int var2, int var3, int var4, int var5) {
		int var6 = super.e(var1, var2, var3, var4, var5);
		int var7 = getDirection(var5);
		int var8 = var2 + Direction.offsetX[var7];
		int var9 = var4 + Direction.offsetZ[var7];
		int var10 = var1.getTypeId(var8, var3, var9);

		if (var10 > 0) {
			if (Block.byId[var10].hasComparatorInputOverride()) {
				var6 = Block.byId[var10].getComparatorInputOverride(var1, var8, var3, var9,
						Direction.rotateOpposite[var7]);
			} else if (var6 < 15 && Block.isNormalCube(var10)) {
				var8 += Direction.offsetX[var7];
				var9 += Direction.offsetZ[var7];
				var10 = var1.getTypeId(var8, var3, var9);

				if (var10 > 0 && Block.byId[var10].hasComparatorInputOverride()) {
					var6 = Block.byId[var10].getComparatorInputOverride(var1, var8, var3, var9,
							Direction.rotateOpposite[var7]);
				}
			}
		}

		return var6;
	}

	public TileEntityComparator a_(IBlockAccess var1, int var2, int var3, int var4) {
		return (TileEntityComparator) var1.getTileEntity(var2, var3, var4);
	}

	public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5, int var6, float var7,
			float var8, float var9) {
		int var10 = var1.getData(var2, var3, var4);
		boolean var11 = this.displayOnCreativeTab | (var10 & 8) != 0;
		boolean var12 = !this.d(var10);
		int var13 = var12 ? 4 : 0;
		var13 |= var11 ? 8 : 0;
		var1.makeSound((double) var2 + 0.5D, (double) var3 + 0.5D, (double) var4 + 0.5D, "random.click", 0.3F,
				var12 ? 0.55F : 0.5F);
		var1.setData(var2, var3, var4, var13 | var10 & 3, 2);
		this.c(var1, var2, var3, var4, var1.random);
		return true;
	}

	protected void f(World var1, int var2, int var3, int var4, int var5) {
		if (!var1.isBlockTickScheduledThisTick(var2, var3, var4, this.id)) {
			int var6 = var1.getData(var2, var3, var4);
			int var7 = this.m(var1, var2, var3, var4, var6);
			int var8 = this.a_(var1, var2, var3, var4).getOutputSignal();

			if (var7 != var8 || this.c(var6) != this.d(var1, var2, var3, var4, var6)) {
				if (this.h(var1, var2, var3, var4, var6)) {
					var1.scheduleBlockUpdateWithPriority(var2, var3, var4, this.id, this.k_(0), -1);
				} else {
					var1.scheduleBlockUpdateWithPriority(var2, var3, var4, this.id, this.k_(0), 0);
				}
			}
		}
	}

	private void c(World var1, int var2, int var3, int var4, Random var5) {
		int var6 = var1.getData(var2, var3, var4);
		int var7 = this.m(var1, var2, var3, var4, var6);
		int var8 = this.a_(var1, var2, var3, var4).getOutputSignal();
		this.a_(var1, var2, var3, var4).setOutputSignal(var7);

		if (var8 != var7 || !this.d(var6)) {
			boolean var9 = this.d(var1, var2, var3, var4, var6);
			boolean var10 = this.displayOnCreativeTab || (var6 & 8) != 0;

			if (var10 && !var9) {
				var1.setData(var2, var3, var4, var6 & -9, 2);
			} else if (!var10 && var9) {
				var1.setData(var2, var3, var4, var6 | 8, 2);
			}

			this.h_(var1, var2, var3, var4);
		}
	}

	/**
	 * Ticks the block if it's been scheduled
	 */
	public void updateTick(World var1, int var2, int var3, int var4, Random var5) {
		if (this.displayOnCreativeTab) {
			int var6 = var1.getData(var2, var3, var4);
			var1.setTypeIdAndData(var2, var3, var4, this.j().id, var6 | 8, 4);
		}

		this.c(var1, var2, var3, var4, var5);
	}

	public void onPlace(World var1, int var2, int var3, int var4) {
		super.onPlace(var1, var2, var3, var4);
		var1.setTileEntity(var2, var3, var4, this.createNewTileEntity(var1));
	}

	public void remove(World var1, int var2, int var3, int var4, int var5, int var6) {
		super.remove(var1, var2, var3, var4, var5, var6);
		var1.removeBlockTileEntity(var2, var3, var4);
		this.h_(var1, var2, var3, var4);
	}

	/**
	 * Called when the block receives a BlockEvent - see World.addBlockEvent. By
	 * default, passes it on to the tile entity at this location. Args: world,
	 * x, y, z, blockID, EventID, event parameter
	 */
	public boolean onBlockEventReceived(World var1, int var2, int var3, int var4, int var5, int var6) {
		super.onBlockEventReceived(var1, var2, var3, var4, var5, var6);
		TileEntity var7 = var1.getTileEntity(var2, var3, var4);
		return var7 != null ? var7.receiveClientEvent(var5, var6) : false;
	}

	/**
	 * Returns a new instance of a block's tile entity class. Called on placing
	 * the block.
	 */
	public TileEntity createNewTileEntity(World var1) {
		return new TileEntityComparator();
	}
}
