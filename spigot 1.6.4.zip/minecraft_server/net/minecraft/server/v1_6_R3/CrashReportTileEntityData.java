package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportTileEntityData implements Callable
{
    final TileEntity a;

    CrashReportTileEntityData(TileEntity var1)
    {
        this.a = var1;
    }

    public String a()
    {
        int var1 = this.a.world.getData(this.a.x, this.a.y, this.a.z);

        if (var1 < 0)
        {
            return "Unknown? (Got " + var1 + ")";
        }
        else
        {
            String var2 = String.format("%4s", new Object[] {Integer.toBinaryString(var1)}).replace(" ", "0");
            return String.format("%1$d / 0x%1$X / 0b%2$s", new Object[] {Integer.valueOf(var1), var2});
        }
    }

    public Object call()
    {
        return this.a();
    }
}
