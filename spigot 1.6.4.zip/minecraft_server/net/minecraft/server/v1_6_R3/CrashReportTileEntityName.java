package net.minecraft.server.v1_6_R3;

import java.util.concurrent.Callable;

class CrashReportTileEntityName implements Callable
{
    final TileEntity a;

    CrashReportTileEntityName(TileEntity var1)
    {
        this.a = var1;
    }

    public String a()
    {
        return (String)TileEntity.getClassToNameMap().get(this.a.getClass()) + " // " + this.a.getClass().getCanonicalName();
    }

    public Object call()
    {
        return this.a();
    }
}
