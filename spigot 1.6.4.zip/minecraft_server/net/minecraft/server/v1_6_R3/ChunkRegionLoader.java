package net.minecraft.server.v1_6_R3;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

public class ChunkRegionLoader implements IAsyncChunkSaver, IChunkLoader {
	private LinkedHashMap<ChunkCoordIntPair, PendingChunkToSave> pendingSaves = new LinkedHashMap();
	private Object c = new Object();
	private final File d;

	public ChunkRegionLoader(File file1) {
		this.d = file1;
	}

	public boolean chunkExists(World world, int i, int j) {
		ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(i, j);
		Object var5 = this.c;

		synchronized (this.c) {
			if (this.pendingSaves.containsKey(chunkcoordintpair)) {
				return true;
			}
		}

		return RegionFileCache.createOrLoadRegionFile(this.d, i, j).chunkExists(i & 31, j & 31);
	}

	/**
	 * Loads the specified(XZ) chunk into the specified world.
	 */
	public Chunk loadChunk(World world, int i, int j) {
		Object[] data = this.loadChunkObject(world, i, j);

		if (data != null) {
			Chunk chunk = (Chunk) data[0];
			NBTTagCompound nbttagcompound = (NBTTagCompound) data[1];
			this.loadEntities(chunk, nbttagcompound.getCompound("Level"), world);
			return chunk;
		} else {
			return null;
		}
	}

	public Object[] loadChunkObject(World world, int i, int j) {
		NBTTagCompound nbttagcompound = null;
		ChunkCoordIntPair chunkcoordintpair = new ChunkCoordIntPair(i, j);
		Object object = this.c;
		Object datainputstream = this.c;

		synchronized (this.c) {
			PendingChunkToSave pendingchunktosave = (PendingChunkToSave) this.pendingSaves.get(chunkcoordintpair);

			if (pendingchunktosave != null) {
				nbttagcompound = pendingchunktosave.b;
			}
		}

		if (nbttagcompound == null) {
			DataInputStream datainputstream1 = RegionFileCache.getChunkInputStream(this.d, i, j);

			if (datainputstream1 == null) {
				return null;
			}

			try {
				nbttagcompound = NBTCompressedStreamTools.a((DataInput) datainputstream1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return this.a(world, i, j, nbttagcompound);
	}

	protected Object[] a(World world, int i, int j, NBTTagCompound nbttagcompound) {
		if (!nbttagcompound.hasKey("Level")) {
			world.getLogger().severe("Chunk file at " + i + "," + j + " is missing level data, skipping");
			return null;
		} else if (!nbttagcompound.getCompound("Level").hasKey("Sections")) {
			world.getLogger().severe("Chunk file at " + i + "," + j + " is missing block data, skipping");
			return null;
		} else {
			Chunk chunk = this.a(world, nbttagcompound.getCompound("Level"));

			if (!chunk.isAtLocation(i, j)) {
				world.getLogger()
						.severe("Chunk file at " + i + "," + j + " is in the wrong location; relocating. (Expected " + i
								+ ", " + j + ", got " + chunk.x + ", " + chunk.z + ")");
				nbttagcompound.getCompound("Level").setInt("xPos", i);
				nbttagcompound.getCompound("Level").setInt("zPos", j);
				NBTTagList data = nbttagcompound.getCompound("Level").getList("TileEntities");

				if (data != null) {
					for (int te = 0; te < data.size(); ++te) {
						NBTTagCompound tileEntity = (NBTTagCompound) data.get(te);
						int x = tileEntity.getInt("x") - chunk.x * 16;
						int z = tileEntity.getInt("z") - chunk.z * 16;
						tileEntity.setInt("x", i * 16 + x);
						tileEntity.setInt("z", j * 16 + z);
					}
				}

				chunk = this.a(world, nbttagcompound.getCompound("Level"));
			}

			Object[] var11 = new Object[] { chunk, nbttagcompound };
			return var11;
		}
	}

	public void saveChunk(World world, Chunk chunk) {
		try {
			world.checkSessionLock();
		} catch (Exception var6) {
			var6.printStackTrace();
		}

		try {
			NBTTagCompound exception = new NBTTagCompound();
			NBTTagCompound nbttagcompound1 = new NBTTagCompound();
			exception.set("Level", nbttagcompound1);
			this.a(chunk, world, nbttagcompound1);
			this.a(chunk.getChunkCoordIntPair(), exception);
		} catch (Exception var5) {
			var5.printStackTrace();
		}
	}

	protected void a(ChunkCoordIntPair chunkcoordintpair, NBTTagCompound nbttagcompound) {
		Object object = this.c;
		Object var4 = this.c;

		synchronized (this.c) {
			if (this.pendingSaves.put(chunkcoordintpair,
					new PendingChunkToSave(chunkcoordintpair, nbttagcompound)) == null) {
				FileIOThread.threadedIOInstance.queueIO(this);
			}
		}
	}

	public boolean c() {
		PendingChunkToSave pendingchunktosave = null;
		Object object = this.c;
		Object exception = this.c;

		synchronized (this.c) {
			if (this.pendingSaves.isEmpty()) {
				return false;
			}

			pendingchunktosave = (PendingChunkToSave) this.pendingSaves.values().iterator().next();
			this.pendingSaves.remove(pendingchunktosave.a);
		}

		if (pendingchunktosave != null) {
			try {
				this.a(pendingchunktosave);
			} catch (Exception var5) {
				var5.printStackTrace();
			}
		}

		return true;
	}

	public void a(PendingChunkToSave pendingchunktosave) throws IOException {
		DataOutputStream dataoutputstream = RegionFileCache.getChunkOutputStream(this.d, pendingchunktosave.a.x,
				pendingchunktosave.a.z);
		NBTCompressedStreamTools.a(pendingchunktosave.b, (DataOutput) dataoutputstream);
		dataoutputstream.close();
	}

	/**
	 * Save extra data associated with this Chunk not normally saved during
	 * autosave, only during chunk unload. Currently unused.
	 */
	public void saveExtraChunkData(World world, Chunk chunk) {
	}

	/**
	 * Called every World.tick()
	 */
	public void chunkTick() {
	}

	/**
	 * Save extra data not associated with any Chunk. Not saved during autosave,
	 * only during world unload. Currently unused.
	 */
	public void saveExtraData() {
		while (this.c()) {
			;
		}
	}

	private void a(Chunk chunk, World world, NBTTagCompound nbttagcompound) {
		nbttagcompound.setInt("xPos", chunk.x);
		nbttagcompound.setInt("zPos", chunk.z);
		nbttagcompound.setLong("LastUpdate", world.getTime());
		nbttagcompound.setIntArray("HeightMap", chunk.heightMap);
		nbttagcompound.setBoolean("TerrainPopulated", chunk.done);
		nbttagcompound.setLong("InhabitedTime", chunk.inhabitedTime);
		ChunkSection[] achunksection = chunk.i();
		NBTTagList nbttaglist = new NBTTagList("Sections");
		boolean flag = !world.worldProvider.hasNoSky;
		ChunkSection[] achunksection1 = achunksection;
		int i = achunksection.length;
		NBTTagCompound nbttagcompound1;

		for (int nbttaglist1 = 0; nbttaglist1 < i; ++nbttaglist1) {
			ChunkSection iterator = achunksection1[nbttaglist1];

			if (iterator != null) {
				nbttagcompound1 = new NBTTagCompound();
				nbttagcompound1.setByte("Y", (byte) (iterator.getYPosition() >> 4 & 255));
				nbttagcompound1.setByteArray("Blocks", iterator.getIdArray());

				if (iterator.getExtendedIdArray() != null) {
					nbttagcompound1.setByteArray("Add", iterator.getExtendedIdArray().getValueArray());
				}

				nbttagcompound1.setByteArray("Data", iterator.getDataArray().getValueArray());
				nbttagcompound1.setByteArray("BlockLight", iterator.getEmittedLightArray().getValueArray());

				if (flag) {
					nbttagcompound1.setByteArray("SkyLight", iterator.getSkyLightArray().getValueArray());
				} else {
					nbttagcompound1.setByteArray("SkyLight",
							new byte[iterator.getEmittedLightArray().getValueArray().length]);
				}

				nbttaglist.add(nbttagcompound1);
			}
		}

		nbttagcompound.set("Sections", nbttaglist);
		nbttagcompound.setByteArray("Biomes", chunk.getBiomeArray());
		chunk.hasEntities = false;
		NBTTagList var20 = new NBTTagList();
		Iterator var21;

		for (i = 0; i < chunk.entitySlices.length; ++i) {
			var21 = chunk.entitySlices[i].iterator();

			while (var21.hasNext()) {
				Entity nbttaglist2 = (Entity) var21.next();
				nbttagcompound1 = new NBTTagCompound();

				if (nbttaglist2.writeToNBTOptional(nbttagcompound1)) {
					chunk.hasEntities = true;
					var20.add(nbttagcompound1);
				}
			}
		}

		nbttagcompound.set("Entities", var20);
		NBTTagList var22 = new NBTTagList();
		var21 = chunk.tileEntities.values().iterator();

		while (var21.hasNext()) {
			TileEntity list = (TileEntity) var21.next();
			nbttagcompound1 = new NBTTagCompound();
			list.writeToNBT(nbttagcompound1);
			var22.add(nbttagcompound1);
		}

		nbttagcompound.set("TileEntities", var22);
		List var23 = world.getPendingBlockUpdates(chunk, false);

		if (var23 != null) {
			long k = world.getTime();
			NBTTagList nbttaglist3 = new NBTTagList();
			Iterator iterator1 = var23.iterator();

			while (iterator1.hasNext()) {
				NextTickListEntry nextticklistentry = (NextTickListEntry) iterator1.next();
				NBTTagCompound nbttagcompound2 = new NBTTagCompound();
				nbttagcompound2.setInt("i", nextticklistentry.blockID);
				nbttagcompound2.setInt("x", nextticklistentry.xCoord);
				nbttagcompound2.setInt("y", nextticklistentry.yCoord);
				nbttagcompound2.setInt("z", nextticklistentry.zCoord);
				nbttagcompound2.setInt("t", (int) (nextticklistentry.scheduledTime - k));
				nbttagcompound2.setInt("p", nextticklistentry.priority);
				nbttaglist3.add(nbttagcompound2);
			}

			nbttagcompound.set("TileTicks", nbttaglist3);
		}
	}

	private Chunk a(World world, NBTTagCompound nbttagcompound) {
		int i = nbttagcompound.getInt("xPos");
		int j = nbttagcompound.getInt("zPos");
		Chunk chunk = new Chunk(world, i, j);
		chunk.heightMap = nbttagcompound.getIntArray("HeightMap");
		chunk.done = nbttagcompound.getBoolean("TerrainPopulated");
		chunk.inhabitedTime = nbttagcompound.getLong("InhabitedTime");
		NBTTagList nbttaglist = nbttagcompound.getList("Sections");
		byte b0 = 16;
		ChunkSection[] achunksection = new ChunkSection[b0];
		boolean flag = !world.worldProvider.hasNoSky;

		for (int k = 0; k < nbttaglist.size(); ++k) {
			NBTTagCompound nbttagcompound1 = (NBTTagCompound) nbttaglist.get(k);
			byte b1 = nbttagcompound1.getByte("Y");
			ChunkSection chunksection = new ChunkSection(b1 << 4, flag);
			chunksection.setIdArray(nbttagcompound1.getByteArray("Blocks"));

			if (nbttagcompound1.hasKey("Add")) {
				chunksection.setExtendedIdArray(new NibbleArray(nbttagcompound1.getByteArray("Add"), 4));
			}

			chunksection.setDataArray(new NibbleArray(nbttagcompound1.getByteArray("Data"), 4));
			chunksection.setEmittedLightArray(new NibbleArray(nbttagcompound1.getByteArray("BlockLight"), 4));

			if (flag) {
				chunksection.setSkyLightArray(new NibbleArray(nbttagcompound1.getByteArray("SkyLight"), 4));
			}

			chunksection.recalcBlockCounts();
			achunksection[b1] = chunksection;
		}

		chunk.a(achunksection);

		if (nbttagcompound.hasKey("Biomes")) {
			chunk.setBiomeArray(nbttagcompound.getByteArray("Biomes"));
		}

		return chunk;
	}

	public void loadEntities(Chunk chunk, NBTTagCompound nbttagcompound, World world) {
		NBTTagList nbttaglist1 = nbttagcompound.getList("Entities");

		if (nbttaglist1 != null) {
			for (int nbttaglist2 = 0; nbttaglist2 < nbttaglist1.size(); ++nbttaglist2) {
				NBTTagCompound nbttaglist3 = (NBTTagCompound) nbttaglist1.get(nbttaglist2);
				Entity j1 = EntityTypes.a(nbttaglist3, world);
				chunk.hasEntities = true;

				if (j1 != null) {
					chunk.addEntity(j1);
					Entity nbttagcompound5 = j1;

					for (NBTTagCompound nbttagcompound3 = nbttaglist3; nbttagcompound3
							.hasKey("Riding"); nbttagcompound3 = nbttagcompound3.getCompound("Riding")) {
						Entity entity2 = EntityTypes.a(nbttagcompound3.getCompound("Riding"), world);

						if (entity2 != null) {
							chunk.addEntity(entity2);
							nbttagcompound5.mount(entity2);
						}

						nbttagcompound5 = entity2;
					}
				}
			}
		}

		NBTTagList var11 = nbttagcompound.getList("TileEntities");

		if (var11 != null) {
			for (int var12 = 0; var12 < var11.size(); ++var12) {
				NBTTagCompound var14 = (NBTTagCompound) var11.get(var12);
				TileEntity var16 = TileEntity.createAndLoadEntity(var14);

				if (var16 != null) {
					chunk.addTileEntity(var16);
				}
			}
		}

		if (nbttagcompound.hasKey("TileTicks")) {
			NBTTagList var13 = nbttagcompound.getList("TileTicks");

			if (var13 != null) {
				for (int var15 = 0; var15 < var13.size(); ++var15) {
					NBTTagCompound var17 = (NBTTagCompound) var13.get(var15);
					world.scheduleBlockUpdateFromLoad(var17.getInt("x"), var17.getInt("y"), var17.getInt("z"),
							var17.getInt("i"), var17.getInt("t"), var17.getInt("p"));
				}
			}
		}
	}
}
