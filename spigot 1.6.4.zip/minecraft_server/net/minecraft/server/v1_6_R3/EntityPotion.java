package net.minecraft.server.v1_6_R3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftLivingEntity;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.entity.PotionSplashEvent;

public class EntityPotion extends EntityProjectile
{
    public ItemStack item;

    public EntityPotion(World par1World)
    {
        super(par1World);
    }

    public EntityPotion(World world, EntityLiving entityliving, int i)
    {
        this(world, entityliving, new ItemStack(Item.POTION, 1, i));
    }

    public EntityPotion(World world, EntityLiving entityliving, ItemStack itemstack)
    {
        super(world, entityliving);
        this.item = itemstack;
    }

    public EntityPotion(World par1World, double par2, double par4, double par6, ItemStack par8ItemStack)
    {
        super(par1World, par2, par4, par6);
        this.item = par8ItemStack;
    }

    /**
     * Gets the amount of gravity to apply to the thrown entity with each tick.
     */
    protected float getGravityVelocity()
    {
        return 0.05F;
    }

    protected float func_70182_d()
    {
        return 0.5F;
    }

    protected float func_70183_g()
    {
        return -20.0F;
    }

    public void setPotionValue(int i)
    {
        if (this.item == null)
        {
            this.item = new ItemStack(Item.POTION, 1, 0);
        }

        this.item.setData(i);
    }

    public int getPotionValue()
    {
        if (this.item == null)
        {
            this.item = new ItemStack(Item.POTION, 1, 0);
        }

        return this.item.getData();
    }

    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected void onImpact(MovingObjectPosition par1MovingObjectPosition)
    {
        if (!this.world.isStatic)
        {
            List var2 = Item.POTION.getEffects(this.item);
            AxisAlignedBB var3 = this.boundingBox.grow(4.0D, 2.0D, 4.0D);
            List var4 = this.world.getEntitiesWithinAABB(EntityLiving.class, var3);

            if (var4 != null)
            {
                Iterator var5 = var4.iterator();
                HashMap var6 = new HashMap();

                while (var5.hasNext())
                {
                    EntityLiving var7 = (EntityLiving)var5.next();
                    double var8 = this.getDistanceSqToEntity(var7);

                    if (var8 < 16.0D)
                    {
                        double var10 = 1.0D - Math.sqrt(var8) / 4.0D;

                        if (var7 == par1MovingObjectPosition.entity)
                        {
                            var10 = 1.0D;
                        }

                        var6.put((LivingEntity)var7.getBukkitEntity(), Double.valueOf(var10));
                    }
                }

                PotionSplashEvent var21 = CraftEventFactory.callPotionSplashEvent(this, var6);

                if (!var21.isCancelled() && var2 != null && !var2.isEmpty())
                {
                    Iterator var12 = var21.getAffectedEntities().iterator();

                    while (var12.hasNext())
                    {
                        LivingEntity var13 = (LivingEntity)var12.next();

                        if (var13 instanceof CraftLivingEntity)
                        {
                            EntityLiving var14 = ((CraftLivingEntity)var13).getHandle();
                            double var15 = var21.getIntensity(var13);
                            Iterator var17 = var2.iterator();

                            while (var17.hasNext())
                            {
                                MobEffect var18 = (MobEffect)var17.next();
                                int var19 = var18.getEffectId();

                                if (this.world.pvpMode || !(this.getShooter() instanceof EntityPlayer) || !(var14 instanceof EntityPlayer) || var14 == this.getShooter() || var19 != 2 && var19 != 4 && var19 != 7 && var19 != 15 && var19 != 17 && var19 != 18 && var19 != 19)
                                {
                                    if (MobEffectList.byId[var19].isInstant())
                                    {
                                        MobEffectList.byId[var19].applyInstantEffect(this.getShooter(), var14, var18.getAmplifier(), var15, this);
                                    }
                                    else
                                    {
                                        int var20 = (int)(var15 * (double)var18.getDuration() + 0.5D);

                                        if (var20 > 20)
                                        {
                                            var14.addEffect(new MobEffect(var19, var20, var18.getAmplifier()));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            this.world.triggerEffect(2002, (int)Math.round(this.locX), (int)Math.round(this.locY), (int)Math.round(this.locZ), this.getPotionValue());
            this.die();
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.readEntityFromNBT(par1NBTTagCompound);

        if (par1NBTTagCompound.hasKey("Potion"))
        {
            this.item = ItemStack.createStack(par1NBTTagCompound.getCompound("Potion"));
        }
        else
        {
            this.setPotionValue(par1NBTTagCompound.getInt("potionValue"));
        }

        if (this.item == null)
        {
            this.die();
        }
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound par1NBTTagCompound)
    {
        super.writeEntityToNBT(par1NBTTagCompound);

        if (this.item != null)
        {
            par1NBTTagCompound.setCompound("Potion", this.item.save(new NBTTagCompound()));
        }
    }
}
