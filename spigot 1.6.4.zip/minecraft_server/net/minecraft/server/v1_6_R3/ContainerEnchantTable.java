package net.minecraft.server.v1_6_R3;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Map.Entry;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryEnchanting;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftInventoryView;
import org.bukkit.craftbukkit.v1_6_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.enchantment.PrepareItemEnchantEvent;
import org.bukkit.inventory.InventoryView;

public class ContainerEnchantTable extends Container {
	public ContainerEnchantTableInventory enchantSlots = new ContainerEnchantTableInventory(this, "Enchant", true, 1);
	private World world;
	private int x;
	private int y;
	private int z;
	private Random l = new Random();
	public long field_94535_f;
	public int[] costs = new int[3];
	private CraftInventoryView bukkitEntity = null;
	private Player player;

	public ContainerEnchantTable(PlayerInventory playerinventory, World world, int i, int j, int k) {
		this.world = world;
		this.x = i;
		this.y = j;
		this.z = k;
		this.addSlotToContainer(new SlotEnchant(this, this.enchantSlots, 0, 25, 47));
		int l;

		for (l = 0; l < 3; ++l) {
			for (int i1 = 0; i1 < 9; ++i1) {
				this.addSlotToContainer(new Slot(playerinventory, i1 + l * 9 + 9, 8 + i1 * 18, 84 + l * 18));
			}
		}

		for (l = 0; l < 9; ++l) {
			this.addSlotToContainer(new Slot(playerinventory, l, 8 + l * 18, 142));
		}

		this.player = (Player) playerinventory.player.getBukkitEntity();
		this.enchantSlots.player = this.player;
	}

	public void addSlotListener(ICrafting icrafting) {
		super.addSlotListener(icrafting);
		icrafting.setContainerData(this, 0, this.costs[0]);
		icrafting.setContainerData(this, 1, this.costs[1]);
		icrafting.setContainerData(this, 2, this.costs[2]);
	}

	/**
	 * Looks for changes made in the container, sends them to every listener.
	 */
	public void detectAndSendChanges() {
		super.detectAndSendChanges();

		for (int i = 0; i < this.listeners.size(); ++i) {
			ICrafting icrafting = (ICrafting) this.listeners.get(i);
			icrafting.setContainerData(this, 0, this.costs[0]);
			icrafting.setContainerData(this, 1, this.costs[1]);
			icrafting.setContainerData(this, 2, this.costs[2]);
		}
	}

	/**
	 * Callback for when the crafting matrix is changed.
	 */
	public void onCraftMatrixChanged(IInventory iinventory) {
		if (iinventory == this.enchantSlots) {
			ItemStack itemstack = iinventory.getItem(0);
			int i;

			if (itemstack != null) {
				this.field_94535_f = this.l.nextLong();

				if (!this.world.isStatic) {
					i = 0;
					int j;

					for (j = -1; j <= 1; ++j) {
						for (int item = -1; item <= 1; ++item) {
							if ((j != 0 || item != 0) && this.world.isEmpty(this.x + item, this.y, this.z + j)
									&& this.world.isEmpty(this.x + item, this.y + 1, this.z + j)) {
								if (this.world.getTypeId(this.x + item * 2, this.y,
										this.z + j * 2) == Block.BOOKSHELF.id) {
									++i;
								}

								if (this.world.getTypeId(this.x + item * 2, this.y + 1,
										this.z + j * 2) == Block.BOOKSHELF.id) {
									++i;
								}

								if (item != 0 && j != 0) {
									if (this.world.getTypeId(this.x + item * 2, this.y,
											this.z + j) == Block.BOOKSHELF.id) {
										++i;
									}

									if (this.world.getTypeId(this.x + item * 2, this.y + 1,
											this.z + j) == Block.BOOKSHELF.id) {
										++i;
									}

									if (this.world.getTypeId(this.x + item, this.y,
											this.z + j * 2) == Block.BOOKSHELF.id) {
										++i;
									}

									if (this.world.getTypeId(this.x + item, this.y + 1,
											this.z + j * 2) == Block.BOOKSHELF.id) {
										++i;
									}
								}
							}
						}
					}

					for (j = 0; j < 3; ++j) {
						this.costs[j] = EnchantmentManager.a(this.l, j, i, itemstack);
					}

					CraftItemStack var7 = CraftItemStack.asCraftMirror(itemstack);
					PrepareItemEnchantEvent event = new PrepareItemEnchantEvent(this.player, this.getBukkitView(),
							this.world.getWorld().getBlockAt(this.x, this.y, this.z), var7, this.costs, i);
					event.setCancelled(!itemstack.isItemEnchantable());
					this.world.getServer().getPluginManager().callEvent(event);

					if (event.isCancelled()) {
						for (i = 0; i < 3; ++i) {
							this.costs[i] = 0;
						}

						return;
					}

					this.detectAndSendChanges();
				}
			} else {
				for (i = 0; i < 3; ++i) {
					this.costs[i] = 0;
				}
			}
		}
	}

	public boolean a(EntityHuman entityhuman, int i) {
		ItemStack itemstack = this.enchantSlots.getItem(0);

		if (this.costs[i] > 0 && itemstack != null
				&& (entityhuman.expLevel >= this.costs[i] || entityhuman.abilities.canInstantlyBuild)) {
			if (!this.world.isStatic) {
				List list = EnchantmentManager.b(this.l, itemstack, this.costs[i]);
				boolean flag = itemstack.id == Item.BOOK.id;

				if (list != null) {
					HashMap enchants = new HashMap();
					Iterator item = list.iterator();

					while (item.hasNext()) {
						Object event = item.next();
						EnchantmentInstance level = (EnchantmentInstance) event;
						enchants.put(org.bukkit.enchantments.Enchantment.getById(level.enchantment.id),
								Integer.valueOf(level.level));
					}

					CraftItemStack item1 = CraftItemStack.asCraftMirror(itemstack);
					EnchantItemEvent event1 = new EnchantItemEvent((Player) entityhuman.getBukkitEntity(),
							this.getBukkitView(), this.world.getWorld().getBlockAt(this.x, this.y, this.z), item1,
							this.costs[i], enchants, i);
					this.world.getServer().getPluginManager().callEvent(event1);
					int level1 = event1.getExpLevelCost();

					if (event1.isCancelled()
							|| level1 > entityhuman.expLevel && !entityhuman.abilities.canInstantlyBuild
							|| enchants.isEmpty()) {
						return false;
					}

					boolean applied = !flag;
					Iterator i$ = event1.getEnchantsToAdd().entrySet().iterator();

					while (i$.hasNext()) {
						Entry entry = (Entry) i$.next();

						try {
							if (flag) {
								int e = ((org.bukkit.enchantments.Enchantment) entry.getKey()).getId();

								if (Enchantment.byId[e] != null) {
									EnchantmentInstance enchantment = new EnchantmentInstance(e,
											((Integer) entry.getValue()).intValue());
									Item.ENCHANTED_BOOK.a(itemstack, enchantment);
									applied = true;
									itemstack.id = Item.ENCHANTED_BOOK.id;
									break;
								}
							} else {
								item1.addEnchantment((org.bukkit.enchantments.Enchantment) entry.getKey(),
										((Integer) entry.getValue()).intValue());
							}
						} catch (IllegalArgumentException var15) {
							;
						}
					}

					if (applied) {
						entityhuman.levelDown(-level1);
					}

					this.onCraftMatrixChanged(this.enchantSlots);
				}
			}

			return true;
		} else {
			return false;
		}
	}

	public void b(EntityHuman entityhuman) {
		super.b(entityhuman);

		if (!this.world.isStatic) {
			ItemStack itemstack = this.enchantSlots.splitWithoutUpdate(0);

			if (itemstack != null) {
				entityhuman.drop(itemstack);
			}
		}
	}

	public boolean a(EntityHuman entityhuman) {
		return !this.checkReachable ? true
				: (this.world.getTypeId(this.x, this.y, this.z) != Block.ENCHANTMENT_TABLE.id ? false
						: entityhuman.getDistanceSq((double) this.x + 0.5D, (double) this.y + 0.5D,
								(double) this.z + 0.5D) <= 64.0D);
	}

	public ItemStack b(EntityHuman entityhuman, int i) {
		ItemStack itemstack = null;
		Slot slot = (Slot) this.inventorySlots.get(i);

		if (slot != null && slot.getHasStack()) {
			ItemStack itemstack1 = slot.getItem();
			itemstack = itemstack1.cloneItemStack();

			if (i == 0) {
				if (!this.mergeItemStack(itemstack1, 1, 37, true)) {
					return null;
				}
			} else {
				if (((Slot) this.inventorySlots.get(0)).getHasStack()
						|| !((Slot) this.inventorySlots.get(0)).isAllowed(itemstack1)) {
					return null;
				}

				if (itemstack1.hasTag() && itemstack1.count == 1) {
					((Slot) this.inventorySlots.get(0)).set(itemstack1.cloneItemStack());
					itemstack1.count = 0;
				} else if (itemstack1.count >= 1) {
					((Slot) this.inventorySlots.get(0)).set(new ItemStack(itemstack1.id, 1, itemstack1.getData()));
					--itemstack1.count;
				}
			}

			if (itemstack1.count == 0) {
				slot.set((ItemStack) null);
			} else {
				slot.onSlotChanged();
			}

			if (itemstack1.count == itemstack.count) {
				return null;
			}

			slot.a(entityhuman, itemstack1);
		}

		return itemstack;
	}

	public CraftInventoryView getBukkitView() {
		if (this.bukkitEntity != null) {
			return this.bukkitEntity;
		} else {
			CraftInventoryEnchanting inventory = new CraftInventoryEnchanting(this.enchantSlots);
			this.bukkitEntity = new CraftInventoryView(this.player, inventory, this);
			return this.bukkitEntity;
		}
	}
}
