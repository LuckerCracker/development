package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockDispenser extends BlockContainer
{
    /** Registry for all dispense behaviors. */
    public static final IRegistry dispenseBehaviorRegistry = new RegistryDefault(new DispenseBehaviorItem());
    protected Random random = new Random();
    public static boolean eventFired = false;

    protected BlockDispenser(int par1)
    {
        super(par1, Material.STONE);
        this.a(CreativeModeTab.d);
    }

    /**
     * How many world ticks before ticking
     */
    public int tickRate(World par1World)
    {
        return 4;
    }

    public void onPlace(World world, int i, int j, int k)
    {
        super.onPlace(world, i, j, k);
        this.setDispenserDefaultDirection(world, i, j, k);
    }

    /**
     * sets Dispenser block direction so that the front faces an non-opaque block; chooses west to be direction if all
     * surrounding blocks are opaque.
     */
    private void setDispenserDefaultDirection(World par1World, int par2, int par3, int par4)
    {
        if (!par1World.isStatic)
        {
            int var5 = par1World.getTypeId(par2, par3, par4 - 1);
            int var6 = par1World.getTypeId(par2, par3, par4 + 1);
            int var7 = par1World.getTypeId(par2 - 1, par3, par4);
            int var8 = par1World.getTypeId(par2 + 1, par3, par4);
            byte var9 = 3;

            if (Block.opaqueCubeLookup[var5] && !Block.opaqueCubeLookup[var6])
            {
                var9 = 3;
            }

            if (Block.opaqueCubeLookup[var6] && !Block.opaqueCubeLookup[var5])
            {
                var9 = 2;
            }

            if (Block.opaqueCubeLookup[var7] && !Block.opaqueCubeLookup[var8])
            {
                var9 = 5;
            }

            if (Block.opaqueCubeLookup[var8] && !Block.opaqueCubeLookup[var7])
            {
                var9 = 4;
            }

            par1World.setData(par2, par3, par4, var9, 2);
        }
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman, int l, float f, float f1, float f2)
    {
        if (world.isStatic)
        {
            return true;
        }
        else
        {
            TileEntityDispenser tileentitydispenser = (TileEntityDispenser)world.getTileEntity(i, j, k);

            if (tileentitydispenser != null)
            {
                entityhuman.openDispenser(tileentitydispenser);
            }

            return true;
        }
    }

    public void dispense(World world, int i, int j, int k)
    {
        SourceBlock sourceblock = new SourceBlock(world, i, j, k);
        TileEntityDispenser tileentitydispenser = (TileEntityDispenser)sourceblock.getTileEntity();

        if (tileentitydispenser != null)
        {
            int l = tileentitydispenser.getRandomStackFromInventory();

            if (l < 0)
            {
                world.triggerEffect(1001, i, j, k, 0);
            }
            else
            {
                ItemStack itemstack = tileentitydispenser.getItem(l);
                IDispenseBehavior idispensebehavior = this.a(itemstack);

                if (idispensebehavior != IDispenseBehavior.a)
                {
                    ItemStack itemstack1 = idispensebehavior.a(sourceblock, itemstack);
                    eventFired = false;
                    tileentitydispenser.setItem(l, itemstack1.count == 0 ? null : itemstack1);
                }
            }
        }
    }

    protected IDispenseBehavior a(ItemStack itemstack)
    {
        return (IDispenseBehavior)dispenseBehaviorRegistry.getObject(itemstack.getItem());
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        boolean flag = world.isBlockIndirectlyPowered(i, j, k) || world.isBlockIndirectlyPowered(i, j + 1, k);
        int i1 = world.getData(i, j, k);
        boolean flag1 = (i1 & 8) != 0;

        if (flag && !flag1)
        {
            world.scheduleBlockUpdate(i, j, k, this.id, this.tickRate(world));
            world.setData(i, j, k, i1 | 8, 4);
        }
        else if (!flag && flag1)
        {
            world.setData(i, j, k, i1 & -9, 4);
        }
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World par1World, int par2, int par3, int par4, Random par5Random)
    {
        if (!par1World.isStatic)
        {
            this.dispense(par1World, par2, par3, par4);
        }
    }

    /**
     * Returns a new instance of a block's tile entity class. Called on placing the block.
     */
    public TileEntity createNewTileEntity(World par1World)
    {
        return new TileEntityDispenser();
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving, ItemStack itemstack)
    {
        int l = BlockPiston.a(world, i, j, k, entityliving);
        world.setData(i, j, k, l, 2);

        if (itemstack.hasName())
        {
            ((TileEntityDispenser)world.getTileEntity(i, j, k)).setCustomName(itemstack.getName());
        }
    }

    public void remove(World world, int i, int j, int k, int l, int i1)
    {
        TileEntityDispenser tileentitydispenser = (TileEntityDispenser)world.getTileEntity(i, j, k);

        if (tileentitydispenser != null)
        {
            for (int j1 = 0; j1 < tileentitydispenser.getSize(); ++j1)
            {
                ItemStack itemstack = tileentitydispenser.getItem(j1);

                if (itemstack != null)
                {
                    float f = this.random.nextFloat() * 0.8F + 0.1F;
                    float f1 = this.random.nextFloat() * 0.8F + 0.1F;
                    float f2 = this.random.nextFloat() * 0.8F + 0.1F;

                    while (itemstack.count > 0)
                    {
                        int k1 = this.random.nextInt(21) + 10;

                        if (k1 > itemstack.count)
                        {
                            k1 = itemstack.count;
                        }

                        itemstack.count -= k1;
                        EntityItem entityitem = new EntityItem(world, (double)((float)i + f), (double)((float)j + f1), (double)((float)k + f2), new ItemStack(itemstack.id, k1, itemstack.getData()));

                        if (itemstack.hasTag())
                        {
                            entityitem.getItemStack().setTag((NBTTagCompound)itemstack.getTag().clone());
                        }

                        float f3 = 0.05F;
                        entityitem.motX = (double)((float)this.random.nextGaussian() * f3);
                        entityitem.motY = (double)((float)this.random.nextGaussian() * f3 + 0.2F);
                        entityitem.motZ = (double)((float)this.random.nextGaussian() * f3);
                        world.addEntity(entityitem);
                    }
                }
            }

            world.func_96440_m(i, j, k, l);
        }

        super.remove(world, i, j, k, l, i1);
    }

    public static IPosition a(ISourceBlock isourceblock)
    {
        EnumFacing enumfacing = getFacing(isourceblock.h());
        double d0 = isourceblock.getX() + 0.7D * (double)enumfacing.getFrontOffsetX();
        double d1 = isourceblock.getY() + 0.7D * (double)enumfacing.getFrontOffsetY();
        double d2 = isourceblock.getZ() + 0.7D * (double)enumfacing.getFrontOffsetZ();
        return new Position(d0, d1, d2);
    }

    public static EnumFacing getFacing(int par0)
    {
        return EnumFacing.getFront(par0 & 7);
    }

    /**
     * If this returns true, then comparators facing away from this block will use the value from
     * getComparatorInputOverride instead of the actual redstone signal strength.
     */
    public boolean hasComparatorInputOverride()
    {
        return true;
    }

    /**
     * If hasComparatorInputOverride returns true, the return value from this is used instead of the redstone signal
     * strength when this block inputs to a comparator.
     */
    public int getComparatorInputOverride(World par1World, int par2, int par3, int par4, int par5)
    {
        return Container.calcRedstoneFromInventory((IInventory)par1World.getTileEntity(par2, par3, par4));
    }
}
