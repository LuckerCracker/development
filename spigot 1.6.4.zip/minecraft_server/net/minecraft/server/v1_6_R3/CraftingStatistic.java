package net.minecraft.server.v1_6_R3;

public class CraftingStatistic extends Statistic
{
    private final int a;

    public CraftingStatistic(int var1, String var2, int var3)
    {
        super(var1, var2);
        this.a = var3;
    }
}
