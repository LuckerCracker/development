package net.minecraft.server.v1_6_R3;

final class CreativeModeTab6 extends CreativeModeTab
{
    CreativeModeTab6(int var1, String var2)
    {
        super(var1, var2);
    }
}
