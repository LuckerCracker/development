package net.minecraft.server.v1_6_R3;

import java.util.List;

public class CommandClear extends CommandAbstract
{
    public String getCommandName()
    {
        return "clear";
    }

    public String c(ICommandListener var1)
    {
        return "commands.clear.usage";
    }

    public int a()
    {
        return 2;
    }

    public void b(ICommandListener var1, String[] var2)
    {
        EntityPlayer var3 = var2.length == 0 ? b(var1) : d(var1, var2[0]);
        int var4 = var2.length >= 2 ? a(var1, var2[1], 1) : -1;
        int var5 = var2.length >= 3 ? a(var1, var2[2], 0) : -1;
        int var6 = var3.inventory.b(var4, var5);
        var3.defaultContainer.detectAndSendChanges();

        if (!var3.abilities.canInstantlyBuild)
        {
            var3.broadcastCarriedItem();
        }

        if (var6 == 0)
        {
            throw new CommandException("commands.clear.failure", new Object[] {var3.getLocalizedName()});
        }
        else
        {
            a(var1, "commands.clear.success", new Object[] {var3.getLocalizedName(), Integer.valueOf(var6)});
        }
    }

    public List a(ICommandListener var1, String[] var2)
    {
        return var2.length == 1 ? a(var2, this.d()) : null;
    }

    protected String[] d()
    {
        return MinecraftServer.getServer().getPlayers();
    }

    /**
     * Return whether the specified command parameter index is a username parameter.
     */
    public boolean isUsernameIndex(String[] var1, int var2)
    {
        return var2 == 0;
    }
}
