package net.minecraft.server.v1_6_R3;

public class BlockQuartz extends Block
{
    public static final String[] quartzBlockTypes = new String[] {"default", "chiseled", "lines"};
    private static final String[] quartzBlockTextureTypes = new String[] {"side", "chiseled", "lines", null, null};

    public BlockQuartz(int par1)
    {
        super(par1, Material.STONE);
        this.a(CreativeModeTab.b);
    }

    public int getPlacedData(World var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, int var9)
    {
        if (var9 == 2)
        {
            switch (var5)
            {
                case 0:
                case 1:
                    var9 = 2;
                    break;

                case 2:
                case 3:
                    var9 = 4;
                    break;

                case 4:
                case 5:
                    var9 = 3;
            }
        }

        return var9;
    }

    public int getDropData(int var1)
    {
        return var1 != 3 && var1 != 4 ? var1 : 2;
    }

    /**
     * Returns an item stack containing a single instance of the current block type. 'i' is the block's subtype/damage
     * and is ignored for blocks which do not support subtypes. Blocks which cannot be harvested should return null.
     */
    protected ItemStack createStackedBlock(int par1)
    {
        return par1 != 3 && par1 != 4 ? super.createStackedBlock(par1) : new ItemStack(this.id, 1, 2);
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 39;
    }
}
