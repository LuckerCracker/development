package net.minecraft.server.v1_6_R3;

import java.util.Random;

public class BlockLightStone extends Block
{
    public BlockLightStone(int var1, Material var2)
    {
        super(var1, var2);
        this.a(CreativeModeTab.b);
    }

    public int getDropCount(int var1, Random var2)
    {
        return MathHelper.clamp_int(this.quantityDropped(var2) + var2.nextInt(var1 + 1), 1, 4);
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random var1)
    {
        return 2 + var1.nextInt(3);
    }

    public int getDropType(int var1, Random var2, int var3)
    {
        return Item.GLOWSTONE_DUST.id;
    }
}
