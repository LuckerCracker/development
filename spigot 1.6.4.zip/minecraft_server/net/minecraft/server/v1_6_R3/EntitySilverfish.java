package net.minecraft.server.v1_6_R3;

import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class EntitySilverfish extends EntityMonster
{
    /**
     * A cooldown before this entity will search for another Silverfish to join them in battle.
     */
    private int allySummonCooldown;

    public EntitySilverfish(World par1World)
    {
        super(par1World);
        this.setSize(0.3F, 0.7F);
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getAttributeInstance(GenericAttributes.a).setValue(8.0D);
        this.getAttributeInstance(GenericAttributes.d).setValue(0.6000000238418579D);
        this.getAttributeInstance(GenericAttributes.e).setValue(1.0D);
    }

    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    protected Entity findTarget()
    {
        double d0 = 8.0D;
        return this.world.findNearbyVulnerablePlayer(this, d0);
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String getLivingSound()
    {
        return "mob.silverfish.say";
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String getHurtSound()
    {
        return "mob.silverfish.hit";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String getDeathSound()
    {
        return "mob.silverfish.kill";
    }

    public boolean attackEntityFrom(DamageSource damagesource, float f)
    {
        if (this.isInvulnerable())
        {
            return false;
        }
        else
        {
            if (this.allySummonCooldown <= 0 && (damagesource instanceof EntityDamageSource || damagesource == DamageSource.MAGIC))
            {
                this.allySummonCooldown = 20;
            }

            return super.attackEntityFrom(damagesource, f);
        }
    }

    /**
     * Basic mob attack. Default to touch of death in EntityCreature. Overridden by each mob to define their attack.
     */
    protected void attackEntity(Entity par1Entity, float par2)
    {
        if (this.attackTicks <= 0 && par2 < 1.2F && par1Entity.boundingBox.maxY > this.boundingBox.minY && par1Entity.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTicks = 20;
            this.attackEntityAsMob(par1Entity);
        }
    }

    /**
     * Plays step sound at given x, y, z for the entity
     */
    protected void playStepSound(int par1, int par2, int par3, int par4)
    {
        this.makeSound("mob.silverfish.step", 0.15F, 1.0F);
    }

    protected int getLootId()
    {
        return 0;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        this.renderYawOffset = this.yaw;
        super.onUpdate();
    }

    protected void updateEntityActionState()
    {
        super.updateEntityActionState();

        if (!this.world.isStatic)
        {
            int var1;
            int var2;
            int var3;
            int var5;

            if (this.allySummonCooldown > 0)
            {
                --this.allySummonCooldown;

                if (this.allySummonCooldown == 0)
                {
                    var1 = MathHelper.floor(this.locX);
                    var2 = MathHelper.floor(this.locY);
                    var3 = MathHelper.floor(this.locZ);
                    boolean var4 = false;

                    for (var5 = 0; !var4 && var5 <= 5 && var5 >= -5; var5 = var5 <= 0 ? 1 - var5 : 0 - var5)
                    {
                        for (int var6 = 0; !var4 && var6 <= 10 && var6 >= -10; var6 = var6 <= 0 ? 1 - var6 : 0 - var6)
                        {
                            for (int var7 = 0; !var4 && var7 <= 10 && var7 >= -10; var7 = var7 <= 0 ? 1 - var7 : 0 - var7)
                            {
                                int var8 = this.world.getTypeId(var1 + var6, var2 + var5, var3 + var7);

                                if (var8 == Block.MONSTER_EGGS.id && !CraftEventFactory.callEntityChangeBlockEvent(this, var1 + var6, var2 + var5, var3 + var7, 0, 0).isCancelled())
                                {
                                    if (!this.world.getGameRules().getBoolean("mobGriefing"))
                                    {
                                        int var9 = this.world.getData(var1 + var6, var2 + var5, var3 + var7);
                                        Block var10 = Block.STONE;

                                        if (var9 == 1)
                                        {
                                            var10 = Block.COBBLESTONE;
                                        }

                                        if (var9 == 2)
                                        {
                                            var10 = Block.SMOOTH_BRICK;
                                        }

                                        this.world.setTypeIdAndData(var1 + var6, var2 + var5, var3 + var7, var10.id, 0, 3);
                                    }
                                    else
                                    {
                                        this.world.setAir(var1 + var6, var2 + var5, var3 + var7, false);
                                    }

                                    Block.MONSTER_EGGS.postBreak(this.world, var1 + var6, var2 + var5, var3 + var7, 0);

                                    if (this.random.nextBoolean())
                                    {
                                        var4 = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (this.target == null && !this.hasPath())
            {
                var1 = MathHelper.floor(this.locX);
                var2 = MathHelper.floor(this.locY + 0.5D);
                var3 = MathHelper.floor(this.locZ);
                int var11 = this.random.nextInt(6);
                var5 = this.world.getTypeId(var1 + Facing.offsetsXForSide[var11], var2 + Facing.offsetsYForSide[var11], var3 + Facing.offsetsZForSide[var11]);

                if (BlockMonsterEggs.d(var5))
                {
                    if (CraftEventFactory.callEntityChangeBlockEvent(this, var1 + Facing.offsetsXForSide[var11], var2 + Facing.offsetsYForSide[var11], var3 + Facing.offsetsZForSide[var11], Block.MONSTER_EGGS.id, BlockMonsterEggs.e(var5)).isCancelled())
                    {
                        return;
                    }

                    this.world.setTypeIdAndData(var1 + Facing.offsetsXForSide[var11], var2 + Facing.offsetsYForSide[var11], var3 + Facing.offsetsZForSide[var11], Block.MONSTER_EGGS.id, BlockMonsterEggs.e(var5), 3);
                    this.spawnExplosionParticle();
                    this.die();
                }
                else
                {
                    this.updateWanderPath();
                }
            }
            else if (this.target != null && !this.hasPath())
            {
                this.target = null;
            }
        }
    }

    /**
     * Takes a coordinate in and returns a weight to determine how likely this creature will try to path to the block.
     * Args: x, y, z
     */
    public float getBlockPathWeight(int par1, int par2, int par3)
    {
        return this.world.getTypeId(par1, par2 - 1, par3) == Block.STONE.id ? 10.0F : super.getBlockPathWeight(par1, par2, par3);
    }

    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
    protected boolean isValidLightLevel()
    {
        return true;
    }

    public boolean canSpawn()
    {
        if (super.canSpawn())
        {
            EntityHuman entityhuman = this.world.findNearbyPlayer(this, 5.0D);
            return entityhuman == null;
        }
        else
        {
            return false;
        }
    }

    public EnumMonsterType getMonsterType()
    {
        return EnumMonsterType.ARTHROPOD;
    }
}
