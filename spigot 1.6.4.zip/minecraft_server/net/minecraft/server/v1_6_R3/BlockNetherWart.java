package net.minecraft.server.v1_6_R3;

import java.util.Random;
import org.bukkit.craftbukkit.v1_6_R3.event.CraftEventFactory;

public class BlockNetherWart extends BlockFlower
{
    protected BlockNetherWart(int i)
    {
        super(i);
        this.setTickRandomly(true);
        float f = 0.5F;
        this.setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
        this.a((CreativeModeTab)null);
    }

    /**
     * Gets passed in the blockID of the block below and supposed to return true if its allowed to grow on the type of
     * blockID passed in. Args: blockID
     */
    protected boolean canThisPlantGrowOnThisBlockID(int i)
    {
        return i == Block.SOUL_SAND.id;
    }

    /**
     * Can this block stay at this position.  Similar to canPlaceBlockAt except gets checked often with plants.
     */
    public boolean canBlockStay(World world, int i, int j, int k)
    {
        return this.canThisPlantGrowOnThisBlockID(world.getTypeId(i, j - 1, k));
    }

    /**
     * Ticks the block if it's been scheduled
     */
    public void updateTick(World world, int i, int j, int k, Random random)
    {
        int l = world.getData(i, j, k);

        if (l < 3 && random.nextInt(10) == 0)
        {
            ++l;
            CraftEventFactory.handleBlockGrowEvent(world, i, j, k, this.id, l);
        }

        super.updateTick(world, i, j, k, random);
    }

    /**
     * The type of render function that is called for this block
     */
    public int getRenderType()
    {
        return 6;
    }

    public void dropNaturally(World world, int i, int j, int k, int l, float f, int i1)
    {
        if (!world.isStatic)
        {
            int j1 = 1;

            if (l >= 3)
            {
                j1 = 2 + world.random.nextInt(3);

                if (i1 > 0)
                {
                    j1 += world.random.nextInt(i1 + 1);
                }
            }

            for (int k1 = 0; k1 < j1; ++k1)
            {
                this.dropBlockAsItem_do(world, i, j, k, new ItemStack(Item.NETHER_STALK));
            }
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return 0;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int quantityDropped(Random random)
    {
        return 0;
    }
}
