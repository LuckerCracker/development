package net.minecraft.server.v1_6_R3;

public class EnchantmentWaterWorker extends Enchantment
{
    public EnchantmentWaterWorker(int par1, int par2)
    {
        super(par1, par2, EnchantmentSlotType.ARMOR_HEAD);
        this.setName("waterWorker");
    }

    /**
     * Returns the minimal value of enchantability needed on the enchantment level passed.
     */
    public int getMinEnchantability(int par1)
    {
        return 1;
    }

    /**
     * Returns the maximum value of enchantability nedded on the enchantment level passed.
     */
    public int getMaxEnchantability(int par1)
    {
        return this.getMinEnchantability(par1) + 40;
    }

    public int getMaxLevel()
    {
        return 1;
    }
}
