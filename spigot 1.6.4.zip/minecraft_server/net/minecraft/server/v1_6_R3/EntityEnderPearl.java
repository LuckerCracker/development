package net.minecraft.server.v1_6_R3;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_6_R3.entity.CraftPlayer;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class EntityEnderPearl extends EntityProjectile {
	public EntityEnderPearl(World par1World) {
		super(par1World);
	}

	public EntityEnderPearl(World world, EntityLiving entityliving) {
		super(world, entityliving);
	}

	/**
	 * Called when this EntityThrowable hits a block or entity.
	 */
	protected void onImpact(MovingObjectPosition par1MovingObjectPosition) {
		if (par1MovingObjectPosition.entity != null) {
			par1MovingObjectPosition.entity.attackEntityFrom(DamageSource.projectile(this, this.getShooter()), 0.0F);
		}

		for (int var2 = 0; var2 < 32; ++var2) {
			this.world.addParticle("portal", this.locX, this.locY + this.random.nextDouble() * 2.0D, this.locZ,
					this.random.nextGaussian(), 0.0D, this.random.nextGaussian());
		}

		if (!this.world.isStatic) {
			if (this.getShooter() != null && this.getShooter() instanceof EntityPlayer) {
				EntityPlayer var7 = (EntityPlayer) this.getShooter();

				if (!var7.playerConnection.disconnected && var7.world == this.world) {
					CraftPlayer var3 = var7.getBukkitEntity();
					Location var4 = this.getBukkitEntity().getLocation();
					var4.setPitch(var3.getLocation().getPitch());
					var4.setYaw(var3.getLocation().getYaw());
					PlayerTeleportEvent var5 = new PlayerTeleportEvent(var3, var3.getLocation(), var4,
							PlayerTeleportEvent.TeleportCause.ENDER_PEARL);
					Bukkit.getPluginManager().callEvent(var5);

					if (!var5.isCancelled() && !var7.playerConnection.disconnected) {
						var7.playerConnection.teleport(var5.getTo());
						this.getShooter().fallDistance = 0.0F;
						EntityDamageByEntityEvent var6 = new EntityDamageByEntityEvent(this.getBukkitEntity(), var3,
								EntityDamageEvent.DamageCause.FALL, 5.0D);
						Bukkit.getPluginManager().callEvent(var6);

						if (!var6.isCancelled() && !var7.playerConnection.disconnected) {
							var7.invulnerableTicks = -1;
							var3.setLastDamageCause(var6);
							var7.attackEntityFrom(DamageSource.FALL, (float) var6.getDamage());
						}
					}
				}
			}

			this.die();
		}
	}
}
